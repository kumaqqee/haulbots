extends Node
## Procedurally generated sound effects (no external audio files).

const RATE := 22050

var streams := {}
var _active := 0
var _ambience: AudioStreamPlayer
var _chase: AudioStreamPlayer
var _tension := 0.0
var _noise_rng := RandomNumberGenerator.new()


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_noise_rng.seed = 424242
	_generate()


# ------------------------------------------------------------------ playback

func play(sname: String, pos = null, vol_db := 0.0, pitch := 1.0) -> void:
	if not streams.has(sname) or _active > 28:
		return
	var tree := get_tree()
	var parent: Node = tree.current_scene if tree.current_scene else self
	var p
	if pos == null:
		p = AudioStreamPlayer.new()
	else:
		p = AudioStreamPlayer3D.new()
		p.unit_size = 5.0
		p.max_distance = 45.0
		p.attenuation_model = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE
	p.stream = streams[sname]
	p.volume_db = vol_db
	p.pitch_scale = pitch
	parent.add_child(p)
	if pos != null:
		p.global_position = pos
	_active += 1
	p.finished.connect(_on_finished.bind(p))
	p.play()


func _on_finished(p: Node) -> void:
	_active -= 1
	p.queue_free()


func start_ambience() -> void:
	if _ambience == null:
		_ambience = AudioStreamPlayer.new()
		_ambience.stream = streams["ambience"]
		_ambience.volume_db = -10.0
		add_child(_ambience)
	if not _ambience.playing:
		_ambience.play()


func set_tension(v: float) -> void:
	_tension = v
	if _chase == null:
		_chase = AudioStreamPlayer.new()
		_chase.stream = streams["chase"]
		_chase.volume_db = -80.0
		add_child(_chase)
	if v > 0.01:
		if not _chase.playing:
			_chase.play()
		_chase.volume_db = linear_to_db(clampf(v, 0.0001, 1.0)) - 3.0
		_chase.pitch_scale = 0.9 + 0.2 * v
	elif _chase.playing:
		_chase.stop()


var _music: AudioStreamPlayer
var _music_lin := 0.7


func set_music_volume(v: float) -> void:
	_music_lin = v
	if _music:
		_music.volume_db = -8.0 + linear_to_db(maxf(v, 0.0001))


func music(on: bool) -> void:
	if _music == null:
		_music = AudioStreamPlayer.new()
		_music.stream = streams["music"]
		_music.volume_db = -8.0 + linear_to_db(maxf(_music_lin, 0.0001))
		add_child(_music)
	if on and not _music.playing:
		_music.play()
	elif not on and _music.playing:
		_music.stop()


func vibrate(ms: int) -> void:
	if OS.has_feature("mobile") and Settings.vibration:
		Input.vibrate_handheld(ms)


func stop_ambience() -> void:
	if _ambience:
		_ambience.stop()


# ------------------------------------------------------------------ synthesis

func _n() -> float:
	return _noise_rng.randf() * 2.0 - 1.0


func _wav(s: PackedFloat32Array, loop := false) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(s.size() * 2)
	for i in s.size():
		data.encode_s16(i * 2, int(clampf(s[i], -1.0, 1.0) * 30000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = s.size()
	return w


func _buf(dur: float) -> PackedFloat32Array:
	var s := PackedFloat32Array()
	s.resize(int(dur * RATE))
	return s


func _generate() -> void:
	streams["thud"] = _wav(_thud(0.28, 85.0, 18.0))
	streams["step"] = _wav(_thud(0.08, 140.0, 55.0, 0.5))
	streams["clink"] = _wav(_clink(0.4, [2100.0, 3170.0, 4630.0]))
	streams["break"] = _wav(_break())
	streams["beam"] = _wav(_beam(), true)
	streams["grab"] = _wav(_sweep(0.12, 300.0, 900.0, 0.35))
	streams["release"] = _wav(_sweep(0.12, 800.0, 250.0, 0.3))
	streams["jump"] = _wav(_sweep(0.1, 180.0, 380.0, 0.25))
	streams["extract"] = _wav(_arp([523.0, 659.0, 784.0, 1047.0], 0.13, 0.9))
	streams["cash"] = _wav(_arp([1318.0, 1760.0], 0.07, 0.35))
	streams["beep"] = _wav(_tone(0.12, 880.0, 0.4, true))
	streams["beep_hi"] = _wav(_tone(0.18, 1320.0, 0.4, true))
	streams["ui"] = _wav(_tone(0.05, 1000.0, 0.3, false))
	streams["hurt"] = _wav(_hurt())
	streams["death"] = _wav(_sweep(1.0, 420.0, 50.0, 0.5, true))
	streams["growl"] = _wav(_growl(1.3))
	streams["scream"] = _wav(_scream())
	streams["skitter"] = _wav(_skitter())
	streams["mdie"] = _wav(_sweep(0.9, 160.0, 40.0, 0.6, true))
	streams["swing"] = _wav(_whoosh())
	streams["ambience"] = _wav(_ambience_loop(), true)
	streams["chase"] = _wav(_chase_loop(), true)
	streams["music"] = _wav(_menu_music(), true)


func _thud(dur: float, f: float, decay: float, amp := 0.9) -> PackedFloat32Array:
	var s := _buf(dur)
	var lp := 0.0
	for i in s.size():
		var t := float(i) / RATE
		lp = lp * 0.85 + _n() * 0.15
		s[i] = (sin(TAU * f * t * (1.0 - t)) * 0.7 + lp * 1.8) * exp(-t * decay) * amp
	return s


func _clink(dur: float, freqs: Array) -> PackedFloat32Array:
	var s := _buf(dur)
	for i in s.size():
		var t := float(i) / RATE
		var v := 0.0
		for k in freqs.size():
			v += sin(TAU * freqs[k] * t) * exp(-t * (10.0 + k * 7.0)) * 0.28
		v += _n() * exp(-t * 80.0) * 0.35
		s[i] = v
	return s


func _break() -> PackedFloat32Array:
	var s := _buf(0.7)
	for i in s.size():
		var t := float(i) / RATE
		s[i] = _n() * exp(-t * 9.0) * 0.55
	var r := RandomNumberGenerator.new()
	r.seed = 99
	for c in 7:
		var off := int(r.randf_range(0.0, 0.35) * RATE)
		var f := r.randf_range(1800.0, 5200.0)
		for j in int(0.25 * RATE):
			if off + j >= s.size():
				break
			var t := float(j) / RATE
			s[off + j] += sin(TAU * f * t) * exp(-t * 18.0) * 0.22
	return s


func _beam() -> PackedFloat32Array:
	var s := _buf(1.0)
	for i in s.size():
		var t := float(i) / RATE
		s[i] = 0.16 * sin(TAU * 110.0 * t) + 0.1 * sin(TAU * 220.0 * t + 0.6 * sin(TAU * 3.0 * t)) + 0.05 * sin(TAU * 331.0 * t) + _n() * 0.015
	return s


func _sweep(dur: float, f0: float, f1: float, amp: float, saw := false) -> PackedFloat32Array:
	var s := _buf(dur)
	var ph := 0.0
	for i in s.size():
		var t := float(i) / RATE
		var k := t / dur
		var f := lerpf(f0, f1, k)
		ph += f / RATE
		var v := sin(TAU * ph)
		if saw:
			v = (fmod(ph, 1.0) * 2.0 - 1.0) * 0.6 + v * 0.4
		s[i] = v * amp * (1.0 - k) * minf(1.0, t * 200.0)
	return s


func _tone(dur: float, f: float, amp: float, square: bool) -> PackedFloat32Array:
	var s := _buf(dur)
	for i in s.size():
		var t := float(i) / RATE
		var v := sin(TAU * f * t)
		if square:
			v = signf(v) * 0.5 + v * 0.5
		s[i] = v * amp * minf(1.0, (dur - t) * 60.0) * minf(1.0, t * 400.0)
	return s


func _arp(notes: Array, step: float, amp: float) -> PackedFloat32Array:
	var s := _buf(step * notes.size() + 0.5)
	for n in notes.size():
		var off := int(n * step * RATE)
		for j in s.size() - off:
			var t := float(j) / RATE
			s[off + j] += (sin(TAU * notes[n] * t) + 0.3 * sin(TAU * notes[n] * 2.0 * t)) * exp(-t * 5.0) * amp * 0.3
	return s


func _hurt() -> PackedFloat32Array:
	var s := _buf(0.35)
	var ph := 0.0
	for i in s.size():
		var t := float(i) / RATE
		ph += (140.0 - t * 150.0) / RATE
		var v := (fmod(ph, 1.0) * 2.0 - 1.0) + _n() * 0.5
		s[i] = clampf(v * 2.5, -1.0, 1.0) * 0.4 * exp(-t * 7.0)
	return s


func _growl(dur: float) -> PackedFloat32Array:
	var s := _buf(dur)
	var lp := 0.0
	var lp2 := 0.0
	for i in s.size():
		var t := float(i) / RATE
		lp = lp * 0.96 + _n() * 0.04
		lp2 = lp2 * 0.9 + lp * 0.1
		var am := 0.6 + 0.4 * sin(TAU * 28.0 * t)
		var env := minf(1.0, t * 5.0) * minf(1.0, (dur - t) * 3.0)
		s[i] = (lp * 9.0 * am + sin(TAU * 52.0 * t) * 0.35 * am) * env * 0.8
	return s


func _scream() -> PackedFloat32Array:
	var dur := 1.4
	var s := _buf(dur)
	var ph := 0.0
	var ph2 := 0.0
	for i in s.size():
		var t := float(i) / RATE
		var f := 520.0 + 380.0 * t + 45.0 * sin(TAU * 7.0 * t)
		ph += f / RATE
		ph2 += f * 1.49 / RATE
		var v := (fmod(ph, 1.0) * 2.0 - 1.0) * 0.5 + (fmod(ph2, 1.0) * 2.0 - 1.0) * 0.3 + _n() * 0.25
		var env := minf(1.0, t * 8.0) * minf(1.0, (dur - t) * 2.5)
		s[i] = v * env * 0.45
	return s


func _skitter() -> PackedFloat32Array:
	var s := _buf(0.5)
	var r := RandomNumberGenerator.new()
	r.seed = 7
	var pos := 0
	while pos < s.size():
		var ln := int(0.006 * RATE)
		for j in ln:
			if pos + j < s.size():
				s[pos + j] += _n() * (1.0 - float(j) / ln) * 0.6
		pos += int(r.randf_range(0.02, 0.05) * RATE)
	return s


func _whoosh() -> PackedFloat32Array:
	var dur := 0.35
	var s := _buf(dur)
	var lp := 0.0
	for i in s.size():
		var t := float(i) / RATE
		var k := t / dur
		var a := 0.05 + 0.4 * sin(PI * k)
		lp = lp * (1.0 - a) + _n() * a
		s[i] = lp * sin(PI * k) * 0.9
	return s


func _chase_loop() -> PackedFloat32Array:
	# 110 bpm heartbeat + pulsing bass + dissonant high string
	var beat := 60.0 / 110.0
	var dur := beat * 8.0
	var s := _buf(dur)
	var ph := 0.0
	for i in s.size():
		var t := float(i) / RATE
		var bt := fmod(t, beat)
		var hb := sin(TAU * 55.0 * bt) * exp(-bt * 22.0)
		var bt2 := fmod(t + beat * 0.72, beat)
		hb += 0.7 * sin(TAU * 50.0 * bt2) * exp(-bt2 * 26.0)
		var bar := int(t / (beat * 2.0)) % 4
		var bf: float = [41.2, 41.2, 43.65, 38.9][bar]
		ph += bf / RATE
		var bass := (fmod(ph, 1.0) * 2.0 - 1.0) * 0.22 * (0.5 + 0.5 * sin(TAU * t / beat))
		var hi := sin(TAU * 740.0 * t + 2.0 * sin(TAU * 5.0 * t)) * 0.035 + sin(TAU * 784.0 * t) * 0.03
		s[i] = hb * 0.8 + bass + hi
	return s


func _menu_music() -> PackedFloat32Array:
	# slow eerie music-box style loop
	var notes := [220.0, 261.6, 329.6, 311.1, 261.6, 246.9, 220.0, 164.8, 196.0, 246.9, 293.7, 277.2, 246.9, 220.0, 207.7, 164.8]
	var step := 0.5
	var dur := step * notes.size()
	var s := _buf(dur)
	for n in notes.size():
		var off := int(n * step * RATE)
		var f: float = notes[n]
		for j in int(1.2 * RATE):
			var idx := (off + j) % s.size()
			var t := float(j) / RATE
			s[idx] += (sin(TAU * f * 2.0 * t) * 0.5 + sin(TAU * f * 4.0 * t) * 0.15) * exp(-t * 3.0) * 0.18
	for i in s.size():
		var t := float(i) / RATE
		s[i] += sin(TAU * 55.0 * t) * 0.05 + sin(TAU * 82.5 * t) * 0.03
	return s


func _ambience_loop() -> PackedFloat32Array:
	var dur := 8.0
	var fade := int(0.8 * RATE)
	var n := int(dur * RATE)
	var raw := PackedFloat32Array()
	raw.resize(n + fade)
	var lp := 0.0
	for i in raw.size():
		var t := float(i) / RATE
		lp = lp * 0.995 + _n() * 0.005
		raw[i] = sin(TAU * 41.0 * t) * 0.13 + sin(TAU * 55.0 * t) * 0.08 * (0.6 + 0.4 * sin(TAU * t / 8.0)) + lp * 6.0
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		s[i] = raw[i]
	for i in fade:
		var k := float(i) / fade
		s[i] = raw[i] * k + raw[n + i] * (1.0 - k)
	return s
