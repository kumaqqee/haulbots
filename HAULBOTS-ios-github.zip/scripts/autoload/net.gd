extends Node
## Networking (ENet LAN co-op), lobby, LAN discovery and run state.
## Solo play uses the same code path with an OfflineMultiplayerPeer.

const PORT := 7777
const DISC_PORT := 7778
const MAX_PLAYERS := 4
const GAME_ID := "haulbots-1.8"
const SAVE_PATH := "user://save.json"
const COLORS := [Color(1.0, 0.55, 0.1), Color(0.2, 0.75, 1.0), Color(0.45, 1.0, 0.3), Color(1.0, 0.35, 0.65)]
const UPGRADE_KEYS := ["hp", "stamina", "strength", "range", "speed", "jump", "tumble", "crouch"]
const UPGRADE_PRICE := {"hp": 8000, "stamina": 6000, "strength": 10000, "range": 6000, "speed": 9000, "heal": 4000}
const MAX_UPGRADE := 10

signal players_changed
signal connected_ok
signal connect_failed
signal session_ended(reason: String)
signal hosts_changed
signal run_changed

var players := {}
var online := false
var solo := true
var in_game := false
var difficulty := 1

# run state (host is authoritative, replicated to clients)
var level := 1
var money := 0
var total_earned := 0
var upgrades := {}
var hp := {}
var last_stats := {}
var inv := {}
var energy := 1.0
var truck_items := []
## Everything the crew ever bought and has not used up yet: [{"u": uid, "t": type, "b": battery}].
## Like the reference game, bought items appear in the van at the start of every level
## (durable gear even if it broke); consumables leave the list once used.
var owned := []
var next_uid := 1
var bought := {}

var found_hosts := {}
var _bc: PacketPeerUDP = null
var _listen: PacketPeerUDP = null
var _bc_t := 0.0
var _kick_reason := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_conn_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)


func _main() -> Node:
	return get_tree().root.get_node_or_null("Main")


func _world() -> Node:
	var m := _main()
	return m.get_node_or_null("World") if m else null


func my_id() -> int:
	return multiplayer.get_unique_id()


func is_host() -> bool:
	return multiplayer.is_server()


func sender() -> int:
	var s := multiplayer.get_remote_sender_id()
	return s if s != 0 else multiplayer.get_unique_id()


# ------------------------------------------------------------------ stats

func up(id: int, k: String) -> int:
	return int(upgrades.get(id, {}).get(k, 0))


func max_hp(id: int) -> float:
	return 100.0 + 20.0 * up(id, "hp")


func max_stamina(id: int) -> float:
	return 40.0 + 10.0 * up(id, "stamina")


func extra_jumps(id: int) -> int:
	return up(id, "jump")


func tumble_power(id: int) -> float:
	return 1.0 + 0.25 * up(id, "tumble")


func crouch_regen(id: int) -> float:
	return 1.0 + 0.6 * up(id, "crouch")


func inv_of(id: int) -> Array:
	var a = inv.get(id, null)
	if not (a is Array) or a.size() != 3:
		a = [null, null, null]
		inv[id] = a
	return a


func strength(id: int) -> float:
	return 190.0 + 85.0 * up(id, "strength")


func grab_range(id: int) -> float:
	return 4.0 + 1.0 * up(id, "range")


func speed_mult(id: int) -> float:
	return 1.0 + 0.08 * up(id, "speed")


func price(id: int, k: String) -> int:
	var base: float = UPGRADE_PRICE[k]
	var own := 0 if k == "heal" else up(id, k)
	var v := base * (1.0 + 0.12 * (level - 1)) * (1.0 + 0.3 * own)
	return int(round(v / 100.0)) * 100


func _init_player_run(id: int) -> void:
	upgrades[id] = {"hp": 0, "stamina": 0, "strength": 0, "range": 0, "speed": 0, "jump": 0, "tumble": 0, "crouch": 0}
	hp[id] = max_hp(id)
	inv[id] = [null, null, null]


func _new_run() -> void:
	level = 1
	money = 0
	total_earned = 0
	energy = 1.0
	inv = {}
	truck_items = []
	owned = []
	next_uid = 1
	bought = {}
	upgrades = {}
	hp = {}
	last_stats = {}
	for id in players:
		_init_player_run(id)


# ------------------------------------------------------------------ solo

func start_solo(cont: bool) -> void:
	leave()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	solo = true
	online = false
	players = {1: {"name": Settings.player_name, "color": 0}}
	if cont and has_save():
		_load_save()
		last_stats = {}
		run_changed.emit()
		begin_shop({})
	else:
		delete_save()
		_new_run()
		difficulty = Settings.difficulty
		begin_level()


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func save_level() -> int:
	if not has_save():
		return 1
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return 1
	var d = JSON.parse_string(f.get_as_text())
	return int(d.get("level", 1)) if d is Dictionary else 1


func save_run() -> void:
	if not solo:
		return
	var d := {"diff": difficulty, "level": level, "money": money, "earned": total_earned, "up": upgrades.get(1, {}), "hp": hp.get(1, 100.0), "inv": inv_of(1), "energy": energy, "truck": truck_items, "owned": owned, "uid": next_uid, "bought": bought}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))


func _load_save() -> void:
	_new_run()
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	if not (d is Dictionary):
		return
	level = int(d.get("level", 1))
	difficulty = int(d.get("diff", 1))
	money = int(d.get("money", 0))
	total_earned = int(d.get("earned", 0))
	var u = d.get("up", {})
	for k in UPGRADE_KEYS:
		upgrades[1][k] = int(u.get(k, 0)) if u is Dictionary else 0
	hp[1] = clampf(float(d.get("hp", 100.0)), 1.0, max_hp(1))
	var si = d.get("inv", [null, null, null])
	if si is Array and si.size() == 3:
		inv[1] = si
	energy = float(d.get("energy", 1.0))
	var ti = d.get("truck", [])
	truck_items = ti if ti is Array else []
	var ow = d.get("owned", [])
	owned = ow if ow is Array else []
	next_uid = int(d.get("uid", 1))
	var bo = d.get("bought", {})
	bought = bo if bo is Dictionary else {}
	for e in owned:
		next_uid = maxi(next_uid, int(e.get("u", 0)) + 1)


func delete_save() -> void:
	if has_save():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))


# ------------------------------------------------------------------ online

func host_game() -> bool:
	leave()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_PLAYERS - 1)
	if err != OK:
		return false
	multiplayer.multiplayer_peer = peer
	online = true
	solo = false
	in_game = false
	players = {1: {"name": Settings.player_name, "color": 0}}
	_new_run()
	_start_broadcast()
	players_changed.emit()
	return true


func join_game(ip: String) -> void:
	leave()
	_kick_reason = ""
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip.strip_edges(), PORT)
	if err != OK:
		connect_failed.emit()
		return
	multiplayer.multiplayer_peer = peer
	online = true
	solo = false


func leave() -> void:
	_stop_broadcast()
	stop_listen()
	var p := multiplayer.multiplayer_peer
	if p and not (p is OfflineMultiplayerPeer):
		p.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	online = false
	in_game = false
	players = {}


func _on_connected() -> void:
	rpc_id(1, "_register", Settings.player_name, GAME_ID)
	connected_ok.emit()


func _on_conn_failed() -> void:
	leave()
	connect_failed.emit()


func _on_server_disconnected() -> void:
	var r := _kick_reason if _kick_reason != "" else "host_left"
	leave()
	session_ended.emit(r)


func _on_peer_connected(_id: int) -> void:
	pass


func _on_peer_disconnected(id: int) -> void:
	if not is_host():
		return
	if players.has(id):
		var pname: String = players[id]["name"]
		players.erase(id)
		var w := _world()
		if w:
			w.server_peer_left(id, pname)
		_sync_all()


@rpc("any_peer", "reliable")
func _register(pname: String, gid: String) -> void:
	if not is_host():
		return
	var id := multiplayer.get_remote_sender_id()
	var reason := ""
	if gid != GAME_ID:
		reason = "kicked_version"
	elif in_game:
		reason = "kicked_in_game"
	elif players.size() >= MAX_PLAYERS:
		reason = "kicked_full"
	if reason != "":
		rpc_id(id, "_kicked", reason)
		get_tree().create_timer(0.5).timeout.connect(_kick_peer.bind(id))
		return
	var used := []
	for p in players.values():
		used.append(p["color"])
	var c := 0
	while c in used:
		c += 1
	players[id] = {"name": pname.substr(0, 16), "color": c}
	_init_player_run(id)
	_sync_all()


func _kick_peer(id: int) -> void:
	var p := multiplayer.multiplayer_peer
	if p is ENetMultiplayerPeer:
		p.disconnect_peer(id)


func _sync_all() -> void:
	rpc("_sync_players", players)
	players_changed.emit()
	send_run()


@rpc("authority", "reliable")
func _sync_players(p: Dictionary) -> void:
	players = p
	players_changed.emit()


@rpc("authority", "reliable")
func _kicked(reason: String) -> void:
	_kick_reason = reason


# ------------------------------------------------------------------ run flow

func send_run() -> void:
	if not is_host():
		return
	if online:
		rpc("_recv_run", level, money, total_earned, upgrades, hp, inv, energy)
	run_changed.emit()


@rpc("authority", "reliable")
func _recv_run(l: int, m: int, te: int, u: Dictionary, h: Dictionary, iv: Dictionary, en: float) -> void:
	inv = iv
	energy = en
	level = l
	money = m
	total_earned = te
	upgrades = u
	hp = h
	run_changed.emit()


func start_run() -> void:
	if not is_host():
		return
	_new_run()
	difficulty = Settings.difficulty
	begin_level()


func begin_level() -> void:
	if not is_host():
		return
	in_game = true
	for id in players:
		if not upgrades.has(id):
			_init_player_run(id)
		if float(hp.get(id, 0.0)) <= 0.0:
			hp[id] = 1.0   # not revived during the level: back with 1 HP, buy a health pack
	send_run()
	rpc("_load_level", randi(), level, difficulty)


@rpc("authority", "call_local", "reliable")
func _load_level(s: int, l: int, diff: int) -> void:
	level = l
	difficulty = diff
	in_game = true
	stop_listen()
	_main().start_world(s, l)


func _update_records(lvl: int) -> bool:
	var rec := false
	if lvl > Settings.best_level:
		Settings.best_level = lvl
		rec = true
	if total_earned > Settings.best_earned:
		Settings.best_earned = total_earned
		rec = true
	Settings.save_cfg()
	return rec


func add_owned(t: String, b := 1.0) -> int:
	var u := next_uid
	next_uid += 1
	owned.append({"u": u, "t": t, "b": b})
	return u


func consume_owned(u: int) -> void:
	if u <= 0:
		return
	for i in range(owned.size() - 1, -1, -1):
		if int(owned[i]["u"]) == u:
			owned.remove_at(i)


func set_owned_battery(u: int, b: float) -> void:
	for e in owned:
		if int(e["u"]) == u:
			e["b"] = b


func inv_uids() -> Dictionary:
	var out := {}
	for pid in inv:
		for e in inv[pid]:
			if e != null and int(e.get("u", 0)) > 0:
				out[int(e["u"])] = true
	return out


static func is_consumable(t: String) -> bool:
	return t.begins_with("up_") or t.begins_with("med_") or t.begins_with("g_") or t.begins_with("m_") or t == "i_crystal"


func server_level_complete(extracted: int, quota: int, extra := {}) -> void:
	if level == 1:
		add_owned("i_crystal", 1.0)   # free energy crystal after the first level, like the reference game
	money += extracted
	total_earned += extracted
	var stats := {"level": level, "extracted": extracted, "quota": quota}
	stats.merge(extra)
	level += 1
	in_game = false
	send_run()
	stats["earned"] = total_earned
	save_run()
	begin_shop(stats)


func begin_shop(stats: Dictionary) -> void:
	if not is_host():
		return
	in_game = true
	for id in players:
		if float(hp.get(id, 0.0)) <= 0.0:
			hp[id] = maxf(1.0, max_hp(id) * 0.25)
	send_run()
	rpc("_load_shop", randi(), level, stats)


@rpc("authority", "call_local", "reliable")
func _load_shop(s: int, l: int, stats: Dictionary) -> void:
	last_stats = stats
	level = l
	in_game = true
	if stats.has("earned"):
		total_earned = int(stats["earned"])
		_update_records(int(stats.get("level", 1)))
	_main().start_world(s, l, true)


@rpc("authority", "call_local", "reliable")
func _goto_shop(stats: Dictionary) -> void:
	last_stats = stats
	total_earned = int(stats.get("earned", total_earned))
	_update_records(int(stats.get("level", 1)))
	in_game = false
	_main().show_shop()


func request_buy(k: String) -> void:
	rpc_id(1, "_req_buy", k)


@rpc("any_peer", "call_local", "reliable")
func _req_buy(k: String) -> void:
	if not is_host() or in_game:
		return
	var id := sender()
	if not players.has(id) or not UPGRADE_PRICE.has(k):
		return
	var p := price(id, k)
	if money < p:
		return
	if k == "heal":
		if float(hp.get(id, 0.0)) >= max_hp(id) - 0.5:
			return
		hp[id] = minf(max_hp(id), float(hp.get(id, 0.0)) + max_hp(id) * 0.5)
	else:
		if up(id, k) >= MAX_UPGRADE:
			return
		var old_max := max_hp(id)
		upgrades[id][k] = up(id, k) + 1
		if k == "hp":
			hp[id] = float(hp.get(id, 0.0)) + (max_hp(id) - old_max)
	money -= p
	send_run()
	save_run()


## Everyone died online: the Taxman sends the crew to the disposal arena first.
func begin_arena() -> void:
	if not is_host():
		return
	for id in players:
		hp[id] = max_hp(id)
	send_run()
	rpc("_load_arena", randi(), level)


@rpc("authority", "call_local", "reliable")
func _load_arena(s: int, l: int) -> void:
	in_game = true
	_main().start_world(s, l, false, true)


func server_game_over() -> void:
	in_game = false
	rpc("_game_over", {"level": level, "earned": total_earned})


@rpc("authority", "call_local", "reliable")
func _game_over(stats: Dictionary) -> void:
	in_game = false
	total_earned = int(stats.get("earned", total_earned))
	stats["record"] = _update_records(maxi(0, int(stats.get("level", 1)) - 1))
	last_stats = stats
	if solo:
		delete_save()
	_main().show_gameover(stats)


func back_to_lobby() -> void:
	if not is_host():
		return
	_new_run()
	send_run()
	rpc("_to_lobby")


@rpc("authority", "call_local", "reliable")
func _to_lobby() -> void:
	in_game = false
	_main().show_lobby()


# ------------------------------------------------------------------ LAN discovery

func _start_broadcast() -> void:
	_bc = PacketPeerUDP.new()
	_bc.set_broadcast_enabled(true)
	_bc.set_dest_address("255.255.255.255", DISC_PORT)
	_bc_t = 0.0


func _stop_broadcast() -> void:
	if _bc:
		_bc.close()
	_bc = null


func start_listen() -> void:
	stop_listen()
	found_hosts.clear()
	_listen = PacketPeerUDP.new()
	if _listen.bind(DISC_PORT) != OK:
		_listen = null


func stop_listen() -> void:
	if _listen:
		_listen.close()
	_listen = null


func local_ips() -> Array:
	var out := []
	for a in IP.get_local_addresses():
		if a.begins_with("192.168.") or a.begins_with("10.") or a.begins_with("172."):
			out.append(a)
	return out


func _process(delta: float) -> void:
	if _bc and not in_game:
		_bc_t -= delta
		if _bc_t <= 0.0:
			_bc_t = 1.0
			var msg := JSON.stringify({"g": GAME_ID, "n": Settings.player_name, "c": players.size()})
			_bc.put_packet(msg.to_utf8_buffer())
	if _listen:
		var changed := false
		while _listen.get_available_packet_count() > 0:
			var pkt := _listen.get_packet()
			var ip := _listen.get_packet_ip()
			var d = JSON.parse_string(pkt.get_string_from_utf8())
			if d is Dictionary and d.get("g", "") == GAME_ID:
				if not found_hosts.has(ip):
					changed = true
				found_hosts[ip] = {"name": str(d.get("n", "?")), "count": int(d.get("c", 1)), "t": Time.get_ticks_msec()}
		var now := Time.get_ticks_msec()
		for ip in found_hosts.keys():
			if now - int(found_hosts[ip]["t"]) > 4000:
				found_hosts.erase(ip)
				changed = true
		if changed:
			hosts_changed.emit()
