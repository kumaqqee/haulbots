extends Node
## Global settings, input map and translations.

const PATH := "user://settings.cfg"
const VERSION := "1.8.1"

var sensitivity := 1.0
var volume := 0.8
var lang := "en"
var player_name := ""
var quality := 2
var invert_y := false
var fov := 75.0
var last_ip := "192.168.1."
var force_touch := false
var difficulty := 1
var voice := false
var best_level := 0
var best_earned := 0
var tutorial_done := false
var vibration := true
var btn_scale := 1.0
var btn_alpha := 0.75
var show_detect := true
var show_fps := false
var music_vol := 0.7
var film_fx := true
var fps_cap := 60
var crown_name := ""
var brightness := 1.0
var adaptive_res := true
var auto_q_done := false

signal changed

const STR := {
	"ru": {
		"basket": "КОРЗИНА",
		"cash": "КАССА",
		"shop_welcome": "Мастерская: несите товары на платформу и жмите кнопку — покупки будут ждать в фургоне на следующем уровне. Потом — все в фургон.",
		"msg_basket_empty": "В зоне покупки пусто",
		"msg_no_money": "Не хватает денег в кассе",
		"msg_bought": "Куплено на $%s!",
		"msg_used": "%s применил: %s",
		"obj_shop": "Мастерская · Касса $%s",
		"press_buy": "ИСП. — оплатить товары в зоне",
		"press_use_item": "ИСП. — применить",
		"owned_tag": "КУПЛЕНО",
		"item_med_s": "Аптечка малая",
		"item_med_m": "Аптечка",
		"item_med_l": "Аптечка большая",
		"btn_crouch": "ПРИСЕД",
		"btn_map": "КАРТА",
		"btn_mic": "МИК",
		"btn_ping": "МЕТКА",
		"item_chest": "Сундук",
		"item_crown": "Корона",
		"item_mask": "Маска",
		"item_beaker": "Колба",
		"item_microscope": "Микроскоп",
		"item_powercell": "Энергоячейка",
		"item_server": "Сервер",
		"tut_move": "Левый джойстик — ходьба, свайп справа — обзор.",
		"tut_grab": "Наведите прицел на ценность и нажмите ЛУЧ.",
		"tut_carry": "Несите её к зелёной точке сдачи — путь показывает стрелка вверху. ▲▼ меняют дистанцию.",
		"tut_button": "Соберите квоту в зоне и нажмите ИСП. у тумбы с кнопкой.",
		"tut_hide": "Слышите шаги? ПРИСЕД делает вас тише — а под столом или кроватью монстр вас почти не увидит. МЕТКА отмечает место для друзей.",
		"difficulty": "Сложность",
		"diff_0": "Лёгкая",
		"diff_1": "Нормальная",
		"diff_2": "Хардкор",
		"record": "Рекорд: уровень %d · $%s",
		"loc_0": "Особняк",
		"loc_1": "Музей",
		"loc_2": "Лаборатория",
		"msg_location": "Локация: %s",
		"vibration": "Вибрация",
		"new_record": "НОВЫЙ РЕКОРД!",
		"mic_hint": "MIC — голосовой чат с напарниками рядом",
		"tagline": "Тащи. Не разбей. Выживи.",
		"name": "Имя",
		"continue": "Продолжить (уровень %d)",
		"new_game": "Новая игра (соло)",
		"host": "Создать игру по Wi‑Fi",
		"join": "Подключиться по Wi‑Fi",
		"settings": "Настройки",
		"how_to_play": "Как играть",
		"quit": "Выход",
		"back": "Назад",
		"close": "Закрыть",
		"searching": "Поиск игр в вашей сети Wi‑Fi...",
		"no_games": "Игры пока не найдены. Убедитесь, что вы в одной сети Wi‑Fi, или введите IP хоста вручную.",
		"ip_hint": "IP хоста, например 192.168.1.5",
		"connect": "Подключиться",
		"connecting": "Подключение...",
		"cancel": "Отмена",
		"conn_failed": "Не удалось подключиться",
		"host_left": "Хост завершил игру",
		"kicked_full": "Лобби заполнено",
		"kicked_in_game": "Игра уже идёт — дождитесь конца забега",
		"kicked_version": "У хоста другая версия игры",
		"host_failed": "Не удалось создать сервер (порт занят?)",
		"lobby": "Лобби",
		"your_ip": "Друзья подключаются к IP: %s",
		"players_n": "Игроки (%d/4)",
		"start": "Начать забег",
		"waiting_host": "Ожидание хоста...",
		"leave": "Выйти",
		"shop": "Мастерская",
		"level_done": "Уровень %d пройден! Сдано: $%s (квота $%s)",
		"team_money": "Касса команды: $%s",
		"next_level": "Следующий уровень ▶",
		"buy": "Купить",
		"maxed": "МАКС",
		"lvl_short": "ур. %d",
		"up_hp": "Бронекорпус",
		"up_hp_d": "+20 к максимальному здоровью",
		"up_stamina": "Батарея",
		"up_stamina_d": "+10 к выносливости",
		"up_strength": "Сервоприводы",
		"up_strength_d": "Луч держит более тяжёлые вещи",
		"up_range": "Фокусировщик",
		"up_range_d": "+1 м к дальности луча",
		"up_speed": "Моторы",
		"up_speed_d": "+8% к скорости движения",
		"heal": "Ремкомплект",
		"heal_d": "Восстановить 50% здоровья",
		"hp_now": "Здоровье: %d / %d",
		"next_quota": "Следующий уровень: %d",
		"game_over": "ИГРА ОКОНЧЕНА",
		"go_levels": "Пройдено уровней: %d",
		"go_earned": "Всего заработано: $%s",
		"to_menu": "В меню",
		"to_lobby": "В лобби",
		"sensitivity": "Чувствительность",
		"volume": "Громкость",
		"quality": "Графика",
		"q_low": "Низкая",
		"q_med": "Средняя",
		"q_high": "Высокая",
		"fov": "Поле зрения",
		"invert_y": "Инверсия по вертикали",
		"language": "Язык",
		"pause": "Пауза",
		"resume": "Продолжить",
		"leave_game": "Выйти в меню",
		"hud_level": "Уровень %d",
		"hud_cash": "Касса $%s",
		"level_haul": "Сдано за уровень: $%s",
		"obj_extract": "Точка %d/%d: $%s / $%s",
		"obj_ready": "Квота точки набрана — нажмите кнопку!",
		"obj_truck": "Все точки сданы — все в фургон!",
		"obj_extracting": "Отправка ценностей...",
		"obj_wait": "Подготовка...",
		"press_extract": "ИСП. — отправить ценности",
		"press_truck": "ИСП. — уехать с уровня",
		"btn_grab": "ЛУЧ",
		"btn_drop": "ОТПУСТ.",
		"btn_jump": "ПРЫЖОК",
		"btn_use": "ИСП.",
		"btn_throw": "БРОСОК",
		"btn_run": "БЕГ",
		"msg_level": "Уровень %d. Найдите ценности и донесите их до точки сдачи!",
		"msg_tip1": "Берите вещи лучом. Удары снижают их стоимость!",
		"msg_need_more": "Не хватает ценностей до квоты этой точки",
		"msg_extract_fail": "Отправка сорвана — ценности убрали из зоны",
		"msg_next_point": "Точка закрыта! Активирована следующая",
		"msg_all_done": "Квота выполнена! Возвращайтесь в фургон",
		"msg_quota_first": "Сначала закройте все точки сдачи",
		"msg_everyone_truck": "Все живые роботы должны быть в фургоне",
		"msg_player_down": "%s уничтожен! Отнесите его голову в фургон",
		"msg_revived": "%s отремонтирован!",
		"msg_monsters_awake": "В доме что-то проснулось...",
		"msg_player_left": "%s отключился",
		"dead_title": "ВЫ УНИЧТОЖЕНЫ",
		"dead_hint": "Напарники могут отнести вашу голову в фургон.\nКоснитесь экрана, чтобы сменить камеру.",
		"extr_done": "СДАНО",
		"extr_idle": "НЕАКТИВНА",
		"extr_press": "НАЖМИ КНОПКУ",
		"extr_sending": "ОТПРАВКА %d",
		"truck_label": "ФУРГОН",
		"truck_ready": "ВСЕ СЮДА → КНОПКА",
		"truck_wait": "СНАЧАЛА КВОТА",
		"item_goblet": "Кубок",
		"item_moneybag": "Мешок с излишком",
		"loading": "ЗАГРУЗКА",
		"tip_0": "Совет: хватайте тележку за ручку — так она едет перед вами.",
		"tip_1": "Совет: на платформе сдачи и в тележке вещи не бьются.",
		"tip_2": "Совет: присядьте под стол или кровать — монстры заметят вас только вплотную.",
		"tip_3": "Совет: держите товарища лучом, чтобы передать ему здоровье.",
		"tip_4": "Совет: перебор на точке сдачи вернётся мешком для следующей точки.",
		"tip_5": "Совет: фонарик помогает видеть, но и выдаёт вас.",
		"tip_6": "Совет: купленное в магазине ждёт в фургоне на следующем уровне.",
		"tip_7": "Совет: кнопка с глазами меняет эмоции вашего робота.",
		"tip_8": "Совет: тяжёлую вещь поднимают вдвоём — лучи складываются.",
		"tip_9": "Совет: после последней точки у вас 10 секунд, чтобы забраться в фургон.",
		"arena_title": "Арена утилизации",
		"msg_arena_out": "%s выбывает!",
		"arena_sub": "Выживет только один",
		"arena_obj": "Арена: осталось роботов — %d",
		"arena_win": "Король неудачников",
		"arena_draw": "Никто не выжил",
		"msg_arena_next": "Все сломаны... Налоговик отправляет вас на арену!",
		"expr_angry": "Злость",
		"expr_sad": "Грусть",
		"expr_sus": "Подозрение",
		"expr_closed": "Глаза закрыты",
		"expr_crazy": "Безумие",
		"expr_happy": "Радость",
		"expr_hint": "Эмоции робота видят напарники. Можно включать несколько сразу.",
		"broken_tag": "РАЗБИТО  −$%s",
		"sum_title": "Уровень %d пройден",
		"sum_haul": "Сдано",
		"sum_quota": "Квота",
		"sum_broken": "Разбито вещей",
		"sum_kills": "Монстров убито",
		"sum_deaths": "Поломок роботов",
		"sum_cash": "В кассе",
		"sum_tap": "нажмите, чтобы закрыть",
		"moon_1": "Растущая луна",
		"moon_2": "Полулуние",
		"moon_3": "Полнолуние",
		"moon_4": "Суперлуние",
		"msg_truck_leaving": "Фургон уезжает через 10 секунд! Кто не внутри — взорвётся!",
		"truck_leave": "УЕЗЖАЕМ\n%d",
		"msg_bought_truck": "Куплено на $%s — покупки будут ждать в фургоне на следующем уровне",
		"msg_surplus_last": "Излишек $%s вернулся мешком — отнесите его в фургон, он зачтётся при отъезде!",
		"msg_surplus": "Излишек $%s вернулся мешком — отнесите его к следующей точке!",
		"item_jewelbox": "Шкатулка",
		"item_crystal": "Хрустальный шар",
		"item_vase": "Ваза",
		"item_clock": "Часы",
		"item_painting": "Картина",
		"item_lamp": "Лампа",
		"item_radio": "Радиола",
		"item_gramophone": "Граммофон",
		"item_statue": "Статуя",
		"item_grandclock": "Напольные часы",
		"item_orb": "Ядро монстра",
		"item_head": "Голова робота",
		"item_cart": "Тележка",
		"tab_game": "Игра",
		"tab_controls": "Управление",
		"tab_video": "Графика",
		"tab_audio": "Звук",
		"btn_scale": "Размер кнопок",
		"btn_alpha": "Прозрачность кнопок",
		"show_detect": "Индикатор обнаружения",
		"show_fps": "Показывать FPS",
		"film_fx": "Эффект камеры (зерно, виньетка)",
		"fps_cap": "Частота кадров",
		"brightness": "Яркость",
		"cart_strong": "Хват за ручку: тележка едет перед вами",
		"cart_weak": "Слабый хват — возьмитесь за ручку",
		"cart_hint": "Возьмите лучом за ручку, чтобы катить",
		"adaptive_res": "Адаптивное разрешение",
		"adaptive_hint": "Если кадров не хватает, игра чуть снижает внутреннее разрешение вместо рывков, а когда запас есть — возвращает полное.",
		"hd_pack": "HD-пакет текстур",
		"hd_on": "HD включён (%s)",
		"hd_off": "Не установлен — базовое качество",
		"hd_install": "Установить из «Загрузок»",
		"hd_remove": "Удалить HD",
		"hd_restart": "Перезапустить игру",
		"hd_hint": "Скачайте файлы HAULBOTS-HD-1.6-*.pck в папку «Загрузки» (Download) телефона и нажмите «Установить». Игра попросит доступ к файлам — он нужен только чтобы скопировать пакет.",
		"hd_need_perm": "Разрешите доступ ко всем файлам для HAULBOTS и вернитесь в игру…",
		"hd_not_found": "Файлы HAULBOTS-HD-1.6-*.pck не найдены в «Загрузках»",
		"hd_bad": "Файл повреждён или это не пакет HAULBOTS",
		"hd_done": "Установлено частей: %d. Перезапустите игру",
		"hd_removed": "HD удалён. Перезапустите игру",
		"hd_pending": "Нужен перезапуск, чтобы применить",
		"hd_hint_ios": "Скопируйте файлы HAULBOTS-HD-1.6-*.pck через приложение «Файлы» в папку «На iPhone → HAULBOTS» и нажмите «Установить».",
		"hd_install_ios": "Установить из «Файлов»",
		"hd_not_found_ios": "Файлы HAULBOTS-HD-1.6-*.pck не найдены в «Файлы → На iPhone → HAULBOTS»",
		"hd_restart_ios": "Закрыть игру",
		"hd_done_ios": "Установлено частей: %d. Закройте игру и откройте снова",
		"hd_removed_ios": "HD удалён. Закройте игру и откройте снова",
		"hd_pending_ios": "Закройте игру и откройте снова, чтобы применить",
		"music_vol": "Музыка",
		"reset_tutorial": "Пройти обучение заново",
		"tutorial_reset_done": "Обучение будет показано на 1-м уровне",
		"detect_hint": "Глаз над прицелом показывает, что монстр вас замечает",
		"hud_hp": "Здоровье",
		"hud_stamina": "Энергия",
		"hidden_tag": "СПРЯТАН",
		"btn_slot": "Слот",
		"energy": "Энергия",
		"msg_pay_first": "Сначала оплатите товар в зоне покупки",
		"msg_drone_no_target": "Дрону не к чему прикрепиться",
		"msg_crystal": "Кристалл вставлен: +3 заряда станции",
		"msg_cant_store": "Это нельзя положить в слот",
		"msg_no_energy": "Станции нужна энергия — купите кристалл",
		"msg_truck_heal": "Фургон подлатал роботов: +%s здоровья",
		"btn_tumble": "КУВЫРОК",
		"item_w_bat": "Бита",
		"item_w_sledge": "Кувалда",
		"item_w_pan": "Сковорода",
		"item_w_prod": "Электрошокер",
		"item_w_pistol": "Пистолет",
		"item_w_shotgun": "Дробовик",
		"item_w_tranq": "Транквилизатор",
		"item_g_explosive": "Граната",
		"item_g_stun": "Оглушающая граната",
		"item_g_shock": "Шоковая граната",
		"item_m_explosive": "Мина",
		"item_m_stun": "Оглушающая мина",
		"item_d_feather": "Дрон-перо",
		"item_d_shield": "Дрон-щит",
		"item_t_valuable": "Искатель ценностей",
		"item_t_extract": "Искатель точки сдачи",
		"item_i_crystal": "Энергокристалл",
		"item_i_pocketcart": "Карманная тележка",
		"mon_gremlin": "Гремлин",
		"mon_bomber": "Бомбочка",
		"mon_eye": "Око",
		"mon_tick": "Клещ",
		"mon_spewer": "Рыгун",
		"mon_rugrat": "Хулиган",
		"mon_skitter": "Зверёк",
		"mon_puff": "Пушок",
		"mon_howler": "Ревун",
		"mon_levitator": "Левитатор",
		"mon_butcher": "Мясник",
		"mon_lurker": "Жнец",
		"mon_hidden": "Невидимка",
		"mon_mimic": "Мимик",
		"mon_bighead": "Башка",
		"mon_projector": "Прожектор",
		"mon_hunter": "Слепой охотник",
		"mon_brute": "Громила",
		"mon_watcher": "Манекен",
		"up_jump": "Пружины",
		"up_jump_d": "+1 дополнительный прыжок в воздухе",
		"up_tumble": "Катапульта",
		"up_tumble_d": "Кувырок-рывок летит дальше и бьёт сильнее",
		"up_crouch": "Режим покоя",
		"up_crouch_d": "Сидя или в кувырке выносливость восстанавливается быстрее",
		"battery": "Заряд",
		"slot_empty": "пусто",
		"to_charge": "Положите в фургон на станцию для зарядки",
		"trk_dist": "%d м",
		"too_heavy": "Слишком тяжело!",
		"help_title": "Как играть",
		"help_text": "[b]Цель[/b]\nВы — робот-грузчик. На каждом уровне найдите в особняке ценности и отнесите их в активную [color=#6f6]точку сдачи[/color]. Когда сумма в зоне достигнет квоты — нажмите кнопку на тумбе. Закройте все точки и вернитесь в [color=#fc3]фургон[/color].\n\n[b]Ценности хрупкие[/b]\nКаждый удар об стену или пол снижает стоимость. Разбитая вещь исчезает. Хрусталь и вазы — самые хрупкие.\n\n[b]Луч-захват[/b]\nНаведите прицел и нажмите ЛУЧ. Кнопки ▲▼ меняют дистанцию, БРОСОК — швыряет предмет. Тяжёлые вещи требуют улучшений или помощи друзей: лучи складываются!\n\n[b]Монстры[/b]\nВ доме живут твари. Они слышат грохот и видят вас. Бегите, прячьтесь — или швырните в них что-нибудь тяжёлое. Из убитого монстра выпадает дорогое ядро.\n\n[b]Хитрые твари[/b]\nНе каждый сундук — сундук. А манекен крадётся за вами — и если посмотреть ему прямо в лицо, он бросится в погоню.\n\n[b]Скрытность[/b]\nПРИСЕД уменьшает дальность, с которой вас замечают монстры. МЕТКА показывает друзьям точку.\n\n[b]Локации[/b]\nОсобняк, музей и лаборатория сменяют друг друга, а квоты и число монстров растут.\n\n[b]Магазин[/b]\nМежду уровнями вы попадаете в магазин: кладите товары лучом на платформу кассы и жмите кнопку — их «сдадут» как ценности, и они будут ждать в фургоне в начале следующего уровня (деньги округляются вниз до $1K). Улучшения и аптечки применяйте там кнопкой ИСП. Купленное снаряжение возвращается в фургон каждый уровень, даже если сломалось; гранаты, мины, улучшения и аптечки исчезают после использования.\n\n[b]Фургон[/b]\nПосле последней точки нажмите кнопку фургона: он уедет через 10 секунд, кто снаружи — взорвётся. Фургон лечит (+50 на первых уровнях). Голова товарища на платформе сдачи оживляет его с 1 HP, в фургоне после последней точки — с 25 HP. Держите товарища лучом — он получает 10 HP/с из вашего здоровья. Каждые 5 уровней меняется фаза луны: монстры крепче, а их ядра дороже.\n\n[b]Оружие и слоты[/b]\nУ каждого робота 3 слота (кнопки 1/2/3): держа предмет лучом, нажмите номер слота — он спрячется; нажмите снова — достанете. Оружие и дроны тратят заряд батареи — заряжайте их на станции в фургоне (на неё тратятся энергокристаллы). Гранаты взрываются через 3 секунды после активации, мины взводятся за 1,5 с.\n\n[b]Прятки[/b]\nМонстр замечает стоящего робота примерно за секунду, присевшего — за две. Присядьте и заползите под стол, кровать или лабораторный стол: там вас увидят, только если подойдут вплотную. Присед на бегу — подкат. Потеряв вас, монстр обыскивает последнее место и может уйти. Глаз над прицелом показывает, что вас замечают.\n\n[b]Кувырок[/b]\nQ (КУВЫРОК) — сжаться в шар. На бегу кувырок превращается в рывок, который сбивает монстров. Монстров полегче можно поднять лучом и швырнуть.\n\n[b]Здоровье[/b]\nПосле каждой сданной точки фургон чинит всех на 25. Аптечки продаются в магазине.\n\n[b]Кооп[/b]\nДо 4 игроков в одной сети Wi‑Fi. Если робот уничтожен, напарники могут отнести его голову в фургон, чтобы починить его.\n\n[b]Тележка и точки сдачи[/b]\nХватайте тележку лучом за ручку — так она едет перед вами (сильный хват); экран на ручке показывает сумму внутри. Когда квота точки набрана, жмите красную кнопку: сверху опустится труба и заберёт всё с платформы — сойдите с неё! Излишек вернётся мешком: несите его к следующей точке, а после последней — в фургон. На платформе и в тележке вещи не бьются.\n\n[b]Тела[/b]\nВещи и других роботов можно толкать, просто упираясь в них. Брошенные предметы бьют тех, в кого попали.\n\n[b]Эмоции и арена[/b]\nКнопка с глазами (вверху справа, на ПК клавиши 5–0) меняет лицо робота: злость, грусть, подозрение, закрытые глаза, безумие, радость — можно сочетать. По сети, если сломалась вся команда, все попадают на арену утилизации: хватайте оружие, сталкивайте других в яму, края платформы обрушиваются. Последний выживший — Король неудачников и носит корону.\n\n[b]HD-пакет[/b]\nПо желанию — более чёткие текстуры и полные модели: положите файлы HAULBOTS-HD-1.6-*.pck в папку «Загрузки» (Download), затем Настройки → Графика → «Установить из «Загрузок»» и перезапустите игру.\n\n[b]Управление на ПК[/b]\nWASD — ходьба, Shift — бег, Пробел — прыжок, ЛКМ — луч, ПКМ — бросок, колесо — дистанция, E — использовать, Esc — пауза, C — присесть, Q — кувырок, G — метка, 1/2/3 — слоты инвентаря, M — карта, V — микрофон.",
	},
	"en": {
		"basket": "BASKET",
		"cash": "CASH",
		"shop_welcome": "Workshop: carry goods onto the pad and press the button — your purchases will wait in the van next level. Then everyone to the van.",
		"msg_basket_empty": "The checkout zone is empty",
		"msg_no_money": "Not enough team cash",
		"msg_bought": "Bought for $%s!",
		"msg_used": "%s used: %s",
		"obj_shop": "Workshop · Cash $%s",
		"press_buy": "USE — pay for goods in the zone",
		"press_use_item": "USE — apply",
		"owned_tag": "OWNED",
		"item_med_s": "Small medkit",
		"item_med_m": "Medkit",
		"item_med_l": "Large medkit",
		"btn_crouch": "CROUCH",
		"btn_map": "MAP",
		"btn_mic": "MIC",
		"btn_ping": "PING",
		"item_chest": "Chest",
		"item_crown": "Crown",
		"item_mask": "Mask",
		"item_beaker": "Beaker",
		"item_microscope": "Microscope",
		"item_powercell": "Power cell",
		"item_server": "Server",
		"tut_move": "Left stick to walk, swipe on the right to look.",
		"tut_grab": "Aim at a valuable and press GRAB.",
		"tut_carry": "Carry it to the green extraction point — follow the arrow at the top. ▲▼ change distance.",
		"tut_button": "Fill the quota in the zone and press USE at the button pedestal.",
		"tut_hide": "Hear footsteps? CROUCH makes you quieter — under a table or bed monsters can barely see you. PING marks a spot for friends.",
		"difficulty": "Difficulty",
		"diff_0": "Easy",
		"diff_1": "Normal",
		"diff_2": "Hardcore",
		"record": "Best: level %d · $%s",
		"loc_0": "Mansion",
		"loc_1": "Museum",
		"loc_2": "Laboratory",
		"msg_location": "Location: %s",
		"vibration": "Vibration",
		"new_record": "NEW RECORD!",
		"mic_hint": "MIC — voice chat with nearby teammates",
		"tagline": "Haul it. Don't break it. Survive.",
		"name": "Name",
		"continue": "Continue (level %d)",
		"new_game": "New game (solo)",
		"host": "Host Wi‑Fi game",
		"join": "Join Wi‑Fi game",
		"settings": "Settings",
		"how_to_play": "How to play",
		"quit": "Quit",
		"back": "Back",
		"close": "Close",
		"searching": "Searching for games on your Wi‑Fi...",
		"no_games": "No games found yet. Make sure you're on the same Wi‑Fi, or type the host IP.",
		"ip_hint": "Host IP, e.g. 192.168.1.5",
		"connect": "Connect",
		"connecting": "Connecting...",
		"cancel": "Cancel",
		"conn_failed": "Connection failed",
		"host_left": "Host ended the session",
		"kicked_full": "Lobby is full",
		"kicked_in_game": "Game in progress — wait for the run to end",
		"kicked_version": "Host has a different game version",
		"host_failed": "Could not start server (port busy?)",
		"lobby": "Lobby",
		"your_ip": "Friends connect to IP: %s",
		"players_n": "Players (%d/4)",
		"start": "Start run",
		"waiting_host": "Waiting for host...",
		"leave": "Leave",
		"shop": "Workshop",
		"level_done": "Level %d cleared! Hauled: $%s (quota $%s)",
		"team_money": "Team cash: $%s",
		"next_level": "Next level ▶",
		"buy": "Buy",
		"maxed": "MAX",
		"lvl_short": "lv %d",
		"up_hp": "Armor plating",
		"up_hp_d": "+20 max health",
		"up_stamina": "Battery",
		"up_stamina_d": "+10 stamina",
		"up_strength": "Servos",
		"up_strength_d": "Beam can hold heavier things",
		"up_range": "Beam focus",
		"up_range_d": "+1 m beam range",
		"up_speed": "Motors",
		"up_speed_d": "+8% movement speed",
		"heal": "Repair kit",
		"heal_d": "Restore 50% health",
		"hp_now": "Health: %d / %d",
		"next_quota": "Next level: %d",
		"game_over": "GAME OVER",
		"go_levels": "Levels cleared: %d",
		"go_earned": "Total earned: $%s",
		"to_menu": "Main menu",
		"to_lobby": "Back to lobby",
		"sensitivity": "Sensitivity",
		"volume": "Volume",
		"quality": "Graphics",
		"q_low": "Low",
		"q_med": "Medium",
		"q_high": "High",
		"fov": "Field of view",
		"invert_y": "Invert Y",
		"language": "Language",
		"pause": "Paused",
		"resume": "Resume",
		"leave_game": "Quit to menu",
		"hud_level": "Level %d",
		"hud_cash": "Cash $%s",
		"level_haul": "Hauled this level: $%s",
		"obj_extract": "Point %d/%d: $%s / $%s",
		"obj_ready": "Quota reached — press the button!",
		"obj_truck": "All points done — everyone to the van!",
		"obj_extracting": "Extracting valuables...",
		"obj_wait": "Getting ready...",
		"press_extract": "USE — extract valuables",
		"press_truck": "USE — leave the level",
		"btn_grab": "GRAB",
		"btn_drop": "DROP",
		"btn_jump": "JUMP",
		"btn_use": "USE",
		"btn_throw": "THROW",
		"btn_run": "RUN",
		"msg_level": "Level %d. Find valuables and bring them to the extraction point!",
		"msg_tip1": "Grab things with your beam. Hits lower their value!",
		"msg_need_more": "Not enough value for this point's quota",
		"msg_extract_fail": "Extraction aborted — valuables left the zone",
		"msg_next_point": "Point closed! Next one activated",
		"msg_all_done": "Quota complete! Head back to the van",
		"msg_quota_first": "Close all extraction points first",
		"msg_everyone_truck": "All living bots must be inside the van",
		"msg_player_down": "%s was destroyed! Carry their head to the van",
		"msg_revived": "%s has been repaired!",
		"msg_monsters_awake": "Something woke up in the house...",
		"msg_player_left": "%s disconnected",
		"dead_title": "YOU WERE DESTROYED",
		"dead_hint": "Teammates can carry your head to the van.\nTap the screen to switch camera.",
		"extr_done": "DONE",
		"extr_idle": "INACTIVE",
		"extr_press": "PRESS BUTTON",
		"extr_sending": "SENDING %d",
		"truck_label": "VAN",
		"truck_ready": "ALL IN → BUTTON",
		"truck_wait": "QUOTA FIRST",
		"item_goblet": "Goblet",
		"item_moneybag": "Surplus bag",
		"loading": "LOADING",
		"tip_0": "Tip: grab the cart by its handle and it rolls in front of you.",
		"tip_1": "Tip: items on an extraction pad or in a cart don't break.",
		"tip_2": "Tip: crouch under a table or bed — monsters only spot you point-blank.",
		"tip_3": "Tip: hold a teammate in your beam to give them health.",
		"tip_4": "Tip: overshoot at a point comes back as a bag for the next one.",
		"tip_5": "Tip: your flashlight helps you see, but gives you away.",
		"tip_6": "Tip: what you buy in the shop waits in the van next level.",
		"tip_7": "Tip: the eyes button changes your robot's expression.",
		"tip_8": "Tip: two beams lift heavy things together.",
		"tip_9": "Tip: after the last point you have 10 seconds to get into the van.",
		"arena_title": "Disposal arena",
		"msg_arena_out": "%s is out!",
		"arena_sub": "Only one survives",
		"arena_obj": "Arena: robots left — %d",
		"arena_win": "King of Losers",
		"arena_draw": "Nobody survived",
		"msg_arena_next": "Everyone is broken... the Taxman sends you to the arena!",
		"expr_angry": "Angry",
		"expr_sad": "Sad",
		"expr_sus": "Suspicious",
		"expr_closed": "Eyes closed",
		"expr_crazy": "Crazy",
		"expr_happy": "Happy",
		"expr_hint": "Teammates see your robot's face. Combine several at once.",
		"broken_tag": "BROKEN  −$%s",
		"sum_title": "Level %d complete",
		"sum_haul": "Extracted",
		"sum_quota": "Quota",
		"sum_broken": "Items broken",
		"sum_kills": "Monsters killed",
		"sum_deaths": "Robots broken",
		"sum_cash": "Cash",
		"sum_tap": "tap to close",
		"moon_1": "Waxing moon",
		"moon_2": "Half moon",
		"moon_3": "Full moon",
		"moon_4": "Super moon",
		"msg_truck_leaving": "The van leaves in 10 seconds! Anyone outside will explode!",
		"truck_leave": "LEAVING\n%d",
		"msg_bought_truck": "Bought for $%s — your purchases will wait in the van next level",
		"msg_surplus_last": "Surplus $%s came back as a bag — carry it into the van, it pays out when you leave!",
		"msg_surplus": "Surplus $%s came back as a bag — carry it to the next point!",
		"item_jewelbox": "Jewel box",
		"item_crystal": "Crystal ball",
		"item_vase": "Vase",
		"item_clock": "Clock",
		"item_painting": "Painting",
		"item_lamp": "Lamp",
		"item_radio": "Radio",
		"item_gramophone": "Gramophone",
		"item_statue": "Statue",
		"item_grandclock": "Grandfather clock",
		"item_orb": "Monster core",
		"item_head": "Robot head",
		"item_cart": "Cart",
		"tab_game": "Game",
		"tab_controls": "Controls",
		"tab_video": "Graphics",
		"tab_audio": "Audio",
		"btn_scale": "Button size",
		"btn_alpha": "Button opacity",
		"show_detect": "Detection indicator",
		"show_fps": "Show FPS",
		"film_fx": "Camera effect (grain, vignette)",
		"fps_cap": "Frame rate",
		"brightness": "Brightness",
		"cart_strong": "Handle grip: the cart rolls in front of you",
		"cart_weak": "Weak grip — grab the handle",
		"cart_hint": "Grab the handle with the beam to push",
		"adaptive_res": "Adaptive resolution",
		"adaptive_hint": "When frames drop the game lowers internal resolution slightly instead of stuttering, and returns to full when there is headroom.",
		"hd_pack": "HD texture pack",
		"hd_on": "HD enabled (%s)",
		"hd_off": "Not installed — base quality",
		"hd_install": "Install from Downloads",
		"hd_remove": "Remove HD",
		"hd_restart": "Restart game",
		"hd_hint": "Download the HAULBOTS-HD-1.6-*.pck files into your phone's Download folder and tap Install. The game will ask for file access — it is only used to copy the pack.",
		"hd_need_perm": "Allow all-files access for HAULBOTS, then return to the game…",
		"hd_not_found": "No HAULBOTS-HD-1.6-*.pck files found in Downloads",
		"hd_bad": "File is damaged or not a HAULBOTS pack",
		"hd_done": "Installed parts: %d. Restart the game",
		"hd_removed": "HD removed. Restart the game",
		"hd_pending": "Restart required to apply",
		"hd_hint_ios": "Copy the HAULBOTS-HD-1.6-*.pck files with the Files app into \"On My iPhone > HAULBOTS\" and tap Install.",
		"hd_install_ios": "Install from Files",
		"hd_not_found_ios": "No HAULBOTS-HD-1.6-*.pck files in Files > On My iPhone > HAULBOTS",
		"hd_restart_ios": "Close game",
		"hd_done_ios": "Installed parts: %d. Close the game and open it again",
		"hd_removed_ios": "HD removed. Close the game and open it again",
		"hd_pending_ios": "Close the game and open it again to apply",
		"music_vol": "Music",
		"reset_tutorial": "Replay tutorial",
		"tutorial_reset_done": "The tutorial will show on level 1",
		"detect_hint": "The eye above the crosshair shows a monster noticing you",
		"hud_hp": "Health",
		"hud_stamina": "Energy",
		"hidden_tag": "HIDDEN",
		"btn_slot": "Slot",
		"energy": "Energy",
		"msg_pay_first": "Pay for it in the purchase zone first",
		"msg_drone_no_target": "Nothing for the drone to attach to",
		"msg_crystal": "Crystal inserted: +3 charger charges",
		"msg_cant_store": "This can't go into a slot",
		"msg_no_energy": "The charger needs energy — buy a crystal",
		"msg_truck_heal": "The van patched everyone up: +%s health",
		"btn_tumble": "TUMBLE",
		"item_w_bat": "Baseball bat",
		"item_w_sledge": "Sledgehammer",
		"item_w_pan": "Frying pan",
		"item_w_prod": "Shock prod",
		"item_w_pistol": "Pistol",
		"item_w_shotgun": "Shotgun",
		"item_w_tranq": "Tranquilizer gun",
		"item_g_explosive": "Grenade",
		"item_g_stun": "Stun grenade",
		"item_g_shock": "Shock grenade",
		"item_m_explosive": "Mine",
		"item_m_stun": "Stun mine",
		"item_d_feather": "Feather drone",
		"item_d_shield": "Shield drone",
		"item_t_valuable": "Valuable tracker",
		"item_t_extract": "Extraction tracker",
		"item_i_crystal": "Energy crystal",
		"item_i_pocketcart": "Pocket cart",
		"mon_gremlin": "Gremlin",
		"mon_bomber": "Bomblet",
		"mon_eye": "The Eye",
		"mon_tick": "Tick",
		"mon_spewer": "Spewer",
		"mon_rugrat": "Rugrat",
		"mon_skitter": "Critter",
		"mon_puff": "Puff",
		"mon_howler": "Howler",
		"mon_levitator": "Levitator",
		"mon_butcher": "Butcher",
		"mon_lurker": "Reaper",
		"mon_hidden": "The Unseen",
		"mon_mimic": "Mimic",
		"mon_bighead": "Bighead",
		"mon_projector": "Projector",
		"mon_hunter": "Blind hunter",
		"mon_brute": "Brute",
		"mon_watcher": "Mannequin",
		"up_jump": "Springs",
		"up_jump_d": "+1 extra mid-air jump",
		"up_tumble": "Catapult",
		"up_tumble_d": "Tumble launch flies farther and hits harder",
		"up_crouch": "Rest mode",
		"up_crouch_d": "Stamina regenerates faster while crouched or tumbling",
		"battery": "Charge",
		"slot_empty": "empty",
		"to_charge": "Put it on the van charger to recharge",
		"trk_dist": "%d m",
		"too_heavy": "Too heavy!",
		"help_title": "How to play",
		"help_text": "[b]Goal[/b]\nYou are a salvage robot. On each level find valuables in the mansion and bring them to the active [color=#6f6]extraction point[/color]. When the value in the zone reaches the quota, press the button on the pedestal. Close every point, then return to the [color=#fc3]van[/color].\n\n[b]Valuables are fragile[/b]\nEvery hit against a wall or floor lowers the value. Broken items disappear. Crystal and vases are the most fragile.\n\n[b]Grab beam[/b]\nAim and press GRAB. ▲▼ change the distance, THROW flings the item. Heavy things need upgrades or friends: beams add up!\n\n[b]Monsters[/b]\nCreatures live in the house. They hear noise and see you. Run, hide — or throw something heavy at them. A killed monster drops a valuable core.\n\n[b]Tricky creatures[/b]\nNot every chest is a chest. And the mannequin creeps after you — look it straight in the face and it will hunt you down.\n\n[b]Stealth[/b]\nCROUCH reduces how far monsters can spot you. PING shows friends a spot.\n\n[b]Locations[/b]\nMansion, museum and laboratory rotate while quotas and monster counts grow.\n\n[b]Shop[/b]\nBetween levels you visit the shop: carry goods onto the checkout pad and press the button — they are extracted like valuables and wait in the van at the start of the next level (cash is rounded down to $1K). Use upgrades and health packs there with USE. Gear you bought comes back in the van every level, even if it broke; grenades, mines, upgrades and health packs are gone once used.\n\n[b]Van[/b]\nAfter the last point press the van button: it leaves in 10 s and anyone outside explodes. The van heals you (+50 HP early on). A teammate's head on an extraction pad revives them with 1 HP, in the van after the last point with 25 HP. Hold a teammate in the beam to give them 10 HP/s of your health. Every 5 levels the moon phase changes: monsters get tougher and their cores more valuable.\n\n[b]Weapons & slots[/b]\nEvery bot has 3 slots (keys 1/2/3): while holding an item press a slot number to pocket it, press again to take it out. Weapons and drones use battery charge — recharge them at the charger in the van (it consumes energy crystals). Grenades go off 3 s after activation, mines arm in 1.5 s.\n\n[b]Hiding[/b]\nA monster needs about a second to notice a standing bot and two seconds for a crouching one. Crouch and crawl under a table, bed or lab bench: there you are only spotted from point-blank range. Crouch while sprinting to slide. After losing you a monster searches the last spot and may wander off. The eye above the crosshair shows that you are being noticed.\n\n[b]Tumble[/b]\nQ (TUMBLE) curls you into a ball. While sprinting it becomes a launch that knocks monsters over. Lighter monsters can be lifted with the beam and thrown.\n\n[b]Health[/b]\nThe van repairs everyone by 25 after every extraction. Medkits are sold in the shop.\n\n[b]Co-op[/b]\nUp to 4 players on the same Wi‑Fi. If a bot is destroyed, teammates can carry its head to the van to repair it.\n\n[b]Cart & extraction[/b]\nGrab the cart by its handle to push it (strong grip); the screen on the handle shows what is inside. Press the red button at a point when its goal is met: the tube drops and takes everything on the pad — step off! Overshoot comes back as a surplus bag: carry it to the next point, or into the van after the last one. Items on a pad or in a cart do not break.\n\n[b]Bodies[/b]\nYou can shove items and other robots by walking into them. Flung objects hurt whoever they hit.\n\n[b]Expressions & arena[/b]\nThe eyes button (top right, keys 5-0 on PC) changes your robot's face: angry, sad, suspicious, eyes closed, crazy, happy — combine them. Online, if the whole crew is broken, everyone lands in the disposal arena: grab weapons, knock others into the pit, the rim falls away ring by ring. The last robot standing is the King of Losers and wears a crown.\n\n[b]HD pack[/b]\nOptional sharper textures and full-detail models: put the HAULBOTS-HD-1.6-*.pck files into the phone's Download folder, then Settings → Graphics → Install from Downloads, and restart.\n\n[b]PC controls[/b]\nWASD move, Shift sprint, Space jump, LMB beam, RMB throw, wheel distance, E use, Esc pause, C crouch, Q tumble, G ping, 1/2/3 inventory slots, M map, V microphone.",
	},
}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var loc := OS.get_locale_language()
	lang = "ru" if loc in ["ru", "uk", "be", "kk", "uz", "ky"] else "en"
	randomize()
	player_name = "Bot-%d" % (randi() % 900 + 100)
	_setup_input()
	load_cfg()
	if not auto_q_done:
		# first launch (or first run of 1.5.1): pick a quality that suits this phone; never raise a manual choice
		quality = mini(quality, detect_quality())
		auto_q_done = true
		save_cfg()
	apply()


## Rough device class from GPU, memory and renderer: 0 low, 1 medium, 2 high.
func detect_quality() -> int:
	if OS.get_name() == "iOS":
		var ram_i := float(OS.get_memory_info().get("physical", 0)) / 1073741824.0
		return 1 if (ram_i > 0.0 and ram_i < 3.5) else 2
	if OS.get_name() != "Android":
		return 2
	var drv := RenderingServer.get_current_rendering_driver_name()
	var ram := float(OS.get_memory_info().get("physical", 0)) / 1073741824.0
	var gpu := RenderingServer.get_video_adapter_name().to_lower()
	var cores := OS.get_processor_count()
	if drv.begins_with("opengl") or (ram > 0.0 and ram < 3.5) or cores <= 4:
		return 0
	for w in ["mali-t", "mali-g31", "mali-g51", "mali-g52", "mali-g57", "mali-g68", "powervr", "ge8", "adreno (tm) 5", "adreno (tm) 4"]:
		if gpu.contains(w):
			return 0 if ram < 5.0 else 1
	var m := RegEx.create_from_string("adreno \\(tm\\) 6([0-3])\\d").search(gpu)
	if m != null or (ram > 0.0 and ram < 6.0):
		return 1
	return 2


func t(key: String) -> String:
	var d: Dictionary = STR.get(lang, STR["en"])
	if OS.get_name() == "iOS" and d.has(key + "_ios"):
		return d[key + "_ios"]
	if d.has(key):
		return d[key]
	return STR["en"].get(key, key)


## REPO-style short money: 950 -> "950", 4230 -> "4.2K", 12400 -> "12.4K", 1250000 -> "1.25M"
func money_k(v: int) -> String:
	var a := absi(v)
	var sgn := "-" if v < 0 else ""
	if a < 1000:
		return sgn + str(a)
	if a < 1000000:
		var k := a / 1000.0
		return sgn + ("%.1fK" % k if k < 100.0 else "%dK" % int(k))
	return sgn + "%.2fM" % (a / 1000000.0)


func money(v: int) -> String:
	var s := str(absi(v))
	var out := ""
	var n := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		n += 1
		if n % 3 == 0 and i > 0:
			out = "," + out
	return ("-" if v < 0 else "") + out


func is_touch() -> bool:
	return force_touch or DisplayServer.is_touchscreen_available()


func _setup_input() -> void:
	_add_keys("move_forward", [KEY_W, KEY_UP])
	_add_keys("move_back", [KEY_S, KEY_DOWN])
	_add_keys("move_left", [KEY_A, KEY_LEFT])
	_add_keys("move_right", [KEY_D, KEY_RIGHT])
	_add_keys("jump", [KEY_SPACE])
	_add_keys("sprint", [KEY_SHIFT])
	_add_keys("use", [KEY_E, KEY_F])
	_add_keys("pause", [KEY_ESCAPE])
	_add_keys("crouch", [KEY_C, KEY_CTRL])
	_add_keys("ping", [KEY_G])
	_add_keys("tumble", [KEY_Q])
	_add_keys("slot1", [KEY_1])
	_add_keys("slot2", [KEY_2])
	_add_keys("slot3", [KEY_3])
	for i in 6:
		_add_keys("expr%d" % i, [[KEY_5, KEY_6, KEY_7, KEY_8, KEY_9, KEY_0][i]])
	_add_keys("map", [KEY_M, KEY_TAB])
	_add_keys("talk", [KEY_V])
	_add_mouse("grab", MOUSE_BUTTON_LEFT)
	_add_mouse("throw", MOUSE_BUTTON_RIGHT)


func _add_keys(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var e := InputEventKey.new()
		e.physical_keycode = k
		InputMap.action_add_event(action, e)


func _add_mouse(action: String, button: int) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var e := InputEventMouseButton.new()
	e.button_index = button
	InputMap.action_add_event(action, e)


func load_cfg() -> void:
	var cf := ConfigFile.new()
	if cf.load(PATH) != OK:
		return
	sensitivity = cf.get_value("s", "sensitivity", sensitivity)
	volume = cf.get_value("s", "volume", volume)
	lang = cf.get_value("s", "lang", lang)
	player_name = cf.get_value("s", "name", player_name)
	quality = cf.get_value("s", "quality", quality)
	invert_y = cf.get_value("s", "invert_y", invert_y)
	fov = cf.get_value("s", "fov", fov)
	last_ip = cf.get_value("s", "last_ip", last_ip)
	difficulty = cf.get_value("s", "difficulty", difficulty)
	voice = cf.get_value("s", "voice", voice)
	best_level = cf.get_value("s", "best_level", best_level)
	best_earned = cf.get_value("s", "best_earned", best_earned)
	tutorial_done = cf.get_value("s", "tutorial_done", tutorial_done)
	vibration = cf.get_value("s", "vibration", vibration)
	btn_scale = cf.get_value("s", "btn_scale", btn_scale)
	btn_alpha = cf.get_value("s", "btn_alpha", btn_alpha)
	show_detect = cf.get_value("s", "show_detect", show_detect)
	show_fps = cf.get_value("s", "show_fps", show_fps)
	music_vol = cf.get_value("s", "music_vol", music_vol)
	film_fx = cf.get_value("s", "film_fx", film_fx)
	fps_cap = cf.get_value("s", "fps_cap", fps_cap)
	crown_name = cf.get_value("s", "crown", crown_name)
	brightness = cf.get_value("s", "brightness", brightness)
	adaptive_res = cf.get_value("s", "adaptive_res", adaptive_res)
	auto_q_done = cf.get_value("s", "auto_q_151", auto_q_done)


func save_cfg() -> void:
	var cf := ConfigFile.new()
	cf.set_value("s", "sensitivity", sensitivity)
	cf.set_value("s", "volume", volume)
	cf.set_value("s", "lang", lang)
	cf.set_value("s", "name", player_name)
	cf.set_value("s", "quality", quality)
	cf.set_value("s", "invert_y", invert_y)
	cf.set_value("s", "fov", fov)
	cf.set_value("s", "last_ip", last_ip)
	cf.set_value("s", "difficulty", difficulty)
	cf.set_value("s", "voice", voice)
	cf.set_value("s", "best_level", best_level)
	cf.set_value("s", "best_earned", best_earned)
	cf.set_value("s", "tutorial_done", tutorial_done)
	cf.set_value("s", "vibration", vibration)
	cf.set_value("s", "btn_scale", btn_scale)
	cf.set_value("s", "btn_alpha", btn_alpha)
	cf.set_value("s", "show_detect", show_detect)
	cf.set_value("s", "show_fps", show_fps)
	cf.set_value("s", "music_vol", music_vol)
	cf.set_value("s", "film_fx", film_fx)
	cf.set_value("s", "fps_cap", fps_cap)
	cf.set_value("s", "crown", crown_name)
	cf.set_value("s", "brightness", brightness)
	cf.set_value("s", "adaptive_res", adaptive_res)
	cf.set_value("s", "auto_q_151", auto_q_done)
	cf.save(PATH)


func apply() -> void:
	# capping the frame rate keeps 90/120 Hz phones cool: no thermal throttling mid-run
	Engine.max_fps = fps_cap
	AudioServer.set_bus_volume_db(0, linear_to_db(max(volume, 0.0001)))
	var sx := get_node_or_null("/root/Sfx")
	if sx:
		sx.set_music_volume(music_vol)
	changed.emit()
