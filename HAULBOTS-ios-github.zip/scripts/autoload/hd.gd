extends Node
## HD content packs (2048 px surfaces, 512 px model atlases, full-poly models).
## Must stay the FIRST autoload: packs are mounted in _init(), before any other
## script, scene, texture or model is loaded, so the HD files replace the base ones.
## Install: put HAULBOTS-HD-*.pck into Download, then Settings > Graphics > HD pack.

const DIR := "user://hd"
const PATTERN := "haulbots-hd"
## Packs are tied to the asset version of the game; older packs are ignored (their models/UVs differ).
const HD_VER := "1.6"
const MANAGE := "android.permission.MANAGE_EXTERNAL_STORAGE"
const READ := "android.permission.READ_EXTERNAL_STORAGE"

signal status_changed(msg: String)

var mounted: PackedStringArray = []   # file names mounted at startup
var pending_restart := false
var _waiting_perm := false


func _init() -> void:
	var d := DirAccess.open(DIR)
	if d == null:
		return
	var files := d.get_files()
	files.sort()
	for f in files:
		if f.to_lower().ends_with(".pck") and _matches(f) and _valid(DIR + "/" + f):
			if ProjectSettings.load_resource_pack(DIR + "/" + f, true):
				mounted.append(f)
	if not mounted.is_empty():
		print("[HD] mounted ", mounted)


func active() -> bool:
	return not mounted.is_empty()


func installed() -> PackedStringArray:
	var out: PackedStringArray = []
	var d := DirAccess.open(DIR)
	if d:
		for f in d.get_files():
			if f.to_lower().ends_with(".pck"):
				out.append(f)
	out.sort()
	return out


static func _matches(f: String) -> bool:
	return f.to_lower().begins_with("%s-%s-" % [PATTERN, HD_VER])


static func _valid(path: String) -> bool:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null or f.get_length() < 64:
		return false
	# Godot packs start with "GDPC" (0x43504447 little-endian)
	return f.get_32() == 0x43504447


## Folders where a downloaded pack may be.
static func search_dirs() -> PackedStringArray:
	var out: PackedStringArray = []
	if OS.get_name() == "iOS":
		# app Documents folder, shown in Files as "On My iPhone > HAULBOTS"
		out.append(ProjectSettings.globalize_path("user://"))
		return out
	var sys := OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	if sys != "":
		out.append(sys)
	for p in ["/storage/emulated/0/Download", "/storage/emulated/0/Downloads",
			"/sdcard/Download", "/storage/emulated/0/Android/data/com.jiokim.haulbots/files",
			"/storage/emulated/0/Documents", "/storage/emulated/0/Telegram/Telegram Documents"]:
		if not out.has(p):
			out.append(p)
	if OS.get_name() != "Android":
		out.append(OS.get_executable_path().get_base_dir())
		out.append(ProjectSettings.globalize_path("res://").path_join("build"))
	return out


func find_candidates() -> PackedStringArray:
	var out: PackedStringArray = []
	for dir in search_dirs():
		var d := DirAccess.open(dir)
		if d == null:
			continue
		for f in d.get_files():
			var l := f.to_lower()
			if l.begins_with(PATTERN) and l.ends_with(".pck") and _matches(f):
				out.append(dir.path_join(f))
	return out


func has_storage_access() -> bool:
	if OS.get_name() != "Android":
		return true
	var g := OS.get_granted_permissions()
	return g.has(MANAGE) or (_old_android() and g.has(READ))


static func _old_android() -> bool:
	return OS.get_version().get_slice(".", 0).to_int() < 11


## Called from the settings button. Returns immediately; progress via status_changed.
func install() -> void:
	if not has_storage_access():
		_waiting_perm = true
		status_changed.emit(Settings.t("hd_need_perm"))
		OS.request_permission(READ if _old_android() else MANAGE)
		# Permission screen is a separate Activity: resume in _notification.
		# Folder may still be readable (app-specific dir), so try anyway.
	_do_install()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_IN and _waiting_perm:
		_waiting_perm = false
		_do_install()


func _do_install() -> void:
	var found := find_candidates()
	if found.is_empty():
		if not _waiting_perm:
			status_changed.emit(Settings.t("hd_not_found"))
		return
	_waiting_perm = false
	DirAccess.make_dir_recursive_absolute(DIR)
	for old in installed():
		if not _matches(old):
			DirAccess.remove_absolute(DIR + "/" + old)
	var n := 0
	for src in found:
		if not _valid(src):
			continue
		var name := _clean_name(src.get_file())
		var dst := DIR + "/" + name
		var err := _copy(src, dst)
		if err == OK:
			n += 1
			if OS.get_name() == "iOS":
				DirAccess.remove_absolute(src)   # same app sandbox: don't keep a second copy
	if n == 0:
		status_changed.emit(Settings.t("hd_bad"))
		return
	pending_restart = true
	status_changed.emit(Settings.t("hd_done") % n)


## "HAULBOTS-HD-1.5-1 (2).pck" -> "haulbots-hd-1.5-1.pck"
static func _clean_name(f: String) -> String:
	var base := f.get_basename().to_lower()
	var i := base.find(" (")
	if i > 0:
		base = base.substr(0, i)
	return base.replace(" ", "") + ".pck"


static func _copy(src: String, dst: String) -> int:
	var a := FileAccess.open(src, FileAccess.READ)
	if a == null:
		return FileAccess.get_open_error()
	var tmp := dst + ".part"
	var b := FileAccess.open(tmp, FileAccess.WRITE)
	if b == null:
		return FileAccess.get_open_error()
	var left := a.get_length()
	while left > 0:
		var chunk := a.get_buffer(mini(left, 4 << 20))
		if chunk.is_empty():
			break
		b.store_buffer(chunk)
		left -= chunk.size()
	b.close()
	a.close()
	if left > 0:
		DirAccess.remove_absolute(tmp)
		return ERR_FILE_CORRUPT
	if FileAccess.file_exists(dst):
		DirAccess.remove_absolute(dst)
	return DirAccess.rename_absolute(tmp, dst)


func uninstall() -> void:
	for f in installed():
		DirAccess.remove_absolute(DIR + "/" + f)
	pending_restart = true
	status_changed.emit(Settings.t("hd_removed"))


func restart() -> void:
	# A fresh process is the only way to (un)mount packs cleanly.
	if OS.get_name() != "iOS":
		OS.set_restart_on_exit(true, [])
	get_tree().quit()
