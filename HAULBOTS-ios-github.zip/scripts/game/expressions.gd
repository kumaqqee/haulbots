extends RefCounted
## Robot eye expressions like the reference game's Semibots: six toggles that can be combined.
## bit 0 angry, 1 sad, 2 suspicious, 3 eyes closed, 4 crazy, 5 happy.

const COUNT := 6
const KEYS := ["expr_angry", "expr_sad", "expr_sus", "expr_closed", "expr_crazy", "expr_happy"]


## -> {"up": upper-lid close 0..1, "tilt": inner-corner tilt (rad), "low": lower lid raise 0..1, "crazy": bool}
static func params(mask: int) -> Dictionary:
	var up := 0.0
	var tilt := 0.0
	var low := 0.0
	if mask & 1:
		up = maxf(up, 0.42)
		tilt += 0.5
	if mask & 2:
		up = maxf(up, 0.36)
		tilt -= 0.5
	if mask & 4:
		up = maxf(up, 0.52)
		low = maxf(low, 0.38)
	if mask & 8:
		up = 1.0
	if mask & 32:
		low = maxf(low, 0.62)
	return {"up": up, "tilt": clampf(tilt, -0.7, 0.7), "low": low, "crazy": (mask & 16) != 0}


## 2D preview of a face (HUD buttons).
static func draw_face(ci: CanvasItem, c: Vector2, s: float, mask: int, col: Color, bg := Color(0.05, 0.05, 0.06)) -> void:
	var p := params(mask)
	for side in [-1.0, 1.0]:
		var ec := c + Vector2(side * s * 0.22, 0)
		var rx := s * 0.13
		var ry := s * 0.19
		if p["crazy"]:
			var k := 1.3 if side < 0 else 0.7
			rx *= k
			ry *= k
		var pts := PackedVector2Array()
		for i in 24:
			var a := TAU * i / 24.0
			pts.append(ec + Vector2(cos(a) * rx, sin(a) * ry))
		ci.draw_colored_polygon(pts, col)
		# upper lid: a dark quad whose lower edge drops and tilts
		var drop: float = -ry + p["up"] * ry * 2.05
		var t: float = p["tilt"] * (-side)
		var w := s * 0.2
		var l0 := ec + Vector2(-w, drop - t * w * 0.8)
		var l1 := ec + Vector2(w, drop + t * w * 0.8)
		ci.draw_colored_polygon(PackedVector2Array([l0, l1, ec + Vector2(w, -ry - 4), ec + Vector2(-w, -ry - 4)]), bg)
		if p["up"] >= 1.0:
			ci.draw_line(ec + Vector2(-rx, 0), ec + Vector2(rx, 0), col, maxf(2.0, s * 0.05), true)
		if p["low"] > 0.0:
			var rise: float = ry - p["low"] * ry * 1.2
			ci.draw_colored_polygon(PackedVector2Array([ec + Vector2(-w, rise), ec + Vector2(w, rise), ec + Vector2(w, ry + 4), ec + Vector2(-w, ry + 4)]), bg)
