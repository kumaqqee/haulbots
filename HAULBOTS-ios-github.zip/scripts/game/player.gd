extends CharacterBody3D
## Robot player. The local instance reads input and owns its movement;
## remote instances are interpolated puppets.

const GRAV := 14.0
const ML = preload("res://scripts/game/matlib.gd")
const ItemDefs = preload("res://scripts/game/item_defs.gd")
const JUMP_V := 5.2

var peer_id := 1
var is_local := false
var world: Node = null

var yaw := 0.0
var pitch := 0.0
var head: Node3D
var cam: Camera3D
var flashlight: SpotLight3D
var gadget: Node3D
var gadget_tip: Node3D
var _gad_y := -0.22
var _bump_t := 0.0
const Expr = preload("res://scripts/game/expressions.gd")
var expr := 0             # eye expression bitmask (synced)
var _eyes := []           # [{root, iris, up, low, side}]
var _blink_t := 3.0
var _blink := 0.0
var _eye_state := {"up": 0.0, "tilt": 0.0, "low": 0.0}
var model: Node3D
var model_head: Node3D
var legs := []
var arms := []
var hand: Node3D
var name_label: Label3D
var beam: MeshInstance3D
var beam_mat: ShaderMaterial
var beam_end: MeshInstance3D
var beam_light: OmniLight3D
var beam_snd: AudioStreamPlayer3D
var color := Color.ORANGE

var dead := false
var hp := 100.0
var stamina := 100.0
var stam_block := 0.0
var sprinting := false
var crouching := false
var cap_shape: CapsuleShape3D
var col_shape: CollisionShape3D
var look_mimic = null
var ping_cd := 0.0
var grabbed_ever := false
var grabbed_id := -1
var grab_offset := Vector3.ZERO
var hold_dist := 2.5
var grab_far_t := 0.0
var knock_v := Vector3.ZERO
var shake := 0.0
var send_t := 0.0
var grab_send_t := 0.0
var step_acc := 0.0
var anim_t := 0.0
var spectate_idx := 0
var look_item = null
var look_interact = null
var heavy_warn_t := 0.0

var net_pos := Vector3.ZERO
var net_yaw := 0.0
var net_pitch := 0.0
var net_grab := -1
var _last_pos := Vector3.ZERO


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	# solid bodies: robots bump each other, get blocked (and shoved) by monsters, push items
	collision_mask = 1 | 2 | 4 | 8
	floor_snap_length = 0.3
	floor_max_angle = deg_to_rad(50)
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.32
	cap.height = 1.5
	cs.shape = cap
	cap_shape = cap
	col_shape = cs
	cs.position.y = 0.75
	add_child(cs)
	color = Net.COLORS[int(Net.players.get(peer_id, {}).get("color", 0)) % 4]
	head = Node3D.new()
	head.position.y = 1.38
	add_child(head)
	_build_model()
	_build_beam()
	hp = float(Net.hp.get(peer_id, Net.max_hp(peer_id)))
	if hp <= 0.0:
		hp = 1.0
	if is_local:
		cam = Camera3D.new()
		cam.fov = Settings.fov
		cam.near = 0.05
		cam.far = 90.0
		head.add_child(cam)
		cam.current = true
		flashlight = SpotLight3D.new()
		flashlight.spot_range = 18.0
		flashlight.spot_angle = 32.0
		flashlight.spot_attenuation = 0.8
		flashlight.light_energy = 2.4
		flashlight.light_color = Color(1.0, 0.97, 0.9)
		flashlight.shadow_enabled = Settings.quality >= 1
		flashlight.shadow_bias = 0.04
		flashlight.shadow_blur = 1.2
		flashlight.light_size = 0.05
		flashlight.spot_angle_attenuation = 1.6
		flashlight.position = Vector3(0.2, -0.15, 0.0)
		cam.add_child(flashlight)
		_build_light_cone()
		set_light_cone(Settings.quality >= 1)
		_build_dust()
		_build_gadget()
		model.visible = false
		name_label.visible = false
		stamina = Net.max_stamina(peer_id)
		_face_door()
	net_pos = global_position
	_last_pos = global_position


const ConeShader = preload("res://assets/shaders/lightcone.gdshader")
var light_cone: MeshInstance3D = null
var dust: GPUParticles3D = null


func _build_light_cone() -> void:
	var cm := CylinderMesh.new()
	var ln := 6.0
	cm.top_radius = 0.04
	cm.bottom_radius = tan(deg_to_rad(flashlight.spot_angle)) * ln * 0.75
	cm.height = ln
	cm.radial_segments = 24
	cm.rings = 1
	cm.cap_top = false
	cm.cap_bottom = false
	light_cone = MeshInstance3D.new()
	light_cone.mesh = cm
	light_cone.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var m := ShaderMaterial.new()
	m.shader = ConeShader
	m.set_shader_parameter("length", ln)
	m.set_shader_parameter("strength", 0.035)
	light_cone.material_override = m
	# cylinder axis is +Y: rotate so it points down -Z (camera forward), apex at the lamp
	light_cone.rotation = Vector3(-PI / 2, 0, 0)
	light_cone.position = Vector3(0.2, -0.15, -ln / 2.0)
	cam.add_child(light_cone)


func set_light_cone(on: bool) -> void:
	if light_cone:
		light_cone.visible = on
	if dust:
		dust.emitting = on
		dust.visible = on


func _build_dust() -> void:
	dust = GPUParticles3D.new()
	dust.amount = [30, 60, 90][Settings.quality]
	dust.lifetime = 6.0
	dust.preprocess = 6.0
	dust.local_coords = false
	dust.visibility_aabb = AABB(Vector3(-4, -3, -6), Vector3(8, 6, 8))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(2.5, 1.5, 3.0)
	pm.gravity = Vector3(0, -0.01, 0)
	pm.initial_velocity_min = 0.0
	pm.initial_velocity_max = 0.05
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 180.0
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.3
	pm.turbulence_noise_scale = 2.0
	pm.scale_min = 0.5
	pm.scale_max = 1.2
	var fade := Gradient.new()
	fade.set_color(0, Color(1, 1, 1, 0))
	fade.add_point(0.2, Color(1, 1, 1, 1))
	fade.add_point(0.8, Color(1, 1, 1, 1))
	fade.set_color(fade.get_point_count() - 1, Color(1, 1, 1, 0))
	var gt := GradientTexture1D.new()
	gt.gradient = fade
	pm.color_ramp = gt
	dust.process_material = pm
	var qm := QuadMesh.new()
	qm.size = Vector2(0.012, 0.012)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mat.vertex_color_use_as_albedo = true
	mat.albedo_color = Color(1.0, 0.95, 0.85, 0.35)
	qm.material = mat
	dust.draw_pass_1 = qm
	dust.position = Vector3(0, 0, -2.5)
	cam.add_child(dust)


func _face_door() -> void:
	if world == null or world.gen == null:
		return
	var d: Vector2i = world.gen.door_dir
	var dir := Vector3(d.x, 0, d.y)
	yaw = atan2(-dir.x, -dir.z)
	head.rotation = Vector3(pitch, yaw, 0)


# ------------------------------------------------------------------ building

func _m(parent: Node3D, mesh: Mesh, m: Material, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi


func _mat(c: Color, emit := 0.0, metal := 0.3) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.metallic = metal
	m.roughness = 0.45
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emit
	return m


func _bm(s: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = s
	return b


func _build_model() -> void:
	model = Node3D.new()
	add_child(model)
	var rb := ML.model("robot", {"M_player": ML.plain(color, 0.45, 0.25), "M_player_glow": ML.plain(color.lightened(0.2), 0.3, 0.0, 3.0)})
	if rb:
		model.add_child(rb)
		legs = [ML.find(rb, "leg_l"), ML.find(rb, "leg_r")]
		arms = [ML.find(rb, "arm_l"), ML.find(rb, "arm_r")]
		knees = [ML.find(rb, "leg_l_lo"), ML.find(rb, "leg_r_lo")]
		elbows = [ML.find(rb, "arm_l_lo"), ML.find(rb, "arm_r_lo")]
		model_head = ML.find(rb, "head")
		if model_head:
			_build_eyes(model_head)
			if Settings.crown_name != "" and str(Net.players.get(peer_id, {}).get("name", "")) == Settings.crown_name:
				put_crown()
		hand = Node3D.new()
		hand.position = Vector3(0.34, 0.95, -0.35)
		model.add_child(hand)
		_make_name_label()
		return
	var body_m := _mat(Color(0.78, 0.78, 0.8), 0.0, 0.6)
	var accent := _mat(color)
	var glow := _mat(color, 2.5)
	var dark := _mat(Color(0.12, 0.12, 0.14))
	_m(model, _bm(Vector3(0.55, 0.6, 0.38)), body_m, Vector3(0, 0.82, 0))
	_m(model, _bm(Vector3(0.57, 0.12, 0.4)), accent, Vector3(0, 0.95, 0))
	for sx in [-0.14, 0.14]:
		var piv := Node3D.new()
		piv.position = Vector3(sx, 0.52, 0)
		model.add_child(piv)
		_m(piv, _bm(Vector3(0.16, 0.5, 0.18)), dark, Vector3(0, -0.25, 0))
		legs.append(piv)
	for sx in [-0.34, 0.34]:
		var piv := Node3D.new()
		piv.position = Vector3(sx, 1.05, 0)
		model.add_child(piv)
		_m(piv, _bm(Vector3(0.12, 0.5, 0.12)), body_m, Vector3(0, -0.22, 0))
		arms.append(piv)
	hand = Node3D.new()
	hand.position = Vector3(0.34, 0.95, -0.35)
	model.add_child(hand)
	model_head = Node3D.new()
	model_head.position = Vector3(0, 1.36, 0)
	model.add_child(model_head)
	var hs := SphereMesh.new()
	hs.radius = 0.24
	hs.height = 0.44
	_m(model_head, hs, body_m, Vector3.ZERO)
	_m(model_head, _bm(Vector3(0.34, 0.1, 0.08)), glow, Vector3(0, 0.03, -0.2))
	var ant := CylinderMesh.new()
	ant.top_radius = 0.01
	ant.bottom_radius = 0.01
	ant.height = 0.2
	_m(model_head, ant, dark, Vector3(0.08, 0.3, 0))
	var tip := SphereMesh.new()
	tip.radius = 0.035
	tip.height = 0.07
	_m(model_head, tip, glow, Vector3(0.08, 0.41, 0))
	_make_name_label()


## Semibot-style eyes: a procedural eye (glowing iris + lids) on each side of the visor.
const EyeShader = preload("res://assets/shaders/eye.gdshader")
const EYE_POS := Vector3(0.072, 0.245, -0.254)


func _build_eyes(h: Node3D) -> void:
	var q := QuadMesh.new()
	q.size = Vector2(0.132, 0.132)
	for side in [-1.0, 1.0]:
		var m := ShaderMaterial.new()
		m.shader = EyeShader
		m.set_shader_parameter("eye_color", color.lightened(0.3))
		m.set_shader_parameter("lid", Vector4(0, 0, 0, side))
		var mi := MeshInstance3D.new()
		mi.mesh = q
		mi.material_override = m
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		mi.position = EYE_POS * Vector3(side, 1, 1)
		mi.rotation.y = PI
		h.add_child(mi)
		_eyes.append({"mat": m, "side": side, "scale": 1.0})


func _animate_eyes(delta: float) -> void:
	if _eyes.is_empty():
		return
	_blink_t -= delta
	if _blink_t <= 0.0:
		_blink_t = randf_range(2.5, 6.0)
		_blink = 0.13
	_blink = maxf(0.0, _blink - delta)
	var p := Expr.params(expr)
	var k := minf(1.0, delta * 12.0)
	_eye_state["up"] = lerpf(_eye_state["up"], 1.0 if _blink > 0.0 else float(p["up"]), minf(1.0, delta * (40.0 if _blink > 0.0 else 12.0)))
	_eye_state["tilt"] = lerpf(_eye_state["tilt"], float(p["tilt"]), k)
	_eye_state["low"] = lerpf(_eye_state["low"], float(p["low"]), k)
	var t := Time.get_ticks_msec() * 0.001
	for e in _eyes:
		var side: float = e["side"]
		var sc := 1.0
		var off := Vector2.ZERO
		if p["crazy"]:
			sc = 1.3 if side < 0.0 else 0.65
			off = Vector2(sin(t * 23.0 + side), cos(t * 19.0 - side)) * 0.06
		e["scale"] = lerpf(float(e["scale"]), sc, k)
		var m: ShaderMaterial = e["mat"]
		m.set_shader_parameter("lid", Vector4(_eye_state["up"], -float(_eye_state["tilt"]), _eye_state["low"], side))
		m.set_shader_parameter("look", Vector4(e["scale"], off.x, off.y, 2.6))


## King of Losers: a small gold crown on the head (won in the disposal arena).
func put_crown() -> void:
	if model_head == null or model_head.has_node("Crown"):
		return
	var c := ML.model("crown", {}, false)
	if c:
		c.name = "Crown"
		c.scale = Vector3.ONE * 0.55
		c.position = Vector3(0.0, 0.5, 0.0)
		c.rotation.z = 0.18
		model_head.add_child(c)


func set_expr_bit(i: int) -> void:
	expr ^= 1 << i
	if world and world.hud:
		world.hud.expr_changed(expr)


func _make_name_label() -> void:
	name_label = Label3D.new()
	name_label.text = str(Net.players.get(peer_id, {}).get("name", "Bot"))
	name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_label.font_size = 40
	name_label.pixel_size = 0.005
	name_label.modulate = color
	name_label.outline_size = 8
	name_label.position = Vector3(0, 1.95, 0)
	add_child(name_label)


func _build_gadget() -> void:
	gadget = Node3D.new()
	cam.add_child(gadget)
	var gm := ML.model("gadget", {"M_player": ML.plain(color, 0.4, 0.2), "M_player_glow": ML.plain(color.lightened(0.25), 0.3, 0.0, 4.0)})
	if gm:
		gadget.position = Vector3(0.165, -0.19, -0.36)
		_gad_y = -0.19
		gadget.rotation = Vector3(0.04, 0.07, 0.0)
		gadget.scale = Vector3.ONE * 0.72
		gm.position = Vector3(0, -0.062, 0.02)
		gadget.add_child(gm)
		gadget_tip = Node3D.new()
		gadget_tip.position = Vector3(0, 0, -0.17)
		gadget.add_child(gadget_tip)
		for mi in gm.find_children("*", "MeshInstance3D", true, false):
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		return
	gadget.position = Vector3(0.24, -0.22, -0.5)
	gadget.scale = Vector3.ONE * 0.55
	var body_m := _mat(Color(0.3, 0.3, 0.33), 0.0, 0.7)
	_m(gadget, _bm(Vector3(0.09, 0.1, 0.34)), body_m, Vector3.ZERO)
	_m(gadget, _bm(Vector3(0.1, 0.03, 0.2)), _mat(color), Vector3(0, 0.06, 0.02))
	var ring := CylinderMesh.new()
	ring.top_radius = 0.045
	ring.bottom_radius = 0.045
	ring.height = 0.05
	var r := _m(gadget, ring, _mat(color, 3.0), Vector3(0, 0, -0.18))
	r.rotation.x = PI / 2
	gadget_tip = Node3D.new()
	gadget_tip.position = Vector3(0, 0, -0.21)
	gadget.add_child(gadget_tip)
	for mi in gadget.get_children():
		if mi is MeshInstance3D:
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _build_beam() -> void:
	beam = MeshInstance3D.new()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var n := 40
	for i in n:
		var t0 := float(i) / n
		var t1 := float(i + 1) / n
		for q in [[t0, 0.0], [t1, 0.0], [t1, 1.0], [t0, 0.0], [t1, 1.0], [t0, 1.0]]:
			st.set_uv(Vector2(q[0], q[1]))
			st.add_vertex(Vector3(0, 0, -q[0]))
	var am := st.commit()
	am.custom_aabb = AABB(Vector3(-500, -500, -500), Vector3(1000, 1000, 1000))
	beam.mesh = am
	beam_mat = ShaderMaterial.new()
	beam_mat.shader = preload("res://assets/shaders/beam.gdshader")
	beam_mat.set_shader_parameter("color", color)
	beam_mat.set_shader_parameter("seed", randf() * 10.0)
	beam_mat.set_shader_parameter("width", 0.03 if is_local else 0.045)
	beam.material_override = beam_mat
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	beam.top_level = true
	beam.visible = false
	add_child(beam)
	beam_end = MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.05
	sm.height = 0.1
	sm.radial_segments = 12
	sm.rings = 6
	beam_end.mesh = sm
	var em := StandardMaterial3D.new()
	em.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	em.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	em.albedo_color = color * 1.4
	em.disable_fog = true
	beam_end.material_override = em
	beam_end.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	beam_end.top_level = true
	beam.add_child(beam_end)
	beam_light = OmniLight3D.new()
	beam_light.light_color = color
	beam_light.light_energy = 0.7
	beam_light.omni_range = 1.8
	beam_light.shadow_enabled = false
	beam_end.add_child(beam_light)
	beam_snd = AudioStreamPlayer3D.new()
	beam_snd.stream = Sfx.streams["beam"]
	beam_snd.volume_db = -14.0 if is_local else -8.0
	beam_snd.unit_size = 4.0
	add_child(beam_snd)


# ------------------------------------------------------------------ main loop

func _physics_process(delta: float) -> void:
	if world == null:
		return
	if is_local:
		_local_physics(delta)
	else:
		_puppet_physics(delta)
	_update_beam()
	_animate(delta)


func _touch():
	if world and world.hud and world.hud.touch and world.hud.touch.visible:
		return world.hud.touch
	return null


func _local_physics(delta: float) -> void:
	var t = _touch()
	if dead:
		_spectate(delta, t)
		return
	_tick_effects(delta)
	if t:
		var ld: Vector2 = t.consume_look()
		if ld != Vector2.ZERO:
			_apply_look(ld * 0.16 * Settings.sensitivity)
	if eff_lock_t > 0.0:
		var to := eff_lock_pos - (global_position + Vector3(0, head.position.y, 0))
		var want_yaw := atan2(-to.x, -to.z)
		var want_pitch := atan2(to.y, Vector2(to.x, to.z).length())
		yaw = lerp_angle(yaw, want_yaw, minf(1.0, delta * 6.0))
		pitch = lerpf(pitch, clampf(want_pitch, -1.4, 1.4), minf(1.0, delta * 6.0))
	var iv := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if t and t.move_vec.length() > 0.05:
		iv = t.move_vec
	var paused: bool = world.hud and world.hud.is_paused()
	if paused or eff_carry_t > 0.0:
		iv = Vector2.ZERO
	# tumble toggle
	var want_tumble := not paused and Input.is_action_just_pressed("tumble")
	if t and t.take("tumble") and not paused:
		want_tumble = true
	if want_tumble:
		_toggle_tumble()
	var want_crouch_toggle := not paused and Input.is_action_just_pressed("crouch")
	if t and t.take("crouch") and not paused:
		want_crouch_toggle = true
	var want_sprint: bool = Input.is_action_pressed("sprint") or (t != null and t.sprint_on)
	if want_crouch_toggle and not tumbling:
		var was_sprinting := sprinting and is_on_floor()
		_set_crouch(not crouching)
		if crouching and was_sprinting:
			# dive / slide: lets you slip under a table while fleeing
			var f := look_dir()
			f.y = 0.0
			knock_v += f.normalized() * 5.5
			_dive_block = 1.0
			_make_noise(0.4)
			Sfx.play("swing", null, -8.0, 0.7)
			if t:
				t.sprint_on = false
	_dive_block -= delta
	if want_sprint and crouching and iv.length() > 0.1 and not under_cover and _dive_block <= 0.0:
		_set_crouch(false)
	if crouching:
		want_sprint = false
	var moving := iv.length() > 0.1
	if stam_block > 0.0:
		stam_block -= delta
	var stunned := eff_stun_t > 0.0
	sprinting = want_sprint and moving and stamina > 0.5 and stam_block <= 0.0 and not stunned and not tumbling
	var mult := Net.speed_mult(peer_id)
	var speed := (6.3 if sprinting else (1.9 if crouching else 3.7)) * mult
	if stunned:
		speed *= 0.5
	if eff_vomit_t > 0.0:
		speed *= 0.6
	if grabbed_id > 0:
		var gi = world.items.get(grabbed_id)
		if gi and (gi.type == "cart" or gi.type == "i_pocketcart"):
			speed *= 0.85
	if sprinting:
		stamina -= 7.0 * delta
		if stamina <= 0.0:
			stamina = 0.0
			stam_block = 1.5
	else:
		var regen := 7.5
		if crouching or (tumbling and is_on_floor()):
			regen *= 1.5 * Net.crouch_regen(peer_id)
		stamina = minf(Net.max_stamina(peer_id), stamina + regen * delta)
	var dir := Basis(Vector3.UP, yaw) * Vector3(iv.x, 0, iv.y)
	if dir.length() > 1.0:
		dir = dir.normalized()
	var target := dir * speed
	var k := 1.0 - exp(-(12.0 if is_on_floor() else 2.5) * delta)
	if tumbling:
		target = dir * 2.4
		k = 1.0 - exp(-(1.6 if is_on_floor() else 0.3) * delta)
	var hv := Vector3(velocity.x - knock_v.x, 0, velocity.z - knock_v.z)
	hv = hv.lerp(target, k)
	knock_v = knock_v.lerp(Vector3.ZERO, 1.0 - exp(-4.0 * delta))
	velocity.x = hv.x + knock_v.x
	velocity.z = hv.z + knock_v.z
	var was_air := not is_on_floor()
	if eff_float_t > 0.0:
		var want_vy := 1.3 if global_position.y < float_base + 2.0 else 0.0
		velocity.y = lerpf(velocity.y, want_vy, minf(1.0, delta * 3.0))
	elif is_on_floor():
		if velocity.y < 0.0:
			velocity.y = 0.0
		jumps_left = Net.extra_jumps(peer_id)
	else:
		velocity.y -= GRAV * delta
	if eff_pull_t > 0.0:
		velocity = velocity.lerp(eff_pull_v, minf(1.0, delta * 6.0))
	var jump := false
	if not paused and not stunned and eff_carry_t <= 0.0:
		jump = Input.is_action_just_pressed("jump")
		if t and t.take("jump"):
			jump = true
	if jump and stamina > 2.5 and not tumbling:
		if is_on_floor():
			velocity.y = JUMP_V
			stamina -= 2.5
			Sfx.play("jump", null, -10.0)
		elif jumps_left > 0:
			jumps_left -= 1
			velocity.y = JUMP_V * 0.9
			stamina -= 2.5
			Sfx.play("jump", null, -8.0, 1.3)
	if eff_carry_t > 0.0:
		velocity = (eff_carry_pos - global_position) * 10.0
	move_and_slide()
	_push_bodies(delta)
	if was_air and is_on_floor() and _air_vy < -6.0:
		_make_noise(0.7)
	_air_vy = velocity.y
	if global_position.y < (-40.0 if world.arena_mode else -20.0):
		global_position = world.gen.spawn_points[0]
		velocity = Vector3.ZERO
	# footsteps + noise
	if is_on_floor() and moving and not tumbling:
		step_acc += Vector2(velocity.x, velocity.z).length() * delta
		if step_acc > (1.9 if sprinting else 1.5):
			step_acc = 0.0
			Sfx.play("step", null, -14.0, randf_range(0.85, 1.15))
			_make_noise(1.0 if sprinting else (0.08 if crouching else 0.35))
	if tumbling:
		_tumble_tick(delta)
	if world.voice and world.voice.talking and world.voice.mic_level > 0.12:
		_voice_noise_t -= delta
		if _voice_noise_t <= 0.0:
			_voice_noise_t = 0.4
			_make_noise(0.9)
	head.rotation = Vector3(pitch, yaw, 0)
	# cover check: crawling under furniture hides you (REPO "crawl")
	_cover_t -= delta
	if _cover_t <= 0.0:
		_cover_t = 0.15
		under_cover = false
		if crouching or tumbling:
			var cq := PhysicsRayQueryParameters3D.create(global_position + Vector3(0, 0.3, 0), global_position + Vector3(0, 1.3, 0), 1, [get_rid()])
			under_cover = not get_world_3d().direct_space_state.intersect_ray(cq).is_empty()
	var head_y := 1.38
	if crouching:
		head_y = 0.5
	if tumbling:
		head_y = 0.32
	head.position.y = move_toward(head.position.y, head_y, delta * 5.0)
	# look targets
	look_item = null
	look_interact = null
	look_mimic = null
	look_target = null
	var hit := _ray(Net.grab_range(peer_id), 1 | 2 | 4 | 8)
	if hit:
		var col = hit["collider"]
		if col.is_in_group("item"):
			look_item = col
		elif col.is_in_group("monster"):
			if col.mtype == "mimic" and col.disguised:
				look_mimic = col
			else:
				look_target = col
		elif col.is_in_group("player"):
			look_target = col
		elif col.has_meta("interact") and cam.global_position.distance_to(hit["position"]) < 3.2:
			look_interact = col
	# actions
	if not paused:
		var mouse_ok := not Settings.is_touch() and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED
		var grab_start := mouse_ok and Input.is_action_just_pressed("grab")
		var grab_end := mouse_ok and Input.is_action_just_released("grab")
		var do_throw := mouse_ok and Input.is_action_just_pressed("throw")
		var do_use := Input.is_action_just_pressed("use")
		var slot := -1
		for si in 3:
			if Input.is_action_just_pressed("slot%d" % (si + 1)):
				slot = si
		if t:
			if t.take("grab"):
				if grabbed_id == -1:
					grab_start = true
				else:
					grab_end = true
			if t.take("throw"):
				do_throw = true
			if t.take("use"):
				do_use = true
			for si in 3:
				if t.take("slot%d" % si):
					slot = si
			if t.held("pull"):
				hold_dist = minf(hold_dist + 2.5 * delta, Net.grab_range(peer_id))
			if t.held("push"):
				hold_dist = maxf(hold_dist - 2.5 * delta, 0.9)
		if grab_start and grabbed_id == -1 and not tumbling and eff_carry_t <= 0.0:
			_try_grab()
		elif grab_end and grabbed_id != -1:
			release(Vector3.ZERO)
		if do_throw and grabbed_id != -1:
			release(-cam.global_basis.z)
		if do_use:
			_interact()
		if slot != -1:
			_slot_pressed(slot)
		for ei in Expr.COUNT:
			if Input.is_action_just_pressed("expr%d" % ei):
				set_expr_bit(ei)
		ping_cd -= delta
		var do_ping := Input.is_action_just_pressed("ping")
		if t and t.take("ping"):
			do_ping = true
		if do_ping and ping_cd <= 0.0:
			ping_cd = 1.0
			var ph := _ray(40.0, 1 | 4 | 8)
			if not ph.is_empty():
				world.rpc("rpc_ping", ph["position"])
	_grab_tick(delta)
	# camera shake
	if shake > 0.0:
		shake -= delta
		cam.h_offset = randf_range(-1, 1) * shake * 0.08
		cam.v_offset = randf_range(-1, 1) * shake * 0.08
	else:
		cam.h_offset = 0.0
		cam.v_offset = 0.0
	heavy_warn_t = maxf(0.0, heavy_warn_t - delta)
	# network
	send_t -= delta
	if send_t <= 0.0 and Net.online:
		send_t = 0.05
		world.rpc("rpc_player_state", global_position, yaw, pitch, grabbed_id, (1 if sprinting else 0) | (2 if crouching else 0) | (4 if tumbling else 0) | (8 if under_cover else 0) | (expr << 4))


# ------------------------------------------------------------------ effects from monsters

var eff_lock_pos := Vector3.ZERO
var eff_lock_t := 0.0
var eff_vomit_t := 0.0
var eff_float_t := 0.0
var eff_pull_v := Vector3.ZERO
var eff_pull_t := 0.0
var eff_stun_t := 0.0
var eff_carry_pos := Vector3.ZERO
var eff_carry_t := 0.0
var float_base := 0.0
var jumps_left := 0
var tumbling := false
var look_target = null
var _air_vy := 0.0
var _voice_noise_t := 0.0
var _tumble_hit_cd := 0.0
var _noise_t := 0.0
var ball: MeshInstance3D = null
var knees := []
var elbows := []
var under_cover := false
var _cover_t := 0.0
var _dive_block := 0.0
const CROUCH_H := 0.66


func apply_effect(kind: String, v: Vector3, dur: float) -> void:
	match kind:
		"lock":
			eff_lock_pos = v
			eff_lock_t = dur
		"vomit":
			eff_vomit_t = dur
		"float":
			if eff_float_t <= 0.0:
				float_base = global_position.y
			eff_float_t = dur
		"pull_to":
			eff_pull_v = v
			eff_pull_t = dur
		"impulse":
			knock_v += Vector3(v.x, 0, v.z)
			velocity.y += v.y
		"stunned":
			eff_stun_t = maxf(eff_stun_t, dur)
		"carried":
			eff_carry_pos = v
			eff_carry_t = dur
			if dur > 0.0 and grabbed_id != -1:
				release(Vector3.ZERO)


func _tick_effects(delta: float) -> void:
	eff_lock_t = maxf(0.0, eff_lock_t - delta)
	eff_vomit_t = maxf(0.0, eff_vomit_t - delta)
	eff_float_t = maxf(0.0, eff_float_t - delta)
	eff_pull_t = maxf(0.0, eff_pull_t - delta)
	eff_stun_t = maxf(0.0, eff_stun_t - delta)
	eff_carry_t = maxf(0.0, eff_carry_t - delta)


func _make_noise(loud: float) -> void:
	world.gear.rpc_id(1, "rpc_noise", global_position, loud)


# ------------------------------------------------------------------ tumble

func _toggle_tumble() -> void:
	if tumbling:
		var q := PhysicsRayQueryParameters3D.create(global_position + Vector3(0, 0.4, 0), global_position + Vector3(0, 1.75, 0), 1, [get_rid()])
		if not get_world_3d().direct_space_state.intersect_ray(q).is_empty():
			return
		tumbling = false
		cap_shape.radius = 0.28 if crouching else 0.32
		cap_shape.height = CROUCH_H if crouching else 1.5
		col_shape.position.y = cap_shape.height / 2.0
		return
	if grabbed_id != -1:
		release(Vector3.ZERO)
	tumbling = true
	crouching = false
	cap_shape.radius = 0.3
	cap_shape.height = 0.6
	col_shape.position.y = 0.3
	# tumble launch: from a sprint (or a jump) you fling yourself forward
	if (sprinting or not is_on_floor()) and stamina >= 8.0:
		stamina -= 8.0
		var f := look_dir()
		f.y = 0.0
		f = f.normalized()
		var pw := Net.tumble_power(peer_id)
		knock_v += f * 7.5 * pw
		velocity.y = maxf(velocity.y, 3.5 * pw)
		Sfx.play("swing", null, -4.0, 0.8)
		_make_noise(0.6)


func _tumble_tick(delta: float) -> void:
	_tumble_hit_cd -= delta
	var spd := Vector3(velocity.x, 0, velocity.z).length()
	if spd > 4.5 and _tumble_hit_cd <= 0.0:
		for m in world.monsters.values():
			if m.state != 4 and m.global_position.distance_to(global_position) < 0.9 + m.cfg["radius"]:
				_tumble_hit_cd = 0.6
				world.gear.rpc_id(1, "rpc_tumble_hit", m.mid, spd)
				knock_v = -knock_v * 0.4
				Sfx.play("thud", null, 0.0, 0.7)
				break


# ------------------------------------------------------------------ inventory

func _slot_pressed(slot: int) -> void:
	var inv: Array = Net.inv_of(peer_id)
	if grabbed_id > 0:
		var it = world.items.get(grabbed_id)
		if it and ItemDefs.can_store(it.type) and inv[slot] == null:
			world.gear.rpc_id(1, "rpc_store", grabbed_id, slot)
			remove_collision_exception_with(it)
			grabbed_id = -1
			Sfx.play("ui", null, -4.0, 0.8)
			return
		elif it and not ItemDefs.can_store(it.type):
			if world.hud:
				world.hud.message(Settings.t("msg_cant_store"))
			return
	if inv[slot] != null and grabbed_id == -1:
		world.gear.rpc_id(1, "rpc_take", slot)
		Sfx.play("ui", null, -4.0, 1.2)


func grab_direct(id: int) -> void:
	var it = world.items.get(id)
	if it == null or dead:
		return
	if grabbed_id != -1:
		release(Vector3.ZERO)
	grabbed_id = id
	grab_offset = Vector3.ZERO
	hold_dist = 1.1
	grab_far_t = 0.0
	add_collision_exception_with(it)


# ------------------------------------------------------------------ crouch & helpers

func _set_crouch(on: bool) -> void:
	if on == crouching:
		return
	if not on:
		var q := PhysicsRayQueryParameters3D.create(global_position + Vector3(0, 0.5, 0), global_position + Vector3(0, 1.75, 0), 1, [get_rid()])
		if not get_world_3d().direct_space_state.intersect_ray(q).is_empty():
			return
	crouching = on
	cap_shape.radius = 0.28 if on else 0.32
	cap_shape.height = CROUCH_H if on else 1.5
	col_shape.position.y = cap_shape.height / 2.0


func eye_pos() -> Vector3:
	if is_local:
		return global_position + Vector3(0, head.position.y, 0)
	return global_position + Vector3(0, 0.32 if tumbling else (0.5 if crouching else 1.38), 0)


func look_dir() -> Vector3:
	return Basis.from_euler(Vector3(pitch, yaw, 0)) * Vector3(0, 0, -1)


## Physical bodies like the reference game: walking into things shoves them, and bumping into
## another robot pushes that robot. Items are simulated on the host, so clients send the shove there.
func _push_bodies(delta: float) -> void:
	if not is_local:
		return
	_bump_t = maxf(0.0, _bump_t - delta)
	var hv := Vector3(velocity.x, 0, velocity.z)
	var spd := hv.length()
	for i in get_slide_collision_count():
		var c := get_slide_collision(i)
		var b = c.get_collider()
		if b == null or c.get_normal().y > 0.5:
			continue
		var n := -c.get_normal()
		n.y = 0.0
		if n.length() < 0.01:
			continue
		n = n.normalized()
		if b is RigidBody3D and b.is_in_group("item"):
			var imp := n * (150.0 if tumbling else 75.0) * maxf(0.5, minf(spd / 3.0, 2.0)) * delta
			if multiplayer.is_server():
				b.apply_impulse(imp, c.get_position() - b.global_position)
			else:
				world.rpc_id(1, "rpc_push_item", b.item_id, imp, c.get_position())
		elif b.is_in_group("player") and not b.is_local and _bump_t <= 0.0 and not b.dead:
			_bump_t = 0.12
			var push := n * clampf(spd * (1.4 if tumbling else 0.75), 0.8, 7.0) + Vector3(0, 0.6 if tumbling else 0.0, 0)
			b.rpc_id(b.peer_id, "rpc_bump", push)


@rpc("any_peer", "call_remote", "unreliable_ordered")
func rpc_bump(v: Vector3) -> void:
	if is_local and not dead:
		apply_effect("impulse", v, 0.0)


func _apply_look(d: Vector2) -> void:
	yaw -= deg_to_rad(d.x)
	var inv := -1.0 if Settings.invert_y else 1.0
	pitch = clampf(pitch - deg_to_rad(d.y) * inv, deg_to_rad(-85), deg_to_rad(85))


func _unhandled_input(e: InputEvent) -> void:
	if not is_local:
		return
	if e is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not dead:
		_apply_look(e.relative * 0.1 * Settings.sensitivity)
	elif e is InputEventMouseButton and e.pressed and not Settings.is_touch():
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			if not (world.hud and world.hud.is_paused()):
				Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			return
		if e.button_index == MOUSE_BUTTON_WHEEL_UP:
			hold_dist = minf(hold_dist + 0.3, Net.grab_range(peer_id))
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			hold_dist = maxf(hold_dist - 0.3, 0.9)
		elif dead and e.button_index == MOUSE_BUTTON_LEFT:
			spectate_idx += 1


func _ray(dist: float, mask: int) -> Dictionary:
	var from := cam.global_position
	var to := from - cam.global_basis.z * dist
	var q := PhysicsRayQueryParameters3D.create(from, to, mask, [get_rid()])
	return get_world_3d().direct_space_state.intersect_ray(q)


# ------------------------------------------------------------------ grabbing

func _try_grab() -> void:
	var hit := _ray(Net.grab_range(peer_id), 1 | 2 | 4 | 8)
	if hit.is_empty():
		return
	var col = hit["collider"]
	if col.is_in_group("monster"):
		if col.mtype == "mimic" and col.disguised:
			world.rpc_id(1, "rpc_poke_monster", col.mid)
			return
		grabbed_id = col.mid
		grab_offset = Vector3.ZERO
		hold_dist = clampf(cam.global_position.distance_to(hit["position"]), 1.2, Net.grab_range(peer_id))
		grab_far_t = 0.0
		Sfx.play("grab", null, -6.0)
		return
	if col.is_in_group("player"):
		if col == self or col.dead:
			return
		grabbed_id = -int(col.peer_id)
		grab_offset = Vector3.ZERO
		hold_dist = clampf(cam.global_position.distance_to(hit["position"]), 1.2, Net.grab_range(peer_id))
		grab_far_t = 0.0
		Sfx.play("grab", null, -6.0)
		return
	if not col.is_in_group("item"):
		return
	grabbed_ever = true
	var it = col
	grabbed_id = it.item_id
	grab_offset = it.to_local(hit["position"])
	hold_dist = clampf(cam.global_position.distance_to(hit["position"]), 0.9, Net.grab_range(peer_id))
	grab_far_t = 0.0
	add_collision_exception_with(it)
	Sfx.play("grab", null, -6.0)
	if it.mass * 9.8 > Net.strength(peer_id) * 0.95 and it.type != "cart":
		heavy_warn_t = 2.0


func _grab_point(o) -> Vector3:
	if o == null:
		return Vector3.ZERO
	if grabbed_id > 0 and world.items.has(grabbed_id):
		return o.global_transform * grab_offset
	if o.is_in_group("player"):
		return o.global_position + Vector3(0, 0.9, 0)
	return o.global_position + Vector3(0, o.cfg["height"] * 0.5, 0)


func _grab_tick(delta: float) -> void:
	if grabbed_id == -1:
		return
	var o = world.gobj(grabbed_id)
	if o == null or (o.is_in_group("monster") and o.state == 4) or (o.is_in_group("player") and o.dead):
		force_release()
		return
	var target := cam.global_position - cam.global_basis.z * hold_dist
	grab_send_t -= delta
	if grab_send_t <= 0.0:
		grab_send_t = 1.0 / 30.0
		world.rpc_id(1, "rpc_grab_update", grabbed_id, target, grab_offset)
	var gp: Vector3 = _grab_point(o)
	var is_cart: bool = grabbed_id > 0 and o.is_in_group("item") and (o.type == "cart" or o.type == "i_pocketcart")
	if gp.distance_to(target) > (3.0 if is_cart else 2.2):
		grab_far_t += delta
	else:
		grab_far_t = 0.0
	if grab_far_t > 1.2 or gp.distance_to(cam.global_position) > Net.grab_range(peer_id) + 2.5:
		release(Vector3.ZERO)


func release(throw_dir: Vector3) -> void:
	if grabbed_id == -1:
		return
	var it = world.items.get(grabbed_id) if grabbed_id > 0 else null
	if it:
		remove_collision_exception_with(it)
	world.rpc_id(1, "rpc_grab_release", grabbed_id, throw_dir)
	grabbed_id = -1
	Sfx.play("swing" if throw_dir != Vector3.ZERO else "release", null, -6.0)


func force_release() -> void:
	grabbed_id = -1


func _interact() -> void:
	if grabbed_id > 0:
		var gi = world.items.get(grabbed_id)
		if gi:
			if gi.owned and (gi.type.begins_with("up_") or gi.type.begins_with("med_") or gi.type == "i_crystal"):
				world.rpc_id(1, "rpc_use_item", grabbed_id)
				release(Vector3.ZERO)
				return
			if ItemDefs.is_gear(gi.type):
				world.gear.rpc_id(1, "rpc_use", grabbed_id, cam.global_position, -cam.global_basis.z)
				return
	var hit := _ray(3.2, 1 | 4)
	if hit.is_empty():
		return
	var col = hit["collider"]
	if col.is_in_group("item"):
		if col.owned:
			world.rpc_id(1, "rpc_use_item", col.item_id)
			Sfx.play("ui")
		return
	if col.has_meta("interact"):
		world.rpc_id(1, "rpc_interact", str(col.get_meta("interact")), int(col.get_meta("idx", 0)))
		Sfx.play("ui")


func _update_beam() -> void:
	var gid := grabbed_id if is_local else net_grab
	var o = world.gobj(gid) if gid != -1 else null
	if o == null or dead or (o.is_in_group("player") and o == self):
		if beam.visible:
			beam.visible = false
			beam_snd.stop()
		return
	var a: Vector3 = gadget_tip.global_position if is_local else hand.global_position
	var b: Vector3
	if is_local:
		b = _grab_point(o)
	elif o.is_in_group("item"):
		b = o.global_position
	elif o.is_in_group("player"):
		b = o.global_position + Vector3(0, 0.9, 0)
	else:
		b = o.global_position + Vector3(0, o.cfg["height"] * 0.5, 0)
	var d := b - a
	var ln := d.length()
	if ln < 0.02:
		return
	# the beam leaves the emitter straight ahead and bends toward the held object
	var fwd: Vector3 = -(cam.global_transform.basis.z if is_local else model.global_transform.basis.z)
	var c := a + fwd * ln * 0.5
	beam_mat.set_shader_parameter("p0", a)
	beam_mat.set_shader_parameter("ctrl", c)
	beam_mat.set_shader_parameter("p2", b)
	beam.global_position = a
	beam_end.global_position = b
	var pulse := 1.0 + 0.2 * sin(Time.get_ticks_msec() * 0.02)
	beam_end.scale = Vector3.ONE * pulse
	beam_light.light_energy = 0.6 * pulse if Settings.quality >= 1 else 0.0
	if not beam.visible:
		beam.visible = true
		beam_snd.play()


# ------------------------------------------------------------------ puppets

func set_net(p: Vector3, y: float, pi: float, g: int) -> void:
	net_pos = p
	net_yaw = y
	net_pitch = pi
	net_grab = g


func _puppet_physics(delta: float) -> void:
	var k := minf(1.0, delta * 12.0)
	if global_position.distance_to(net_pos) > 6.0:
		global_position = net_pos
	else:
		global_position = global_position.lerp(net_pos, k)
	yaw = lerp_angle(yaw, net_yaw, k)
	pitch = lerpf(pitch, net_pitch, k)


func _animate(delta: float) -> void:
	var moved := global_position - _last_pos
	_last_pos = global_position
	var spd := Vector2(moved.x, moved.z).length() / maxf(delta, 0.001)
	anim_t += delta * (2.0 + spd * 2.2)
	if is_local:
		if gadget:
			gadget.position.y = _gad_y + sin(anim_t * 0.5) * 0.006 * minf(spd, 6.0)
		return
	model.rotation.y = yaw
	model.scale.y = move_toward(model.scale.y, 0.45 if crouching else 1.0, delta * 3.0)
	if tumbling != (ball != null and ball.visible):
		if ball == null:
			ball = MeshInstance3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.33
			sm.height = 0.66
			ball.mesh = sm
			ball.material_override = ML.plain(color, 0.45, 0.25)
			ball.position.y = 0.34
			add_child(ball)
		ball.visible = tumbling
		model.visible = not tumbling and not dead
	if ball and ball.visible:
		ball.rotation.x += spd * delta * 3.0
	model_head.rotation.x = pitch * 0.6
	_animate_eyes(delta)
	var amt := minf(spd / 4.0, 1.0)
	var sw := sin(anim_t) * amt * 0.7
	if legs.size() == 2:
		legs[0].rotation.x = sw
		legs[1].rotation.x = -sw
	for i in knees.size():
		if knees[i]:
			var ph := anim_t + (0.0 if i == 0 else PI)
			knees[i].rotation.x = -maxf(0.0, sin(ph + 1.4)) * 1.0 * amt - (0.5 if crouching else 0.0)
	if arms.size() == 2:
		arms[0].rotation.x = -sw * 0.6
		arms[1].rotation.x = 1.2 if net_grab != -1 else sw * 0.6
	for i in elbows.size():
		if elbows[i]:
			elbows[i].rotation.x = 0.25 + 0.35 * amt + (0.3 if i == 1 and net_grab != -1 else 0.0)
	model.position.y = absf(sin(anim_t)) * 0.03 * amt
	if spd > 0.5 and not dead:
		step_acc += spd * delta
		if step_acc > 1.7:
			step_acc = 0.0
			Sfx.play("step", global_position, -8.0, randf_range(0.85, 1.1))


# ------------------------------------------------------------------ health

func on_hp(h: float, is_dead: bool, knock: Vector3) -> void:
	var dmg := hp - h
	hp = h
	if is_local:
		if dmg > 0.0:
			shake = 0.45
			knock_v += knock
			velocity.y = maxf(velocity.y, knock.length() * 0.25)
			Sfx.play("hurt", null, -2.0)
			Sfx.vibrate(int(clampf(dmg * 8.0, 60.0, 400.0)))
			if world.hud:
				world.hud.flash_damage(knock, dmg)
	if is_dead and not dead:
		_die()


func _die() -> void:
	dead = true
	collision_layer = 0
	if is_local:
		release(Vector3.ZERO)
		Sfx.play("death")
		cam.top_level = true
		if flashlight:
			flashlight.light_energy = 0.0
		if gadget:
			gadget.visible = false
	else:
		model.visible = false
		name_label.visible = false
		Sfx.play("death", global_position)
	beam.visible = false
	beam_snd.stop()


func revive(pos: Vector3, h: float) -> void:
	dead = false
	hp = h
	collision_layer = 2
	global_position = pos
	net_pos = pos
	velocity = Vector3.ZERO
	if is_local:
		cam.top_level = false
		cam.transform = Transform3D()
		if flashlight:
			flashlight.light_energy = 2.4
		if gadget:
			gadget.visible = true
		stamina = Net.max_stamina(peer_id)
	else:
		model.visible = true
		name_label.visible = true


func _spectate(delta: float, t) -> void:
	if t and t.take("grab"):
		spectate_idx += 1
	var alive := []
	for p in world.players.values():
		if not p.dead and p != self:
			alive.append(p)
	var focus: Vector3
	if alive.is_empty():
		focus = global_position + Vector3(0, 1.0, 0)
	else:
		var tp = alive[spectate_idx % alive.size()]
		focus = tp.global_position + Vector3(0, 1.3, 0)
	var back := Vector3(sin(Time.get_ticks_msec() * 0.0002), 0.0, cos(Time.get_ticks_msec() * 0.0002)) * 3.0
	var want := focus + back + Vector3(0, 1.4, 0)
	cam.global_position = cam.global_position.lerp(want, minf(1.0, delta * 4.0))
	if cam.global_position.distance_to(focus) > 0.1:
		cam.look_at(focus, Vector3.UP)
