extends RigidBody3D
## A physics valuable. Simulated on the host; clients show interpolated copies.

const ItemDefs = preload("res://scripts/game/item_defs.gd")

var item_id := 0
var type := ""
var value := 0
var base_value := 0
var extra := 0
var world: Node = null
var server_side := true
var fragility := 1.0
var glass := false
var held := 0
var last_vel := Vector3.ZERO
var hit_cd := 1.0
var net_pos := Vector3.ZERO
var net_rot := Quaternion.IDENTITY
var main_color := Color.WHITE
var owned := false
var uid := 0
var last_holder := 0
var battery := 1.0
var synced_battery := 1.0
var mass_scale := 1.0
var indestructible := false
var thrown_by_monster := 0.0
var armed := false
var _flag_light: OmniLight3D = null
var _cart_label: Label3D = null
var cart_total := 0
var _cart_t := 0.0


func _ready() -> void:
	var d: Dictionary = ItemDefs.DEFS[type]
	mass = d["mass"]
	fragility = d["frag"]
	glass = d["glass"]
	var cidx := 0
	if type == "head":
		cidx = int(Net.players.get(extra, {}).get("color", 0))
	main_color = ItemDefs.build(type, self, cidx, item_id * 7919 + 13)
	add_to_group("item")
	collision_layer = 4
	collision_mask = 1 | 2 | 4 | 8
	var pm := PhysicsMaterial.new()
	pm.friction = 0.12 if type == "cart" else 0.7
	pm.bounce = 0.05
	physics_material_override = pm
	linear_damp = 0.1
	angular_damp = 0.6
	continuous_cd = mass < 5.0
	if type == "cart" or type == "i_pocketcart":
		# value readout lives on the handle screen, facing whoever pushes the cart (-X side)
		_cart_label = Label3D.new()
		_cart_label.font_size = 64
		_cart_label.outline_size = 0
		_cart_label.modulate = Color(0.45, 1.0, 0.6)
		_cart_label.double_sided = false
		_cart_label.billboard = BaseMaterial3D.BILLBOARD_DISABLED
		_cart_label.text = "$0"
		if type == "cart":
			_cart_label.pixel_size = 0.0019
			_cart_label.position = Vector3(-0.775, 0.408, 0)
			_cart_label.rotation = Vector3(0, -PI / 2, 0)
			_cart_label.rotate_object_local(Vector3.RIGHT, -0.35)
		else:
			_cart_label.pixel_size = 0.0014
			_cart_label.position = Vector3(-0.452, 0.206, 0)
			_cart_label.rotation = Vector3(0, -PI / 2, 0)
			_cart_label.rotate_object_local(Vector3.RIGHT, -0.5)
		add_child(_cart_label)
	if server_side:
		contact_monitor = true
		max_contacts_reported = 4
		body_entered.connect(_on_body_entered)
	else:
		freeze_mode = RigidBody3D.FREEZE_MODE_KINEMATIC
		freeze = true


func display_name() -> String:
	if type.begins_with("up_"):
		return Settings.t("up_" + type.substr(3))
	return Settings.t("item_" + type)


func is_shop() -> bool:
	return ItemDefs.is_shop(type)


func set_net(p: Vector3, q: Quaternion) -> void:
	net_pos = p
	net_rot = q


func _physics_process(delta: float) -> void:
	if thrown_by_monster > 0.0:
		thrown_by_monster -= delta
	if _cart_label:
		_cart_t -= delta
		if _cart_t <= 0.0:
			_cart_t = 0.4
			_update_cart_value()
	if armed and _flag_light:
		_flag_light.light_energy = 2.0 if fmod(Time.get_ticks_msec() * 0.004, 1.0) < 0.5 else 0.2
	if server_side:
		hit_cd -= delta
		last_vel = linear_velocity
	else:
		var t := global_transform
		var k := minf(1.0, delta * 16.0)
		var q := t.basis.get_rotation_quaternion().slerp(net_rot.normalized(), k)
		global_transform = Transform3D(Basis(q), t.origin.lerp(net_pos, k))


func _on_body_entered(b: Node) -> void:
	if hit_cd > 0.0 or world == null:
		return
	var ov := Vector3.ZERO
	if b is RigidBody3D:
		ov = b.linear_velocity
	var sp := (last_vel - ov).length()
	if sp > 2.2:
		hit_cd = 0.12
		world.server_item_impact(self, sp, b)


func set_flag(f: String) -> void:
	match f:
		"armed":
			armed = true
			_ensure_light(Color(1.0, 0.2, 0.1))
		"drone_d_feather":
			_ensure_light(Color(0.6, 1.0, 0.7))
			_flag_light.light_energy = 1.2
			mass_scale = 0.12
		"drone_d_shield":
			_ensure_light(Color(1.0, 0.85, 0.3))
			_flag_light.light_energy = 1.2
			indestructible = true
		"owned":
			owned = true
		"drone_off":
			mass_scale = 1.0
			indestructible = false
			if _flag_light:
				_flag_light.light_energy = 0.0


func _ensure_light(c: Color) -> void:
	if _flag_light == null:
		_flag_light = OmniLight3D.new()
		_flag_light.omni_range = 1.5
		add_child(_flag_light)
	_flag_light.light_color = c


func _update_cart_value() -> void:
	if world == null:
		return
	var total := 0
	var inv := global_transform.affine_inverse()
	var hx := 0.6 if type == "cart" else 0.3
	var hz := 0.4 if type == "cart" else 0.2
	for it in world.items.values():
		if it == self or it.base_value <= 0 or it.is_shop():
			continue
		var lp: Vector3 = inv * it.global_position
		if absf(lp.x) < hx and absf(lp.z) < hz and lp.y > -0.3 and lp.y < 0.9:
			total += it.value
	_cart_label.text = "$" + Settings.money_k(total)
	cart_total = total


func held_changed() -> void:
	angular_damp = 4.0 if held > 0 else 0.6
	if held > 0:
		sleeping = false


func teleport(p: Vector3) -> void:
	var xf := Transform3D(global_transform.basis, p)
	PhysicsServer3D.body_set_state(get_rid(), PhysicsServer3D.BODY_STATE_TRANSFORM, xf)
	PhysicsServer3D.body_set_state(get_rid(), PhysicsServer3D.BODY_STATE_LINEAR_VELOCITY, Vector3.ZERO)
	PhysicsServer3D.body_set_state(get_rid(), PhysicsServer3D.BODY_STATE_SLEEPING, false)
	global_transform = xf
	net_pos = p
