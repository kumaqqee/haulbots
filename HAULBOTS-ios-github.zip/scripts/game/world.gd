extends Node3D
## One level: geometry, items, monsters, players, objectives and all gameplay RPCs.
## The host (or solo player) is authoritative for physics, AI and scoring.

const LevelGen = preload("res://scripts/game/level_gen.gd")
const ShopGen = preload("res://scripts/game/shop_gen.gd")
const ArenaGen = preload("res://scripts/game/arena_gen.gd")
const ItemScript = preload("res://scripts/game/item.gd")
const ItemDefs = preload("res://scripts/game/item_defs.gd")
const PlayerScript = preload("res://scripts/game/player.gd")
const MonsterScript = preload("res://scripts/game/monster.gd")
const HudScript = preload("res://scripts/ui/hud.gd")
const Fx = preload("res://scripts/game/fx.gd")
const VoiceScript = preload("res://scripts/game/voice.gd")
const ML = preload("res://scripts/game/matlib.gd")
const GearScript = preload("res://scripts/game/gear.gd")

var seed_val := 0
var level_num := 1
var gen = null
var items := {}
var monsters := {}
var players := {}
var local_player = null
var hud = null
var next_id := 1
var rng := RandomNumberGenerator.new()

var extr := []
var active_extr := -1
var extracting := false
var extract_t := 0.0
var beep_t := 0.0
var all_done := false
var quota_total := 0
var level_extracted := 0
var truck_pos := Vector3.ZERO
var truck_half := Vector3(2.5, 3.0, 2.5)
var truck_label: Label3D

var ready_peers := {}
var started := false
var ending := false
var grabs := {}
var noise := []
var game_time := 0.0
var state_t := 0.0
var full_t := 0.0
var zone_t := 0.0
var respawn_queue := []
var monsters_awake_msg := false
var shop_mode := false
var basket := 0
var shop_label: Label3D
var danger := 0.0
var alert := 0.0
var danger_t := 0.0
var music_level := 0.0

var items_root: Node3D
var monsters_root: Node3D
var players_root: Node3D
var fx_root: Node3D
var voice: Node = null
var visited := {}
var truck_healed := {}
var gear: Node = null
var tut_zone_seen := false


## Monster composition per tier, modelled on the reference game's table but a bit gentler early on.
static func roster_counts(lvl: int, diff: int) -> Array:
	var c: Array
	if lvl <= 1:
		c = [1, 1, 0]
	elif lvl == 2:
		c = [2, 1, 0]
	elif lvl <= 5:
		c = [1, 1, 1]
	elif lvl <= 8:
		c = [2, 2, 1]
	elif lvl <= 11:
		c = [2, 2, 2]
	elif lvl <= 19:
		c = [2, 3, 2]
	else:
		c = [3, 3, 3]
	if diff == 0:
		if c[2] > 0 and lvl < 6:
			c[2] -= 1
			c[0] += 1
		elif c[1] > 1:
			c[1] -= 1
	elif diff == 2:
		c[1] += 1
		if lvl >= 3:
			c[2] += 1
	return c


## Seconds monsters stay idle at level start (long on early levels, like the original).
func idle_time(r: RandomNumberGenerator) -> float:
	var lo := maxf(8.0, 110.0 - (level_num - 1) * 11.0)
	var hi := lo * 1.5
	var t: float = r.randf_range(lo, hi) * [1.4, 1.0, 0.6][clampi(Net.difficulty, 0, 2)]
	if r.randf() < 0.15:
		t *= 0.35
	return t


func respawn_delay(killed: bool) -> float:
	var base: float = rng.randf_range(150.0, 240.0) * [1.4, 1.0, 0.75][clampi(Net.difficulty, 0, 2)]
	if all_done:
		base *= 0.5
	return base * (2.0 if killed else 1.0)


## A monster that lost its prey walks off (sinks away) and returns later somewhere far.
func server_monster_leave(m) -> void:
	if m.state == MonsterScript.DEAD:
		return
	respawn_queue.append({"type": m.mtype, "t": game_time + respawn_delay(false)})
	for pid in grabs.keys():
		if grabs[pid]["id"] == m.mid:
			grabs.erase(pid)
	rpc("rpc_monster_event", m.mid, "leave")


func dmg_mult() -> float:
	return [0.5, 0.8, 1.15][clampi(Net.difficulty, 0, 2)]


func frag_mult() -> float:
	return [0.6, 0.85, 1.1][clampi(Net.difficulty, 0, 2)]


func is_server() -> bool:
	return multiplayer.is_server()


func sender() -> int:
	var s := multiplayer.get_remote_sender_id()
	return s if s != 0 else multiplayer.get_unique_id()


func _mk(n: String) -> Node3D:
	var x := Node3D.new()
	x.name = n
	add_child(x)
	return x


# ------------------------------------------------------------------ setup

func setup(s: int, l: int, shop := false, arena := false) -> void:
	seed_val = s
	level_num = l
	shop_mode = shop
	arena_mode = arena
	all_done = shop or arena
	rng.seed = s ^ 0x5bd1e995
	_make_env()
	gen = ArenaGen.new() if arena else (ShopGen.new() if shop else LevelGen.new())
	gen.build(s, l, self)
	items_root = _mk("Items")
	monsters_root = _mk("Monsters")
	players_root = _mk("Players")
	fx_root = _mk("Fx")
	truck_pos = gen.truck_pos
	_build_extractions()
	if not arena_mode:
		_build_truck_button()
	if shop_mode:
		_build_shop()
	var ids := Net.players.keys()
	ids.sort()
	for i in ids.size():
		_add_player(ids[i], i)
	gear = GearScript.new()
	gear.name = "Gear"
	gear.world = self
	add_child(gear)
	voice = VoiceScript.new()
	voice.name = "Voice"
	voice.world = self
	add_child(voice)
	hud = HudScript.new()
	hud.name = "HUD"
	add_child(hud)
	hud.setup(self)
	Net.players_changed.connect(_on_players_changed)
	apply_quality()
	if is_server():
		ready_peers[multiplayer.get_unique_id()] = true
		_try_start()
	else:
		rpc_id(1, "client_ready")
	if arena_mode:
		hud.intro_card(Settings.t("arena_title"), Settings.t("arena_sub"))
		return
	if shop_mode:
		var st: Dictionary = Net.last_stats
		if st.has("extracted"):
			hud.summary_card(st)
		hud.message(Settings.t("shop_welcome"))
		return
	var sub := Settings.t("loc_%d" % gen.location)
	if moon_phase(level_num) > 0:
		sub += "   ·   " + Settings.t("moon_%d" % moon_phase(level_num))
	hud.intro_card(Settings.t("hud_level") % level_num, sub)
	if Net.online and level_num == 1:
		hud.message(Settings.t("mic_hint"))
	if level_num == 1:
		get_tree().create_timer(4.0).timeout.connect(_show_tip)


func _show_tip() -> void:
	if is_instance_valid(hud):
		hud.message(Settings.t("msg_tip1"))


const PostShader = preload("res://assets/shaders/postfx.gdshader")
var env: Environment = null
var post_rect: ColorRect = null
var _shadow_t := 0.0
var _res_max := 1.0
var _res_scale := 1.0
var _perf_acc := 0.0
var _perf_frames := 0
var _perf_good := 0


func _make_env() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.008, 0.008, 0.012)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	# dim, dusty, desaturated look of the reference game: dark corners, the flashlight matters
	env.ambient_light_color = Color(0.46, 0.45, 0.5)
	env.ambient_light_energy = 0.1 if not shop_mode else 0.24
	env.tonemap_mode = Environment.TONE_MAPPER_AGX
	env.tonemap_exposure = 1.0 * Settings.brightness
	env.tonemap_white = 6.0
	env.fog_enabled = true
	env.fog_mode = Environment.FOG_MODE_EXPONENTIAL
	env.fog_light_color = Color(0.022, 0.022, 0.026)
	env.fog_density = 0.034
	if arena_mode:
		env.ambient_light_energy = 0.3
		env.fog_light_color = Color(0.09, 0.02, 0.015)
		env.fog_density = 0.014
		env.fog_height_density = 0.0
	env.fog_sky_affect = 0.0
	env.fog_height = 0.35
	env.fog_height_density = 0.07
	env.glow_enabled = Settings.quality >= 1
	env.glow_intensity = 0.7
	env.glow_strength = 1.0
	env.glow_bloom = 0.04
	env.glow_hdr_threshold = 0.9
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	env.set_glow_level(1, 1.0)
	env.set_glow_level(2, 0.8)
	env.set_glow_level(3, 0.6)
	env.set_glow_level(5, 0.3)
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.18, 0.16, 0.14)
	sm.sky_horizon_color = Color(0.35, 0.3, 0.25)
	sm.ground_bottom_color = Color(0.06, 0.05, 0.05)
	sm.ground_horizon_color = Color(0.3, 0.26, 0.22)
	sky.sky_material = sm
	env.sky = sky
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.14
	env.adjustment_saturation = 0.78
	env.adjustment_brightness = 1.0
	we.environment = env
	add_child(we)
	# full-screen film look (vignette, grain, edge aberration) under the HUD
	var cl := CanvasLayer.new()
	cl.layer = 1
	add_child(cl)
	post_rect = ColorRect.new()
	post_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	post_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var pm := ShaderMaterial.new()
	pm.shader = PostShader
	post_rect.material = pm
	cl.add_child(post_rect)
	apply_quality()
	Settings.changed.connect(apply_quality)


## Applies the graphics preset (0 low, 1 medium, 2 high) to the running level.
func apply_quality() -> void:
	var q := Settings.quality
	var vp := get_viewport()
	if env:
		env.tonemap_exposure = Settings.brightness * (0.86 if moon_phase(level_num) >= 3 and not shop_mode else 1.0)
	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
	_res_max = [0.7, 0.85, 1.0][q] as float
	_res_scale = _res_max
	vp.scaling_3d_scale = _res_scale
	vp.msaa_3d = Viewport.MSAA_2X if q == 2 else Viewport.MSAA_DISABLED
	if env:
		env.glow_enabled = q >= 1
	if post_rect:
		post_rect.visible = q >= 1 and Settings.film_fx
	if local_player and local_player.flashlight:
		local_player.flashlight.shadow_enabled = q >= 1
		local_player.set_light_cone(q >= 1)
	_shadow_t = 0.0


## Dynamic resolution: when the phone can't hold the target frame rate, render the 3D view a bit
## smaller (HUD stays sharp) instead of stuttering; climb back to full quality when there is headroom.
func _adapt_resolution(fps: float) -> void:
	var vp := get_viewport()
	if not Settings.adaptive_res:
		if _res_scale != _res_max:
			_res_scale = _res_max
			vp.scaling_3d_scale = _res_scale
		return
	var target := float(Settings.fps_cap)
	var hz := DisplayServer.screen_get_refresh_rate()
	if hz > 20.0:
		target = minf(target, hz)
	var mn := maxf(0.5, _res_max - 0.3)
	var old := _res_scale
	if fps < target * 0.86:
		_res_scale = maxf(mn, _res_scale - (0.1 if fps < target * 0.6 else 0.05))
		_perf_good = 0
	elif fps > target * 0.96:
		_perf_good += 1
		if _perf_good >= 3:
			_res_scale = minf(_res_max, _res_scale + 0.05)
			_perf_good = 0
	else:
		_perf_good = 0
	if _res_scale != old:
		vp.scaling_3d_scale = _res_scale
		# MSAA only while we are at full resolution
		vp.msaa_3d = Viewport.MSAA_2X if Settings.quality == 2 and _res_scale >= _res_max - 0.001 else Viewport.MSAA_DISABLED


## Only the few lamps closest to the local player cast shadows (cheap on phones).
func _update_light_shadows() -> void:
	if gen == null or local_player == null:
		return
	var maxn: int = [0, 1, 3][Settings.quality]
	var p: Vector3 = local_player.global_position
	var arr := []
	for l in gen.lights:
		arr.append([l["light"].global_position.distance_squared_to(p), l["light"]])
	arr.sort_custom(func(a, b): return a[0] < b[0])
	for i in arr.size():
		var lt: OmniLight3D = arr[i][1]
		var on: bool = i < maxn and arr[i][0] < 196.0
		if lt.shadow_enabled != on:
			lt.shadow_enabled = on


func _add_player(pid: int, idx: int) -> void:
	var p = PlayerScript.new()
	p.name = "P%d" % pid
	p.peer_id = pid
	p.is_local = pid == multiplayer.get_unique_id()
	p.world = self
	players_root.add_child(p)
	p.global_position = gen.spawn_points[idx % gen.spawn_points.size()]
	p.net_pos = p.global_position
	players[pid] = p
	if p.is_local:
		local_player = p


func _on_players_changed() -> void:
	for pid in players.keys():
		if not Net.players.has(pid):
			var p = players[pid]
			players.erase(pid)
			grabs.erase(pid)
			ready_peers.erase(pid)
			p.queue_free()
	if is_server():
		_try_start()
		_check_all_dead()


func server_peer_left(pid: int, pname: String) -> void:
	_end_grab(pid)
	rpc_message("msg_player_left", [pname])


@rpc("any_peer", "call_local", "reliable")
func client_ready() -> void:
	if not is_server():
		return
	ready_peers[sender()] = true
	_try_start()


func _try_start() -> void:
	if started:
		return
	for pid in Net.players:
		if not ready_peers.has(pid) and game_time < 15.0:
			return
	started = true
	if arena_mode:
		_server_populate_arena()
	elif shop_mode:
		_server_populate_shop()
	else:
		_server_populate()


var map_value := 0
var arena_mode := false
var arena_t := 0.0
var arena_ring := 0        # next ring to drop (counts down from the rim)
var arena_warned := false
# run statistics for the end-of-level summary
var stat_broken := 0
var stat_lost := 0
var stat_kills := 0
var stat_deaths := 0
# aim highlight + floating value tag (local only)
const HighlightShader = preload("res://assets/shaders/highlight.gdshader")
var _hl_target = null
var _hl_mat: ShaderMaterial = null
var _hl_tag: Label3D = null
var _hl_h := 0.4
var buying := false
var buy_t := 0.0
var shop_pad := {}
var leaving := false
var leave_t := 0.0
var _leave_beep := 0.0


## "Moon phase" like the reference game: every 5 levels monsters get tougher, cores are worth more,
## and from the full moon on the house gets darker.
static func moon_phase(l: int) -> int:
	return 0 if l < 5 else (1 if l < 10 else (2 if l < 15 else (3 if l < 20 else 4)))


static func valuables_for_level(l: int) -> int:
	return clampi(13 + 2 * l, 15, 34)


static func haul_curve(l: int) -> float:
	return clampf(0.4 + 0.0333 * (l - 1), 0.4, 1.0)


func _server_populate() -> void:
	var r := RandomNumberGenerator.new()
	r.seed = seed_val + 77
	var basis_total := 0.0
	# REPO-style haul: a limited number of valuables per level (fewer, pricier, fragile),
	# growing slowly with the level; heavy pieces become more common later.
	var spots: Array = gen.item_spots.duplicate()
	for i in range(spots.size() - 1, 0, -1):
		var j := r.randi_range(0, i)
		var tmp = spots[i]
		spots[i] = spots[j]
		spots[j] = tmp
	var want := valuables_for_level(level_num)
	var placed := 0
	for spot in spots:
		if placed >= want:
			break
		var type := ""
		for attempt in 4:
			type = ItemDefs.pick_type(r, spot["kind"], level_num, gen.location, true)
			if type != "":
				break
		if type == "":
			continue
		var val := ItemDefs.roll_value(r, type, level_num)
		var m: float = ItemDefs.DEFS[type]["mass"]
		basis_total += val if m <= 15.0 else val * 0.5
		var rot := Quaternion(Vector3.UP, r.randf() * TAU)
		spawn_item(type, val, spot["pos"] + Vector3(0, ItemDefs.spawn_lift(type), 0), rot, 0)
		placed += 1
	map_value = int(basis_total)
	spawn_item("cart", 0, gen.cart_pos, Quaternion.IDENTITY, 0)
	# everything the crew bought (and has not used up) waits in the van, like the reference game
	for e in Net.truck_items:   # saves from older versions
		Net.add_owned(str(e["t"]), float(e.get("b", 1.0)))
	Net.truck_items = []
	var in_inv := Net.inv_uids()
	var ti := 0
	for e in Net.owned:
		if in_inv.has(int(e["u"])):
			continue
		var col := ti % 3
		var row := (ti / 3) % 3
		var lay := ti / 9
		var tp: Vector3 = truck_pos + gen.truck_side * (col - 1) * 0.55 + gen.truck_back * (row - 1) * 0.6 + Vector3(0, 0.35 + lay * 0.35, 0)
		var oid := spawn_item(str(e["t"]), 0, tp, Quaternion.IDENTITY, 0, float(e.get("b", 1.0)))
		if items.has(oid):
			items[oid].uid = int(e["u"])
			var ot := str(e["t"])
			if ot.begins_with("up_") or ot.begins_with("med_") or ot == "i_crystal":
				rpc("rpc_item_flag", oid, "owned")
		ti += 1
	# Haul goal like the reference game: 70% of what the map holds, times a difficulty curve that
	# starts at 0.4 on level 1 and reaches 1.0 around level 19; split evenly between the points.
	var n := extr.size()
	var qf: float = 0.7 * haul_curve(level_num) * [0.75, 1.0, 1.15][clampi(Net.difficulty, 0, 2)]
	var goal_each := maxi(1000, int(round(basis_total * qf / n / 100.0)) * 100)
	quota_total = goal_each * n
	for e in extr:
		e["goal"] = goal_each
	# monsters: tiered roster like the reference game
	var tiers := {1: [], 2: [], 3: []}
	for k in MonsterScript.TYPES:
		tiers[int(MonsterScript.TYPES[k]["tier"])].append(k)
	var diff := clampi(Net.difficulty, 0, 2)
	var comp := roster_counts(level_num, diff)
	var roster := []
	for tier in [1, 2, 3]:
		for i in comp[tier - 1]:
			roster.append(tiers[tier][r.randi() % tiers[tier].size()])
	var floor_spots := []
	for sp in gen.item_spots:
		if sp["kind"] == "floor" and LevelGen.cell_at(sp["pos"]) != gen.spawn_cell:
			floor_spots.append(sp["pos"])
	var cells: Array = gen.monster_cells.duplicate()
	for i in roster.size():
		var t: String = roster[i]
		var c: Vector2i = cells[r.randi() % cells.size()]
		var pos: Vector3 = LevelGen.cell_center(c) + Vector3(r.randf_range(-1.5, 1.5), 0.1, r.randf_range(-1.5, 1.5))
		if t == "mimic" and floor_spots.size() > 0:
			pos = floor_spots[r.randi() % floor_spots.size()] + Vector3(0, 0.05, 0)
		if t == "eye":
			pos = LevelGen.cell_center(c) + Vector3(r.randf_range(-2.0, 2.0), LevelGen.H, r.randf_range(-2.0, 2.0))
		var grp: int = MonsterScript.TYPES[t]["group"]
		for g in grp:
			var off := Vector3(cos(g * 2.1) * 0.7, 0, sin(g * 2.1) * 0.7) if g > 0 else Vector3.ZERO
			var mid := spawn_monster(t, pos + off)
			if not (t in ["mimic", "eye"]):
				monsters[mid].dormant = idle_time(r)
				monsters[mid].lurking = true
	active_extr = 0
	_broadcast_extr()
	rpc("rpc_begin")


@rpc("authority", "call_local", "reliable")
func rpc_begin() -> void:
	started = true
	Sfx.play("beep_hi")


# ------------------------------------------------------------------ items

func spawn_item(type: String, value: int, pos: Vector3, rot: Quaternion, extra: int, bat := 1.0) -> int:
	var id := next_id
	next_id += 1
	rpc("rpc_spawn_item", id, type, value, pos, rot, extra, bat)
	return id


@rpc("authority", "call_local", "reliable")
func rpc_item_flag(id: int, f: String) -> void:
	var it = items.get(id)
	if it:
		it.set_flag(f)


@rpc("authority", "call_local", "reliable")
func rpc_spawn_item(id: int, type: String, value: int, pos: Vector3, rot: Quaternion, extra: int, bat: float) -> void:
	if items.has(id):
		return
	var it = ItemScript.new()
	it.name = "I%d" % id
	it.item_id = id
	it.type = type
	it.value = value
	it.base_value = value
	it.extra = extra
	it.battery = bat
	it.synced_battery = bat
	it.world = self
	it.server_side = is_server()
	items_root.add_child(it)
	it.global_transform = Transform3D(Basis(rot), pos)
	it.net_pos = pos
	it.net_rot = rot
	items[id] = it


@rpc("authority", "call_local", "reliable")
func rpc_broken_text(pos: Vector3, base: int) -> void:
	Fx.float_text(fx_root, pos + Vector3(0, 0.4, 0), Settings.t("broken_tag") % Settings.money_k(base), Color(1.0, 0.25, 0.2), 72)


func remove_item(id: int, fx: int) -> void:
	rpc("rpc_remove_item", id, fx)


@rpc("authority", "call_local", "reliable")
func rpc_remove_item(id: int, fx: int) -> void:
	var it = items.get(id)
	if it == null:
		return
	items.erase(id)
	var pos: Vector3 = it.global_position
	if fx == 1:
		Fx.shatter(fx_root, pos, it.main_color)
		Sfx.play("break", pos, 2.0)
	elif fx == 2:
		Fx.sparkle(fx_root, pos)
	for pid in grabs.keys():
		if grabs[pid]["id"] == id:
			grabs.erase(pid)
	if local_player and local_player.grabbed_id == id:
		local_player.force_release()
	it.queue_free()


@rpc("authority", "call_remote", "unreliable_ordered")
func rpc_items_state(ids: PackedInt32Array, data: PackedFloat32Array) -> void:
	for i in ids.size():
		var it = items.get(ids[i])
		if it == null:
			continue
		var o := i * 7
		it.set_net(Vector3(data[o], data[o + 1], data[o + 2]), Quaternion(data[o + 3], data[o + 4], data[o + 5], data[o + 6]))


@rpc("authority", "call_local", "reliable")
func rpc_item_value(id: int, v: int, dmg: int) -> void:
	var it = items.get(id)
	if it == null:
		return
	it.value = v
	Fx.float_text(fx_root, it.global_position + Vector3(0, 0.3, 0), "-$" + Settings.money(dmg), Color(1.0, 0.3, 0.25))
	Sfx.play("clink" if it.glass else "thud", it.global_position, 0.0, randf_range(0.9, 1.1))


@rpc("authority", "call_local", "unreliable")
func rpc_item_sound(id: int, speed: float) -> void:
	var it = items.get(id)
	if it:
		Sfx.play("thud", it.global_position, clampf(-14.0 + speed * 1.5, -14.0, 0.0), randf_range(0.8, 1.2))
		if speed > 5.0:
			Fx.impact_dust(fx_root, it.global_position, speed)


func server_item_impact(it, speed: float, body) -> void:
	if not is_server() or ending:
		return
	add_noise(it.global_position, clampf(speed * sqrt(it.mass) * 0.2, 0.3, 3.0))
	if body != null and body.is_in_group("monster") and speed > 3.0 and game_time >= float(it.get_meta("mon_hit_t", -1.0)):
		it.set_meta("mon_hit_t", game_time + 0.45)
		var mult: float = ItemDefs.DEFS[it.type].get("melee", 1.0)
		body.take_hit(minf(speed * it.mass * 1.6 * mult, 150.0))
		if mult > 1.0:
			gear.use_battery(it, ItemDefs.DEFS[it.type].get("cost", 0.1))
			if it.type == "w_prod":
				body.stun(4.0)
			elif it.type == "w_pan" and speed > 4.0:
				body.stun(1.2)
		if body.mtype == "puff":
			body.provoke(it.last_holder)
	if arena_mode and body != null and body.is_in_group("player") and it.held > 0 and it.last_holder != body.peer_id \
			and speed > 3.0 and game_time >= float(it.get_meta("pl_hit_t", -1.0)):
		it.set_meta("pl_hit_t", game_time + 0.45)
		var mm: float = ItemDefs.DEFS[it.type].get("melee", 1.0)
		server_damage_player(body.peer_id, clampf(speed * it.mass * mm * 0.9, 6.0, 45.0), it.linear_velocity.normalized() * minf(speed, 7.0) + Vector3(0, 2.0, 0))
	if body != null and body.is_in_group("player") and it.thrown_by_monster <= 0.0 and speed > 5.0 and it.mass >= 1.5 \
			and it.held == 0 and it.last_holder != body.peer_id and game_time >= float(it.get_meta("pl_hit_t", -1.0)):
		# flung objects hurt whoever they hit (friendly fire included, like the reference game)
		it.set_meta("pl_hit_t", game_time + 0.5)
		server_damage_player(body.peer_id, clampf(speed * it.mass * 0.5, 4.0, 22.0) * dmg_mult(), it.linear_velocity.normalized() * minf(speed * 0.6, 5.0))
	if body != null and body.is_in_group("player") and it.thrown_by_monster > 0.0 and speed > 4.0:
		server_damage_player(body.peer_id, clampf(speed * it.mass * 1.2, 10.0, 90.0) * dmg_mult(), it.linear_velocity.normalized() * 4.0)
		it.thrown_by_monster = 0.0
	var dmg := 0
	if it.fragility > 0.0 and it.base_value > 0 and speed > 2.6 and not it.indestructible and not is_protected(it):
		dmg = int((speed - 2.6) * it.fragility * it.base_value * 0.035 * frag_mult())
	if dmg > 0:
		it.value -= dmg
		stat_lost += dmg
		if it.value <= int(it.base_value * 0.08):
			add_noise(it.global_position, 3.0)
			stat_broken += 1
			stat_lost += maxi(0, it.value)
			rpc("rpc_broken_text", it.global_position, it.base_value)
			remove_item(it.item_id, 1)
		else:
			rpc("rpc_item_value", it.item_id, it.value, dmg)
	elif speed > 3.0:
		rpc("rpc_item_sound", it.item_id, speed)


## Like the reference game: valuables resting in a cart or on an extraction pad don't break.
func is_protected(it) -> bool:
	var p: Vector3 = it.global_position
	for e in extr:
		if not e["done"] and _in_zone(p, e["pos"], 1.6):
			return true
	for c in items.values():
		if c == it or not (c.type == "cart" or c.type == "i_pocketcart"):
			continue
		var lp: Vector3 = c.global_transform.affine_inverse() * p
		var hx := 0.64 if c.type == "cart" else 0.33
		var hz := 0.44 if c.type == "cart" else 0.23
		if absf(lp.x) < hx and absf(lp.z) < hz and lp.y > -0.35 and lp.y < 0.95:
			return true
	return false


func add_noise(pos: Vector3, loud: float) -> void:
	noise.append({"pos": pos, "loud": loud, "t": game_time})
	if noise.size() > 24:
		noise.pop_front()


# ------------------------------------------------------------------ grabbing (host)

@rpc("any_peer", "call_local", "unreliable_ordered")
func rpc_grab_update(id: int, target: Vector3, offset: Vector3) -> void:
	if not is_server():
		return
	var pid := sender()
	if not players.has(pid) or players[pid].dead:
		return
	var kind := ""
	if id > 0 and items.has(id):
		kind = "item"
	elif id > 0 and monsters.has(id):
		kind = "mon"
	elif id < 0 and players.has(-id) and -id != pid and not players[-id].dead:
		kind = "player"
	if kind == "":
		return
	var g = grabs.get(pid)
	if pid != 1:
		set_meta("client_grabbed", true)
	if g == null or g["id"] != id:
		if g != null:
			_end_grab(pid)
		grabs[pid] = {"id": id, "target": target, "offset": offset, "t": game_time, "kind": kind}
		if kind == "item":
			items[id].held += 1
			items[id].held_changed()
	else:
		g["target"] = target
		g["offset"] = offset
		g["t"] = game_time


@rpc("any_peer", "call_local", "reliable")
func rpc_grab_release(_id: int, throw_dir: Vector3) -> void:
	if not is_server():
		return
	var pid := sender()
	var g = grabs.get(pid)
	if g == null:
		return
	var gid: int = g["id"]
	var it = items.get(gid) if gid > 0 else null
	var mon = monsters.get(gid) if gid > 0 and it == null else null
	_end_grab(pid)
	if it and throw_dir != Vector3.ZERO:
		var imp := minf(Net.strength(pid) * 0.12, it.mass * it.mass_scale * 12.0)
		it.apply_central_impulse(throw_dir.normalized() * imp)
	elif mon and throw_dir != Vector3.ZERO:
		mon.release_throw(throw_dir.normalized() * clampf(Net.strength(pid) * 0.12 / maxf(mon.weight(), 1.0), 1.0, 12.0))
	elif mon:
		mon.release_throw(Vector3.ZERO)
	elif gid < 0 and throw_dir != Vector3.ZERO:
		send_effect(-gid, "impulse", throw_dir.normalized() * 7.0 + Vector3(0, 2.0, 0), 0.0)


func _end_grab(pid: int) -> void:
	var g = grabs.get(pid)
	if g == null:
		return
	grabs.erase(pid)
	if g.get("kind", "item") == "mon":
		var m = monsters.get(g["id"])
		if m and m.state == MonsterScript.HELD:
			m.release_throw(Vector3.ZERO)
		return
	if g.get("kind", "item") != "item":
		return
	var it = items.get(g["id"])
	if it:
		it.held = maxi(0, it.held - 1)
		it.held_changed()


func _any_owned() -> bool:
	for it in items.values():
		if it.owned:
			return true
	return false


func gobj(id: int):
	if id == -1 or id == 0:
		return null
	if id < 0:
		return players.get(-id)
	var it = items.get(id)
	return it if it != null else monsters.get(id)


func _apply_grabs() -> void:
	var mon_strength := {}
	var mon_target := {}
	for pid in grabs.keys():
		var g = grabs[pid]
		var kind: String = g.get("kind", "item")
		if game_time - float(g["t"]) > 0.45 or not players.has(pid):
			_end_grab(pid)
			continue
		if kind == "mon":
			var m = monsters.get(g["id"])
			if m == null or m.state == MonsterScript.DEAD:
				_end_grab(pid)
				continue
			mon_strength[m] = mon_strength.get(m, 0.0) + Net.strength(pid)
			mon_target[m] = g["target"]
			continue
		if kind == "player":
			var tp = players.get(-int(g["id"]))
			if tp == null or tp.dead:
				_end_grab(pid)
				continue
			var pv: Vector3 = (g["target"] - (tp.global_position + Vector3(0, 0.9, 0))) * 6.0
			if pv.length() > 8.0:
				pv = pv.normalized() * 8.0
			send_effect(tp.peer_id, "pull_to", pv, 0.25)
			# like the reference game: holding a teammate passes them 10 HP/s of your own health
			var dt := get_physics_process_delta_time()
			var mine: float = float(Net.hp.get(pid, 0.0))
			var theirs: float = float(Net.hp.get(tp.peer_id, 0.0))
			var mx: float = Net.max_hp(tp.peer_id)
			if mine > 11.0 and theirs < mx:
				var amt := minf(10.0 * dt, minf(mine - 10.0, mx - theirs))
				Net.hp[pid] = mine - amt
				Net.hp[tp.peer_id] = theirs + amt
				g["heal_acc"] = float(g.get("heal_acc", 0.0)) + dt
				if float(g["heal_acc"]) >= 0.25:
					g["heal_acc"] = 0.0
					rpc("rpc_player_hp", pid, float(Net.hp[pid]), false, Vector3.ZERO)
					rpc("rpc_player_hp", tp.peer_id, float(Net.hp[tp.peer_id]), false, Vector3.ZERO)
			continue
		var it = items.get(g["id"])
		if it == null:
			_end_grab(pid)
			continue
		it.last_holder = pid
		if (it.type == "cart" or it.type == "i_pocketcart") and (g["offset"] as Vector3).x < (-0.45 if it.type == "cart" else -0.28):
			# STRONG grip (by the handle): the cart snaps in front of you and turns with you.
			# Grabbed anywhere else it is a WEAK grip and behaves like any other object.
			_push_cart(it, pid)
			continue
		var pw: Vector3 = it.global_transform * g["offset"]
		var to: Vector3 = g["target"] - pw
		var desired := to * 10.0
		if desired.length() > 9.0:
			desired = desired.normalized() * 9.0
		var n := maxi(1, it.held)
		var accel: Vector3 = (desired - it.linear_velocity) * 12.0
		var em: float = it.mass * it.mass_scale
		var force: Vector3 = (accel * em + Vector3(0, 9.8 * it.mass, 0) - Vector3(0, 9.8 * it.mass * (1.0 - it.mass_scale), 0)) / n
		var fmax := Net.strength(pid)
		if force.length() > fmax:
			force = force.normalized() * fmax
		it.apply_force(force, pw - it.global_position)
	for m in mon_strength:
		m.grab_hold(mon_target[m], mon_strength[m])


func _push_cart(it, pid: int) -> void:
	# carts are steered by their handle: they stay in front of the pusher and turn with them
	var p = players[pid]
	var fwd: Vector3 = p.look_dir()
	fwd.y = 0.0
	if fwd.length() < 0.01:
		return
	fwd = fwd.normalized()
	var dist := 1.35 if it.type == "cart" else 1.0
	var target: Vector3 = p.global_position + fwd * dist
	var to: Vector3 = target - it.global_position
	to.y = 0.0
	var desired := to * 8.0
	if desired.length() > 7.0:
		desired = desired.normalized() * 7.0
	var hv := Vector3(it.linear_velocity.x, 0, it.linear_velocity.z)
	var force: Vector3 = (desired - hv) * 10.0 * it.mass
	it.apply_central_force(force.limit_length(Net.strength(pid) * 3.0))
	# yaw alignment: cart +X axis follows the look direction
	var ax: Vector3 = it.global_transform.basis.x
	ax.y = 0.0
	var ang := ax.normalized().signed_angle_to(fwd, Vector3.UP)
	var torque: Vector3 = Vector3(0, ang * 60.0 - it.angular_velocity.y * 12.0, 0) * it.mass * 0.2
	it.apply_torque(torque)


# ------------------------------------------------------------------ effects & area attacks

func send_effect(pid: int, kind: String, v: Vector3, dur: float) -> void:
	if not players.has(pid):
		return
	if pid == multiplayer.get_unique_id():
		players[pid].apply_effect(kind, v, dur)
	elif Net.online:
		rpc_id(pid, "rpc_effect", kind, v, dur)


@rpc("any_peer", "call_remote", "unreliable")
func rpc_push_item(id: int, imp: Vector3, at: Vector3) -> void:
	if not is_server():
		return
	var it = items.get(id)
	if it == null or imp.length() > 8.0:
		return
	it.apply_impulse(imp, at - it.global_position)


@rpc("authority", "call_remote", "unreliable_ordered")
func rpc_effect(kind: String, v: Vector3, dur: float) -> void:
	if local_player:
		local_player.apply_effect(kind, v, dur)


@rpc("authority", "call_local", "reliable")
func rpc_fx(kind: String, pos: Vector3, a: float) -> void:
	match kind:
		"explosion":
			Fx.explosion(fx_root, pos, a)
			Sfx.play("break", pos, 10.0, 0.4)
			Sfx.play("thud", pos, 10.0, 0.5)
			if local_player and local_player.global_position.distance_to(pos) < 12.0:
				local_player.shake = 0.6
		"stun":
			Fx.sparks(fx_root, pos, Color(0.4, 0.7, 1.0), 40, 6.0, 0.7)
			Fx.shockwave(fx_root, pos, 3.5, Color(0.4, 0.7, 1.0))
			Fx.flash(fx_root, pos, Color(0.5, 0.7, 1.0), 5.0, 7.0, 0.3)
			Sfx.play("beep_hi", pos, 8.0, 0.5)
		"shock":
			Fx.sparks(fx_root, pos, Color(1.0, 0.85, 0.4), 50, 8.0, 0.5)
			Fx.shockwave(fx_root, pos, 3.0, Color(1.0, 0.85, 0.4), 0.3)
			Fx.flash(fx_root, pos, Color(1.0, 0.9, 0.5), 5.0, 6.0, 0.25)
			Sfx.play("thud", pos, 8.0, 0.4)
		"vomit":
			Fx.burst(fx_root, pos, Color(0.5, 0.7, 0.1), 8, 3.0, -9.0, 0.6, 0.06)
		"muzzle":
			Fx.sparks(fx_root, pos, Color(1.0, 0.8, 0.4), 10, 4.0, 0.2)
			Fx.flash(fx_root, pos, Color(1.0, 0.8, 0.5), 4.0, 5.0, 0.12)
			Fx.smoke(fx_root, pos, Color(0.6, 0.6, 0.6, 0.35), 4, 0.25, 0.8, 0.5, 0.3)
			Sfx.play("thud", pos, 4.0, 1.8 if a < 1.5 else 1.0)
		"tracer":
			pass


func _players_in(center: Vector3, radius: float) -> Array:
	var out := []
	for p in players.values():
		if not p.dead and p.global_position.distance_to(center) < radius:
			out.append(p)
	return out


func _los_world(a: Vector3, b: Vector3) -> bool:
	var q := PhysicsRayQueryParameters3D.create(a, b, 1)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func server_damage_item(it, frac: float) -> void:
	if it == null or it.base_value <= 0 or it.indestructible:
		return
	var dmg := int(it.base_value * frac)
	it.value -= dmg
	if it.value <= int(it.base_value * 0.08):
		remove_item(it.item_id, 1)
	else:
		rpc("rpc_item_value", it.item_id, it.value, dmg)


func server_explosion(pos: Vector3, radius: float, player_dmg: float, mon_dmg: float, src = null) -> void:
	rpc("rpc_fx", "explosion", pos, radius / 4.0)
	add_noise(pos, 3.5)
	for p in _players_in(pos, radius):
		var d: float = p.global_position.distance_to(pos)
		var k := 1.0 - d / radius
		var dir: Vector3 = (p.global_position - pos).normalized()
		server_damage_player(p.peer_id, player_dmg * (0.3 + 0.7 * k), dir * 9.0 * k + Vector3(0, 4.0 * k, 0))
	for m in monsters.values():
		if m == src or m.state == MonsterScript.DEAD:
			continue
		var d2: float = m.global_position.distance_to(pos)
		if d2 < radius:
			m.take_hit(mon_dmg * (0.4 + 0.6 * (1.0 - d2 / radius)))
	for it in items.values().duplicate():
		if not is_instance_valid(it):
			continue
		var d3: float = it.global_position.distance_to(pos)
		if d3 < radius * 1.3:
			var k3 := 1.0 - d3 / (radius * 1.3)
			it.apply_central_impulse((it.global_position - pos).normalized() * it.mass * 9.0 * k3 + Vector3(0, it.mass * 3.0 * k3, 0))
			if d3 < radius:
				server_damage_item(it, 0.35 * k3)


func server_stun_area(pos: Vector3, radius: float, sec: float) -> void:
	rpc("rpc_fx", "stun", pos, 1.0)
	for m in monsters.values():
		if m.state != MonsterScript.DEAD and m.global_position.distance_to(pos) < radius:
			m.stun(sec)
	for p in _players_in(pos, radius):
		send_effect(p.peer_id, "stunned", Vector3.ZERO, sec * 0.5)


func server_vomit(pid: int, delta: float) -> void:
	var v = players.get(pid)
	if v == null:
		return
	var from: Vector3 = v.eye_pos()
	var dir: Vector3 = v.look_dir()
	server_damage_player(pid, 2.5 * dmg_mult() * delta, Vector3.ZERO)
	if randf() < delta * 6.0:
		rpc("rpc_fx", "vomit", from + dir * 0.5, 1.0)
	for p in players.values():
		if p == v or p.dead:
			continue
		var to: Vector3 = p.global_position + Vector3(0, 1.0, 0) - from
		if to.length() < 3.5 and dir.dot(to.normalized()) > 0.7:
			server_damage_player(p.peer_id, 10.0 * delta * dmg_mult(), Vector3.ZERO)


func server_scream(mon, radius: float, sec: float) -> void:
	var c: Vector3 = mon.global_position + Vector3(0, 1.2, 0)
	for p in _players_in(c, radius):
		if _los_world(c, p.global_position + Vector3(0, 1.0, 0)):
			var dir: Vector3 = (p.global_position - mon.global_position)
			dir.y = 0.0
			send_effect(p.peer_id, "impulse", dir.normalized() * 8.0 + Vector3(0, 2.5, 0), 0.0)
			send_effect(p.peer_id, "stunned", Vector3.ZERO, sec)
			server_damage_player(p.peer_id, float(mon.cfg["dmg"]) * dmg_mult(), Vector3.ZERO)
	for it in items.values():
		var d: float = it.global_position.distance_to(c)
		if d < radius * 0.7:
			it.apply_central_impulse((it.global_position - c).normalized() * it.mass * 4.0)


func server_antigrav(center: Vector3, radius: float, delta: float) -> void:
	for p in _players_in(center, radius):
		send_effect(p.peer_id, "float", Vector3.ZERO, 0.4)
	for it in items.values():
		if it.global_position.distance_to(center) < radius and not it.freeze:
			var lift := 1.0 if it.global_position.y < center.y + 1.6 else 0.9
			it.apply_central_force(Vector3(0, 9.8 * it.mass * lift + it.mass * 1.5 * (1.0 if it.global_position.y < center.y + 1.6 else -1.0), 0))
			it.sleeping = false


func server_slam(center: Vector3, radius: float, dmg: float) -> void:
	rpc("rpc_fx", "shock", center, 1.0)
	for p in _players_in(center, radius + 1.0):
		send_effect(p.peer_id, "impulse", Vector3(0, -14.0, 0), 0.0)
		server_damage_player(p.peer_id, dmg, Vector3.ZERO)
	for it in items.values():
		if it.global_position.distance_to(center) < radius + 1.0:
			it.apply_central_impulse(Vector3(0, -it.mass * 10.0, 0))


func server_pull(center: Vector3, radius: float, strength: float) -> void:
	for p in _players_in(center, radius):
		var dir: Vector3 = center - p.global_position
		dir.y = 0.0
		send_effect(p.peer_id, "pull_to", dir.normalized() * strength, 0.2)


func server_shock(center: Vector3, radius: float, dmg: float, src) -> void:
	rpc("rpc_fx", "shock", center + Vector3(0, 0.2, 0), 1.0)
	add_noise(center, 3.0)
	for p in _players_in(center, radius):
		server_damage_player(p.peer_id, dmg, (p.global_position - center).normalized() * 10.0 + Vector3(0, 4.0, 0))
	for it in items.values():
		var d: float = it.global_position.distance_to(center)
		if d < radius * 1.5:
			it.apply_central_impulse((it.global_position - center).normalized() * it.mass * 6.0 + Vector3(0, it.mass * 5.0, 0))
			server_damage_item(it, 0.2)


func server_beam(mon, from: Vector3, dir: Vector3, length: float, dmg: float) -> void:
	for p in players.values():
		if p.dead:
			continue
		var pp: Vector3 = p.global_position + Vector3(0, 1.0, 0)
		var rel := pp - from
		var t := rel.dot(dir)
		if t < 0.0 or t > length:
			continue
		var closest := from + dir * t
		if closest.distance_to(pp) < 0.7 and _los_world(from, pp):
			server_damage_player(p.peer_id, dmg, Vector3.ZERO)


func server_shotgun(mon, from: Vector3, target: Vector3, dmg: float) -> void:
	var dir := (target - from).normalized()
	rpc("rpc_fx", "muzzle", from + dir * 0.8, 2.0)
	add_noise(from, 3.0)
	for p in players.values():
		if p.dead:
			continue
		var to: Vector3 = p.global_position + Vector3(0, 1.0, 0) - from
		var d := to.length()
		if d < 22.0 and dir.dot(to / d) > 0.93 and _los_world(from, p.global_position + Vector3(0, 1.0, 0)):
			var k := clampf(1.0 - (d - 5.0) / 17.0, 0.25, 1.0)
			server_damage_player(p.peer_id, dmg * k, dir * 8.0 * k)
	for it in items.values():
		var to2: Vector3 = it.global_position - from
		var d2 := to2.length()
		if d2 < 18.0 and dir.dot(to2 / maxf(d2, 0.01)) > 0.95:
			it.apply_central_impulse(dir * it.mass * 5.0)
			server_damage_item(it, 0.25)


# ------------------------------------------------------------------ players

@rpc("any_peer", "call_remote", "unreliable_ordered")
func rpc_player_state(pos: Vector3, y: float, pi: float, g: int, flags: int) -> void:
	var p = players.get(sender())
	if p and not p.is_local:
		p.set_net(pos, y, pi, g)
		p.crouching = (flags & 2) != 0
		p.tumbling = (flags & 4) != 0
		p.under_cover = (flags & 8) != 0
		p.sprinting = (flags & 1) != 0
		p.expr = (flags >> 4) & 63


var _big_hit_t := {}


func server_damage_player(pid: int, dmg: float, knock: Vector3) -> void:
	if not players.has(pid) or players[pid].dead or ending:
		return
	# short mercy window after a big hit so combos can't chain-kill instantly
	if dmg >= 6.0:
		if game_time - float(_big_hit_t.get(pid, -10.0)) < 0.8:
			return
		_big_hit_t[pid] = game_time
	var h: float = float(Net.hp.get(pid, 100.0)) - dmg
	Net.hp[pid] = h
	var dead := h <= 0.0
	if dead:
		players[pid].dead = true
	rpc("rpc_player_hp", pid, maxf(h, 0.0), dead, knock)
	if dead:
		_on_player_dead(pid)


@rpc("authority", "call_local", "reliable")
func rpc_player_hp(pid: int, h: float, dead: bool, knock: Vector3) -> void:
	Net.hp[pid] = h
	var p = players.get(pid)
	if p:
		if dead:
			p.dead = false  # let _die() run its effects
		p.on_hp(h, dead, knock)


func _on_player_dead(pid: int) -> void:
	stat_deaths += 1
	_end_grab(pid)
	var p = players[pid]
	if not _check_all_dead():
		spawn_item("head", 0, p.global_position + Vector3(0, 1.0, 0), Quaternion.IDENTITY, pid)
		rpc_message("msg_arena_out" if arena_mode else "msg_player_down", [str(Net.players.get(pid, {}).get("name", "?"))])


func _check_all_dead() -> bool:
	if ending or players.is_empty():
		return false
	for p in players.values():
		if not p.dead:
			return false
	ending = true
	if Net.online and players.size() >= 2 and not arena_mode and not shop_mode:
		rpc_message("msg_arena_next")
		get_tree().create_timer(3.5).timeout.connect(Net.begin_arena)
	else:
		get_tree().create_timer(3.0).timeout.connect(Net.server_game_over)
	return true


func _revive(pid: int) -> void:
	if not players.has(pid) or not players[pid].dead:
		return
	var h := 25.0   # head brought into the van after the final extraction
	Net.hp[pid] = h
	rpc("rpc_revive", pid, gen.spawn_points[0], h)
	rpc_message("msg_revived", [str(Net.players.get(pid, {}).get("name", "?"))])


@rpc("authority", "call_local", "reliable")
func rpc_revive(pid: int, pos: Vector3, h: float) -> void:
	Net.hp[pid] = h
	var p = players.get(pid)
	if p:
		p.revive(pos, h)
	Sfx.play("extract", pos)


# ------------------------------------------------------------------ monsters

func spawn_monster(type: String, pos: Vector3) -> int:
	var id := next_id
	next_id += 1
	rpc("rpc_spawn_monster", id, type, pos)
	if monsters.has(id):
		monsters[id].hp *= 1.0 + 0.2 * moon_phase(level_num)
	return id


@rpc("authority", "call_local", "reliable")
func rpc_spawn_monster(id: int, type: String, pos: Vector3) -> void:
	if monsters.has(id):
		return
	var m = MonsterScript.new()
	m.name = "M%d" % id
	m.mid = id
	m.mtype = type
	m.world = self
	m.server_side = is_server()
	monsters_root.add_child(m)
	m.global_position = pos
	m.net_pos = pos
	monsters[id] = m


@rpc("authority", "call_local", "reliable")
func rpc_monster_event(id: int, ev: String) -> void:
	var m = monsters.get(id)
	if m == null:
		return
	m.on_event(ev)
	if ev == "dead" or ev == "leave":
		monsters.erase(id)


@rpc("authority", "call_remote", "unreliable_ordered")
func rpc_monsters_state(ids: PackedInt32Array, data: PackedFloat32Array) -> void:
	for i in ids.size():
		var m = monsters.get(ids[i])
		if m == null:
			continue
		var o := i * 4
		m.net_pos = Vector3(data[o], data[o + 1], data[o + 2])
		m.net_yaw = data[o + 3]


func server_monster_died(m, drop := true) -> void:
	var orb: Array = MonsterScript.TYPES[m.mtype]["orb"]
	if drop and orb[1] > 0:
		var val := int(round(randi_range(orb[0], orb[1]) * (1.0 + 0.12 * (level_num - 1)) * (1.0 + 0.25 * moon_phase(level_num)) / 100.0)) * 100
		spawn_item("orb", val, m.global_position + Vector3(0, 0.9, 0), Quaternion.IDENTITY, 0)
	if drop:
		stat_kills += 1
	respawn_queue.append({"type": m.mtype, "t": game_time + respawn_delay(true)})
	for pid in grabs.keys():
		if grabs[pid]["id"] == m.mid:
			grabs.erase(pid)
	rpc("rpc_monster_event", m.mid, "dead")


# ------------------------------------------------------------------ extraction

static var _hazard_tex: ImageTexture = null


## Yellow/black diagonal hazard stripes, generated once (no asset in the APK).
static func hazard_texture() -> ImageTexture:
	if _hazard_tex == null:
		var img := Image.create(64, 16, true, Image.FORMAT_RGBA8)
		for y in 16:
			for x in 64:
				var band := int(floor((x + y) / 8.0)) % 2 == 0
				var c := Color(0.85, 0.62, 0.08) if band else Color(0.05, 0.05, 0.05)
				var n := 0.9 + 0.1 * sin(x * 1.7 + y * 2.3)
				img.set_pixel(x, y, Color(c.r * n, c.g * n, c.b * n))
		img.generate_mipmaps()
		_hazard_tex = ImageTexture.create_from_image(img)
	return _hazard_tex


func _xmat(col: Color, rough := 0.6, metal := 0.0, emit := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = rough
	m.metallic = metal
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = emit
	return m


func _xmesh(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


## Grated steel pad in a hazard-striped frame with beacon posts, a frame in the ceiling and four
## steel walls that drop down around it (used by extraction points and the shop checkout).
func _build_pad(n: Node3D, h: float) -> Dictionary:
	var pad := BoxMesh.new()
	pad.size = Vector3(h * 2.0, 0.06, h * 2.0)
	var padm := LevelGen.surface_material("metal", 1.4, 0.0, 1.0, 0.55, 0.05, 0.4, 1.4)
	_xmesh(n, pad, padm, Vector3(0, 0.03, 0))
	var slot_m := _xmat(Color(0.02, 0.02, 0.025), 0.9)
	var sm := BoxMesh.new()
	sm.size = Vector3(h * 2.0 - 0.4, 0.004, 0.05)
	var ns := int(h * 2.0 / 0.3) - 1
	for k in ns:
		_xmesh(n, sm, slot_m, Vector3(0, 0.062, -(ns - 1) * 0.15 + k * 0.3))
	var hz := StandardMaterial3D.new()
	hz.albedo_texture = hazard_texture()
	hz.uv1_scale = Vector3(6.0 * h / 1.55, 1.0, 1.0)
	hz.roughness = 0.7
	hz.emission_enabled = true
	hz.emission_texture = hazard_texture()
	hz.emission_energy_multiplier = 0.0
	var fr := h + 0.09
	for k in 4:
		var bm := BoxMesh.new()
		bm.size = Vector3(fr * 2.0 + 0.22, 0.09, 0.22) if k < 2 else Vector3(fr * 2.0 - 0.22, 0.09, 0.22)
		var bp := Vector3(0, 0.045, (fr if k == 0 else -fr)) if k < 2 else Vector3((fr if k == 2 else -fr), 0.045, 0)
		_xmesh(n, bm, hz, bp, Vector3(0, PI / 2 if k >= 2 else 0.0, 0))
	var post_m := _xmat(Color(0.12, 0.12, 0.13), 0.5, 0.7)
	var bea_m := _xmat(Color(0.3, 0.3, 0.3), 0.3, 0.0, 0.0)
	var pm := CylinderMesh.new()
	pm.top_radius = 0.045
	pm.bottom_radius = 0.06
	pm.height = 0.95
	pm.radial_segments = 10
	var bmsh := SphereMesh.new()
	bmsh.radius = 0.075
	bmsh.height = 0.11
	bmsh.radial_segments = 12
	bmsh.rings = 6
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			_xmesh(n, pm, post_m, Vector3(sx * fr, 0.475, sz * fr))
			_xmesh(n, bmsh, bea_m, Vector3(sx * fr, 1.0, sz * fr))
	var ceil_y := LevelGen.H - 0.02
	var ring_m := _xmat(Color(0.1, 0.1, 0.11), 0.45, 0.8)
	var half := h + 0.05
	for k in 4:
		var fb := BoxMesh.new()
		fb.size = Vector3(half * 2.0 + 0.24, 0.08, 0.14)
		var fp := Vector3(0, ceil_y, half) if k == 0 else (Vector3(0, ceil_y, -half) if k == 1 else (Vector3(half, ceil_y, 0) if k == 2 else Vector3(-half, ceil_y, 0)))
		_xmesh(n, fb, ring_m, fp, Vector3(0, PI / 2 if k >= 2 else 0.0, 0))
	var gap := BoxMesh.new()
	gap.size = Vector3(half * 2.0 - 0.1, 0.01, half * 2.0 - 0.1)
	_xmesh(n, gap, _xmat(Color(0.015, 0.015, 0.018), 0.9), Vector3(0, ceil_y + 0.03, 0))
	var tube := Node3D.new()
	tube.position = Vector3(0, ceil_y, 0)
	n.add_child(tube)
	var wall_m := LevelGen.surface_material("metal", 1.0, 0.0, 1.0, 0.35, 0.0, 0.3, 1.2)
	var lip_m := _xmat(Color(0.3, 0.3, 0.3), 0.3, 0.0, 0.0)
	for k in 4:
		var rot := Vector3(0, PI / 2 if k >= 2 else 0.0, 0)
		var dir := Vector3(0, 0, half) if k == 0 else (Vector3(0, 0, -half) if k == 1 else (Vector3(half, 0, 0) if k == 2 else Vector3(-half, 0, 0)))
		var wm := BoxMesh.new()
		wm.size = Vector3(half * 2.0 + 0.06, 2.5, 0.06)
		_xmesh(tube, wm, wall_m, dir + Vector3(0, 1.45, 0), rot)
		var band := BoxMesh.new()
		band.size = Vector3(half * 2.0 + 0.1, 0.16, 0.08)
		_xmesh(tube, band, hz, dir + Vector3(0, 0.12, 0), rot)
		var strip := BoxMesh.new()
		strip.size = Vector3(half * 2.0 + 0.1, 0.05, 0.085)
		_xmesh(tube, strip, lip_m, dir + Vector3(0, 0.23, 0), rot)
		for r in 3:
			var rb := BoxMesh.new()
			rb.size = Vector3(0.08, 2.3, 0.1)
			_xmesh(tube, rb, ring_m, dir + Vector3(0, 1.5, 0) + (Vector3(1, 0, 0) if k < 2 else Vector3(0, 0, 1)) * (-half * 0.62 + r * half * 0.62), rot)
	return {"hz": hz, "bea_m": bea_m, "lip_m": lip_m, "post_m": post_m, "tube": tube, "ceil_y": ceil_y}


## Extraction point in the style of the reference game: a grated steel pad framed by hazard
## stripes, beacon posts in the corners, a console with a big red button, a screen with the goal,
## and a vacuum tube in the ceiling that drops down and sucks the haul away.
func _build_extractions() -> void:
	for i in gen.extraction_points.size():
		var pos: Vector3 = gen.extraction_points[i]
		var e := {"pos": pos, "goal": 0, "value": 0, "done": false}
		var n := Node3D.new()
		gen.root.add_child(n)
		n.position = pos
		var pd := _build_pad(n, 1.55)
		var hz: StandardMaterial3D = pd["hz"]
		var bea_m: StandardMaterial3D = pd["bea_m"]
		var lip_m: StandardMaterial3D = pd["lip_m"]
		var post_m: StandardMaterial3D = pd["post_m"]
		var tube: Node3D = pd["tube"]
		var ceil_y: float = pd["ceil_y"]
		# console with the big red button
		var ped := StaticBody3D.new()
		ped.collision_layer = 1
		ped.collision_mask = 0
		ped.position = Vector3(2.15, 0, 0)
		ped.set_meta("interact", "extract")
		ped.set_meta("idx", i)
		n.add_child(ped)
		var cons := ML.model("extractor")
		if cons:
			ped.add_child(cons)
			cons.basis = Basis.looking_at(Vector3(-1, 0, 0), Vector3.UP)
		var btn := MeshInstance3D.new()
		var bsm := CylinderMesh.new()
		bsm.top_radius = 0.1
		bsm.bottom_radius = 0.12
		bsm.height = 0.07
		btn.mesh = bsm
		btn.position.y = 1.12
		var btn_mat := _xmat(Color(0.5, 0.1, 0.1), 0.35, 0.0, 1.0)
		btn.material_override = btn_mat
		ped.add_child(btn)
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = Vector3(0.45, 1.15, 0.45)
		cs.shape = sh
		cs.position.y = 0.57
		ped.add_child(cs)
		# goal screen: dark panel on a post, facing the pad
		var scr := Node3D.new()
		scr.position = Vector3(2.15, 1.95, 0)
		scr.rotation.y = -PI / 2
		n.add_child(scr)
		var panel := BoxMesh.new()
		panel.size = Vector3(1.25, 0.62, 0.06)
		_xmesh(scr, panel, _xmat(Color(0.05, 0.05, 0.06), 0.4, 0.5), Vector3.ZERO)
		var glass := QuadMesh.new()
		glass.size = Vector2(1.13, 0.5)
		var glass_m := _xmat(Color(0.02, 0.06, 0.03), 0.1, 0.0, 0.35)
		_xmesh(scr, glass, glass_m, Vector3(0, 0, 0.032))
		var pole := CylinderMesh.new()
		pole.top_radius = 0.03
		pole.bottom_radius = 0.03
		pole.height = 0.7
		_xmesh(scr, pole, post_m, Vector3(0, -0.62, -0.02))
		var lbl := Label3D.new()
		lbl.font_size = 72
		lbl.pixel_size = 0.0028
		lbl.outline_size = 0
		lbl.position = Vector3(0, 0, 0.04)
		lbl.double_sided = false
		scr.add_child(lbl)
		var lbl2 := Label3D.new()   # small far-readable tag above the pad
		lbl2.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lbl2.font_size = 40
		lbl2.pixel_size = 0.006
		lbl2.outline_size = 10
		lbl2.position = Vector3(0, 2.25, 0)
		n.add_child(lbl2)
		var light := OmniLight3D.new()
		light.position = Vector3(0, 1.6, 0)
		light.omni_range = 5.0
		light.light_energy = 0.0
		light.light_color = Color(0.3, 1.0, 0.45)
		n.add_child(light)
		var tube_light := OmniLight3D.new()
		tube_light.position = Vector3(0, 1.0, 0)
		tube_light.omni_range = 3.5
		tube_light.light_energy = 0.0
		tube.add_child(tube_light)
		e["plate_mat"] = hz
		e["border_mat"] = bea_m
		e["btn_mat"] = btn_mat
		e["glass_mat"] = glass_m
		e["lip_mat"] = lip_m
		e["label"] = lbl
		e["tag"] = lbl2
		e["light"] = light
		e["tube"] = tube
		e["tube_light"] = tube_light
		e["tube_y"] = ceil_y
		e["tube_t"] = 0.0
		extr.append(e)
		_update_extr_visual(i)


func _build_truck_button() -> void:
	var ped := StaticBody3D.new()
	ped.collision_layer = 1
	ped.set_meta("interact", "truck")
	gen.root.add_child(ped)
	ped.position = gen.truck_button
	var bmodel := ML.model("button")
	if bmodel:
		ped.add_child(bmodel)
	else:
		var pmesh := MeshInstance3D.new()
		var pbm := BoxMesh.new()
		pbm.size = Vector3(0.45, 1.1, 0.45)
		pmesh.mesh = pbm
		pmesh.position.y = 0.55
		ped.add_child(pmesh)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(0.5, 1.25, 0.5)
	cs.shape = sh
	cs.position.y = 0.62
	ped.add_child(cs)
	truck_label = Label3D.new()
	truck_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	truck_label.font_size = 64
	truck_label.pixel_size = 0.006
	truck_label.outline_size = 12
	truck_label.modulate = Color(1.0, 0.8, 0.2)
	truck_label.position = gen.truck_screen - gen.truck_back * 0.06 if gen.truck_back != Vector3.ZERO else gen.truck_pos + Vector3(0, 2.6, 0)
	if gen.truck_back != Vector3.ZERO:
		truck_label.billboard = BaseMaterial3D.BILLBOARD_DISABLED
		truck_label.basis = Basis.looking_at(gen.truck_back, Vector3.UP)
		truck_label.font_size = 40
		truck_label.pixel_size = 0.0017
		truck_label.modulate = Color(0.4, 1.0, 0.6)
	gen.root.add_child(truck_label)
	_update_truck_label()


func _update_truck_label() -> void:
	if truck_label:
		if leaving:
			truck_label.text = Settings.t("truck_leave") % int(ceil(leave_t))
		else:
			truck_label.text = Settings.t("truck_label") + "\n" + (Settings.t("truck_ready") if all_done else Settings.t("truck_wait"))


func _update_extr_visual(i: int) -> void:
	var e: Dictionary = extr[i]
	var lbl: Label3D = e["label"]
	var tag: Label3D = e["tag"]
	var col: Color
	var ready := false
	if e["done"]:
		col = Color(0.35, 0.6, 1.0)
		lbl.text = "%s\n$%s" % [Settings.t("extr_done"), Settings.money_k(e["value"])]
		tag.text = ""
	elif i == active_extr:
		col = Color(0.35, 1.0, 0.5)
		if extracting:
			col = Color(1.0, 0.25, 0.2)
			lbl.text = Settings.t("extr_sending") % int(ceil(maxf(extract_t, 0.0)))
		elif e["value"] >= e["goal"] and e["goal"] > 0:
			col = Color(1.0, 0.85, 0.2)
			ready = true
			lbl.text = "$%s / $%s\n%s" % [Settings.money_k(e["value"]), Settings.money_k(e["goal"]), Settings.t("extr_press")]
		else:
			lbl.text = "$%s\n/ $%s" % [Settings.money_k(e["value"]), Settings.money_k(e["goal"])]
		tag.text = "$%s / $%s" % [Settings.money_k(e["value"]), Settings.money_k(e["goal"])]
	else:
		col = Color(0.4, 0.4, 0.42)
		lbl.text = Settings.t("extr_idle")
		tag.text = ""
	lbl.modulate = col
	tag.modulate = col
	var active: bool = i == active_extr and not e["done"]
	e["plate_mat"].emission_energy_multiplier = 0.25 if active else 0.0
	e["border_mat"].albedo_color = col * (1.0 if active or e["done"] else 0.5)
	e["border_mat"].emission_enabled = active or e["done"]
	e["border_mat"].emission = col
	e["border_mat"].emission_energy_multiplier = 2.2 if active else 0.6
	e["btn_mat"].emission = Color(1.0, 0.12, 0.08) if active else Color(0.15, 0.03, 0.03)
	e["btn_mat"].emission_energy_multiplier = (2.5 if ready else 1.2) if active else 0.3
	e["glass_mat"].emission = col * 0.25
	e["lip_mat"].emission_enabled = active
	e["lip_mat"].emission = col
	e["lip_mat"].emission_energy_multiplier = 1.5
	e["light"].light_energy = 1.1 if active else (0.3 if e["done"] else 0.0)
	e["light"].light_color = col


# ------------------------------------------------------------------ disposal arena

func _server_populate_arena() -> void:
	for pid in players:
		Net.hp[pid] = Net.max_hp(pid)
		rpc("rpc_revive", pid, gen.spawn_points[players.keys().find(pid) % gen.spawn_points.size()], Net.hp[pid])
	var pool := ["w_bat", "w_pan", "w_sledge", "w_prod", "w_pistol", "w_shotgun", "g_explosive", "g_stun", "g_shock", "m_explosive", "w_bat", "w_pan"]
	var r := RandomNumberGenerator.new()
	r.seed = seed_val + 3
	var spots: Array = gen.item_spots.duplicate()
	var n := mini(spots.size(), 4 + players.size() * 3)
	for i in n:
		var sp: Dictionary = spots[r.randi() % spots.size()]
		spots.erase(sp)
		spawn_item(pool[r.randi() % pool.size()], 0, sp["pos"] + Vector3(0, 0.2, 0), Quaternion(Vector3.UP, r.randf() * TAU), 0)
	arena_t = 0.0
	arena_ring = ArenaGen.RINGS
	rpc("rpc_begin")


func _arena_tick(delta: float) -> void:
	if ending:
		return
	arena_t += delta
	# the rim falls away: first ring after 18 s, then one every 12 s
	var drop_at := 18.0 + (ArenaGen.RINGS - arena_ring) * 12.0
	if arena_ring >= 1:
		if not arena_warned and arena_t >= drop_at - 2.5:
			arena_warned = true
			rpc("rpc_arena_ring", arena_ring, true)
		if arena_t >= drop_at:
			rpc("rpc_arena_ring", arena_ring, false)
			arena_ring -= 1
			arena_warned = false
	# falling into the pit
	for p in players.values():
		if not p.dead and p.global_position.y < -3.0:
			_big_hit_t[p.peer_id] = -10.0
			server_damage_player(p.peer_id, 99999.0, Vector3.ZERO)
	var alive := []
	for p in players.values():
		if not p.dead:
			alive.append(p)
	if alive.size() <= 1 and not ending:
		ending = true
		var wid: int = alive[0].peer_id if alive.size() == 1 else -1
		rpc("rpc_arena_winner", wid, str(Net.players.get(wid, {}).get("name", "")))
		get_tree().create_timer(6.0).timeout.connect(Net.server_game_over)


@rpc("authority", "call_local", "reliable")
func rpc_arena_ring(r: int, warn: bool) -> void:
	if gen and gen.has_method("warn_ring"):
		if warn:
			gen.warn_ring(r)
			Sfx.play("beep", null, -4.0, 0.7)
		else:
			gen.drop_ring(r)
			Sfx.play("thud", null, 0.0, 0.6)
			if local_player and local_player.has_method("shake"):
				local_player.shake(0.4)


@rpc("authority", "call_local", "reliable")
func rpc_arena_winner(pid: int, pname: String) -> void:
	if pid >= 0:
		Settings.crown_name = pname
		Settings.save_cfg()
		hud.intro_card(Settings.t("arena_win"), pname)
		var p = players.get(pid)
		if p and p.has_method("put_crown"):
			p.put_crown()
	else:
		hud.intro_card(Settings.t("arena_draw"), "")


## Rim glow on the aimed/held object and a floating price tag above it, like the reference game.
func _update_highlight() -> void:
	var lp = local_player
	var t = null
	var held := false
	if lp and not lp.dead:
		if lp.grabbed_id > 0 and items.has(lp.grabbed_id):
			t = items[lp.grabbed_id]
			held = true
		elif lp.look_item != null and is_instance_valid(lp.look_item):
			t = lp.look_item
	if t != _hl_target:
		_set_overlay(_hl_target, null)
		if _hl_mat == null:
			_hl_mat = ShaderMaterial.new()
			_hl_mat.shader = HighlightShader
		_set_overlay(t, _hl_mat)
		_hl_target = t
		if t != null:
			_hl_h = 0.3
			for g in t.find_children("*", "GeometryInstance3D", true, false):
				if g is Label3D:
					continue
				var ab: AABB = g.get_aabb()
				var top: float = (g.global_transform * (ab.position + ab.size)).y
				_hl_h = maxf(_hl_h, top - t.global_position.y)
	if _hl_tag == null:
		_hl_tag = Label3D.new()
		_hl_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		_hl_tag.no_depth_test = true
		_hl_tag.font_size = 44
		_hl_tag.pixel_size = 0.0038
		_hl_tag.outline_size = 10
		_hl_tag.outline_modulate = Color(0, 0, 0, 0.85)
		_hl_tag.render_priority = 5
		fx_root.add_child(_hl_tag)
	if t == null:
		_hl_tag.visible = false
		return
	_hl_mat.set_shader_parameter("color", (lp.color if held else Color(0.85, 0.9, 1.0)) * (1.0 if held else 0.7))
	var txt := ""
	var col := Color(0.9, 0.95, 1.0)
	if t.base_value > 0:
		txt = "$" + Settings.money(t.value)
		var r: float = float(t.value) / float(maxi(1, t.base_value))
		col = Color(0.45, 1.0, 0.55) if r > 0.85 else (Color(1.0, 0.85, 0.3) if r > 0.5 else Color(1.0, 0.35, 0.3))
	elif t.type == "cart" or t.type == "i_pocketcart":
		txt = "$" + Settings.money_k(t.cart_total)
	elif shop_mode and t.is_shop() and t.value > 0:
		txt = "$" + Settings.money(t.value)
		col = Color(1.0, 0.8, 0.3)
	_hl_tag.text = txt
	_hl_tag.modulate = col
	_hl_tag.visible = txt != ""
	_hl_tag.global_position = t.global_position + Vector3(0, _hl_h + 0.18, 0)


func _set_overlay(it, m: Material) -> void:
	if it == null or not is_instance_valid(it):
		return
	for g in it.find_children("*", "GeometryInstance3D", true, false):
		if not (g is Label3D):
			g.material_overlay = m


## Tube and beacon animation (runs on every peer).
func _animate_extractions(delta: float) -> void:
	var t := Time.get_ticks_msec() * 0.001
	for i in extr.size():
		var e: Dictionary = extr[i]
		var target := 0.0
		if i == active_extr and extracting:
			target = clampf(1.0 - (extract_t - 0.2) / 1.6, 0.0, 1.0)   # drops during the last ~1.6 s
			var blink := fmod(t * 3.0, 1.0) < 0.5
			e["border_mat"].emission_energy_multiplier = 4.0 if blink else 0.3
			e["light"].light_energy = 1.8 if blink else 0.4
		var cur: float = e["tube_t"]
		cur = move_toward(cur, target, delta * (1.6 if target > cur else 0.8))
		e["tube_t"] = cur
		var tube: Node3D = e["tube"]
		tube.position.y = float(e["tube_y"]) - cur * (float(e["tube_y"]) - 0.03)
		e["tube_light"].light_energy = cur * 2.2
		e["tube_light"].light_color = Color(1.0, 0.35, 0.25) if extracting else Color(0.5, 0.9, 1.0)


func item_in_zone(it) -> bool:
	if active_extr < 0 or active_extr >= extr.size():
		return false
	return _in_zone(it.global_position, extr[active_extr]["pos"], 1.55)


static func _in_zone(p: Vector3, c: Vector3, half: float) -> bool:
	return absf(p.x - c.x) < half and absf(p.z - c.z) < half and p.y > c.y - 0.5 and p.y < c.y + 2.6


func in_truck(p: Vector3) -> bool:
	var rel := p - (truck_pos - Vector3(0, 0.5, 0))
	if gen.truck_back == Vector3.ZERO:
		return absf(rel.x) < truck_half.x and absf(rel.z) < truck_half.z and rel.y < 3.0
	return absf(rel.dot(gen.truck_back)) < 1.62 and absf(rel.dot(gen.truck_side)) < 1.18 and rel.y > -0.3 and rel.y < 3.0


func _zone_tick() -> void:
	var changed := false
	if active_extr >= 0 and active_extr < extr.size():
		var e: Dictionary = extr[active_extr]
		var v := 0
		for it in items.values():
			if it.value > 0 and _in_zone(it.global_position, e["pos"], 1.55):
				v += it.value
		if v != e["value"]:
			e["value"] = v
			changed = true
	for it in items.values():
		if it.type == "head" and all_done and in_truck(it.global_position):
			var pid: int = it.extra
			remove_item(it.item_id, 2)
			_revive(pid)
	# the van patches everyone up once all points are done
	if all_done and not shop_mode:
		for p in players.values():
			if not p.dead and not truck_healed.has(p.peer_id) and in_truck(p.global_position):
				truck_healed[p.peer_id] = true
				var amt := 50.0 if level_num < 5 else (35.0 if level_num < 10 else 25.0)
				var h: float = minf(Net.max_hp(p.peer_id), float(Net.hp.get(p.peer_id, 0.0)) + amt)
				Net.hp[p.peer_id] = h
				rpc("rpc_player_hp", p.peer_id, h, false, Vector3.ZERO)
				rpc_message("msg_truck_heal", [str(int(amt))])
	if changed:
		_broadcast_extr()


func _try_extract(idx: int) -> void:
	if idx != active_extr or extracting or all_done:
		return
	var e: Dictionary = extr[idx]
	if e["value"] < e["goal"]:
		rpc_message("msg_need_more")
		return
	extracting = true
	extract_t = 3.5
	beep_t = 0.0
	_broadcast_extr()


func _finish_extract() -> void:
	extracting = false
	var e: Dictionary = extr[active_extr]
	var ids := []
	var v := 0
	for it in items.values():
		if it.value > 0 and _in_zone(it.global_position, e["pos"], 1.55):
			ids.append(it.item_id)
			v += it.value
	if v < e["goal"]:
		rpc_message("msg_extract_fail")
		_broadcast_extr()
		return
	for id in ids:
		remove_item(id, 2)
	for it in items.values():
		if it.type == "head" and _in_zone(it.global_position, e["pos"], 1.55):
			var hp_pid: int = it.extra
			remove_item(it.item_id, 2)
			if players.has(hp_pid) and players[hp_pid].dead:
				Net.hp[hp_pid] = 1.0   # revived by an extraction: 1 HP, like the reference game
				rpc("rpc_revive", hp_pid, e["pos"] + Vector3(0, 0.3, 0), Net.hp[hp_pid])
	# anyone standing under the tube gets blasted out of the pad
	for p in players.values():
		if not p.dead and _in_zone(p.global_position, e["pos"], 1.6):
			var out: Vector3 = p.global_position - e["pos"]
			out.y = 0.0
			out = (out.normalized() if out.length() > 0.1 else Vector3.RIGHT) * 7.0 + Vector3(0, 3.0, 0)
			server_damage_player(p.peer_id, 20.0, out)
	var more_left := false
	for k in extr.size():
		if k != active_extr and not extr[k]["done"]:
			more_left = true
	var surplus: int = v - int(e["goal"])
	if surplus > 0 and more_left:
		# "tax return": the overshoot comes back as a money bag for the next point
		level_extracted += int(e["goal"])
		var bag := spawn_item("moneybag", surplus, e["pos"] + Vector3(0.0, 1.2, 0.0), Quaternion.IDENTITY, 0)
		if items.has(bag):
			items[bag].indestructible = true
		rpc_message("msg_surplus", [Settings.money(surplus)])
	else:
		level_extracted += v
	if not more_left:
		# the job is done: carts are not needed any more and get picked up with the last haul
		for cid in items.keys():
			var c = items.get(cid)
			if c != null and (c.type == "cart" or c.type == "i_pocketcart"):
				remove_item(cid, 2)
	e["done"] = true
	e["value"] = v
	rpc("rpc_haul_popup", mini(v, int(e["goal"])) if (surplus > 0 and more_left) else v)
	rpc("rpc_extract_fx", active_extr)
	rpc("rpc_sfx", "extract", e["pos"])
	rpc("rpc_vibrate", 120)
	active_extr = -1
	for i in extr.size():
		if not extr[i]["done"]:
			active_extr = i
			break
	if active_extr == -1:
		all_done = true
		rpc_message("msg_all_done")
	else:
		rpc_message("msg_next_point")
	_broadcast_extr()


@rpc("authority", "call_local", "reliable")
func rpc_extract_fx(i: int) -> void:
	if i < 0 or i >= extr.size():
		return
	var e: Dictionary = extr[i]
	e["tube_t"] = 1.0
	var p: Vector3 = e["pos"]
	Fx.flash(fx_root, p + Vector3(0, 1.0, 0), Color(0.6, 0.95, 1.0), 3.0)
	Fx.shockwave(fx_root, p + Vector3(0, 0.1, 0), 2.2, Color(0.5, 0.9, 1.0))
	Fx.sparkle(fx_root, p + Vector3(0, 0.6, 0))


func _broadcast_extr() -> void:
	var goals := []
	var vals := []
	var done := []
	for e in extr:
		goals.append(e["goal"])
		vals.append(e["value"])
		done.append(e["done"])
	rpc("rpc_extr_state", active_extr, goals, vals, done, extracting, extract_t, all_done, level_extracted, quota_total)


@rpc("authority", "call_local", "reliable")
func rpc_extr_state(a: int, goals: Array, vals: Array, done: Array, ex: bool, ex_t: float, ad: bool, le: int, qt: int) -> void:
	active_extr = a
	extracting = ex
	extract_t = ex_t
	all_done = ad
	level_extracted = le
	quota_total = qt
	for i in extr.size():
		extr[i]["goal"] = goals[i]
		extr[i]["value"] = vals[i]
		extr[i]["done"] = done[i]
		_update_extr_visual(i)
	_update_truck_label()


func _try_truck() -> void:
	if ending:
		return
	if shop_mode:
		for p in players.values():
			if not p.dead and not in_truck(p.global_position):
				rpc_message("msg_everyone_truck")
				return
		ending = true
		rpc("rpc_sfx", "extract", truck_pos)
		get_tree().create_timer(1.5).timeout.connect(func(): Net.begin_level())
		return
	if not all_done:
		rpc_message("msg_quota_first")
		return
	if leaving:
		return
	# like the reference game: 10 s countdown, whoever is not inside the van when it leaves explodes
	leaving = true
	leave_t = 10.0
	_leave_beep = 0.0
	rpc("rpc_leave_state", true, leave_t)
	rpc_message("msg_truck_leaving")


@rpc("authority", "call_local", "reliable")
func rpc_leave_state(on: bool, t: float) -> void:
	leaving = on
	leave_t = t
	_update_truck_label()


func _depart() -> void:
	leaving = false
	rpc("rpc_leave_state", false, 0.0)
	var anyone := false
	for p in players.values():
		if p.dead:
			continue
		if in_truck(p.global_position):
			anyone = true
		else:
			rpc("rpc_fx", "explosion", p.global_position + Vector3(0, 0.8, 0), 1.0)
			_big_hit_t[p.peer_id] = -10.0
			server_damage_player(p.peer_id, 99999.0, Vector3(0, 6.0, 0))
	if not anyone or ending:
		return
	ending = true
	for it in items.values():
		if it.uid > 0:
			Net.set_owned_battery(it.uid, it.battery)
	rpc("rpc_sfx", "extract", truck_pos)
	# surplus bags brought into the van are paid out with the haul
	var bags := 0
	for it in items.values():
		if it.type == "moneybag" and in_truck(it.global_position):
			bags += it.value
	if bags > 0:
		level_extracted += bags
		rpc("rpc_haul_popup", bags)
	var extra := {"broken": stat_broken, "lost": stat_lost, "kills": stat_kills, "deaths": stat_deaths}
	get_tree().create_timer(1.5).timeout.connect(func(): Net.server_level_complete(level_extracted, quota_total, extra))


@rpc("any_peer", "call_local", "reliable")
func rpc_poke_monster(id: int) -> void:
	if not is_server():
		return
	var m = monsters.get(id)
	if m and m.mtype == "mimic" and m.disguised:
		m.reveal(sender())


@rpc("any_peer", "call_local", "reliable")
func rpc_ping(pos: Vector3) -> void:
	var pid := sender()
	var col: Color = Net.COLORS[int(Net.players.get(pid, {}).get("color", 0)) % 4]
	Fx.ping(fx_root, pos, str(Net.players.get(pid, {}).get("name", "?")), col)
	Sfx.play("beep_hi", pos, 0.0, 1.3)


@rpc("authority", "call_remote", "unreliable")
func rpc_danger(v: float, a: float) -> void:
	danger = v
	alert = a


func _danger_tick() -> void:
	for pid in players:
		var v := 0.0
		var al := 0.0
		var p = players[pid]
		for m in monsters.values():
			if m.state == MonsterScript.DEAD or (m.mtype == "mimic" and m.disguised):
				continue
			al = maxf(al, m.max_sus_for(pid))
			if (m.state == MonsterScript.CHASE or m.state == MonsterScript.ATTACK or m.state == MonsterScript.SPECIAL) and m.target_pid == pid:
				v = 1.0
			elif m.global_position.distance_to(p.global_position) < 9.0 and m.dormant <= 0.0:
				v = maxf(v, 0.35)
		if pid == multiplayer.get_unique_id():
			danger = v
			alert = al
		elif Net.online:
			rpc_id(pid, "rpc_danger", v, al)


@rpc("any_peer", "call_local", "reliable")
func rpc_interact(what: String, idx: int) -> void:
	if not is_server() or not started:
		return
	if what == "buy":
		_try_buy()
	elif what == "extract":
		_try_extract(idx)
	elif what == "truck":
		_try_truck()


# ------------------------------------------------------------------ misc rpc

func rpc_message(key: String, args := []) -> void:
	rpc("rpc_msg", key, args)


@rpc("authority", "call_local", "reliable")
func rpc_msg(key: String, args: Array) -> void:
	var s := Settings.t(key)
	if args.size() > 0:
		s = s % args
	if OS.is_debug_build():
		print("[MSG] ", s)
	if hud:
		hud.message(s)


@rpc("authority", "call_local", "reliable")
func rpc_vibrate(ms: int) -> void:
	Sfx.vibrate(ms)


@rpc("authority", "call_local", "reliable")
func rpc_haul_popup(v: int) -> void:
	if hud:
		hud.money_popup(v)


@rpc("authority", "call_local", "reliable")
func rpc_sfx(sname: String, pos: Vector3) -> void:
	Sfx.play(sname, pos, 2.0)


# ------------------------------------------------------------------ loop

func _process(delta: float) -> void:
	# chase music follows danger
	music_level = move_toward(music_level, danger, delta * (1.5 if danger > music_level else 0.4))
	Sfx.set_tension(music_level)
	_shadow_t -= delta
	if _shadow_t <= 0.0:
		_shadow_t = 0.4
		_update_light_shadows()
	_perf_acc += delta
	_perf_frames += 1
	if _perf_acc >= 1.0:
		_adapt_resolution(_perf_frames / _perf_acc)
		_perf_acc = 0.0
		_perf_frames = 0
	# cosmetic light flicker (local)
	for l in gen.lights:
		if l["flicker"]:
			var on := randf() > 0.04
			l["light"].light_energy = l["base"] * (randf_range(0.7, 1.0) if on else 0.05)
			if l.has("halo") and is_instance_valid(l["halo"]):
				l["halo"].visible = on
	if extracting:
		if not is_server():
			extract_t = maxf(0.0, extract_t - delta)
		for i in extr.size():
			if i == active_extr:
				_update_extr_visual(i)
	if not extr.is_empty():
		_animate_extractions(delta)
	if not shop_pad.is_empty():
		if buying and not is_server():
			buy_t = maxf(0.0, buy_t - delta)
		var target := clampf(1.0 - (buy_t - 0.2) / 1.4, 0.0, 1.0) if buying else 0.0
		var cur: float = move_toward(float(shop_pad["tube_t"]), target, delta * (1.8 if target > float(shop_pad["tube_t"]) else 0.8))
		shop_pad["tube_t"] = cur
		shop_pad["tube"].position.y = float(shop_pad["tube_y"]) - cur * (float(shop_pad["tube_y"]) - 0.03)
		shop_pad["tube_light"].light_energy = cur * 2.0
		var blink := buying and fmod(Time.get_ticks_msec() * 0.003, 1.0) < 0.5
		shop_pad["bea_m"].emission = Color(1.0, 0.25, 0.2) if blink else Color(1.0, 0.8, 0.25)
	if leaving:
		if not is_server():
			leave_t = maxf(0.0, leave_t - delta)
		_update_truck_label()
	_update_highlight()
	if local_player and gen:
		visited[LevelGen.cell_at(local_player.global_position)] = true


func _physics_process(delta: float) -> void:
	game_time += delta
	if not is_server():
		return
	if not started:
		_try_start()
		return
	_apply_grabs()
	zone_t -= delta
	if zone_t <= 0.0:
		zone_t = 0.25
		if shop_mode:
			_shop_zone_tick()
		else:
			_zone_tick()
	if arena_mode and started:
		_arena_tick(delta)
	if buying:
		buy_t -= delta
		beep_t -= delta
		if beep_t <= 0.0:
			beep_t = 0.5
			rpc("rpc_sfx", "beep", gen.checkout_pos)
		if buy_t <= 0.0:
			_finish_buy()
	if leaving and not ending:
		leave_t -= delta
		_leave_beep -= delta
		if _leave_beep <= 0.0:
			_leave_beep = 1.0
			rpc("rpc_sfx", "beep", truck_pos)
		if leave_t <= 0.0:
			_depart()
	if extracting:
		extract_t -= delta
		beep_t -= delta
		if beep_t <= 0.0:
			beep_t = 1.0
			rpc("rpc_sfx", "beep", extr[active_extr]["pos"])
		if extract_t <= 0.0:
			_finish_extract()
	danger_t -= delta
	if danger_t <= 0.0:
		danger_t = 0.25
		_danger_tick()
	if not monsters_awake_msg and game_time > 5.0 and not shop_mode:
		for m in monsters.values():
			if m.dormant <= 0.0 and m.mtype != "mimic" and m.mtype != "eye":
				monsters_awake_msg = true
				rpc_message("msg_monsters_awake")
				break
	# respawns
	for i in range(respawn_queue.size() - 1, -1, -1):
		var r = respawn_queue[i]
		if game_time >= float(r["t"]):
			respawn_queue.remove_at(i)
			_respawn_far(r["type"])
	# fell out of the world
	for it in items.values():
		if it.global_position.y < -20.0:
			remove_item(it.item_id, 0)
	# state replication
	if Net.online:
		state_t -= delta
		full_t -= delta
		if state_t <= 0.0:
			state_t = 0.05
			var full := full_t <= 0.0
			if full:
				full_t = 1.0
			var ids := PackedInt32Array()
			var data := PackedFloat32Array()
			for id in items:
				var it = items[id]
				if full or not it.sleeping:
					ids.append(id)
					var p: Vector3 = it.global_position
					var q: Quaternion = it.global_transform.basis.get_rotation_quaternion()
					data.append_array([p.x, p.y, p.z, q.x, q.y, q.z, q.w])
					if ids.size() >= 40:
						rpc("rpc_items_state", ids, data)
						ids = PackedInt32Array()
						data = PackedFloat32Array()
			if ids.size() > 0:
				rpc("rpc_items_state", ids, data)
			var mids := PackedInt32Array()
			var md := PackedFloat32Array()
			for id in monsters:
				var m = monsters[id]
				mids.append(id)
				var p: Vector3 = m.global_position
				md.append_array([p.x, p.y, p.z, m.yaw])
			if mids.size() > 0:
				rpc("rpc_monsters_state", mids, md)


## A floor point in a monster cell at least `min_d` from every player (best effort).
func far_spawn_point(min_d: float) -> Vector3:
	var best := LevelGen.cell_center(gen.monster_cells[0])
	var bd := -1.0
	for i in 10:
		var c: Vector2i = gen.monster_cells[rng.randi() % gen.monster_cells.size()]
		var cp: Vector3 = LevelGen.cell_center(c) + Vector3(rng.randf_range(-1.5, 1.5), 0.1, rng.randf_range(-1.5, 1.5))
		var md := 1e9
		for p in players.values():
			md = minf(md, cp.distance_to(p.global_position))
		if md > bd:
			bd = md
			best = cp
		if md >= min_d and i >= 3:
			break
	return best


func _respawn_far(type: String) -> void:
	var best: Vector2i = gen.monster_cells[0]
	var bd := -1.0
	for i in 6:
		var c: Vector2i = gen.monster_cells[rng.randi() % gen.monster_cells.size()]
		var cp: Vector3 = LevelGen.cell_center(c)
		var md := 1e9
		for p in players.values():
			md = minf(md, cp.distance_to(p.global_position))
		if md > bd:
			bd = md
			best = c
	spawn_monster(type, LevelGen.cell_center(best) + Vector3(0, 0.1, 0))


# ------------------------------------------------------------------ shop

func _build_shop() -> void:
	var g = gen
	var n := Node3D.new()
	gen.root.add_child(n)
	n.position = g.checkout_pos
	var pd := _build_pad(n, SHOP_HALF + 0.05)
	var stl := OmniLight3D.new()
	stl.position = Vector3(0, 1.0, 0)
	stl.omni_range = 3.0
	stl.light_energy = 0.0
	pd["tube"].add_child(stl)
	pd["hz"].emission_energy_multiplier = 0.3
	shop_pad = {"tube": pd["tube"], "tube_y": pd["ceil_y"], "tube_t": 0.0, "bea_m": pd["bea_m"], "lip_m": pd["lip_m"], "tube_light": stl}
	pd["bea_m"].emission_enabled = true
	pd["bea_m"].emission = Color(1.0, 0.8, 0.25)
	pd["bea_m"].emission_energy_multiplier = 1.5
	var ped := StaticBody3D.new()
	ped.collision_layer = 1
	ped.set_meta("interact", "buy")
	gen.root.add_child(ped)
	ped.position = g.checkout_button
	var bmodel := ML.model("button")
	if bmodel:
		ped.add_child(bmodel)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(0.5, 1.25, 0.5)
	cs.shape = sh
	cs.position.y = 0.62
	ped.add_child(cs)
	shop_label = Label3D.new()
	shop_label.font_size = 56
	shop_label.pixel_size = 0.005
	shop_label.outline_size = 10
	shop_label.modulate = Color(0.4, 1.0, 0.6)
	gen.root.add_child(shop_label)
	shop_label.global_transform = Transform3D(Basis.looking_at(-g.screen_fwd, Vector3.UP), g.screen_pos + g.screen_fwd * 0.02)
	var sign := Label3D.new()
	sign.text = Settings.t("shop")
	sign.font_size = 110
	sign.pixel_size = 0.006
	sign.modulate = Color(1.0, 0.55, 0.1)
	sign.outline_size = 16
	gen.root.add_child(sign)
	sign.global_transform = Transform3D(Basis.looking_at(Vector3(-1, 0, 0), Vector3.UP), g.sign_pos + Vector3(0.05, 0, 0))
	var glow := OmniLight3D.new()
	glow.light_color = Color(1.0, 0.55, 0.1)
	glow.light_energy = 0.8
	glow.omni_range = 4.0
	gen.root.add_child(glow)
	glow.position = g.sign_pos + Vector3(0.8, 0, 0)
	_update_shop_label()
	Net.run_changed.connect(_update_shop_label)


func _update_shop_label() -> void:
	if shop_label:
		shop_label.text = "%s\n$%s\n%s: $%s" % [Settings.t("basket"), Settings.money(basket), Settings.t("cash"), Settings.money(Net.money)]
		shop_label.modulate = Color(1.0, 0.35, 0.3) if basket > Net.money else Color(0.4, 1.0, 0.6)


const UP_PRICES := {"up_hp": 7000, "up_stamina": 2000, "up_strength": 7000, "up_range": 7000, "up_speed": 7000, "up_jump": 12000, "up_tumble": 4500, "up_crouch": 7500}


func shop_price(t: String) -> int:
	var base := 0
	if UP_PRICES.has(t):
		base = UP_PRICES[t]
	else:
		base = int(int(ItemDefs.DEFS.get(t, {}).get("price", 1000)) * 0.75)
	# prices climb with the level and every time the crew buys the same thing again
	var rep := 1.0 + (0.25 if t.begins_with("up_") else 0.08) * int(Net.bought.get(t, 0))
	return int(round(base * (1.0 + 0.06 * (level_num - 1)) * rep * randf_range(0.9, 1.1) / 1000.0)) * 1000


func _server_populate_shop() -> void:
	var r := RandomNumberGenerator.new()
	r.seed = seed_val + 5
	# always stocked: health packs, upgrades, energy crystals; the rest rotates every visit
	var stock := ["med_s", "med_s", "med_m", "med_l", "i_crystal"]
	for u in UP_PRICES.keys():
		stock.append(u)
	for i in 4:
		stock.append(UP_PRICES.keys()[r.randi() % UP_PRICES.size()])
	var gear_pool := ["g_explosive", "g_stun", "g_shock", "m_explosive", "m_stun", "w_bat", "w_sledge", "w_pan", "w_prod",
		"w_pistol", "w_shotgun", "w_tranq", "d_feather", "d_shield", "t_valuable", "t_extract", "i_crystal", "i_pocketcart"]
	for i in r.randi_range(7, 10):
		var g: String = gear_pool[r.randi() % gear_pool.size()]
		stock.append(g)
		if g.begins_with("g_") and r.randf() < 0.6:
			stock.append(g)
	var spots: Array = gen.shop_spots.duplicate()
	for i in range(spots.size() - 1, 0, -1):
		var j := r.randi() % (i + 1)
		var tmp = spots[i]
		spots[i] = spots[j]
		spots[j] = tmp
	for i in mini(stock.size(), spots.size()):
		var t: String = stock[i]
		var lift := 0.24 if t.begins_with("up_") else 0.14
		spawn_item(t, shop_price(t), spots[i] + Vector3(0, lift, 0), Quaternion(Vector3.UP, r.randf_range(-0.3, 0.3)), 0)
	rpc("rpc_begin")


func _shop_zone_tick() -> void:
	var total := 0
	for it in items.values():
		if it.is_shop() and not it.owned and _in_zone(it.global_position, gen.checkout_pos, SHOP_HALF):
			total += it.value
	if total != basket:
		rpc("rpc_basket", total)


@rpc("authority", "call_local", "reliable")
func rpc_basket(total: int) -> void:
	basket = total
	_update_shop_label()


const SHOP_HALF := 1.25


func _basket_items() -> Array:
	var ids := []
	for it in items.values():
		if it.is_shop() and not it.owned and _in_zone(it.global_position, gen.checkout_pos, SHOP_HALF):
			ids.append(it.item_id)
	return ids


## Checkout like the reference game: goods go onto the small extraction pad, the button starts a
## short countdown, the walls drop and the goods are "extracted" — they wait in the van next level.
func _try_buy() -> void:
	if buying:
		return
	var ids := _basket_items()
	var total := 0
	for id in ids:
		total += items[id].value
	if ids.is_empty():
		rpc_message("msg_basket_empty")
		return
	if total > spendable():
		rpc_message("msg_no_money")
		return
	buying = true
	buy_t = 2.5
	beep_t = 0.0
	rpc("rpc_buy_state", true, buy_t)


func spendable() -> int:
	return int(Net.money / 1000) * 1000   # the reference game rounds your cash down to the nearest $1K


func _finish_buy() -> void:
	buying = false
	rpc("rpc_buy_state", false, 0.0)
	var ids := _basket_items()
	var total := 0
	for id in ids:
		total += items[id].value
	if ids.is_empty() or total > spendable():
		rpc_message("msg_no_money" if not ids.is_empty() else "msg_basket_empty")
		return
	Net.money -= total
	for id in ids:
		var it = items[id]
		Net.add_owned(it.type, it.battery)
		Net.bought[it.type] = int(Net.bought.get(it.type, 0)) + 1
		remove_item(id, 2)
	Net.send_run()
	rpc("rpc_shop_fx")
	rpc("rpc_sfx", "cash", gen.checkout_pos)
	rpc("rpc_basket", 0)
	rpc_message("msg_bought_truck", [Settings.money(total)])
	Net.save_run()


@rpc("authority", "call_local", "reliable")
func rpc_buy_state(on: bool, t: float) -> void:
	buying = on
	buy_t = t


@rpc("authority", "call_local", "reliable")
func rpc_shop_fx() -> void:
	if shop_pad.is_empty():
		return
	shop_pad["tube_t"] = 1.0
	var p: Vector3 = gen.checkout_pos
	Fx.flash(fx_root, p + Vector3(0, 1.0, 0), Color(1.0, 0.85, 0.4), 2.5)
	Fx.sparkle(fx_root, p + Vector3(0, 0.6, 0))


@rpc("authority", "call_local", "reliable")
func rpc_item_owned(id: int) -> void:
	var it = items.get(id)
	if it:
		it.owned = true
		Fx.sparkle(fx_root, it.global_position)
	_update_shop_label()


@rpc("any_peer", "call_local", "reliable")
func rpc_use_item(id: int) -> void:
	if not is_server():
		return
	var it = items.get(id)
	var pid := sender()
	if it == null or not it.owned or not players.has(pid):
		return
	if players[pid].global_position.distance_to(it.global_position) > Net.grab_range(pid) + 2.0:
		return
	if ItemDefs.is_gear(it.type) and not it.type.begins_with("med_") and it.type != "i_crystal":
		return
	_apply_shop_item(it, pid, true)


func _apply_shop_item(it, pid: int, announce: bool) -> void:
	var t: String = it.type
	if ItemDefs.is_gear(t) and not t.begins_with("med_"):
		if t == "i_crystal":
			Net.energy += 3.0
			Net.consume_owned(it.uid)
			Net.send_run()
			remove_item(it.item_id, 2)
		else:
			gear.stash(it, pid)
			remove_item(it.item_id, 0)
		return
	if t.begins_with("up_"):
		var k := t.substr(3)
		if Net.up(pid, k) < Net.MAX_UPGRADE:
			var old_max := Net.max_hp(pid)
			Net.upgrades[pid][k] = Net.up(pid, k) + 1
			if k == "hp":
				Net.hp[pid] = float(Net.hp.get(pid, 0.0)) + (Net.max_hp(pid) - old_max)
	else:
		var heal: float = {"med_s": 25.0, "med_m": 50.0, "med_l": 100.0}.get(t, 25.0)
		Net.hp[pid] = minf(Net.max_hp(pid), float(Net.hp.get(pid, 0.0)) + heal)
	Net.consume_owned(it.uid)
	Net.send_run()
	rpc("rpc_player_hp", pid, float(Net.hp[pid]), false, Vector3.ZERO)
	remove_item(it.item_id, 2)
	if announce:
		rpc_message("msg_used", [str(Net.players.get(pid, {}).get("name", "?")), it.display_name()])
	Net.save_run()


func objective_pos() -> Vector3:
	if shop_mode:
		return gen.checkout_pos if basket > 0 else truck_pos
	if all_done or active_extr < 0 or active_extr >= extr.size():
		return truck_pos
	return extr[active_extr]["pos"]


func _exit_tree() -> void:
	Sfx.set_tension(0.0)
	if Settings.changed.is_connected(apply_quality):
		Settings.changed.disconnect(apply_quality)
	if Net.run_changed.is_connected(_update_shop_label):
		Net.run_changed.disconnect(_update_shop_label)
	if Net.players_changed.is_connected(_on_players_changed):
		Net.players_changed.disconnect(_on_players_changed)
