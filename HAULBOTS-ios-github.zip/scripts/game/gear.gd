extends Node
## Weapons, throwables, mines, drones, trackers, batteries, the van charger and the 3-slot inventory.
## Lives at /root/Main/World/Gear on every peer; the host is authoritative.

const ItemDefs = preload("res://scripts/game/item_defs.gd")
const ML = preload("res://scripts/game/matlib.gd")
const MonsterScript = preload("res://scripts/game/monster.gd")

var world: Node = null
var fuses := {}
var mines := {}
var drones := {}
var cooldown := {}
var charger_pos := Vector3.ZERO
var charger_label: Label3D = null
var _bat_sync_t := 0.0
var _noise_cd := {}
var _no_energy_msg := 0.0


func _ready() -> void:
	var g = world.gen
	if g.truck_back != Vector3.ZERO:
		var tb: Vector3 = g.truck_pos - Vector3(0, 0.5, 0)
		charger_pos = tb + g.truck_back * 1.05 - g.truck_side * 0.72 + Vector3(0, 0.51, 0)
		var m := ML.model("charger")
		var sb := StaticBody3D.new()
		sb.collision_layer = 1
		g.root.add_child(sb)
		sb.global_position = charger_pos
		if m:
			sb.add_child(m)
			m.basis = Basis.looking_at(-g.truck_side, Vector3.UP)
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = Vector3(0.9, 0.5, 0.9)
		cs.shape = bs
		cs.position.y = 0.25
		sb.add_child(cs)
		charger_label = Label3D.new()
		charger_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		charger_label.font_size = 32
		charger_label.pixel_size = 0.0022
		charger_label.outline_size = 8
		charger_label.modulate = Color(1.0, 0.85, 0.3)
		g.root.add_child(charger_label)
		charger_label.global_position = charger_pos + Vector3(0, 1.1, 0)
		_update_charger_label()
		Net.run_changed.connect(_update_charger_label)


func _exit_tree() -> void:
	if Net.run_changed.is_connected(_update_charger_label):
		Net.run_changed.disconnect(_update_charger_label)


func _update_charger_label() -> void:
	if charger_label:
		charger_label.text = "⚡ %s: %.1f" % [Settings.t("energy"), Net.energy]


func is_server() -> bool:
	return multiplayer.is_server()


func sender() -> int:
	var s := multiplayer.get_remote_sender_id()
	return s if s != 0 else multiplayer.get_unique_id()


# ------------------------------------------------------------------ battery

func use_battery(it, cost: float) -> bool:
	if it == null or cost <= 0.0:
		return true
	if it.battery < cost - 0.001:
		return false
	it.battery = maxf(0.0, it.battery - cost)
	rpc("rpc_battery", it.item_id, it.battery)
	return true


@rpc("authority", "call_local", "reliable")
func rpc_battery(id: int, b: float) -> void:
	var it = world.items.get(id)
	if it:
		it.battery = b


# ------------------------------------------------------------------ using held gear

@rpc("any_peer", "call_local", "reliable")
func rpc_use(id: int, from: Vector3, dir: Vector3) -> void:
	if not is_server():
		return
	var pid := sender()
	var it = world.items.get(id)
	var p = world.players.get(pid)
	if it == null or p == null or p.dead:
		return
	if p.global_position.distance_to(it.global_position) > Net.grab_range(pid) + 2.5:
		return
	if world.shop_mode and it.is_shop() and not it.owned:
		world.rpc_message("msg_pay_first")
		return
	var d: Dictionary = ItemDefs.DEFS[it.type]
	var t: String = it.type
	var now: float = world.game_time
	if now < float(cooldown.get(id, 0.0)):
		return
	dir = dir.normalized()
	match d.get("cat", ""):
		"gun":
			if not use_battery(it, d["cost"]):
				world.rpc("rpc_sfx", "beep", it.global_position)
				return
			cooldown[id] = now + float(d.get("cd", 1.0))
			var muzzle: Vector3 = it.global_position + dir * 0.35
			world.rpc("rpc_fx", "muzzle", muzzle, 2.0 if t == "w_shotgun" else 1.0)
			world.add_noise(muzzle, 2.5)
			if t == "w_shotgun":
				for i in 8:
					var sd := dir.rotated(Vector3.UP, randf_range(-0.1, 0.1)).rotated(dir.cross(Vector3.UP).normalized(), randf_range(-0.08, 0.08))
					_hitscan(from, sd, 22.0, d["dmg"], pid, false, it)
				world.send_effect(pid, "impulse", -dir * 4.0, 0.0)
			else:
				_hitscan(from, dir, 40.0, d["dmg"], pid, t == "w_tranq", it)
			it.apply_central_impulse(-dir * it.mass * 1.5)
		"melee":
			cooldown[id] = now + float(d.get("cd", 0.6))
			it.apply_central_impulse(dir * it.mass * 7.0 + Vector3(0, it.mass * 1.0, 0))
			it.apply_torque_impulse(dir.cross(Vector3.UP) * it.mass * 0.8)
			world.rpc("rpc_sfx", "swing", it.global_position)
			var hit := false
			for m in world.monsters.values():
				if m.state == MonsterScript.DEAD:
					continue
				var to: Vector3 = m.global_position + Vector3(0, 0.5, 0) - p.global_position
				if to.length() < float(d.get("reach", 1.9)) + m.cfg["radius"] and dir.dot(to.normalized()) > 0.3:
					if not use_battery(it, d["cost"]):
						world.rpc("rpc_sfx", "beep", it.global_position)
						break
					it.set_meta("mon_hit_t", world.game_time + 0.45)
					m.take_hit(d["dmg"])
					if t == "w_prod":
						m.stun(4.0)
					elif t == "w_pan":
						m.stun(1.2)
					elif t == "w_sledge":
						m.stun(1.5)
					hit = true
			if hit:
				world.rpc("rpc_sfx", "thud", it.global_position)
		"throw":
			if not fuses.has(id):
				fuses[id] = 3.0
				world.rpc("rpc_sfx", "beep_hi", it.global_position)
				world.rpc("rpc_item_flag", id, "armed")
		"mine":
			if not mines.has(id):
				mines[id] = 1.5
				world.rpc("rpc_sfx", "beep", it.global_position)
				world.rpc("rpc_item_flag", id, "armed")
		"drone":
			if drones.has(id) or it.battery <= 0.01:
				return
			var target = _aim_item(from, dir, it)
			if target == null:
				world.rpc_message("msg_drone_no_target")
				return
			drones[id] = target.item_id
			if t == "d_feather":
				target.mass_scale = 0.12
			else:
				target.indestructible = true
			world.rpc("rpc_item_flag", target.item_id, "drone_" + t)
			world.rpc("rpc_sfx", "grab", it.global_position)
			for gp in world.grabs.keys():
				if world.grabs[gp]["id"] == id:
					world._end_grab(gp)
			it.freeze = true
		"crystal":
			Net.energy += 3.0
			Net.consume_owned(it.uid)
			Net.send_run()
			world.remove_item(id, 2)
			world.rpc_message("msg_crystal")
		"med":
			var heal: float = d.get("heal", 25.0)
			Net.hp[pid] = minf(Net.max_hp(pid), float(Net.hp.get(pid, 0.0)) + heal)
			Net.send_run()
			world.rpc("rpc_player_hp", pid, float(Net.hp[pid]), false, Vector3.ZERO)
			Net.consume_owned(it.uid)
			world.remove_item(id, 2)
			world.rpc("rpc_sfx", "extract", p.global_position)


func _hitscan(from: Vector3, dir: Vector3, length: float, dmg: float, pid: int, tranq: bool, gun = null) -> void:
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * length, (1 | 2 | 4 | 8) if world.arena_mode else (1 | 4 | 8))
	var p = world.players.get(pid)
	var ex: Array[RID] = []
	if p:
		ex.append(p.get_rid())
	if gun:
		ex.append(gun.get_rid())
	q.exclude = ex
	var hit := get_viewport().get_world_3d().direct_space_state.intersect_ray(q)
	if hit.is_empty():
		return
	var c = hit["collider"]
	if world.arena_mode and c.is_in_group("player") and not c.dead:
		if tranq:
			world.send_effect(c.peer_id, "stunned", Vector3.ZERO, 3.0)
		else:
			world.server_damage_player(c.peer_id, dmg * 0.45, dir * 3.0)
	elif c.is_in_group("monster"):
		if tranq:
			c.stun(12.0, true)
		else:
			c.take_hit(dmg)
	elif c.is_in_group("item"):
		c.apply_impulse(dir * 6.0, hit["position"] - c.global_position)
		if not tranq:
			world.server_damage_item(c, 0.12)
	world.rpc("rpc_fx", "shock" if not tranq else "stun", hit["position"], 0.3)


func _aim_item(from: Vector3, dir: Vector3, self_it):
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 8.0, 4)
	q.exclude = [self_it.get_rid()]
	var hit := get_viewport().get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty() and hit["collider"].is_in_group("item") and not ItemDefs.is_gear(hit["collider"].type):
		return hit["collider"]
	var best = null
	var bd := 3.5
	for it in world.items.values():
		if it == self_it or ItemDefs.is_gear(it.type):
			continue
		var dd: float = it.global_position.distance_to(self_it.global_position)
		if dd < bd:
			bd = dd
			best = it
	return best


# ------------------------------------------------------------------ inventory

@rpc("any_peer", "call_local", "reliable")
func rpc_store(id: int, slot: int) -> void:
	if not is_server() or slot < 0 or slot > 2:
		return
	var pid := sender()
	var it = world.items.get(id)
	if it == null or not world.players.has(pid):
		return
	if not ItemDefs.can_store(it.type) or (world.shop_mode and it.is_shop() and not it.owned):
		world.rpc_message("msg_cant_store")
		return
	var inv: Array = Net.inv_of(pid)
	if inv[slot] != null:
		return
	inv[slot] = {"t": it.type, "b": it.battery, "u": it.uid}
	Net.inv[pid] = inv
	for gp in world.grabs.keys():
		if world.grabs[gp]["id"] == id:
			world._end_grab(gp)
	fuses.erase(id)
	mines.erase(id)
	world.remove_item(id, 0)
	Net.send_run()
	Net.save_run()


@rpc("any_peer", "call_local", "reliable")
func rpc_take(slot: int) -> void:
	if not is_server() or slot < 0 or slot > 2:
		return
	var pid := sender()
	var p = world.players.get(pid)
	if p == null or p.dead:
		return
	var inv: Array = Net.inv_of(pid)
	var e = inv[slot]
	if e == null:
		return
	inv[slot] = null
	Net.inv[pid] = inv
	var pos: Vector3 = p.eye_pos() + p.look_dir() * 0.9
	var id: int = world.spawn_item(e["t"], 0, pos, Quaternion(Vector3.UP, p.yaw), 0, float(e["b"]))
	if world.items.has(id):
		world.items[id].uid = int(e.get("u", 0))
		if Net.is_consumable(e["t"]) and (e["t"].begins_with("up_") or e["t"].begins_with("med_") or e["t"] == "i_crystal"):
			world.rpc("rpc_item_flag", id, "owned")
	Net.send_run()
	Net.save_run()
	if pid == multiplayer.get_unique_id():
		rpc_autograb(id)
	else:
		rpc_id(pid, "rpc_autograb", id)


@rpc("authority", "call_local", "reliable")
func rpc_autograb(id: int) -> void:
	if world.local_player:
		world.local_player.grab_direct(id)


## After the shop: purchased gear that nobody pocketed goes to the buyer's free slot or into the van.
func stash(it, pid: int) -> void:
	var inv: Array = Net.inv_of(pid)
	for i in 3:
		if inv[i] == null:
			inv[i] = {"t": it.type, "b": it.battery}
			Net.inv[pid] = inv
			return
	if it.uid <= 0:
		Net.add_owned(it.type, it.battery)


# ------------------------------------------------------------------ noise from players

@rpc("any_peer", "call_local", "unreliable")
func rpc_noise(pos: Vector3, loud: float) -> void:
	if not is_server():
		return
	var pid := sender()
	var t: float = world.game_time
	if t - float(_noise_cd.get(pid, -1.0)) < 0.2:
		return
	_noise_cd[pid] = t
	world.add_noise(pos, clampf(loud, 0.05, 1.5))


@rpc("any_peer", "call_local", "reliable")
func rpc_tumble_hit(mid: int, speed: float) -> void:
	if not is_server():
		return
	var m = world.monsters.get(mid)
	if m and m.state != MonsterScript.DEAD:
		m.take_hit(speed * 7.0)
		m.stun(0.8)


# ------------------------------------------------------------------ host ticks

func _physics_process(delta: float) -> void:
	if world == null or not is_server() or not world.started:
		return
	for id in fuses.keys():
		fuses[id] -= delta
		if fuses[id] <= 0.0:
			fuses.erase(id)
			_detonate(id)
	for id in mines.keys():
		var it = world.items.get(id)
		if it == null:
			mines.erase(id)
			continue
		if mines[id] > 0.0:
			mines[id] -= delta
			continue
		var trig := false
		for m in world.monsters.values():
			if m.state != MonsterScript.DEAD and m.global_position.distance_to(it.global_position) < 1.3:
				trig = true
		for p in world.players.values():
			if not p.dead and p.global_position.distance_to(it.global_position) < 0.7:
				trig = true
		if trig:
			mines.erase(id)
			_detonate(id)
	for did in drones.keys():
		var dr = world.items.get(did)
		var tg = world.items.get(drones[did])
		if dr == null or tg == null or dr.battery <= 0.0:
			if tg:
				tg.mass_scale = 1.0
				tg.indestructible = false
				world.rpc("rpc_item_flag", tg.item_id, "drone_off")
			if dr:
				dr.freeze = false
			drones.erase(did)
			continue
		dr.battery = maxf(0.0, dr.battery - delta / 90.0)
		dr.global_position = tg.global_position + Vector3(0, 0.55 + sin(world.game_time * 3.0) * 0.05, 0)
	# trackers drain while held
	for gp in world.grabs:
		var it2 = world.items.get(world.grabs[gp]["id"])
		if it2 and ItemDefs.DEFS[it2.type].get("cat", "") == "tracker":
			it2.battery = maxf(0.0, it2.battery - delta / 150.0)
	# charger in the van
	if charger_pos != Vector3.ZERO:
		for it3 in world.items.values():
			if it3.battery >= 0.999 or not ItemDefs.is_gear(it3.type):
				continue
			var rel: Vector3 = it3.global_position - charger_pos
			if Vector2(rel.x, rel.z).length() < 0.55 and rel.y > 0.3 and rel.y < 1.2:
				if Net.energy <= 0.0:
					_no_energy_msg -= delta
					if _no_energy_msg <= 0.0:
						_no_energy_msg = 6.0
						world.rpc_message("msg_no_energy")
					continue
				var add := minf(delta * 0.25, 1.0 - it3.battery)
				it3.battery += add
				Net.energy = maxf(0.0, Net.energy - add / 3.0)
	_bat_sync_t -= delta
	if _bat_sync_t <= 0.0:
		_bat_sync_t = 0.5
		for it4 in world.items.values():
			if ItemDefs.is_gear(it4.type) and absf(it4.battery - it4.synced_battery) > 0.01:
				it4.synced_battery = it4.battery
				rpc("rpc_battery", it4.item_id, it4.battery)
		if charger_pos != Vector3.ZERO and absf(Net.energy - _last_energy) > 0.05:
			_last_energy = Net.energy
			Net.send_run()


var _last_energy := 0.0


func _detonate(id: int) -> void:
	var it = world.items.get(id)
	if it == null:
		return
	var pos: Vector3 = it.global_position
	match it.type:
		"g_explosive", "m_explosive":
			world.server_explosion(pos, 4.5, 60.0 * world.dmg_mult(), 180.0)
		"g_stun", "m_stun":
			world.server_stun_area(pos, 5.0, 5.0)
		"g_shock":
			world.server_shock(pos, 4.0, 20.0 * world.dmg_mult(), null)
			for m in world.monsters.values():
				if m.state != MonsterScript.DEAD and m.global_position.distance_to(pos) < 4.0:
					m.take_hit(60.0)
					m.stun(3.0)
	Net.consume_owned(it.uid)
	world.remove_item(id, 0)
