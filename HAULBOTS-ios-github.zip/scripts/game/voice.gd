extends Node
## Proximity voice chat over the LAN session.
## Mic -> AudioEffectCapture -> 11 kHz mu-law -> unreliable RPC -> 3D generator at the speaker.

const OUT_RATE := 11025.0
const PACKET := 551

var world: Node = null
var talking := false
var available := false
var mic_level := 0.0
var capture: AudioEffectCapture = null
var mic_player: AudioStreamPlayer = null
var _bus := -1
var _step := 4.0
var _phase := 0.0
var _acc := 0.0
var _acc_n := 0
var _out := PackedByteArray()
var _voices := {}
var _speak_t := {}
var _perm_asked := false


func _ready() -> void:
	_step = AudioServer.get_mix_rate() / OUT_RATE
	get_tree().on_request_permissions_result.connect(_on_perm)


func _on_perm(perm: String, granted: bool) -> void:
	if perm.ends_with("RECORD_AUDIO") and granted and talking and mic_player:
		mic_player.stop()
		mic_player.play()


func _setup_mic() -> bool:
	if capture != null:
		return true
	_bus = AudioServer.get_bus_index("VoiceMic")
	if _bus == -1:
		_bus = AudioServer.bus_count
		AudioServer.add_bus(_bus)
		AudioServer.set_bus_name(_bus, "VoiceMic")
		AudioServer.set_bus_mute(_bus, true)
		var cap := AudioEffectCapture.new()
		cap.buffer_length = 0.5
		AudioServer.add_bus_effect(_bus, cap)
	capture = AudioServer.get_bus_effect(_bus, 0) as AudioEffectCapture
	mic_player = AudioStreamPlayer.new()
	mic_player.stream = AudioStreamMicrophone.new()
	mic_player.bus = "VoiceMic"
	add_child(mic_player)
	return capture != null


func set_talking(on: bool) -> void:
	if not Net.online:
		talking = false
		return
	if on and OS.get_name() == "Android" and not _perm_asked:
		_perm_asked = true
		OS.request_permission("android.permission.RECORD_AUDIO")
	if on and not _setup_mic():
		return
	talking = on
	if mic_player:
		if on and not mic_player.playing:
			mic_player.play()
		elif not on and mic_player.playing:
			mic_player.stop()
	if capture:
		capture.clear_buffer()
	_out.clear()


static func _mulaw_enc(x: float) -> int:
	var s := 0x80 if x < 0.0 else 0
	var v := minf(absf(x), 1.0)
	var y := log(1.0 + 255.0 * v) / log(256.0)
	return s | int(y * 127.0)


static func _mulaw_dec(b: int) -> float:
	var y := float(b & 0x7f) / 127.0
	var v := (pow(256.0, y) - 1.0) / 255.0
	return -v if (b & 0x80) != 0 else v


func _process(delta: float) -> void:
	for pid in _speak_t.keys():
		_speak_t[pid] -= delta
		var p = world.players.get(pid) if world else null
		if p and p.name_label:
			p.name_label.modulate.a = 1.0 if _speak_t[pid] <= 0.0 else 0.6 + 0.4 * sin(Time.get_ticks_msec() * 0.02)
	if not talking or capture == null:
		mic_level = move_toward(mic_level, 0.0, delta * 2.0)
		return
	var n := capture.get_frames_available()
	if n <= 0:
		return
	feed(capture.get_buffer(n))


## Resample a block of mic frames and send full packets.
func feed(buf: PackedVector2Array) -> void:
	var peak := 0.0
	for f in buf:
		var m := (f.x + f.y) * 0.5
		_acc += m
		_acc_n += 1
		_phase += 1.0
		if _phase >= _step:
			_phase -= _step
			var v := clampf(_acc / _acc_n * 1.6, -1.0, 1.0)
			peak = maxf(peak, absf(v))
			_acc = 0.0
			_acc_n = 0
			_out.append(_mulaw_enc(v))
			if _out.size() >= PACKET:
				if world and Net.online:
					rpc("rpc_voice", _out)
				_out = PackedByteArray()
	mic_level = maxf(mic_level * 0.8, peak)


@rpc("any_peer", "call_remote", "unreliable_ordered", 2)
func rpc_voice(data: PackedByteArray) -> void:
	var pid := multiplayer.get_remote_sender_id()
	if world == null or not world.players.has(pid):
		return
	var pb = _playback_for(pid)
	if pb == null:
		return
	var frames := PackedVector2Array()
	frames.resize(data.size())
	for i in data.size():
		var v := _mulaw_dec(data[i])
		frames[i] = Vector2(v, v)
	if pb.get_frames_available() >= frames.size():
		pb.push_buffer(frames)
	_speak_t[pid] = 0.3


func _playback_for(pid: int):
	if _voices.has(pid) and is_instance_valid(_voices[pid]["player"]):
		return _voices[pid]["pb"]
	var p = world.players.get(pid)
	if p == null:
		return null
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = OUT_RATE
	gen.buffer_length = 0.6
	var ap := AudioStreamPlayer3D.new()
	ap.stream = gen
	ap.unit_size = 6.0
	ap.max_distance = 35.0
	ap.volume_db = 4.0
	ap.position = Vector3(0, 1.4, 0)
	p.add_child(ap)
	ap.play()
	var pb := ap.get_stream_playback()
	_voices[pid] = {"player": ap, "pb": pb}
	return pb


func frames_received(pid: int) -> int:
	if not _voices.has(pid):
		return 0
	var pb = _voices[pid]["pb"]
	return int(OUT_RATE * 0.6) - pb.get_frames_available()
