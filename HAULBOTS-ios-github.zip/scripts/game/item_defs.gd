extends RefCounted
## Catalogue of valuables: stats and procedural models.

const DEFS := {
	"goblet": {"v": [800, 1500], "mass": 1.0, "frag": 1.0, "glass": false},
	"jewelbox": {"v": [1500, 3000], "mass": 1.5, "frag": 0.7, "glass": false},
	"crystal": {"v": [3200, 6200], "mass": 2.0, "frag": 2.4, "glass": true},
	"vase": {"v": [2000, 4200], "mass": 3.0, "frag": 1.6, "glass": true},
	"clock": {"v": [2500, 5000], "mass": 4.0, "frag": 1.0, "glass": false},
	"painting": {"v": [2000, 4500], "mass": 3.0, "frag": 0.8, "glass": false},
	"lamp": {"v": [1200, 2600], "mass": 3.5, "frag": 1.3, "glass": true},
	"radio": {"v": [1500, 3200], "mass": 6.0, "frag": 0.7, "glass": false},
	"gramophone": {"v": [3000, 5500], "mass": 8.0, "frag": 0.9, "glass": false},
	"statue": {"v": [7000, 11000], "mass": 30.0, "frag": 0.45, "glass": false},
	"grandclock": {"v": [9000, 15000], "mass": 40.0, "frag": 0.7, "glass": false},
	"crown": {"v": [2600, 5200], "mass": 1.2, "frag": 0.8, "glass": false},
	"mask": {"v": [1800, 3600], "mass": 1.0, "frag": 1.2, "glass": false},
	"beaker": {"v": [1200, 2600], "mass": 1.0, "frag": 2.2, "glass": true},
	"microscope": {"v": [2800, 5200], "mass": 5.0, "frag": 1.0, "glass": false},
	"powercell": {"v": [3500, 6500], "mass": 7.0, "frag": 1.4, "glass": true},
	"server": {"v": [6500, 10500], "mass": 28.0, "frag": 0.6, "glass": false},
	"orb": {"v": [0, 0], "mass": 4.0, "frag": 1.1, "glass": true},
	"moneybag": {"v": [0, 0], "mass": 2.5, "frag": 0.0, "glass": false},
	"up_hp": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_stamina": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_strength": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_range": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_speed": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_jump": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_tumble": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_crouch": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"med_s": {"v": [0, 0], "mass": 1.0, "frag": 0.0, "glass": false, "cat": "med", "heal": 25.0, "store": true, "price": 4000},
	"med_m": {"v": [0, 0], "mass": 1.5, "frag": 0.0, "glass": false, "cat": "med", "heal": 50.0, "store": true, "price": 7000},
	"med_l": {"v": [0, 0], "mass": 2.5, "frag": 0.0, "glass": false, "cat": "med", "heal": 100.0, "store": true, "price": 10000},
	# weapons & gadgets (battery 0..1; cost = battery per use)
	"w_bat": {"v": [0, 0], "mass": 1.5, "frag": 0.0, "glass": false, "cat": "melee", "dmg": 40.0, "cost": 0.08, "cd": 0.55, "reach": 2.0, "melee": 3.0, "store": true, "price": 30000},
	"w_sledge": {"v": [0, 0], "mass": 5.0, "frag": 0.0, "glass": false, "cat": "melee", "dmg": 75.0, "cost": 0.1, "cd": 1.1, "reach": 2.2, "melee": 2.5, "store": true, "price": 36000},
	"w_pan": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false, "cat": "melee", "dmg": 30.0, "cost": 0.07, "cd": 0.6, "reach": 1.8, "melee": 3.0, "store": true, "price": 16000},
	"w_prod": {"v": [0, 0], "mass": 1.5, "frag": 0.0, "glass": false, "cat": "melee", "dmg": 5.0, "cost": 0.2, "cd": 0.8, "reach": 2.0, "melee": 1.5, "store": true, "price": 28000},
	"w_pistol": {"v": [0, 0], "mass": 1.2, "frag": 0.0, "glass": false, "cat": "gun", "dmg": 45.0, "cost": 0.125, "cd": 1.0, "store": true, "price": 20000},
	"w_shotgun": {"v": [0, 0], "mass": 3.0, "frag": 0.0, "glass": false, "cat": "gun", "dmg": 18.0, "cost": 0.2, "cd": 1.2, "store": true, "price": 45000},
	"w_tranq": {"v": [0, 0], "mass": 1.4, "frag": 0.0, "glass": false, "cat": "gun", "dmg": 0.0, "cost": 0.25, "cd": 1.0, "store": true, "price": 17000},
	"g_explosive": {"v": [0, 0], "mass": 0.5, "frag": 0.0, "glass": false, "cat": "throw", "store": true, "price": 3000},
	"g_stun": {"v": [0, 0], "mass": 0.5, "frag": 0.0, "glass": false, "cat": "throw", "store": true, "price": 3000},
	"g_shock": {"v": [0, 0], "mass": 0.5, "frag": 0.0, "glass": false, "cat": "throw", "store": true, "price": 3000},
	"m_explosive": {"v": [0, 0], "mass": 1.2, "frag": 0.0, "glass": false, "cat": "mine", "store": true, "price": 3000},
	"m_stun": {"v": [0, 0], "mass": 1.2, "frag": 0.0, "glass": false, "cat": "mine", "store": true, "price": 3000},
	"d_feather": {"v": [0, 0], "mass": 0.8, "frag": 0.0, "glass": false, "cat": "drone", "store": true, "price": 16000},
	"d_shield": {"v": [0, 0], "mass": 0.8, "frag": 0.0, "glass": false, "cat": "drone", "store": true, "price": 28000},
	"t_valuable": {"v": [0, 0], "mass": 0.4, "frag": 0.0, "glass": false, "cat": "tracker", "store": true, "price": 15000},
	"t_extract": {"v": [0, 0], "mass": 0.4, "frag": 0.0, "glass": false, "cat": "tracker", "store": true, "price": 6000},
	"i_crystal": {"v": [0, 0], "mass": 0.8, "frag": 0.0, "glass": false, "cat": "crystal", "store": true, "price": 8000},
	"i_pocketcart": {"v": [0, 0], "mass": 6.0, "frag": 0.0, "glass": false, "cat": "cart", "store": true, "price": 17000},
	"head": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"cart": {"v": [0, 0], "mass": 20.0, "frag": 0.0, "glass": false},
}

# spawn tables per location: [small spots, table/cabinet tops, floor]
const TABLES := [
	[
		{"goblet": 3.0, "jewelbox": 2.0, "crystal": 1.0, "vase": 2.0, "clock": 1.2, "lamp": 1.0},
		{"goblet": 2.0, "jewelbox": 2.0, "crystal": 1.0, "vase": 2.0, "clock": 1.5, "lamp": 1.5, "radio": 1.5, "gramophone": 1.0, "painting": 1.2},
		{"painting": 2.0, "radio": 2.0, "gramophone": 2.0, "vase": 1.0, "lamp": 1.0, "statue": 0.9, "grandclock": 0.7},
	],
	[
		{"crown": 1.5, "mask": 2.5, "vase": 2.0, "goblet": 2.0, "crystal": 1.0, "jewelbox": 1.0},
		{"crown": 1.5, "mask": 2.0, "vase": 2.0, "painting": 1.5, "clock": 1.0, "crystal": 1.0},
		{"statue": 1.4, "vase": 1.5, "painting": 2.5, "mask": 1.0, "grandclock": 0.4, "gramophone": 0.8},
	],
	[
		{"beaker": 4.0, "crystal": 1.0, "clock": 1.0, "goblet": 0.5},
		{"beaker": 2.5, "microscope": 2.0, "powercell": 1.5, "radio": 1.0, "clock": 1.0},
		{"server": 1.2, "microscope": 1.5, "powercell": 2.0, "radio": 1.5, "lamp": 0.8},
	],
]
const HEAVY := ["statue", "grandclock", "server"]

static var _mats := {}
const ML = preload("res://scripts/game/matlib.gd")


static func pick_type(rng: RandomNumberGenerator, kind: String, level: int, loc := 0, always := false) -> String:
	if not always and rng.randf() < maxf(0.25, 0.45 - 0.03 * (level - 1)):
		return ""
	var t: Array = TABLES[loc % TABLES.size()]
	var table: Dictionary = t[0]
	if kind == "top":
		table = t[1]
	elif kind == "floor":
		table = (t[2] as Dictionary).duplicate()
		for h in HEAVY:
			if table.has(h):
				table[h] = table[h] + level * 0.15
	var total := 0.0
	for k in table:
		total += table[k]
	var r := rng.randf() * total
	for k in table:
		r -= table[k]
		if r <= 0.0:
			return k
	return table.keys()[0]


static func roll_value(rng: RandomNumberGenerator, type: String, level: int) -> int:
	var v: Array = DEFS[type]["v"]
	var base := rng.randi_range(v[0], v[1])
	# fewer valuables per level than before, so each one is worth more (and hurts more to break)
	return int(round(base * 1.35 * (1.0 + 0.15 * (level - 1)) / 10.0)) * 10


static func spawn_lift(type: String) -> float:
	match type:
		"statue":
			return 0.7
		"grandclock":
			return 0.97
		"lamp":
			return 0.3
		"painting":
			return 0.32
		"gramophone":
			return 0.25
		"cart":
			return 0.35
		"server":
			return 0.75
		"microscope", "powercell":
			return 0.3
	return 0.2


static func mat(col: Color, emit := 0.0, metal := 0.0, alpha := 1.0) -> StandardMaterial3D:
	var key := "%s|%.2f|%.2f|%.2f" % [col.to_html(), emit, metal, alpha]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(col.r, col.g, col.b, alpha)
	m.metallic = metal
	m.roughness = 0.35 if metal > 0.0 else 0.7
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = emit
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_mats[key] = m
	return m


static func _mesh(parent: Node3D, mesh: Mesh, m: Material, pos: Vector3, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


static func _box(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b


static func _cyl(top: float, bottom: float, h: float, seg := 12) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = top
	c.bottom_radius = bottom
	c.height = h
	c.radial_segments = seg
	c.rings = 1
	return c


static func _sph(r: float, h := -1.0) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0 if h < 0.0 else h
	s.radial_segments = 14
	s.rings = 7
	return s


static func _shape(body: CollisionObject3D, shape: Shape3D, pos := Vector3.ZERO) -> void:
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.position = pos
	body.add_child(cs)


static func _bshape(size: Vector3) -> BoxShape3D:
	var b := BoxShape3D.new()
	b.size = size
	return b


static func _cshape(r: float, h: float) -> CylinderShape3D:
	var c := CylinderShape3D.new()
	c.radius = r
	c.height = h
	return c


static func _sshape(r: float) -> SphereShape3D:
	var s := SphereShape3D.new()
	s.radius = r
	return s


## Builds meshes + collision shapes under `body`. Returns the main colour.
static func build(type: String, body: RigidBody3D, extra: int, seed_v: int) -> Color:
	var r := RandomNumberGenerator.new()
	r.seed = seed_v
	var gold := mat(Color(1.0, 0.78, 0.3), 0.0, 0.9)
	var wood := mat(Color(0.35, 0.2, 0.1))
	var dark := mat(Color(0.08, 0.08, 0.08))
	var col := Color.WHITE
	if gear_shapes(type, body):
		_apply_model(type, body, r, col)
		return Color(0.6, 0.6, 0.65)
	match type:
		"goblet":
			col = Color(1.0, 0.78, 0.3)
			_mesh(body, _cyl(0.075, 0.045, 0.12), gold, Vector3(0, 0.06, 0))
			_mesh(body, _cyl(0.015, 0.015, 0.1), gold, Vector3(0, -0.05, 0))
			_mesh(body, _cyl(0.055, 0.055, 0.02), gold, Vector3(0, -0.1, 0))
			_shape(body, _cshape(0.075, 0.24))
		"jewelbox":
			col = Color(0.55, 0.1, 0.12)
			_mesh(body, _box(Vector3(0.26, 0.13, 0.18)), mat(col), Vector3.ZERO)
			_mesh(body, _box(Vector3(0.27, 0.03, 0.19)), gold, Vector3(0, 0.075, 0))
			_mesh(body, _box(Vector3(0.05, 0.05, 0.02)), gold, Vector3(0, 0.02, 0.095))
			_shape(body, _bshape(Vector3(0.27, 0.16, 0.19)), Vector3(0, 0.01, 0))
		"crystal":
			col = Color(0.4, 0.9, 1.0)
			_mesh(body, _sph(0.13), mat(col, 0.8, 0.0, 0.8), Vector3(0, 0.05, 0))
			_mesh(body, _cyl(0.06, 0.09, 0.07), mat(Color(0.2, 0.12, 0.08)), Vector3(0, -0.1, 0))
			_shape(body, _sshape(0.14), Vector3(0, 0.0, 0))
		"vase":
			col = [Color(0.2, 0.35, 0.8), Color(0.75, 0.2, 0.15), Color(0.15, 0.55, 0.4), Color(0.85, 0.85, 0.8)][r.randi() % 4]
			_mesh(body, _cyl(0.07, 0.09, 0.3), mat(col, 0.0, 0.2), Vector3(0, 0.08, 0))
			_mesh(body, _sph(0.14, 0.26), mat(col.lightened(0.2), 0.0, 0.2), Vector3(0, -0.09, 0))
			_mesh(body, _cyl(0.085, 0.07, 0.03), gold, Vector3(0, 0.23, 0))
			_shape(body, _cshape(0.13, 0.46))
		"clock":
			col = Color(0.45, 0.28, 0.14)
			_mesh(body, _box(Vector3(0.34, 0.34, 0.12)), mat(col), Vector3.ZERO)
			_mesh(body, _cyl(0.13, 0.13, 0.02), mat(Color(0.95, 0.92, 0.85)), Vector3(0, 0, 0.065), Vector3(PI / 2, 0, 0))
			_mesh(body, _box(Vector3(0.015, 0.1, 0.01)), dark, Vector3(0, 0.04, 0.08))
			_mesh(body, _box(Vector3(0.07, 0.012, 0.01)), dark, Vector3(0.03, 0, 0.08))
			_shape(body, _bshape(Vector3(0.34, 0.34, 0.14)))
		"painting":
			col = Color.from_hsv(r.randf(), 0.6, 0.7)
			_mesh(body, _box(Vector3(0.8, 0.6, 0.05)), gold, Vector3.ZERO)
			_mesh(body, _box(Vector3(0.66, 0.46, 0.056)), mat(col), Vector3.ZERO)
			_mesh(body, _sph(0.1), mat(col.darkened(0.4)), Vector3(r.randf_range(-0.2, 0.2), r.randf_range(-0.1, 0.1), 0.02))
			_shape(body, _bshape(Vector3(0.8, 0.6, 0.06)))
		"lamp":
			col = Color(1.0, 0.85, 0.55)
			_mesh(body, _cyl(0.1, 0.11, 0.04), gold, Vector3(0, -0.25, 0))
			_mesh(body, _cyl(0.015, 0.015, 0.4), gold, Vector3(0, -0.05, 0))
			_mesh(body, _cyl(0.09, 0.17, 0.18), mat(col, 0.7), Vector3(0, 0.2, 0))
			_shape(body, _cshape(0.16, 0.56))
		"radio":
			col = Color(0.45, 0.25, 0.12)
			_mesh(body, _box(Vector3(0.45, 0.3, 0.2)), mat(col), Vector3.ZERO)
			_mesh(body, _box(Vector3(0.26, 0.2, 0.01)), mat(Color(0.8, 0.7, 0.45)), Vector3(-0.05, 0, 0.1))
			_mesh(body, _cyl(0.025, 0.025, 0.02), gold, Vector3(0.16, 0.05, 0.1), Vector3(PI / 2, 0, 0))
			_mesh(body, _cyl(0.025, 0.025, 0.02), gold, Vector3(0.16, -0.05, 0.1), Vector3(PI / 2, 0, 0))
			_shape(body, _bshape(Vector3(0.45, 0.3, 0.21)))
		"gramophone":
			col = Color(0.85, 0.65, 0.25)
			_mesh(body, _box(Vector3(0.4, 0.18, 0.4)), wood, Vector3(0, -0.14, 0))
			_mesh(body, _cyl(0.17, 0.17, 0.01), dark, Vector3(0, -0.045, 0))
			_mesh(body, _cyl(0.2, 0.025, 0.36), mat(col, 0.0, 0.8), Vector3(0.05, 0.12, -0.05), Vector3(0.5, 0, 0.3))
			_shape(body, _bshape(Vector3(0.4, 0.52, 0.4)), Vector3(0, 0.02, 0))
		"statue":
			col = Color(0.88, 0.87, 0.84)
			var marble := mat(col)
			_mesh(body, _box(Vector3(0.5, 0.3, 0.5)), mat(Color(0.5, 0.48, 0.45)), Vector3(0, -0.55, 0))
			var cap := CapsuleMesh.new()
			cap.radius = 0.17
			cap.height = 0.85
			_mesh(body, cap, marble, Vector3(0, -0.02, 0))
			_mesh(body, _sph(0.13), marble, Vector3(0, 0.5, 0))
			_mesh(body, _box(Vector3(0.6, 0.08, 0.08)), marble, Vector3(0, 0.22, 0), Vector3(0, 0, 0.3))
			_shape(body, _bshape(Vector3(0.5, 1.4, 0.5)))
		"grandclock":
			col = Color(0.3, 0.17, 0.08)
			_mesh(body, _box(Vector3(0.55, 1.9, 0.35)), mat(col), Vector3.ZERO)
			_mesh(body, _cyl(0.18, 0.18, 0.02), mat(Color(0.95, 0.9, 0.75)), Vector3(0, 0.6, 0.18), Vector3(PI / 2, 0, 0))
			_mesh(body, _box(Vector3(0.3, 0.7, 0.02)), mat(Color(0.1, 0.08, 0.05)), Vector3(0, -0.2, 0.18))
			_mesh(body, _sph(0.06), gold, Vector3(0, -0.35, 0.19))
			_mesh(body, _box(Vector3(0.62, 0.08, 0.4)), mat(col.darkened(0.3)), Vector3(0, 0.97, 0))
			_shape(body, _bshape(Vector3(0.55, 1.94, 0.36)))
		"crown":
			col = Color(1.0, 0.8, 0.25)
			_mesh(body, _cyl(0.11, 0.1, 0.1, 10), gold, Vector3(0, -0.02, 0))
			for i in 6:
				var a := i * TAU / 6.0
				_mesh(body, _box(Vector3(0.03, 0.08, 0.03)), gold, Vector3(cos(a) * 0.1, 0.07, sin(a) * 0.1))
				_mesh(body, _sph(0.02), mat(Color(0.9, 0.1, 0.2), 1.0), Vector3(cos(a) * 0.1, 0.12, sin(a) * 0.1))
			_shape(body, _cshape(0.11, 0.2))
		"mask":
			col = Color.from_hsv(r.randf_range(0.05, 0.15), 0.7, 0.8)
			_mesh(body, _sph(0.14, 0.3), mat(col, 0.0, 0.5), Vector3.ZERO)
			_mesh(body, _box(Vector3(0.05, 0.03, 0.02)), dark, Vector3(-0.05, 0.03, 0.12))
			_mesh(body, _box(Vector3(0.05, 0.03, 0.02)), dark, Vector3(0.05, 0.03, 0.12))
			_mesh(body, _box(Vector3(0.08, 0.02, 0.02)), dark, Vector3(0, -0.07, 0.12))
			_shape(body, _bshape(Vector3(0.28, 0.3, 0.2)))
		"beaker":
			col = Color.from_hsv(r.randf(), 0.8, 1.0)
			_mesh(body, _cyl(0.07, 0.07, 0.22), mat(Color(0.8, 0.9, 1.0), 0.0, 0.0, 0.45), Vector3.ZERO)
			_mesh(body, _cyl(0.06, 0.06, 0.12), mat(col, 1.2, 0.0, 0.85), Vector3(0, -0.04, 0))
			_shape(body, _cshape(0.07, 0.22))
		"microscope":
			col = Color(0.85, 0.85, 0.9)
			var wm := mat(col, 0.0, 0.6)
			_mesh(body, _box(Vector3(0.25, 0.04, 0.3)), dark, Vector3(0, -0.2, 0))
			_mesh(body, _box(Vector3(0.06, 0.35, 0.06)), wm, Vector3(0, -0.02, -0.1))
			_mesh(body, _cyl(0.035, 0.035, 0.22), wm, Vector3(0, 0.1, -0.02), Vector3(0.5, 0, 0))
			_mesh(body, _box(Vector3(0.16, 0.02, 0.14)), wm, Vector3(0, -0.1, 0.02))
			_shape(body, _bshape(Vector3(0.25, 0.44, 0.3)))
		"powercell":
			col = Color(0.2, 1.0, 0.5)
			_mesh(body, _cyl(0.1, 0.1, 0.36), mat(col, 1.8, 0.0, 0.8), Vector3.ZERO)
			_mesh(body, _cyl(0.12, 0.12, 0.05), mat(Color(0.3, 0.3, 0.32), 0.0, 0.8), Vector3(0, 0.19, 0))
			_mesh(body, _cyl(0.12, 0.12, 0.05), mat(Color(0.3, 0.3, 0.32), 0.0, 0.8), Vector3(0, -0.19, 0))
			_shape(body, _cshape(0.12, 0.43))
		"server":
			col = Color(0.12, 0.13, 0.16)
			_mesh(body, _box(Vector3(0.6, 1.5, 0.6)), mat(col, 0.0, 0.5), Vector3.ZERO)
			for i in 6:
				_mesh(body, _box(Vector3(0.45, 0.04, 0.02)), mat(Color(0.2, 0.6, 1.0) if i % 2 == 0 else Color(0.3, 1.0, 0.4), 2.0), Vector3(0, -0.55 + i * 0.2, 0.31))
			_shape(body, _bshape(Vector3(0.6, 1.5, 0.6)))
		"up_hp", "up_stamina", "up_strength", "up_range", "up_speed", "up_jump", "up_tumble", "up_crouch":
			col = UP_COLORS[type]
			_mesh(body, _cyl(0.1, 0.1, 0.4), mat(col, 1.5), Vector3.ZERO)
			_shape(body, _cshape(0.12, 0.44))
		"med_s", "med_m", "med_l":
			var sc: float = {"med_s": 0.7, "med_m": 1.0, "med_l": 1.3}[type]
			col = Color(0.85, 0.15, 0.15)
			_mesh(body, _box(Vector3(0.3, 0.14, 0.2) * sc), mat(Color(0.85, 0.85, 0.85)), Vector3.ZERO)
			_shape(body, _bshape(Vector3(0.32, 0.16, 0.22) * sc))
		"moneybag":
			col = Color(0.72, 0.6, 0.38)
			_mesh(body, _sph(0.2), mat(col), Vector3.ZERO)
			_shape(body, _sshape(0.2), Vector3(0, 0.0, 0))
			_shape(body, _sshape(0.08), Vector3(0, 0.2, 0))
		"orb":
			col = Color(0.75, 0.3, 1.0)
			_mesh(body, _sph(0.22), mat(col, 1.6, 0.0, 0.9), Vector3.ZERO)
			_mesh(body, _sph(0.12), mat(Color(1, 0.9, 1), 2.5), Vector3.ZERO)
			var l := OmniLight3D.new()
			l.light_color = col
			l.omni_range = 3.0
			l.light_energy = 0.8
			body.add_child(l)
			_shape(body, _sshape(0.22))
		"head":
			col = COLORS_SAFE[extra % COLORS_SAFE.size()] if extra >= 0 else Color.ORANGE
			_mesh(body, _sph(0.2), mat(Color(0.75, 0.75, 0.78), 0.0, 0.6), Vector3.ZERO)
			_mesh(body, _box(Vector3(0.28, 0.08, 0.06)), mat(col, 2.0), Vector3(0, 0.03, -0.17))
			_mesh(body, _cyl(0.01, 0.01, 0.15), dark, Vector3(0, 0.25, 0))
			_mesh(body, _sph(0.03), mat(col, 2.0), Vector3(0, 0.33, 0))
			_shape(body, _sshape(0.2))
		"cart":
			col = Color(0.6, 0.62, 0.65)
			var metal := mat(col, 0.0, 0.7)
			_mesh(body, _box(Vector3(1.2, 0.06, 0.8)), metal, Vector3(0, -0.18, 0))
			_mesh(body, _box(Vector3(1.2, 0.4, 0.05)), metal, Vector3(0, 0.0, 0.4))
			_mesh(body, _box(Vector3(1.2, 0.4, 0.05)), metal, Vector3(0, 0.0, -0.4))
			_mesh(body, _box(Vector3(0.05, 0.4, 0.8)), metal, Vector3(0.6, 0.0, 0))
			_mesh(body, _box(Vector3(0.05, 0.4, 0.8)), metal, Vector3(-0.6, 0.0, 0))
			_mesh(body, _cyl(0.02, 0.02, 0.8), mat(Color(0.9, 0.3, 0.1)), Vector3(-0.75, 0.3, 0), Vector3(PI / 2, 0, 0))
			for wx in [-0.45, 0.45]:
				for wz in [-0.33, 0.33]:
					_mesh(body, _cyl(0.08, 0.08, 0.05), dark, Vector3(wx, -0.26, wz), Vector3(PI / 2, 0, 0))
			_shape(body, _bshape(Vector3(1.2, 0.08, 0.8)), Vector3(0, -0.2, 0))
			_shape(body, _bshape(Vector3(1.2, 0.4, 0.06)), Vector3(0, 0.0, 0.4))
			_shape(body, _bshape(Vector3(1.2, 0.4, 0.06)), Vector3(0, 0.0, -0.4))
			_shape(body, _bshape(Vector3(0.06, 0.4, 0.8)), Vector3(0.6, 0.0, 0))
			_shape(body, _bshape(Vector3(0.06, 0.4, 0.8)), Vector3(-0.6, 0.0, 0))
			_shape(body, _sshape(0.1), Vector3(0.45, -0.24, 0.3))
			_shape(body, _sshape(0.1), Vector3(-0.45, -0.24, 0.3))
			_shape(body, _sshape(0.1), Vector3(0.45, -0.24, -0.3))
			_shape(body, _sshape(0.1), Vector3(-0.45, -0.24, -0.3))
			_shape(body, _bshape(Vector3(0.1, 0.12, 0.92)), Vector3(-0.78, 0.3, 0))   # handle (strong grip)
	_apply_model(type, body, r, col)
	return col


static func _apply_model(type: String, body: Node3D, r: RandomNumberGenerator, col: Color) -> void:
	var mname := type
	var over := {}
	match type:
		"vase":
			mname = "vase%d" % (r.randi() % 3)
			over["M_vase"] = ML.plain(col, 0.22, 0.1)
		"painting":
			over["M_canvas"] = ML.canvas(r.randi() % 8)
		"mask":
			over["M_mask"] = ML.plain(col, 0.35, 0.5)
		"beaker":
			var lc := Color.from_hsv(r.randf(), 0.8, 1.0)
			over["E_liquid"] = ML.plain(lc, 0.2, 0.0, 1.5, 0.85)
		"up_hp", "up_stamina", "up_strength", "up_range", "up_speed", "up_jump", "up_tumble", "up_crouch":
			mname = "canister"
			over["E_upgrade"] = ML.plain(col, 0.3, 0.0, 2.5)
		"med_s", "med_m", "med_l":
			mname = "medkit_" + type.substr(4)
		"head":
			over["M_player"] = ML.plain(col, 0.45, 0.2)
			over["M_player_glow"] = ML.plain(col, 0.3, 0.0, 3.0)
	var m := ML.model(mname, over)
	if m == null:
		return
	for c in body.get_children():
		if c is MeshInstance3D:
			body.remove_child(c)
			c.queue_free()
	body.add_child(m)
	ML.vis_range(m, 32.0, 4.0)


const UP_COLORS := {"up_hp": Color(1.0, 0.35, 0.3), "up_stamina": Color(0.3, 0.7, 1.0), "up_strength": Color(1.0, 0.6, 0.1), "up_range": Color(0.75, 0.4, 1.0), "up_speed": Color(0.4, 1.0, 0.4), "up_jump": Color(1.0, 1.0, 0.4), "up_tumble": Color(0.3, 1.0, 0.9), "up_crouch": Color(0.9, 0.5, 1.0)}


static func is_gear(type: String) -> bool:
	return DEFS.get(type, {}).has("cat")


static func can_store(type: String) -> bool:
	return DEFS.get(type, {}).get("store", false)


static func gear_shapes(type: String, body: RigidBody3D) -> bool:
	match type:
		"w_bat":
			_shape(body, _bshape(Vector3(0.09, 0.09, 0.82)), Vector3(0, 0, -0.155))
		"w_sledge":
			_shape(body, _bshape(Vector3(0.05, 0.05, 0.9)))
			_shape(body, _bshape(Vector3(0.12, 0.3, 0.13)), Vector3(0, 0, -0.45))
		"w_pan":
			_shape(body, _cshape(0.15, 0.05), Vector3(0, 0, -0.28))
			_shape(body, _bshape(Vector3(0.04, 0.03, 0.3)))
		"w_prod":
			_shape(body, _bshape(Vector3(0.05, 0.05, 0.7)), Vector3(0, 0, -0.1))
		"w_pistol":
			_shape(body, _bshape(Vector3(0.05, 0.14, 0.28)), Vector3(0, 0.01, -0.06))
		"w_shotgun":
			_shape(body, _bshape(Vector3(0.08, 0.12, 0.95)), Vector3(0, 0.02, -0.2))
		"w_tranq":
			_shape(body, _bshape(Vector3(0.05, 0.12, 0.38)), Vector3(0, 0.02, -0.1))
		"g_explosive", "g_stun", "g_shock":
			_shape(body, _sshape(0.07))
		"m_explosive", "m_stun":
			_shape(body, _cshape(0.15, 0.08), Vector3(0, 0.02, 0))
		"d_feather", "d_shield":
			_shape(body, _bshape(Vector3(0.26, 0.08, 0.26)))
		"t_valuable", "t_extract":
			_shape(body, _bshape(Vector3(0.09, 0.17, 0.06)))
		"i_crystal":
			_shape(body, _bshape(Vector3(0.14, 0.26, 0.14)))
		"i_pocketcart":
			_shape(body, _bshape(Vector3(0.6, 0.04, 0.4)), Vector3(0, -0.1, 0))
			_shape(body, _bshape(Vector3(0.6, 0.2, 0.03)), Vector3(0, 0.0, 0.2))
			_shape(body, _bshape(Vector3(0.6, 0.2, 0.03)), Vector3(0, 0.0, -0.2))
			_shape(body, _bshape(Vector3(0.03, 0.2, 0.4)), Vector3(0.3, 0.0, 0))
			_shape(body, _bshape(Vector3(0.03, 0.2, 0.4)), Vector3(-0.3, 0.0, 0))
			_shape(body, _bshape(Vector3(0.08, 0.08, 0.34)), Vector3(-0.42, 0.16, 0))   # handle
		_:
			return false
	return true


static func is_shop(type: String) -> bool:
	if DEFS.get(type, {}).has("price"):
		return true
	return type.begins_with("up_") or type.begins_with("med_")


const COLORS_SAFE := [Color(1.0, 0.55, 0.1), Color(0.2, 0.75, 1.0), Color(0.45, 1.0, 0.3), Color(1.0, 0.35, 0.65)]
