extends RefCounted
## Small visual effects helpers.


static func float_text(parent: Node3D, pos: Vector3, text: String, color: Color, size := 56) -> void:
	var l := Label3D.new()
	l.text = text
	l.modulate = color
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.font_size = size
	l.pixel_size = 0.004
	l.no_depth_test = true
	l.outline_size = 10
	l.outline_modulate = Color(0, 0, 0, 0.8)
	parent.add_child(l)
	l.global_position = pos
	var tw := l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "global_position", pos + Vector3(0, 0.9, 0), 1.3)
	tw.tween_property(l, "modulate:a", 0.0, 1.3).set_delay(0.3)
	tw.chain().tween_callback(l.queue_free)


## Particle budget per quality level (effects keep their look, just fewer, larger-feeling bursts on weak phones).
static func _amt(n: int) -> int:
	var q: int = Settings.quality
	return maxi(3, int(round(n * [0.5, 0.75, 1.0][q])))


static func burst(parent: Node3D, pos: Vector3, color: Color, amount := 18, speed := 3.0, gravity := -9.0, life := 0.9, size := 0.05, emissive := false) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = _amt(amount)
	p.lifetime = life
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, gravity, 0)
	p.scale_amount_min = 0.6
	p.scale_amount_max = 1.2
	var m := BoxMesh.new()
	m.size = Vector3.ONE * size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	if emissive:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = 2.0
	m.material = mat
	p.mesh = m
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	parent.get_tree().create_timer(life + 0.5).timeout.connect(p.queue_free)


static func ping(parent: Node3D, pos: Vector3, who: String, color: Color) -> void:
	var n := Node3D.new()
	parent.add_child(n)
	n.global_position = pos
	var l := Label3D.new()
	l.text = "▼\n" + who
	l.modulate = color
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.font_size = 64
	l.pixel_size = 0.005
	l.outline_size = 10
	l.position = Vector3(0, 0.6, 0)
	n.add_child(l)
	var m := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.03
	cm.bottom_radius = 0.03
	cm.height = 3.0
	m.mesh = cm
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(color.r, color.g, color.b, 0.5)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.material_override = mat
	m.position = Vector3(0, 1.5, 0)
	n.add_child(m)
	var tw := n.create_tween()
	tw.tween_interval(5.0)
	tw.tween_property(l, "modulate:a", 0.0, 1.0)
	tw.tween_callback(n.queue_free)


static func shatter(parent: Node3D, pos: Vector3, color: Color) -> void:
	shards(parent, pos, color, 18)
	smoke(parent, pos, Color(0.6, 0.58, 0.55, 0.5), 8, 0.35, 1.2, 0.4)
	sparks(parent, pos, Color(1.0, 0.95, 0.85), 10, 3.0, 0.4)


static func sparkle(parent: Node3D, pos: Vector3) -> void:
	burst(parent, pos, Color(0.4, 1.0, 0.6), 24, 2.0, 3.0, 1.0, 0.05, true)
	sparks(parent, pos, Color(0.5, 1.0, 0.7), 16, 2.5, 0.8)


# ------------------------------------------------------------------ richer effects

static var _soft: Texture2D = null


## Soft round sprite used for smoke, dust and glows.
static func soft_tex() -> Texture2D:
	if _soft == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.add_point(0.45, Color(1, 1, 1, 0.55))
		g.set_color(g.get_point_count() - 1, Color(1, 1, 1, 0))
		var gt := GradientTexture2D.new()
		gt.gradient = g
		gt.fill = GradientTexture2D.FILL_RADIAL
		gt.fill_from = Vector2(0.5, 0.5)
		gt.fill_to = Vector2(1.0, 0.5)
		gt.width = 64
		gt.height = 64
		_soft = gt
	return _soft


static func _done(parent: Node3D, n: Node, t: float) -> void:
	parent.get_tree().create_timer(t).timeout.connect(n.queue_free)


## Billowing smoke / dust puffs (alpha-blended billboards that grow and fade).
static func smoke(parent: Node3D, pos: Vector3, color: Color, amount := 12, size := 0.5, life := 1.8, speed := 0.8, rise := 0.6) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = _amt(amount)
	p.lifetime = life
	p.explosiveness = 0.9
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = speed * 0.3
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, rise, 0)
	p.damping_min = 1.5
	p.damping_max = 3.0
	var sc := Curve.new()
	sc.add_point(Vector2(0, 0.4))
	sc.add_point(Vector2(1, 1.6))
	p.scale_amount_curve = sc
	var cr := Gradient.new()
	cr.set_color(0, Color(color.r, color.g, color.b, color.a))
	cr.set_color(1, Color(color.r, color.g, color.b, 0.0))
	p.color_ramp = cr
	p.angle_min = 0.0
	p.angle_max = 360.0
	var q := QuadMesh.new()
	q.size = Vector2.ONE * size
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = soft_tex()
	m.disable_receive_shadows = true
	q.material = m
	p.mesh = q
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	_done(parent, p, life + 0.5)


## Bright additive sparks that fall and fade.
static func sparks(parent: Node3D, pos: Vector3, color: Color, amount := 16, speed := 5.0, life := 0.6) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = _amt(amount)
	p.lifetime = life
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, -9.0, 0)
	p.scale_amount_min = 0.5
	p.scale_amount_max = 1.0
	var cr := Gradient.new()
	cr.set_color(0, Color(color.r * 3.0, color.g * 3.0, color.b * 3.0, 1.0))
	cr.set_color(1, Color(color.r, color.g * 0.5, color.b * 0.2, 0.0))
	p.color_ramp = cr
	var q := QuadMesh.new()
	q.size = Vector2(0.03, 0.03)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = soft_tex()
	q.material = m
	p.mesh = q
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	_done(parent, p, life + 0.4)


## Spinning triangular shards (broken valuables, glass).
static func shards(parent: Node3D, pos: Vector3, color: Color, amount := 16) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = _amt(amount)
	p.lifetime = 1.4
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 160.0
	p.initial_velocity_min = 1.5
	p.initial_velocity_max = 4.0
	p.gravity = Vector3(0, -12.0, 0)
	p.angular_velocity_min = -720.0
	p.angular_velocity_max = 720.0
	p.scale_amount_min = 0.5
	p.scale_amount_max = 1.3
	p.particle_flag_rotate_y = true
	var pm := PrismMesh.new()
	pm.size = Vector3(0.06, 0.05, 0.01)
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.3
	m.metallic = 0.2
	pm.material = m
	p.mesh = pm
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	_done(parent, p, 2.0)


## Expanding flat ring (explosions, stun pulses, scream).
static func shockwave(parent: Node3D, pos: Vector3, radius: float, color: Color, life := 0.45) -> void:
	var mi := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.85
	tm.outer_radius = 1.0
	tm.rings = 32
	tm.ring_segments = 6
	mi.mesh = tm
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.albedo_color = Color(color.r, color.g, color.b, 0.9)
	mi.material_override = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	mi.global_position = pos
	mi.scale = Vector3(0.1, 0.05, 0.1)
	var tw := mi.create_tween().set_parallel(true)
	tw.tween_property(mi, "scale", Vector3(radius, 0.3, radius), life).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	tw.tween_property(m, "albedo_color:a", 0.0, life)
	tw.chain().tween_callback(mi.queue_free)


## Glowing fireball that swells and fades (explosions).
static func fireball(parent: Node3D, pos: Vector3, radius: float) -> void:
	for i in 2:
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.5
		sm.height = 1.0
		sm.radial_segments = 20
		sm.rings = 10
		mi.mesh = sm
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		m.albedo_color = Color(4.0, 2.0, 0.6, 1.0) if i == 0 else Color(2.0, 0.6, 0.15, 0.8)
		mi.material_override = m
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(mi)
		mi.global_position = pos
		mi.scale = Vector3.ONE * 0.2
		var tw := mi.create_tween().set_parallel(true)
		var r := radius * (0.7 if i == 0 else 1.1)
		tw.tween_property(mi, "scale", Vector3.ONE * r, 0.25 + i * 0.1).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_EXPO)
		tw.tween_property(m, "albedo_color:a", 0.0, 0.45 + i * 0.15).set_delay(0.08)
		tw.chain().tween_callback(mi.queue_free)


static func flash(parent: Node3D, pos: Vector3, color: Color, energy: float, rng := 6.0, life := 0.35) -> void:
	var l := OmniLight3D.new()
	l.light_color = color
	l.light_energy = energy
	l.omni_range = rng
	parent.add_child(l)
	l.global_position = pos
	var tw := l.create_tween()
	tw.tween_property(l, "light_energy", 0.0, life)
	tw.tween_callback(l.queue_free)


static func explosion(parent: Node3D, pos: Vector3, a := 1.0) -> void:
	fireball(parent, pos, 2.4 * a)
	shockwave(parent, pos + Vector3(0, 0.1, 0), 4.0 * a, Color(1.0, 0.7, 0.4))
	sparks(parent, pos, Color(1.0, 0.6, 0.2), 40, 9.0 * a, 1.0)
	smoke(parent, pos + Vector3(0, 0.3, 0), Color(0.12, 0.11, 0.1, 0.85), 18, 1.4 * a, 2.6, 2.5, 0.9)
	burst(parent, pos, Color(0.2, 0.18, 0.16), 16, 6.0, -9.0, 1.4, 0.07)
	flash(parent, pos, Color(1.0, 0.6, 0.3), 9.0, 10.0, 0.6)


## Dust kicked up by a heavy impact.
static func impact_dust(parent: Node3D, pos: Vector3, strength: float) -> void:
	smoke(parent, pos, Color(0.55, 0.5, 0.45, 0.35), int(clampf(strength * 2.0, 3.0, 10.0)), 0.3 + strength * 0.04, 1.0, 0.6, 0.2)
