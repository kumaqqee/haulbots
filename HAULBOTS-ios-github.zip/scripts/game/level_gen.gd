extends RefCounted
## Deterministic procedural mansion: rooms, doors, furniture, lights, spots.

const ROOM := 8.0
const H := 3.2
const WT := 0.3
const DW := 1.8
const DH := 2.4
const HR := ROOM / 2.0
const DIRS := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
const FRAME := Color(0.2, 0.12, 0.07)

const THEMES := {
	"hall": {"wt": "wall_damask", "ft": "wood_floor", "wn": "wood", "wall": Color(0.45, 0.22, 0.2), "floor": Color(0.38, 0.25, 0.15), "light": Color(1.0, 0.8, 0.55), "pieces": ["table", "cabinet", "fireplace", "shelf"]},
	"library": {"wt": "wall_stripes", "ft": "wood_floor", "wn": "wood_dark", "wall": Color(0.2, 0.32, 0.24), "floor": Color(0.32, 0.2, 0.12), "light": Color(1.0, 0.85, 0.62), "pieces": ["shelf", "shelf", "shelf", "table"]},
	"dining": {"wt": "wall_diamond", "ft": "wood_floor", "wn": "wood", "wall": Color(0.48, 0.4, 0.26), "floor": Color(0.3, 0.18, 0.1), "light": Color(1.0, 0.78, 0.5), "pieces": ["table", "table", "cabinet"]},
	"bedroom": {"wt": "wall_damask", "ft": "carpet", "wn": "wood", "wall": Color(0.32, 0.26, 0.42), "floor": Color(0.34, 0.22, 0.18), "light": Color(0.9, 0.8, 1.0), "pieces": ["bed", "cabinet", "shelf"]},
	"storage": {"wt": "wall_plaster", "ft": "concrete", "wn": "concrete", "wall": Color(0.34, 0.34, 0.32), "floor": Color(0.26, 0.26, 0.26), "light": Color(0.8, 0.9, 1.0), "pieces": ["crates", "shelf", "crates"]},
	"lounge": {"wt": "wall_stripes", "ft": "wood_floor", "wn": "wood_dark", "wall": Color(0.25, 0.28, 0.45), "floor": Color(0.32, 0.2, 0.15), "light": Color(1.0, 0.8, 0.6), "pieces": ["sofa", "piano", "cabinet", "table"]},
	"garage": {"wt": "wall_panels", "ft": "concrete", "wn": "concrete", "wall": Color(0.3, 0.3, 0.28), "floor": Color(0.2, 0.2, 0.21), "light": Color(0.95, 0.95, 1.0), "pieces": []},
	"shop": {"wt": "wall_panels", "ft": "floor_lab", "wn": "wall_panels", "wall": Color(0.5, 0.55, 0.6), "floor": Color(0.5, 0.5, 0.5), "light": Color(1.0, 0.98, 0.92), "pieces": []},
	"gallery": {"wt": "wall_plaster", "ft": "floor_marble", "wn": "marble", "wall": Color(0.8, 0.76, 0.68), "floor": Color(0.72, 0.7, 0.66), "floor2": Color(0.3, 0.29, 0.28), "light": Color(1.0, 0.95, 0.85), "pieces": ["pedestal", "pedestal", "bench", "case"]},
	"exhibit": {"wt": "wall_damask", "ft": "floor_marble", "wn": "wood_dark", "wall": Color(0.5, 0.12, 0.13), "floor": Color(0.25, 0.24, 0.24), "floor2": Color(0.45, 0.44, 0.42), "light": Color(1.0, 0.88, 0.7), "pieces": ["pedestal", "case", "case", "bench"]},
	"archive": {"wt": "wall_plaster", "ft": "wood_floor", "wn": "wood", "wall": Color(0.4, 0.38, 0.33), "floor": Color(0.3, 0.22, 0.14), "light": Color(1.0, 0.85, 0.6), "pieces": ["shelf", "shelf", "crates", "case"]},
	"lab": {"wt": "wall_panels", "ft": "floor_lab", "wn": "wall_panels", "wall": Color(0.82, 0.86, 0.88), "floor": Color(0.58, 0.63, 0.68), "floor2": Color(0.48, 0.53, 0.58), "light": Color(0.85, 0.95, 1.0), "pieces": ["labbench", "labbench", "rack", "shelf"]},
	"servers": {"wt": "wall_panels", "ft": "floor_lab", "wn": "wall_panels", "wall": Color(0.2, 0.22, 0.26), "floor": Color(0.22, 0.24, 0.27), "floor2": Color(0.16, 0.17, 0.2), "light": Color(0.6, 0.8, 1.0), "pieces": ["rack", "rack", "rack", "labbench"]},
	"office": {"wt": "wall_plaster", "ft": "carpet", "wn": "wood", "wall": Color(0.58, 0.6, 0.58), "floor": Color(0.28, 0.3, 0.34), "light": Color(0.95, 0.97, 1.0), "pieces": ["desk", "desk", "cabinet", "shelf"]},
}
const LOCATION_ROOMS := [
	["hall", "library", "dining", "bedroom", "storage", "lounge"],
	["gallery", "gallery", "exhibit", "archive", "storage", "hall"],
	["lab", "lab", "servers", "office", "storage"],
]

var rng := RandomNumberGenerator.new()
var location := 0
var cells := {}
var order := []
var conn := {}
var astar := AStar2D.new()
var cell_ids := {}
var door_pos := {}
var dist := {}
var spawn_cell := Vector2i.ZERO
var door_dir := Vector2i(1, 0)
var spawn_points := []
var truck_pos := Vector3.ZERO
var truck_button := Vector3.ZERO
var cart_pos := Vector3.ZERO
var extraction_cells := []
var extraction_points := []
var item_spots := []
var monster_cells := []
var lights := []
var root: Node3D
var body: StaticBody3D
var truck_back := Vector3.ZERO
var truck_side := Vector3.ZERO
var truck_screen := Vector3.ZERO
var _sts := {}
var _mk := "wall"
var _vis := true
var _th: Dictionary = {}
var _decor := []
var _mcache := {}
const ML = preload("res://scripts/game/matlib.gd")
const LOW_PIECES := ["table", "cabinet", "sofa", "bench", "case", "desk", "labbench", "bed", "crates"]
var mat: StandardMaterial3D
var lamp_mat: StandardMaterial3D


static func key(a: Vector2i, b: Vector2i) -> String:
	if a.x < b.x or (a.x == b.x and a.y < b.y):
		return "%d,%d|%d,%d" % [a.x, a.y, b.x, b.y]
	return "%d,%d|%d,%d" % [b.x, b.y, a.x, a.y]


static func cell_center(c: Vector2i) -> Vector3:
	return Vector3(c.x * ROOM, 0.0, c.y * ROOM)


static func cell_at(p: Vector3) -> Vector2i:
	return Vector2i(roundi(p.x / ROOM), roundi(p.z / ROOM))


func conn_type(a: Vector2i, b: Vector2i) -> int:
	var k := key(a, b)
	if conn.has(k):
		return int(conn[k]["t"])
	return 0


func build(s: int, level: int, parent: Node3D) -> void:
	rng.seed = s
	location = (level - 1) % LOCATION_ROOMS.size()
	_layout(level)
	_connect()
	_graph()
	_pick_special(level)
	_make_geometry(parent)


func _make_geometry(parent: Node3D) -> void:
	root = Node3D.new()
	root.name = "Level"
	parent.add_child(root)
	body = StaticBody3D.new()
	body.name = "Static"
	body.collision_layer = 1
	body.collision_mask = 0
	root.add_child(body)
	mat = StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.92
	var nt := NoiseTexture2D.new()
	nt.width = 128
	nt.height = 128
	nt.seamless = true
	var fn := FastNoiseLite.new()
	fn.frequency = 0.06
	fn.fractal_octaves = 3
	nt.noise = fn
	var g := Gradient.new()
	g.set_color(0, Color(0.72, 0.72, 0.72))
	g.set_color(1, Color(1, 1, 1))
	nt.color_ramp = g
	mat.albedo_texture = nt
	mat.uv1_triplanar = true
	mat.uv1_scale = Vector3(0.6, 0.6, 0.6)
	lamp_mat = StandardMaterial3D.new()
	lamp_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lamp_mat.albedo_color = Color(1.0, 0.9, 0.7)
	for c in order:
		_build_cell(c)


# ------------------------------------------------------------------ layout

func _nb_count(c: Vector2i) -> int:
	var n := 0
	for d in DIRS:
		if cells.has(c + d):
			n += 1
	return n


func _layout(level: int) -> void:
	var target := clampi(7 + level * 3, 8, 34)
	cells[Vector2i.ZERO] = "garage"
	order.append(Vector2i.ZERO)
	var guard := 0
	while order.size() < target and guard < 20000:
		guard += 1
		var base: Vector2i = order[rng.randi() % order.size()]
		var n: Vector2i = base + DIRS[rng.randi() % 4]
		if cells.has(n):
			continue
		var touches_spawn := (n - Vector2i.ZERO).length_squared() == 1
		if touches_spawn and _nb_count(Vector2i.ZERO) >= 1:
			continue
		if base == Vector2i.ZERO and _nb_count(Vector2i.ZERO) >= 1:
			continue
		cells[n] = ""
		order.append(n)
	var names: Array = LOCATION_ROOMS[location]
	for c in order:
		if c != Vector2i.ZERO:
			cells[c] = names[rng.randi() % names.size()]
	for d in DIRS:
		if cells.has(Vector2i.ZERO + d):
			door_dir = d


func _connect() -> void:
	var visited := {spawn_cell: true}
	var stack := [spawn_cell]
	while stack.size() > 0:
		var c: Vector2i = stack[stack.size() - 1]
		var nbs := []
		for d in DIRS:
			var n: Vector2i = c + d
			if cells.has(n) and not visited.has(n):
				nbs.append(n)
		if nbs.is_empty():
			stack.pop_back()
			continue
		var n: Vector2i = nbs[rng.randi() % nbs.size()]
		visited[n] = true
		var t := 1
		if c != spawn_cell and rng.randf() < 0.18:
			t = 2
		conn[key(c, n)] = {"a": c, "b": n, "t": t}
		stack.append(n)
	for c in order:
		for d in [Vector2i(1, 0), Vector2i(0, 1)]:
			var n: Vector2i = c + d
			if not cells.has(n) or conn.has(key(c, n)):
				continue
			if c == spawn_cell or n == spawn_cell:
				continue
			if rng.randf() < 0.3:
				conn[key(c, n)] = {"a": c, "b": n, "t": 1 if rng.randf() < 0.75 else 2}


func _graph() -> void:
	for i in order.size():
		cell_ids[order[i]] = i
		astar.add_point(i, Vector2(order[i].x, order[i].y))
	for k in conn:
		var a: Vector2i = conn[k]["a"]
		var b: Vector2i = conn[k]["b"]
		astar.connect_points(cell_ids[a], cell_ids[b])
		door_pos[k] = (cell_center(a) + cell_center(b)) * 0.5
	dist[spawn_cell] = 0
	var q := [spawn_cell]
	while q.size() > 0:
		var c: Vector2i = q.pop_front()
		for d in DIRS:
			var n: Vector2i = c + d
			if cells.has(n) and not dist.has(n) and conn.has(key(c, n)):
				dist[n] = dist[c] + 1
				q.append(n)


func _pick_special(level: int) -> void:
	var cands := order.duplicate()
	cands.erase(spawn_cell)
	cands.sort_custom(func(a, b): return dist.get(a, 0) > dist.get(b, 0))
	# extraction points per level like the reference game: 1 / 2 / 2 / 3 / 3 / 4 ... / 5 from level 15
	var want := 1 if level <= 1 else (2 if level <= 3 else (3 if level <= 5 else (4 if level <= 14 else 5)))
	want = mini(want, cands.size() - 1)
	for c in cands:
		if extraction_cells.size() >= want:
			break
		if dist.get(c, 0) < 2 and cands.size() > 4:
			continue
		var ok := true
		for e in extraction_cells:
			if absi(e.x - c.x) + absi(e.y - c.y) <= 1:
				ok = false
		if ok:
			extraction_cells.append(c)
	if extraction_cells.is_empty():
		extraction_cells.append(cands[0])
	# order the points so the nearest to spawn is first
	extraction_cells.sort_custom(func(a, b): return dist.get(a, 0) < dist.get(b, 0))
	for c in extraction_cells:
		extraction_points.append(cell_center(c) + Vector3(0, 0.02, 0))
	for c in order:
		if dist.get(c, 0) >= 2:
			monster_cells.append(c)
	if monster_cells.is_empty():
		for c in order:
			if c != spawn_cell:
				monster_cells.append(c)


# ------------------------------------------------------------------ queries

func path_points(from: Vector3, to: Vector3) -> Array:
	var ca := cell_at(from)
	var cb := cell_at(to)
	if not cell_ids.has(ca) or not cell_ids.has(cb) or ca == cb:
		return [to]
	var ids := astar.get_id_path(cell_ids[ca], cell_ids[cb])
	var pts := []
	for j in range(1, ids.size()):
		var prev: Vector2i = order[ids[j - 1]]
		var cur: Vector2i = order[ids[j]]
		var dp: Vector3 = door_pos[key(prev, cur)]
		var axis := (cell_center(cur) - cell_center(prev)).normalized()
		pts.append(dp - axis * 1.0)
		pts.append(dp + axis * 1.0)
	pts.append(to)
	return pts


func random_point(r: RandomNumberGenerator) -> Vector3:
	var c: Vector2i = order[r.randi() % order.size()]
	return cell_center(c) + Vector3(r.randf_range(-2.0, 2.0), 0.1, r.randf_range(-2.0, 2.0))


func is_inside(p: Vector3) -> bool:
	return cells.has(cell_at(p))


# ------------------------------------------------------------------ geometry

func _add_shape(c: Vector3, s: Vector3) -> void:
	var cs := CollisionShape3D.new()
	var b := BoxShape3D.new()
	b.size = s
	cs.shape = b
	cs.position = c
	body.add_child(cs)


func _st() -> SurfaceTool:
	if not _sts.has(_mk):
		var t := SurfaceTool.new()
		t.begin(Mesh.PRIMITIVE_TRIANGLES)
		_sts[_mk] = t
	return _sts[_mk]


func _box(_unused, c: Vector3, s: Vector3, col: Color, collide: bool) -> void:
	if collide:
		_add_shape(c, s)
	if not _vis:
		return
	var st := _st()
	var h := s * 0.5
	for axis in 3:
		for sg in [-1.0, 1.0]:
			var n := Vector3.ZERO
			n[axis] = sg
			var u := Vector3.ZERO
			u[(axis + 1) % 3] = 1.0
			var v := Vector3.ZERO
			v[(axis + 2) % 3] = 1.0
			var fc: Vector3 = c + n * h[axis]
			var hu: Vector3 = u * h[(axis + 1) % 3]
			var hv: Vector3 = v * h[(axis + 2) % 3]
			var p0 := fc - hu - hv
			var p1 := fc + hu - hv
			var p2 := fc + hu + hv
			var p3 := fc - hu + hv
			var shade := 1.0 if axis == 1 else 0.9
			st.set_color(Color(col.r * shade, col.g * shade, col.b * shade))
			st.set_normal(n)
			if (p1 - p0).cross(p2 - p0).dot(n) < 0.0:
				st.add_vertex(p0); st.add_vertex(p1); st.add_vertex(p2)
				st.add_vertex(p0); st.add_vertex(p2); st.add_vertex(p3)
			else:
				st.add_vertex(p0); st.add_vertex(p2); st.add_vertex(p1)
				st.add_vertex(p0); st.add_vertex(p3); st.add_vertex(p2)


## Box in a wall-local frame: x = along wall, y = up, z = distance from wall face.
func _lbox(st, base: Vector3, along: Vector3, inward: Vector3, lc: Vector3, ls: Vector3, col: Color, collide := true) -> void:
	var c := base + along * lc.x + Vector3.UP * lc.y + inward * lc.z
	var s := along.abs() * ls.x + Vector3(0, ls.y, 0) + inward.abs() * ls.z
	_box(st, c, s, col, collide)


static var _halo_mat := {}
static var _shaft_mat: StandardMaterial3D = null


## Soft glow sprite around a lamp (reads as bloom even on low quality, costs one quad).
func _halo(pos: Vector3, col: Color, size: float) -> MeshInstance3D:
	var key := col.to_html()
	if not _halo_mat.has(key):
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
		m.albedo_texture = preload("res://scripts/game/fx.gd").soft_tex()
		m.albedo_color = Color(col.r, col.g, col.b, 0.28)
		m.no_depth_test = false
		m.disable_receive_shadows = true
		_halo_mat[key] = m
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = _halo_mat[key]
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.position = pos
	root.add_child(mi)
	ML.vis_range(mi, 24.0)
	return mi


## Faint cold moonlight falling through a window onto the floor.
func _moon_shaft(win: Vector3, inward: Vector3) -> void:
	if _shaft_mat == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 0.0))
		g.add_point(0.25, Color(1, 1, 1, 1.0))
		g.set_color(g.get_point_count() - 1, Color(1, 1, 1, 0.0))
		var gt := GradientTexture2D.new()
		gt.gradient = g
		gt.width = 64
		gt.height = 8
		_shaft_mat = StandardMaterial3D.new()
		_shaft_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_shaft_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		_shaft_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_shaft_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		_shaft_mat.albedo_texture = gt
		_shaft_mat.albedo_color = Color(0.45, 0.58, 0.9, 0.06)
		_shaft_mat.disable_receive_shadows = true
	var along := inward.cross(Vector3.UP).normalized()
	for k in 2:
		var q := QuadMesh.new()
		q.size = Vector2(3.2, 1.0)
		var mi := MeshInstance3D.new()
		mi.mesh = q
		mi.material_override = _shaft_mat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(mi)
		# slanted slab from the window down into the room; two crossed planes read as a volume
		var down := (inward * 0.8 + Vector3(0, -0.6, 0)).normalized()
		var side := along if k == 0 else (along * 0.5 + Vector3(0, 0.866, 0)).normalized()
		var nrm := down.cross(side).normalized()
		mi.global_transform = Transform3D(Basis(down, side, nrm), win + down * 1.55)
		ML.vis_range(mi, 18.0)


## Occlusion culling: walls hide whole rooms behind them (big win on weak GPUs, zero visual cost).
func _occluder(center: Vector3, size: Vector3) -> void:
	if not _vis:
		return
	var oc := OccluderInstance3D.new()
	var bo := BoxOccluder3D.new()
	bo.size = size
	oc.occluder = bo
	oc.position = center
	root.add_child(oc)


func _wall(_st_unused, c: Vector2i, d: Vector2i, door: bool, col: Color) -> void:
	var cc := cell_center(c)
	var normal := Vector3(d.x, 0, d.y)
	var along := Vector3(absi(d.y), 0, absi(d.x))
	var wc := cc + normal * HR
	var nt := normal.abs() * WT
	var dado := 1.0
	var white := Color(1, 1, 1)
	var segs := []
	if not door:
		segs.append([wc, ROOM + WT])
	else:
		var seg := HR - DW / 2.0 + WT / 2.0
		for sg in [-1.0, 1.0]:
			segs.append([wc + along * sg * (DW / 2.0 + seg / 2.0), seg])
	for sgm in segs:
		var sc: Vector3 = sgm[0]
		var ln: float = sgm[1]
		_mk = "wains"
		_box(null, sc + Vector3(0, dado / 2.0, 0), along * ln + Vector3(0, dado, 0) + nt, white, true)
		_mk = "wall"
		_box(null, sc + Vector3(0, (dado + H) / 2.0, 0), along * ln + Vector3(0, H - dado, 0) + nt, col, true)
		_occluder(sc + Vector3(0, H / 2.0, 0), along * maxf(0.1, ln - 0.3) + Vector3(0, H - 0.3, 0) + normal.abs() * WT * 0.5)
		_mk = "trim"
		_box(null, sc + Vector3(0, 0.07, 0), along * ln + Vector3(0, 0.14, 0) + normal.abs() * (WT + 0.05), white, false)
		_box(null, sc + Vector3(0, dado, 0), along * ln + Vector3(0, 0.05, 0) + normal.abs() * (WT + 0.04), white, false)
		_box(null, sc + Vector3(0, H - 0.06, 0), along * ln + Vector3(0, 0.12, 0) + normal.abs() * (WT + 0.08), white, false)
	if door:
		_mk = "wall"
		_box(null, wc + Vector3(0, (DH + H) / 2.0, 0), along * DW + Vector3(0, H - DH, 0) + nt, col, true)
		_decor.append({"model": "doorframe", "pos": wc, "fwd": normal, "scale": 1.0})
		if location != 2 and rng.randf() < 0.55:
			# an open door leaf resting against the wall inside this room
			var side := 1.0 if rng.randf() < 0.5 else -1.0
			var into := -normal
			var fwd := along
			if fwd.cross(Vector3.UP).dot(into) < 0.0:
				fwd = -fwd
			var hinge := wc + along * side * (DW / 2.0 - 0.03) + into * (WT / 2.0)
			_decor.append({"model": "prop_door", "pos": hinge, "fwd": fwd, "scale": 0.98})
			_add_shape(hinge + into * 0.45 + Vector3(0, 1.15, 0), into.abs() * 0.9 + along.abs() * 0.06 + Vector3(0, 2.3, 0))


const SurfaceShader = preload("res://assets/shaders/surface.gdshader")
static var _dirt_tex: NoiseTexture2D = null


static func dirt_texture() -> NoiseTexture2D:
	if _dirt_tex == null:
		var fn := FastNoiseLite.new()
		fn.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
		fn.frequency = 0.012
		fn.fractal_octaves = 5
		fn.seed = 77
		_dirt_tex = NoiseTexture2D.new()
		_dirt_tex.width = 256
		_dirt_tex.height = 256
		_dirt_tex.seamless = true
		_dirt_tex.generate_mipmaps = true
		_dirt_tex.noise = fn
	return _dirt_tex


## World surface material (see assets/shaders/surface.gdshader).
static func surface_material(tname: String, scale: float, tint: float, boost := 1.3, dirt := 0.5, rough_add := 0.0, ao := 1.0, nstr := 1.0) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = SurfaceShader
	m.set_shader_parameter("albedo_tex", ML.tex(tname))
	var tn: Texture2D = ML.tex(tname + "_n")
	if tn:
		m.set_shader_parameter("normal_tex", tn)
	m.set_shader_parameter("normal_strength", nstr if tn else 0.0)
	var tr: Texture2D = ML.tex(tname + "_r")
	if tr:
		m.set_shader_parameter("rough_tex", tr)
	else:
		m.set_shader_parameter("rough_add", 0.8)
		m.set_shader_parameter("rough_mul", 0.0)
	m.set_shader_parameter("uv_scale", scale)
	m.set_shader_parameter("tint_amount", tint)
	m.set_shader_parameter("tint_boost", boost)
	m.set_shader_parameter("dirt_tex", dirt_texture())
	m.set_shader_parameter("dirt_amount", dirt)
	m.set_shader_parameter("rough_add", rough_add if tr else 0.8)
	m.set_shader_parameter("ao_strength", ao)
	m.set_shader_parameter("room", ROOM)
	m.set_shader_parameter("half_room", HR - WT / 2.0)
	m.set_shader_parameter("room_h", H)
	return m


func _surface_mat(key: String) -> Material:
	var th := _th
	var ck: String = key + "|" + str(th.get("wt", "")) + str(th.get("ft", "")) + str(th.get("wn", ""))
	if _mcache.has(ck):
		return _mcache[ck]
	var m: Material = null
	match key:
		"wall":
			m = surface_material(th["wt"], 0.42, 1.0, 1.25, 0.55)
		"wains":
			var wn: String = th["wn"]
			m = surface_material(wn, 0.55, 0.0 if wn.begins_with("wood") or wn == "marble" else 0.8, 1.2, 0.6)
		"floor":
			var ft: String = th["ft"]
			m = surface_material(ft, 0.34 if ft != "floor_lab" else 0.3, 0.45 if ft in ["carpet", "concrete"] else 0.0, 1.0, 0.45)
		"ceil":
			m = surface_material("ceiling", 0.3, 1.0, 0.62, 0.3, 0.1, 0.8)
		"trim":
			m = surface_material("wood_dark", 1.0, 0.0, 1.0, 0.2, 0.0, 0.4)
		"rug":
			m = surface_material("carpet", 0.8, 0.7, 1.35, 0.3, 0.0, 0.5)
		_:
			var sm := StandardMaterial3D.new()
			sm.vertex_color_use_as_albedo = true
			sm.roughness = 0.85
			m = sm
	_mcache[ck] = m
	return m


func _build_cell(c: Vector2i) -> void:
	_sts = {}
	var th: Dictionary = THEMES[cells[c]]
	_th = th
	var cc := cell_center(c)
	var wcol: Color = th["wall"]
	wcol = wcol.lerp(Color(rng.randf(), rng.randf(), rng.randf()), 0.07)
	var wtint := Color(minf(wcol.r * 1.7, 1.0), minf(wcol.g * 1.7, 1.0), minf(wcol.b * 1.7, 1.0))
	var ftint := Color.WHITE
	if th["ft"] in ["carpet", "concrete"]:
		var fc: Color = th["floor"]
		ftint = Color(minf(fc.r * 2.2, 1.0), minf(fc.g * 2.2, 1.0), minf(fc.b * 2.2, 1.0))
	_mk = "floor"
	_box(null, cc + Vector3(0, -0.1, 0), Vector3(ROOM, 0.2, ROOM), ftint, true)
	_mk = "ceil"
	_box(null, cc + Vector3(0, H + 0.1, 0), Vector3(ROOM, 0.2, ROOM), Color.WHITE, true)
	for d in DIRS:
		var n: Vector2i = c + d
		var own: bool = d == Vector2i(1, 0) or d == Vector2i(0, 1) or not cells.has(n)
		if not own:
			continue
		var t := conn_type(c, n) if cells.has(n) else 0
		if t == 2:
			continue
		_wall(null, c, d, t == 1, wtint)
	if c == spawn_cell:
		_build_garage(null, c)
	else:
		_furnish(null, c)
		_add_decals(c)
	var mesh := ArrayMesh.new()
	var keys := _sts.keys()
	for k in keys:
		var st: SurfaceTool = _sts[k]
		st.commit(mesh)
		mesh.surface_set_material(mesh.get_surface_count() - 1, _surface_mat(k))
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	root.add_child(mi)
	for dc in _decor:
		_spawn_decor(dc)
	_decor.clear()
	# ceiling lamp model + light
	var lname := "lamp_chandelier"
	var tn: String = cells[c]
	if tn in ["library", "archive", "office", "gallery", "exhibit"]:
		lname = "lamp_pendant"
	elif tn in ["lab", "servers", "shop"]:
		lname = "lamp_tube"
	elif tn in ["storage", "garage"]:
		lname = "lamp_cage"
	var lamp := ML.model(lname, {}, false)
	if lamp:
		lamp.position = cc + Vector3(0, H, 0)
		root.add_child(lamp)
		ML.vis_range(lamp, 26.0)
	var l := OmniLight3D.new()
	l.light_color = th["light"]
	l.light_energy = 1.35 if c != spawn_cell else 1.7
	if location == 2:
		l.light_energy *= 1.15
	l.omni_range = 8.5
	l.omni_attenuation = 1.45
	l.light_energy *= 1.05
	l.shadow_enabled = false
	l.omni_shadow_mode = OmniLight3D.SHADOW_DUAL_PARABOLOID
	l.shadow_bias = 0.06
	l.shadow_normal_bias = 1.5
	l.shadow_blur = 1.5
	l.light_size = 0.15
	# lights of far rooms stop costing anything
	l.distance_fade_enabled = true
	l.distance_fade_begin = 24.0
	l.distance_fade_length = 6.0
	l.distance_fade_shadow = 14.0
	l.position = cc + Vector3(0, H - 0.75, 0)
	if c == spawn_cell:
		l.position = cc - truck_back * 2.4 + Vector3(0, H - 0.5, 0)
		var inner := OmniLight3D.new()
		inner.light_color = Color(1.0, 0.95, 0.85)
		inner.light_energy = 0.3
		inner.omni_range = 3.5
		inner.position = truck_pos + Vector3(0, 1.8, 0)
		root.add_child(inner)
	root.add_child(l)
	var halo := _halo(l.position + Vector3(0, 0.25, 0), th["light"], 1.3)
	lights.append({"light": l, "base": l.light_energy, "flicker": c != spawn_cell and rng.randf() < 0.2, "lamp": lamp, "halo": halo})


static var _decal_tex := {}


static func decal_tex(n: String) -> Texture2D:
	if not _decal_tex.has(n):
		var p := "res://assets/decals/%s.png" % n
		_decal_tex[n] = load(p) if ResourceLoader.exists(p) else null
	return _decal_tex[n]


func _decal(tex: String, pos: Vector3, b: Basis, size: Vector3, alpha := 1.0) -> void:
	var t := decal_tex(tex)
	if t == null:
		return
	var d := Decal.new()
	d.texture_albedo = t
	d.size = size
	d.modulate = Color(1, 1, 1, alpha)
	d.albedo_mix = 1.0
	d.upper_fade = 0.2
	d.lower_fade = 0.2
	d.distance_fade_enabled = true
	d.distance_fade_begin = 13.0
	d.distance_fade_length = 4.0
	d.cull_mask = 1
	root.add_child(d)
	d.global_transform = Transform3D(b, pos)


## Grunge: stains, mould, cracks and drips on walls, dirt and scuffs on the floor, cobwebs in corners.
func _add_decals(c: Vector2i) -> void:
	var cc := cell_center(c)
	var clean := location == 2
	var inner := HR - WT / 2.0
	var n_wall := rng.randi_range(2, 4) if not clean else rng.randi_range(1, 2)
	for i in n_wall:
		var d: Vector2i = DIRS[rng.randi() % 4]
		var nb: Vector2i = c + d
		if cells.has(nb) and conn_type(c, nb) == 2:
			continue
		var normal := Vector3(d.x, 0, d.y)
		var along := Vector3(absi(d.y), 0, absi(d.x))
		var off := rng.randf_range(-3.0, 3.0)
		if cells.has(nb) and conn_type(c, nb) == 1 and absf(off) < 1.3:
			off = 2.2 * signf(off + 0.01)
		var kind: String = ["stain_water", "mould", "crack", "drips", "stain_water"][rng.randi() % 5]
		if clean:
			kind = ["crack", "scuffs"][rng.randi() % 2]
		var y := rng.randf_range(1.2, 2.5)
		var sz := rng.randf_range(0.8, 1.8)
		if kind == "drips":
			y = H - 0.9
			sz = rng.randf_range(1.0, 1.6)
		elif kind == "mould":
			y = rng.randf_range(0.4, 1.0) if rng.randf() < 0.5 else H - 0.5
		var yv := -normal
		var xv := yv.cross(Vector3.UP).normalized()
		var b := Basis(xv, yv, xv.cross(yv).normalized())
		_decal(kind, cc + normal * (inner - 0.05) + along * off + Vector3(0, y, 0), b, Vector3(sz, 0.5, sz * (1.6 if kind == "drips" else 1.0)), rng.randf_range(0.6, 1.0))
	for i in rng.randi_range(1, 3):
		var kind2: String = ["floor_dirt", "scuffs", "stain_water"][rng.randi() % 3]
		var b2 := Basis(Vector3.UP, rng.randf() * TAU)
		var sz2 := rng.randf_range(1.0, 2.4)
		_decal(kind2, cc + Vector3(rng.randf_range(-2.8, 2.8), 0.1, rng.randf_range(-2.8, 2.8)), b2, Vector3(sz2, 0.6, sz2), rng.randf_range(0.5, 0.9))
	if not clean and rng.randf() < 0.7:
		for k in rng.randi_range(1, 2):
			var sx := 1.0 if rng.randf() < 0.5 else -1.0
			var sz3 := 1.0 if rng.randf() < 0.5 else -1.0
			# ceiling decal projecting upwards; texture corner turned towards the room corner
			var b3 := Basis(Vector3.RIGHT, PI) * Basis(Vector3.UP, atan2(-sx, -sz3) + PI * 0.25)
			var corner := cc + Vector3(sx * (inner - 0.55), H - 0.1, sz3 * (inner - 0.55))
			_decal("cobweb", corner, b3, Vector3(1.2, 0.4, 1.2), 0.85)


func _spawn_decor(dc: Dictionary) -> void:
	if dc["model"] == "__ramp":
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = dc["size"]
		mi.mesh = bm
		mi.material_override = ML.named("M_metal")
		root.add_child(mi)
		mi.global_transform = dc["xf"]
		return
	var over := {}
	if dc.has("canvas"):
		over["M_canvas"] = ML.canvas(int(dc["canvas"]))
	var m := ML.model(dc["model"], over, dc.get("shadow", true))
	if m == null:
		return
	root.add_child(m)
	var fwd: Vector3 = dc["fwd"]
	m.global_transform = Transform3D(Basis.looking_at(fwd, Vector3.UP).scaled(Vector3.ONE * float(dc.get("scale", 1.0))), dc["pos"])
	var nm: String = dc["model"]
	var small := nm.begins_with("prop_") and nm != "prop_door" and nm != "prop_curtain"
	ML.vis_range(m, 14.0 if small else 26.0)


func _add_model(name: String, pos: Vector3, fwd: Vector3, scale := 1.0, extra := {}) -> void:
	var d := {"model": name, "pos": pos, "fwd": fwd, "scale": scale}
	d.merge(extra)
	_decor.append(d)


func _furnish(st: SurfaceTool, c: Vector2i) -> void:
	var th: Dictionary = THEMES[cells[c]]
	var pieces: Array = th["pieces"]
	var cc := cell_center(c)
	var is_extr := c in extraction_cells
	for d in DIRS:
		var n: Vector2i = c + d
		var t := conn_type(c, n) if cells.has(n) else 0
		if t == 2:
			continue
		var normal := Vector3(d.x, 0, d.y)
		var inward := -normal
		var along := Vector3(absi(d.y), 0, absi(d.x))
		var base := cc + normal * (HR - WT / 2.0)
		var slots := [-2.4, 2.4] if t == 1 else [-2.4, 0.0, 2.4]
		var outer := not cells.has(n)
		var mid_low := true
		for s in slots:
			if rng.randf() < 0.3:
				item_spots.append({"pos": base + along * s + inward * 0.9, "kind": "floor"})
				continue
			var piece: String = pieces[rng.randi() % pieces.size()]
			if s == 0.0 and not (piece in LOW_PIECES):
				if outer or rng.randf() < 0.5:
					piece = LOW_PIECES[rng.randi() % 4]
			_piece(st, piece, base + along * s, along, inward, th)
		if t != 1:
			var wall_face := cc + normal * (HR - WT / 2.0 - 0.02)
			if outer and location != 2:
				_add_model("window", wall_face + Vector3(0, 1.75, 0) + inward * 0.04, inward)
				_moon_shaft(wall_face + Vector3(0, 1.75, 0), inward)
				if rng.randf() < 0.75:
					_add_model("prop_curtain", wall_face + Vector3(0, 0.25, 0) + inward * 0.1, inward, 1.0, {"shadow": false})
			elif rng.randf() < 0.6 and location != 2:
				_add_model("painting", wall_face + Vector3(0, 1.8, 0) + inward * 0.04, inward, 1.5, {"canvas": rng.randi() % 8, "shadow": false})
				if rng.randf() < 0.6:
					for sx in [-1.0, 1.0]:
						_add_model("sconce", wall_face + along * sx * 0.95 + Vector3(0, 1.85, 0), inward, 1.0, {"shadow": false})
	# floor clutter in corners
	var tnm: String = cells[c]
	var floor_props: Array = []
	if tnm in ["storage", "archive"]:
		floor_props = ["prop_box", "prop_paintcans", "prop_bucket", "prop_box", "prop_bookstack"]
	elif location == 2:
		floor_props = ["prop_box", "prop_bucket"]
	else:
		floor_props = ["prop_bookstack", "prop_box"]
	if not is_extr:
		for k in rng.randi_range(0, 2):
			var corner := Vector3(3.2 * (1 if rng.randf() < 0.5 else -1), 0, 3.2 * (1 if rng.randf() < 0.5 else -1))
			_add_model(floor_props[rng.randi() % floor_props.size()], cc + corner + Vector3(rng.randf_range(-0.3, 0.3), 0, rng.randf_range(-0.3, 0.3)), Vector3.FORWARD.rotated(Vector3.UP, rng.randf() * TAU), 1.0, {"shadow": false})
	# rug + centre floor spots
	if not is_extr and not (th["ft"] in ["floor_marble", "floor_lab", "carpet"]):
		var rug := Color.from_hsv(rng.randf(), 0.55, 0.6)
		_mk = "rug"
		_box(st, cc + Vector3(0, 0.01, 0), Vector3(3.2, 0.02, 2.2), rug, false)
	if location != 1 and rng.randf() < 0.5:
		var corner := Vector3(3.35 * (1 if rng.randf() < 0.5 else -1), 0, 3.35 * (1 if rng.randf() < 0.5 else -1))
		_add_model("plant", cc + corner, Vector3.FORWARD)
		_add_shape(cc + corner + Vector3(0, 0.3, 0), Vector3(0.4, 0.6, 0.4))
	if not is_extr:
		for i in rng.randi_range(0, 2):
			item_spots.append({"pos": cc + Vector3(rng.randf_range(-1.6, 1.6), 0.0, rng.randf_range(-1.2, 1.2)), "kind": "floor"})


func _spot(base: Vector3, along: Vector3, inward: Vector3, lc: Vector3, kind: String) -> void:
	item_spots.append({"pos": base + along * lc.x + Vector3.UP * lc.y + inward * lc.z, "kind": kind})


const PIECE_MODEL := {"table": ["table", 1.0], "shelf": ["bookshelf", 0.21], "cabinet": ["cabinet", 0.27], "fireplace": ["fireplace", 0.33],
	"bed": ["bed", 1.05], "sofa": ["sofa", 0.45], "piano": ["piano", 0.35], "pedestal": ["pedestal", 0.9], "bench": ["bench", 1.1],
	"case": ["case", 0.35], "labbench": ["labbench", 0.4], "rack": ["rack", 0.45], "desk": ["desk", 0.45]}


func _piece(st, piece: String, base: Vector3, along: Vector3, inward: Vector3, th: Dictionary) -> void:
	var has_model := ML.scene("table") != null
	if has_model:
		_vis = false
		if PIECE_MODEL.has(piece):
			var pm: Array = PIECE_MODEL[piece]
			_add_model(pm[0], base + inward * float(pm[1]), inward)
		elif piece == "crates":
			_add_model("crate", base + along * -0.45 + inward * 0.45, inward.rotated(Vector3.UP, rng.randf_range(-0.2, 0.2)))
		if piece == "table" and rng.randf() < 0.7:
			for cx in [-0.4, 0.4]:
				_add_model("chair", base + along * cx + inward * 1.65, -inward.rotated(Vector3.UP, rng.randf_range(-0.25, 0.25)))
				_add_shape(base + along * cx + inward * 1.65 + Vector3(0, 0.45, 0), Vector3(0.44, 0.9, 0.44))
	_piece_shapes(st, piece, base, along, inward, th)
	_vis = true
	if has_model:
		_clutter(piece, base, along, inward)


func _prop(name: String, pos: Vector3, fwd: Vector3, scale := 1.0) -> void:
	_add_model(name, pos, fwd.rotated(Vector3.UP, rng.randf_range(-0.5, 0.5)), scale, {"shadow": false})


## Small decorative props on furniture (visual only).
func _clutter(piece: String, base: Vector3, along: Vector3, inward: Vector3) -> void:
	var P := func(lx: float, ly: float, lz: float) -> Vector3:
		return base + along * lx + Vector3.UP * ly + inward * lz
	match piece:
		"table":
			if rng.randf() < 0.6:
				_prop("prop_candle", P.call(0.0, 0.825, 0.95), inward)
			if rng.randf() < 0.4:
				_prop(["prop_papers", "prop_bookstack", "prop_bottles"][rng.randi() % 3], P.call(rng.randf_range(-0.6, 0.6), 0.825, 1.2), inward)
		"cabinet":
			if rng.randf() < 0.7:
				_prop(["prop_candle", "prop_bookstack", "prop_bottles"][rng.randi() % 3], P.call(0.38 * (1.0 if rng.randf() < 0.5 else -1.0), 0.96, 0.25), inward)
		"desk":
			_prop("prop_papers", P.call(-0.3, 0.755, 0.5), inward)
			if rng.randf() < 0.5:
				_prop("prop_clipboard", P.call(0.1, 0.755, 0.6), inward)
		"labbench":
			if rng.randf() < 0.8:
				_prop("prop_flasks", P.call(0.35, 0.89, 0.3), inward)
			if rng.randf() < 0.4:
				_prop("prop_clipboard", P.call(-0.6, 0.89, 0.5), inward)
		"crates":
			if rng.randf() < 0.5:
				_prop("prop_box", P.call(0.45, 0.0, 0.5), inward)
		"bench", "pedestal", "case", "sofa", "piano", "fireplace":
			if piece == "fireplace" and rng.randf() < 0.8:
				_prop("prop_candle", P.call(-0.7, 1.28, 0.34), inward)
				_prop("prop_candle", P.call(0.7, 1.28, 0.34), inward)


func _piece_shapes(st, piece: String, base: Vector3, along: Vector3, inward: Vector3, th: Dictionary) -> void:
	var wood := Color(0.36, 0.22, 0.12).lerp(Color(0.2, 0.12, 0.07), rng.randf())
	match piece:
		"table":
			_lbox(st, base, along, inward, Vector3(0, 0.79, 1.0), Vector3(1.5, 0.07, 0.8), wood)
			for lx in [-0.66, 0.66]:
				for lz in [0.68, 1.32]:
					_lbox(st, base, along, inward, Vector3(lx, 0.38, lz), Vector3(0.08, 0.76, 0.08), wood.darkened(0.2))
			_spot(base, along, inward, Vector3(-0.4, 0.84, 1.0), "top")
			_spot(base, along, inward, Vector3(0.4, 0.84, 1.0), "top")
		"shelf":
			var h := 2.0
			_lbox(st, base, along, inward, Vector3(0, h / 2.0, 0.03), Vector3(1.6, h, 0.04), wood.darkened(0.3))
			for sx in [-0.8, 0.8]:
				_lbox(st, base, along, inward, Vector3(sx, h / 2.0, 0.22), Vector3(0.05, h, 0.42), wood)
			for by in [0.06, 0.7, 1.35, 1.98]:
				_lbox(st, base, along, inward, Vector3(0, by, 0.22), Vector3(1.6, 0.04, 0.42), wood)
			# books on the lower board
			for bx in range(-6, 7):
				if rng.randf() < 0.5:
					var bc := Color.from_hsv(rng.randf(), 0.5, 0.4)
					_lbox(st, base, along, inward, Vector3(bx * 0.11, 0.2, 0.2), Vector3(0.08, 0.24, 0.3), bc, false)
			_spot(base, along, inward, Vector3(-0.4, 0.74, 0.24), "small")
			_spot(base, along, inward, Vector3(0.4, 0.74, 0.24), "small")
			_spot(base, along, inward, Vector3(0.0, 1.39, 0.24), "small")
		"cabinet":
			_lbox(st, base, along, inward, Vector3(0, 0.48, 0.28), Vector3(1.1, 0.96, 0.52), wood)
			_lbox(st, base, along, inward, Vector3(0, 0.5, 0.55), Vector3(0.02, 0.8, 0.02), FRAME, false)
			_spot(base, along, inward, Vector3(0, 1.0, 0.28), "top")
		"fireplace":
			var stone := Color(0.4, 0.38, 0.36)
			_lbox(st, base, along, inward, Vector3(-0.65, 0.6, 0.3), Vector3(0.3, 1.2, 0.6), stone)
			_lbox(st, base, along, inward, Vector3(0.65, 0.6, 0.3), Vector3(0.3, 1.2, 0.6), stone)
			_lbox(st, base, along, inward, Vector3(0, 1.1, 0.3), Vector3(1.6, 0.2, 0.6), stone)
			_lbox(st, base, along, inward, Vector3(0, 1.24, 0.34), Vector3(1.8, 0.08, 0.7), wood)
			_lbox(st, base, along, inward, Vector3(0, 0.5, 0.1), Vector3(1.0, 1.0, 0.2), Color(0.05, 0.04, 0.04), false)
			_spot(base, along, inward, Vector3(0.5, 1.3, 0.34), "small")
			_spot(base, along, inward, Vector3(-0.5, 1.3, 0.34), "small")
		"bed":
			var sheet := Color.from_hsv(rng.randf(), 0.35, 0.6)
			# raised bed on legs: you can crawl underneath
			_lbox(st, base, along, inward, Vector3(0, 0.86, 1.05), Vector3(1.5, 0.22, 2.0), wood)
			for lx in [-0.7, 0.7]:
				for lz in [0.12, 1.98]:
					_lbox(st, base, along, inward, Vector3(lx, 0.38, lz), Vector3(0.09, 0.76, 0.09), wood.darkened(0.2))
			_lbox(st, base, along, inward, Vector3(0, 1.03, 1.1), Vector3(1.4, 0.14, 1.9), sheet, false)
			_lbox(st, base, along, inward, Vector3(0, 1.15, 0.3), Vector3(1.0, 0.12, 0.35), Color(0.9, 0.9, 0.88), false)
			_lbox(st, base, along, inward, Vector3(0, 0.8, 0.06), Vector3(1.6, 1.6, 0.1), wood.darkened(0.2))
			_spot(base, along, inward, Vector3(0.3, 1.15, 1.4), "small")
		"crates":
			var cc := Color(0.5, 0.36, 0.2)
			_lbox(st, base, along, inward, Vector3(-0.45, 0.4, 0.45), Vector3(0.8, 0.8, 0.8), cc)
			if rng.randf() < 0.6:
				_lbox(st, base, along, inward, Vector3(0.45, 0.35, 0.4), Vector3(0.7, 0.7, 0.7), cc.darkened(0.15))
				if not _vis:
					_add_model("crate", base + along * 0.45 + inward * 0.4, inward.rotated(Vector3.UP, 0.3), 0.875)
			_spot(base, along, inward, Vector3(-0.45, 0.82, 0.45), "top")
		"sofa":
			var fab := Color.from_hsv(rng.randf(), 0.45, 0.35)
			_lbox(st, base, along, inward, Vector3(0, 0.22, 0.5), Vector3(1.9, 0.44, 0.8), fab)
			_lbox(st, base, along, inward, Vector3(0, 0.55, 0.15), Vector3(1.9, 0.7, 0.2), fab.darkened(0.15))
			for ax in [-0.9, 0.9]:
				_lbox(st, base, along, inward, Vector3(ax, 0.35, 0.5), Vector3(0.15, 0.3, 0.8), fab.darkened(0.2))
			_spot(base, along, inward, Vector3(0.4, 0.5, 0.55), "small")
		"pedestal":
			var marble := Color(0.86, 0.85, 0.82)
			_lbox(st, base, along, inward, Vector3(0, 0.5, 0.9), Vector3(0.6, 1.0, 0.6), marble)
			_lbox(st, base, along, inward, Vector3(0, 1.02, 0.9), Vector3(0.7, 0.04, 0.7), marble.darkened(0.2))
			_lbox(st, base, along, inward, Vector3(0, 0.05, 0.9), Vector3(0.7, 0.1, 0.7), marble.darkened(0.2))
			_spot(base, along, inward, Vector3(0, 1.06, 0.9), "top")
		"bench":
			_lbox(st, base, along, inward, Vector3(0, 0.42, 1.1), Vector3(1.6, 0.08, 0.5), wood)
			for lx in [-0.7, 0.7]:
				_lbox(st, base, along, inward, Vector3(lx, 0.2, 1.1), Vector3(0.08, 0.4, 0.45), Color(0.15, 0.15, 0.15))
			_spot(base, along, inward, Vector3(0, 0.02, 0.4), "floor")
		"case":
			_lbox(st, base, along, inward, Vector3(0, 0.45, 0.35), Vector3(1.2, 0.9, 0.6), wood.darkened(0.2))
			_lbox(st, base, along, inward, Vector3(0, 0.92, 0.35), Vector3(1.26, 0.04, 0.66), Color(1.0, 0.8, 0.3))
			_spot(base, along, inward, Vector3(-0.3, 0.96, 0.35), "top")
			_spot(base, along, inward, Vector3(0.3, 0.96, 0.35), "small")
		"labbench":
			var wt := Color(0.85, 0.87, 0.9)
			_lbox(st, base, along, inward, Vector3(0, 0.84, 0.4), Vector3(1.84, 0.1, 0.8), Color(0.12, 0.13, 0.15))
			_lbox(st, base, along, inward, Vector3(0, 0.45, 0.04), Vector3(1.8, 0.8, 0.06), wt)
			for lx in [-0.86, 0.86]:
				_lbox(st, base, along, inward, Vector3(lx, 0.4, 0.4), Vector3(0.07, 0.8, 0.72), wt)
			_spot(base, along, inward, Vector3(-0.5, 0.92, 0.4), "top")
			_spot(base, along, inward, Vector3(0.4, 0.92, 0.4), "small")
		"rack":
			_lbox(st, base, along, inward, Vector3(0, 1.05, 0.45), Vector3(0.8, 2.1, 0.8), Color(0.08, 0.09, 0.11))
			for i in 7:
				var lc := Color(0.2, 0.6, 1.0) if rng.randf() < 0.5 else Color(0.3, 1.0, 0.4)
				_lbox(st, base, along, inward, Vector3(rng.randf_range(-0.2, 0.2), 0.3 + i * 0.25, 0.86), Vector3(0.2, 0.03, 0.02), lc, false)
			_spot(base, along, inward, Vector3(0, 0.02, 1.25), "floor")
		"desk":
			_lbox(st, base, along, inward, Vector3(0, 0.73, 0.45), Vector3(1.4, 0.05, 0.7), wood)
			_lbox(st, base, along, inward, Vector3(-0.6, 0.36, 0.45), Vector3(0.1, 0.72, 0.65), wood.darkened(0.2))
			_lbox(st, base, along, inward, Vector3(0.45, 0.36, 0.45), Vector3(0.4, 0.72, 0.65), wood.darkened(0.2))
			_lbox(st, base, along, inward, Vector3(-0.2, 0.98, 0.2), Vector3(0.5, 0.35, 0.05), Color(0.05, 0.05, 0.06))
			_spot(base, along, inward, Vector3(0.35, 0.78, 0.55), "top")
		"piano":
			_lbox(st, base, along, inward, Vector3(0, 0.6, 0.35), Vector3(1.5, 1.2, 0.6), Color(0.06, 0.05, 0.05))
			_lbox(st, base, along, inward, Vector3(0, 0.75, 0.72), Vector3(1.3, 0.06, 0.2), Color(0.92, 0.92, 0.9))
			_lbox(st, base, along, inward, Vector3(0, 0.36, 0.9), Vector3(0.7, 0.08, 0.35), Color(0.1, 0.08, 0.08))
			_spot(base, along, inward, Vector3(0.3, 1.24, 0.35), "top")


func _add_shape_basis(center: Vector3, size: Vector3, b: Basis) -> void:
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	cs.transform = Transform3D(b, center)
	body.add_child(cs)


func _build_garage(_st_unused, c: Vector2i) -> void:
	var cc := cell_center(c)
	var back := -Vector3(door_dir.x, 0, door_dir.y)
	var side := Vector3(absi(door_dir.y), 0, absi(door_dir.x))
	var ba := back.abs()
	var sa := side.abs()
	var tb := cc + back * 0.6
	truck_back = back
	truck_side = side
	truck_pos = tb + Vector3(0, 0.5, 0)
	_add_model("truck", tb, -back)
	var up := Vector3.UP
	_add_shape(tb + up * 0.45, sa * 2.4 + Vector3(0, 0.12, 0) + ba * 3.2)
	_add_shape(tb + side * 1.2 + up * 1.6, sa * 0.1 + Vector3(0, 2.2, 0) + ba * 3.2)
	_add_shape(tb - side * 1.2 + up * 1.6, sa * 0.1 + Vector3(0, 2.2, 0) + ba * 3.2)
	_add_shape(tb + up * 2.7, sa * 2.5 + Vector3(0, 0.1, 0) + ba * 3.2)
	_add_shape(tb + back * 1.6 + up * 1.6, sa * 2.4 + Vector3(0, 2.2, 0) + ba * 0.1)
	_add_shape(tb + back * 2.45 + up * 1.15, sa * 2.3 + Vector3(0, 1.4, 0) + ba * 1.5)
	_add_shape(tb + back * 2.6 + up * 2.1, sa * 2.2 + Vector3(0, 0.8, 0) + ba * 1.2)
	# loading ramp
	var top := tb - back * 1.6 + up * 0.5
	var bottom := tb - back * 2.9 + up * 0.0
	var z := (bottom - top).normalized()
	var x := side
	var y := z.cross(x).normalized()
	var rb := Basis(x, y, z)
	var rc := (top + bottom) * 0.5
	var rlen := top.distance_to(bottom)
	_add_shape_basis(rc, Vector3(2.0, 0.08, rlen), rb)
	_decor.append({"model": "__ramp", "xf": Transform3D(rb, rc), "size": Vector3(2.0, 0.08, rlen)})
	# hazard stripes in front of the truck
	_mk = "flat"
	var stripe := Color(0.95, 0.75, 0.1)
	for i in 5:
		_box(null, tb - back * (3.2 + 0.0) + side * (-1.0 + i * 0.5) + Vector3(0, 0.012, 0), sa * 0.25 + Vector3(0, 0.02, 0) + ba * 0.5, stripe, false)
	# garage decor
	_add_model("store_shelf", cc + side * (HR - 0.45) - back * 1.8, -side)
	_add_shape(cc + side * (HR - 0.45) - back * 1.8 + up * 0.95, sa * 0.55 + Vector3(0, 1.9, 0) + ba * 1.95)
	_add_model("crate", cc - side * (HR - 0.6) - back * 2.6, -side)
	_add_shape(cc - side * (HR - 0.6) - back * 2.6 + up * 0.4, Vector3(0.8, 0.8, 0.8))
	truck_button = tb + back * 1.15 + side * 0.75 + up * 0.51
	truck_screen = tb + back * 1.49 + up * 1.9
	cart_pos = cc - back * 2.6 + side * 2.0 + Vector3(0, 0.4, 0)
	spawn_points = [tb + side * 0.5 + back * 0.5 + up * 0.6, tb - side * 0.5 + back * 0.5 + up * 0.6, tb + side * 0.5 - back * 0.5 + up * 0.6, tb - side * 0.5 - back * 0.5 + up * 0.6]
