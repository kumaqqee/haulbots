extends CharacterBody3D
## Monsters. Host runs the AI; clients interpolate position/yaw and play events.
## Behaviour archetypes follow the reference game's enemies (see TYPES comments),
## with original names and designs.

const ML = preload("res://scripts/game/matlib.gd")

# tier: 1..3, weight: kg-equivalent for the grab beam (0 = cannot be lifted)
const TYPES := {
	# tier 1
	"gremlin": {"tier": 1, "hp": 20.0, "walk": 1.4, "chase": 2.6, "dmg": 10.0, "range": 0.9, "vision": 10.0, "cone": 0.2, "hear": 8.0, "cd": 1.2, "orb": [0, 0], "height": 0.7, "radius": 0.2, "knock": 1.5, "weight": 4.0, "group": 4},
	"bomber": {"tier": 1, "hp": 50.0, "walk": 1.8, "chase": 3.4, "dmg": 0.0, "range": 1.2, "vision": 11.0, "cone": 0.2, "hear": 9.0, "cd": 1.0, "orb": [0, 0], "height": 0.7, "radius": 0.25, "knock": 0.0, "weight": 5.0, "group": 3},
	"eye": {"tier": 1, "hp": 30.0, "walk": 0.0, "chase": 0.0, "dmg": 10.0, "range": 0.0, "vision": 11.0, "cone": -1.0, "hear": 0.0, "cd": 0.0, "orb": [0, 0], "height": 0.8, "radius": 0.22, "knock": 0.0, "weight": 0.0, "group": 1},
	"tick": {"tier": 1, "hp": 10.0, "walk": 1.2, "chase": 3.4, "dmg": 10.0, "range": 0.6, "vision": 7.0, "cone": -1.0, "hear": 0.0, "cd": 1.0, "orb": [800, 1500], "height": 0.15, "radius": 0.12, "knock": 0.0, "weight": 1.0, "group": 1},
	"spewer": {"tier": 1, "hp": 65.0, "walk": 2.0, "chase": 4.6, "dmg": 10.0, "range": 1.4, "vision": 12.0, "cone": 0.1, "hear": 12.0, "cd": 1.5, "orb": [1000, 4000], "height": 0.5, "radius": 0.25, "knock": 0.0, "weight": 6.0, "group": 1},
	"rugrat": {"tier": 1, "hp": 150.0, "walk": 1.2, "chase": 1.6, "dmg": 10.0, "range": 1.2, "vision": 14.0, "cone": 0.1, "hear": 0.0, "cd": 3.5, "orb": [1500, 4000], "height": 1.2, "radius": 0.35, "knock": 2.0, "weight": 28.0, "group": 1},
	"skitter": {"tier": 1, "hp": 150.0, "walk": 2.5, "chase": 5.0, "dmg": 4.0, "range": 1.0, "vision": 11.0, "cone": 0.2, "hear": 8.0, "cd": 0.7, "orb": [1500, 3500], "height": 0.55, "radius": 0.3, "knock": 3.0, "weight": 9.0, "group": 1},
	# tier 2
	"puff": {"tier": 2, "hp": 150.0, "walk": 2.2, "chase": 5.0, "dmg": 10.0, "range": 1.0, "vision": 12.0, "cone": -1.0, "hear": 0.0, "cd": 0.33, "orb": [2000, 3000], "height": 0.5, "radius": 0.25, "knock": 0.5, "weight": 3.0, "group": 1},
	"howler": {"tier": 2, "hp": 200.0, "walk": 1.6, "chase": 3.6, "dmg": 15.0, "range": 1.4, "vision": 14.0, "cone": 0.2, "hear": 0.0, "cd": 8.0, "orb": [2000, 4000], "height": 1.8, "radius": 0.3, "knock": 6.0, "weight": 0.0, "group": 1},
	"levitator": {"tier": 2, "hp": 150.0, "walk": 1.6, "chase": 2.4, "dmg": 35.0, "range": 7.0, "vision": 12.0, "cone": 0.3, "hear": 0.0, "cd": 9.0, "orb": [2000, 5000], "height": 1.3, "radius": 0.25, "knock": 0.0, "weight": 0.0, "group": 1},
	"butcher": {"tier": 2, "hp": 150.0, "walk": 1.8, "chase": 3.2, "dmg": 10.0, "range": 4.5, "vision": 13.0, "cone": 0.2, "hear": 6.0, "cd": 2.0, "orb": [1600, 3000], "height": 1.9, "radius": 0.33, "knock": 2.0, "weight": 20.0, "group": 1},
	"lurker": {"tier": 2, "hp": 250.0, "walk": 1.4, "chase": 4.8, "dmg": 8.0, "range": 1.5, "vision": 9.0, "cone": 0.45, "hear": 0.0, "cd": 0.6, "orb": [6000, 8000], "height": 2.3, "radius": 0.35, "knock": 1.0, "weight": 0.0, "group": 1},
	"hidden": {"tier": 2, "hp": 100.0, "walk": 1.8, "chase": 4.6, "dmg": 0.0, "range": 1.1, "vision": 0.0, "cone": 1.0, "hear": 16.0, "cd": 12.0, "orb": [0, 0], "height": 1.9, "radius": 0.3, "knock": 0.0, "weight": 16.0, "group": 1},
	"mimic": {"tier": 2, "hp": 120.0, "walk": 0.0, "chase": 5.2, "dmg": 20.0, "range": 1.3, "vision": 12.0, "cone": -1.0, "hear": 0.0, "cd": 1.0, "orb": [5000, 8000], "height": 0.6, "radius": 0.36, "knock": 3.0, "weight": 0.0, "group": 1},
	# tier 3
	"bighead": {"tier": 3, "hp": 250.0, "walk": 1.6, "chase": 5.6, "dmg": 40.0, "range": 1.6, "vision": 8.0, "cone": 0.4, "hear": 0.0, "cd": 1.6, "orb": [2000, 6000], "height": 2.0, "radius": 0.45, "knock": 7.0, "weight": 0.0, "group": 1},
	"projector": {"tier": 3, "hp": 250.0, "walk": 1.8, "chase": 2.8, "dmg": 40.0, "range": 1.8, "vision": 15.0, "cone": 0.2, "hear": 8.0, "cd": 5.0, "orb": [5000, 8000], "height": 2.4, "radius": 0.35, "knock": 9.0, "weight": 0.0, "group": 1},
	"hunter": {"tier": 3, "hp": 250.0, "walk": 1.2, "chase": 1.8, "dmg": 60.0, "range": 20.0, "vision": 0.0, "cone": 1.0, "hear": 22.0, "cd": 3.0, "orb": [3000, 7000], "height": 2.3, "radius": 0.35, "knock": 10.0, "weight": 0.0, "group": 1},
	"brute": {"tier": 3, "hp": 500.0, "walk": 0.9, "chase": 1.3, "dmg": 70.0, "range": 3.0, "vision": 14.0, "cone": 0.1, "hear": 6.0, "cd": 4.0, "orb": [8000, 12000], "height": 2.6, "radius": 0.55, "knock": 12.0, "weight": 0.0, "group": 1},
	"watcher": {"tier": 3, "hp": 250.0, "walk": 1.3, "chase": 5.6, "dmg": 40.0, "range": 1.4, "vision": 16.0, "cone": -1.0, "hear": 0.0, "cd": 2.0, "orb": [5000, 8000], "height": 2.2, "radius": 0.3, "knock": 7.0, "weight": 0.0, "group": 1},
}

enum { WANDER, INVESTIGATE, CHASE, ATTACK, DEAD, SPECIAL, HELD, THROWN }

var mid := 0
var mtype := "lurker"
var world: Node = null
var server_side := true
var cfg: Dictionary
var hp := 100.0
var state := WANDER
var target_pid := -1
var goal := Vector3.ZERO
var path := []
var repath_t := 0.0
var perceive_t := 0.0
var attack_t := 0.0
var cd := 0.0
var stun_t := 0.0
var sleeping_mon := false
var dormant := 0.0
var lost_t := 0.0
var wait_t := 0.0
var stuck_t := 0.0
var last_noise_t := 0.0
var yaw := 0.0
var anim_t := 0.0
var speed_now := 0.0
var attack_anim := 0.0
var hurt_flash := 0.0
var sound_t := 4.0
var net_pos := Vector3.ZERO
var net_yaw := 0.0
var rng := RandomNumberGenerator.new()

# specials
var disguised := true
var reveal_t := 0.0
var sp_t := 0.0
var sp_phase := 0
var sp_pos := Vector3.ZERO
var sp_dir := Vector3.ZERO
var attached_pid := -1
var drained := 0.0
var aggro_t := 0.0
var fuse_t := -1.0
var carry_pid := -1
var lock_t := {}
var noise_pos := Vector3.ZERO
var grab_slow := 0.0
var held_target := Vector3.ZERO
var held_t := 0.0
var thrown_t := 0.0
var puff_t := 0.0
var _was_moving := false
var frozen := false
var sus := {}            # pid -> 0..1 suspicion (REPO-style delayed detection)
var last_seen := Vector3.ZERO
var seen_now := false
var leave_roll := false
var lurking := false      # idle at level start: not present in the house yet
var _lurk_hidden := false

var model: Node3D
var knees := []
var elbows := []
var _lean := 0.0
var parts := {}
var legs := []
var arms := []
var _meshes := []
static var _flash_mat: StandardMaterial3D


func _ready() -> void:
	cfg = TYPES[mtype]
	hp = cfg["hp"]
	add_to_group("monster")
	collision_layer = 8
	collision_mask = 1 | 4
	rng.seed = mid * 131 + 7
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = cfg["radius"]
	cap.height = maxf(cfg["height"], cfg["radius"] * 2.0 + 0.01)
	cs.shape = cap
	cs.position.y = cap.height / 2.0
	if mtype == "eye":
		cs.position.y = -cap.height / 2.0 - 0.2
	add_child(cs)
	_build_model()
	net_pos = global_position
	if world:
		last_noise_t = world.game_time
	sound_t = rng.randf_range(3.0, 9.0)
	if world and world.gen and world.gen.order.size() > 0:
		goal = world.gen.random_point(rng)
	if mtype == "hidden":
		model.visible = false


func _appear() -> void:
	lurking = false
	_lurk_hidden = false
	if world.has_method("far_spawn_point") and mtype != "mimic" and mtype != "eye":
		global_position = world.far_spawn_point(14.0)
	_event("appear")


func weight() -> float:
	return cfg["weight"]


func display_name() -> String:
	return Settings.t("mon_" + mtype)


# ------------------------------------------------------------------ model

var _anim_skip := 0.0


func _build_model() -> void:
	model = Node3D.new()
	add_child(model)
	var m := ML.model(mtype)
	if m == null:
		var mi := MeshInstance3D.new()
		var cm := CapsuleMesh.new()
		cm.radius = cfg["radius"]
		cm.height = maxf(cfg["height"], cfg["radius"] * 2.0 + 0.01)
		mi.mesh = cm
		mi.position.y = cm.height / 2.0
		mi.material_override = ML.plain(Color(0.1, 0.1, 0.1))
		model.add_child(mi)
		_meshes.append(mi)
		return
	model.add_child(m)
	for n in m.find_children("*", "MeshInstance3D", true, false):
		_meshes.append(n)
	if mtype != "hidden":
		ML.vis_range(m, 40.0, 4.0)
	for k in ["leg_l", "leg_r"]:
		var l := ML.find(m, k)
		if l:
			legs.append(l)
	for i in 6:
		var l := ML.find(m, "leg%d" % i)
		if l:
			legs.append(l)
	for k in ["arm_l", "arm_r"]:
		var a := ML.find(m, k)
		if a:
			arms.append(a)
	for k in ["leg_l_lo", "leg_r_lo"]:
		var kn := ML.find(m, k)
		if kn:
			knees.append(kn)
	for k in ["arm_l_lo", "arm_r_lo"]:
		var el := ML.find(m, k)
		if el:
			elbows.append(el)
	for k in ["head", "mouth", "lid", "tongue", "body", "jaw", "fuse", "gun"]:
		var p := ML.find(m, k)
		if p:
			parts[k] = p
	if mtype == "mimic":
		parts["eyes"] = [ML.find(m, "eye_l"), ML.find(m, "eye_r")]
		for e in parts["eyes"]:
			if e:
				e.visible = false
		if parts.has("tongue"):
			parts["tongue"].visible = false
	if mtype == "puff" and parts.has("jaw"):
		parts["jaw"].visible = false


# ------------------------------------------------------------------ helpers

func _players_alive() -> Array:
	var out := []
	for p in world.players.values():
		if not p.dead:
			out.append(p)
	return out


func _nearest_player(max_d := 1e9):
	var best = null
	var bd := max_d
	for p in _players_alive():
		var d := global_position.distance_to(p.global_position)
		if d < bd:
			bd = d
			best = p
	return best


func _eye() -> Vector3:
	if mtype == "eye":
		return global_position + Vector3(0, -0.6, 0)
	return global_position + Vector3(0, cfg["height"] * 0.85, 0)


func _los(to: Vector3, from = null) -> bool:
	var f: Vector3 = _eye() if from == null else from
	var q := PhysicsRayQueryParameters3D.create(f, to, 1)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func _fwd() -> Vector3:
	return Vector3(-sin(yaw), 0, -cos(yaw))


func _face(dir: Vector3, k: float) -> void:
	dir.y = 0.0
	if dir.length() < 0.01:
		return
	yaw = lerp_angle(yaw, atan2(-dir.x, -dir.z), minf(1.0, k))
	rotation.y = yaw


func _event(ev: String) -> void:
	world.rpc("rpc_monster_event", mid, ev)


func _gravity_only(delta: float) -> void:
	velocity.x = 0.0
	velocity.z = 0.0
	if mtype == "eye":
		velocity = Vector3.ZERO
		speed_now = 0.0
		return
	velocity.y = -1.0 if is_on_floor() else velocity.y - 14.0 * delta
	move_and_slide()
	speed_now = 0.0


func _hit(pid: int, dmg: float, extra_knock := 0.0) -> void:
	var p = world.players.get(pid)
	if p == null:
		return
	var kd: Vector3 = p.global_position - global_position
	kd.y = 0.0
	var kn: float = cfg["knock"] + extra_knock
	world.server_damage_player(pid, dmg * world.dmg_mult(), kd.normalized() * kn + Vector3(0, kn * 0.15, 0))


func _can_see(p) -> bool:
	var vis: float = cfg["vision"]
	if vis <= 0.0:
		return false
	var d := global_position.distance_to(p.global_position)
	var covered: bool = p.get("under_cover") == true
	if covered:
		# crawling under furniture: only noticed from right next to you
		vis = minf(vis, 1.7)
	elif p.crouching or p.tumbling:
		vis *= 0.6 if mtype != "lurker" else 0.45
	if d > vis:
		return false
	var to: Vector3 = p.global_position - global_position
	to.y = 0.0
	var cone: float = cfg["cone"]
	if (p.crouching or covered) and cone > -1.0:
		cone = minf(0.9, cone + 0.2)
	if cone > -1.0 and d > 2.0 and not (state == CHASE and p.peer_id == target_pid) and _fwd().dot(to.normalized()) < cone:
		return false
	var h := 1.0
	if covered or p.tumbling:
		h = 0.3
	elif p.crouching:
		h = 0.45
	return _los(p.global_position + Vector3(0, h, 0))


## Seconds a monster must watch a player before it reacts (1 s standing, 2 s crouched, 5 s under furniture).
func _detect_time(p, d: float) -> float:
	var t := 1.0
	if p.get("under_cover") == true:
		t = 5.0
	elif p.crouching or p.tumbling:
		t = 2.0
	if p.sprinting:
		t *= 0.6
	if d < 2.5:
		t *= 0.4
	return t * [1.5, 1.0, 0.75][clampi(Net.difficulty, 0, 2)]


func max_sus_for(pid: int) -> float:
	if state == CHASE or state == ATTACK or state == SPECIAL:
		if target_pid == pid:
			return 2.0
	return float(sus.get(pid, 0.0))


# ------------------------------------------------------------------ main loop

func _physics_process(delta: float) -> void:
	# far monsters are behind walls and fog: skip purely visual animation work
	var cam := get_viewport().get_camera_3d()
	if mtype == "watcher" or cam == null or global_position.distance_squared_to(cam.global_position) < 1444.0:
		_animate(delta + _anim_skip)
		_anim_skip = 0.0
	else:
		_anim_skip = minf(_anim_skip + delta, 0.5)
	if state == DEAD:
		return
	if not server_side:
		var prev := global_position
		if global_position.distance_to(net_pos) > 5.0:
			global_position = net_pos
		else:
			global_position = global_position.lerp(net_pos, minf(1.0, delta * 10.0))
		speed_now = (global_position - prev).length() / maxf(delta, 0.001)
		yaw = lerp_angle(yaw, net_yaw, minf(1.0, delta * 10.0))
		rotation.y = yaw
		return
	cd -= delta
	grab_slow = maxf(0.0, grab_slow - delta)
	if state == HELD:
		_held_tick(delta)
		return
	if state == THROWN:
		_thrown_tick(delta)
		return
	if dormant > 0.0:
		dormant -= delta
		if lurking:
			if not _lurk_hidden:
				_lurk_hidden = true
				_event("lurk")
			if dormant <= 0.0:
				_appear()
			return
		_gravity_only(delta)
		return
	if stun_t > 0.0:
		stun_t -= delta
		if stun_t <= 0.0 and sleeping_mon:
			sleeping_mon = false
			_event("wake")
		_gravity_only(delta)
		return
	match mtype:
		"eye":
			_brain_eye(delta)
		"tick":
			_brain_tick(delta)
		"mimic":
			_brain_mimic(delta)
		"watcher":
			_brain_watcher(delta)
		"puff":
			_brain_puff(delta)
		"hunter":
			_brain_hunter(delta)
		"hidden":
			_brain_hidden(delta)
		_:
			_brain_default(delta)


# ------------------------------------------------------------------ generic brain

func _perceive() -> void:
	var best = null
	var bd := 1e9
	var chasing := state == CHASE or state == ATTACK or state == SPECIAL
	seen_now = false
	for p in _players_alive():
		var pid: int = p.peer_id
		var d := global_position.distance_to(p.global_position)
		if _can_see(p):
			if chasing and pid == target_pid:
				seen_now = true
				last_seen = p.global_position
				best = p
				bd = -1.0
				continue
			var s0: float = sus.get(pid, 0.0)
			sus[pid] = minf(1.0, s0 + 0.2 / _detect_time(p, d))
			if sus[pid] >= 1.0 and d < bd:
				bd = d
				best = p
			elif sus[pid] > 0.35 and not chasing and state != INVESTIGATE:
				# noticed something: stop and look / step towards it
				state = INVESTIGATE
				goal = p.global_position
				path = []
				wait_t = 0.0
		else:
			sus[pid] = maxf(0.0, float(sus.get(pid, 0.0)) - 0.2 * 0.3)
	if best != null:
		if not chasing:
			_on_spot(best)
		target_pid = best.peer_id
		last_seen = best.global_position
		seen_now = true
		lost_t = 0.0
		return
	if state == CHASE:
		lost_t += 0.2
		if lost_t > 3.0:
			state = INVESTIGATE
			goal = last_seen
			wait_t = 0.0
			path = []
			leave_roll = true
			sus.clear()
			_on_lost()
	_hear()


func _hear() -> void:
	var hear: float = cfg["hear"]
	if hear <= 0.0 or state == CHASE or state == ATTACK or state == SPECIAL:
		last_noise_t = world.game_time
		return
	for n in world.noise:
		if n["t"] <= last_noise_t:
			continue
		if global_position.distance_to(n["pos"]) < hear * n["loud"]:
			state = INVESTIGATE
			goal = n["pos"]
			path = []
			wait_t = 0.0
	last_noise_t = world.game_time


func _on_spot(p) -> void:
	state = CHASE
	target_pid = p.peer_id
	_event("alert")


func _on_lost() -> void:
	if mtype == "bighead":
		_vanish()


func _brain_default(delta: float) -> void:
	perceive_t -= delta
	if perceive_t <= 0.0:
		perceive_t = 0.2
		_perceive()
		if mtype == "gremlin" and state == WANDER:
			_gremlin_seek_valuable()
		if mtype == "bighead" and state != CHASE and state != SPECIAL and state != ATTACK:
			_bighead_flashlight_check()
	if mtype == "bomber" and fuse_t >= 0.0:
		fuse_t -= delta
		if fuse_t <= 0.0:
			_explode_self()
			return
	match state:
		WANDER:
			if wait_t > 0.0:
				wait_t -= delta
				_gravity_only(delta)
			elif _move_to(goal, cfg["walk"], delta):
				wait_t = rng.randf_range(1.0, 3.5)
				goal = world.gen.random_point(rng)
				path = []
		INVESTIGATE:
			if _move_to(goal, (cfg["walk"] + cfg["chase"]) * 0.5, delta):
				wait_t -= delta
				if wait_t <= -2.5:
					state = WANDER
					wait_t = 0.0
					goal = world.gen.random_point(rng)
					path = []
					# after losing its prey a monster may wander off and come back later (REPO despawn)
					if leave_roll:
						leave_roll = false
						if rng.randf() < 0.4 and world.has_method("server_monster_leave"):
							world.server_monster_leave(self)
		CHASE:
			var p = world.players.get(target_pid)
			if p == null or p.dead:
				state = WANDER
				goal = world.gen.random_point(rng)
				path = []
				return
			var d := global_position.distance_to(p.global_position)
			if cd <= 0.0 and d < cfg["range"] and seen_now and _begin_attack(p, d):
				return
			goal = p.global_position if seen_now or lost_t < 0.6 else last_seen
			if seen_now and d < 6.0:
				path = [goal]
				repath_t = 0.3
			_move_to(goal, cfg["chase"], delta)
		ATTACK:
			_attack_tick(delta)
		SPECIAL:
			_special_tick(delta)


## Returns true if an attack began.
func _begin_attack(p, d: float) -> bool:
	match mtype:
		"bomber":
			if fuse_t < 0.0:
				fuse_t = 10.0
				_event("fuse")
			return false
		"spewer":
			state = SPECIAL
			sp_phase = 0
			sp_t = 0.4
			sp_dir = (p.global_position - global_position).normalized()
			_event("attack")
			return true
		"rugrat":
			var it = _nearest_valuable(global_position, 6.0)
			if it:
				state = SPECIAL
				sp_phase = 0
				sp_t = 0.8
				sp_pos = it.global_position
				parts["held_item"] = it.item_id
				_event("attack")
				return true
			return false
		"howler":
			state = SPECIAL
			sp_phase = 0
			sp_t = 1.0
			_event("scream")
			return true
		"levitator":
			state = SPECIAL
			sp_phase = 0
			sp_t = 10.0
			sp_pos = global_position
			_event("lift")
			return true
		"butcher":
			state = SPECIAL
			sp_phase = 0
			sp_t = 1.2
			_event("windup")
			return true
		"projector":
			state = SPECIAL
			if d < 2.2:
				sp_phase = 10
				sp_t = 0.5
				_event("attack")
			else:
				sp_phase = 0
				sp_t = 1.2
				_event("laugh")
			return true
		"brute":
			state = SPECIAL
			sp_phase = 0
			sp_t = 1.6
			_event("windup")
			return true
	state = ATTACK
	attack_t = 0.45 if mtype != "lurker" else 0.1
	_event("attack")
	return true


func _attack_tick(delta: float) -> void:
	_gravity_only(delta)
	var p = world.players.get(target_pid)
	if p:
		_face(p.global_position - global_position, delta * 10.0)
	attack_t -= delta
	if attack_t > 0.0:
		return
	if p and not p.dead:
		var dh := Vector2(p.global_position.x - global_position.x, p.global_position.z - global_position.z).length()
		if dh < cfg["range"] + 0.6 and absf(p.global_position.y - global_position.y) < 2.5:
			_hit(target_pid, cfg["dmg"])
	cd = cfg["cd"]
	state = CHASE


func _special_tick(delta: float) -> void:
	var p = world.players.get(target_pid)
	sp_t -= delta
	match mtype:
		"spewer":
			if sp_phase == 0:
				_gravity_only(delta)
				if sp_t <= 0.0:
					sp_phase = 1
					sp_t = 0.6
					velocity = sp_dir * 7.0 + Vector3(0, 4.0, 0)
			elif sp_phase == 1:
				velocity.y -= 14.0 * delta
				move_and_slide()
				for q in _players_alive():
					if q.global_position.distance_to(global_position) < 1.0:
						_attach_face(q.peer_id)
						return
				if sp_t <= 0.0 or (is_on_floor() and sp_t < 0.4):
					state = CHASE
					cd = cfg["cd"]
					stun_t = 1.0
			elif sp_phase == 2:
				var v = world.players.get(attached_pid)
				if v == null or v.dead or sp_t <= 0.0:
					_detach()
					return
				global_position = v.global_position + Vector3(0, 1.1, 0) + v.look_dir() * 0.35
				speed_now = 0.0
				world.server_vomit(attached_pid, delta)
		"rugrat":
			_gravity_only(delta)
			if p:
				_face(p.global_position - global_position, delta * 6.0)
			if sp_t <= 0.0:
				var it = world.items.get(parts.get("held_item", -1))
				if it and p and not p.dead:
					var from := global_position + Vector3(0, 1.3, 0)
					it.teleport(from + _fwd() * 0.6)
					var to: Vector3 = p.global_position + Vector3(0, 1.0, 0)
					var dir := (to - from).normalized()
					it.apply_central_impulse(dir * it.mass * 11.0 + Vector3(0, it.mass * 1.5, 0))
					it.thrown_by_monster = 1.0
					_event("throw")
				state = CHASE
				cd = cfg["cd"]
		"howler":
			_gravity_only(delta)
			if sp_phase == 0 and sp_t <= 0.0:
				world.server_scream(self, 10.0, 3.0)
				sp_phase = 1
				sp_t = 0.8
			elif sp_phase == 1 and sp_t <= 0.0:
				state = CHASE
				cd = cfg["cd"]
				attack_t = 0.0
		"levitator":
			_gravity_only(delta)
			if sp_phase == 0:
				world.server_antigrav(sp_pos + Vector3(0, 0.5, 0), 5.5, delta)
				if rng.randf() < delta * 0.25:
					_teleport_random()
				if sp_t <= 0.0:
					sp_phase = 1
					sp_t = 0.6
					_event("slam")
			elif sp_t <= 0.0:
				world.server_slam(sp_pos, 5.5, cfg["dmg"] * world.dmg_mult())
				state = WANDER
				cd = cfg["cd"]
				_teleport_random()
		"butcher":
			if sp_phase == 0:
				_gravity_only(delta)
				if p:
					_face(p.global_position - global_position, delta * 8.0)
				if sp_t <= 0.0 and p:
					sp_phase = 1
					sp_t = 0.8
					var dir: Vector3 = (p.global_position - global_position)
					var dist := dir.length()
					dir.y = 0.0
					velocity = dir.normalized() * minf(dist * 1.6, 9.0) + Vector3(0, 4.5, 0)
					_event("attack")
			elif sp_phase == 1:
				velocity.y -= 14.0 * delta
				move_and_slide()
				var hit := false
				for q in _players_alive():
					if q.global_position.distance_to(global_position) < 1.3:
						hit = true
						sp_phase = 2
						sp_t = 0.9
						target_pid = q.peer_id
						break
				if not hit and sp_t <= 0.0 and is_on_floor():
					stun_t = 2.0
					_event("stumble")
					state = CHASE
					cd = cfg["cd"]
			elif sp_phase == 2:
				_gravity_only(delta)
				if fmod(sp_t, 0.3) < delta and p and global_position.distance_to(p.global_position) < 1.8:
					_hit(target_pid, cfg["dmg"])
					_event("attack")
				if sp_t <= 0.0:
					state = CHASE
					cd = cfg["cd"]
		"projector":
			_gravity_only(delta)
			if sp_phase == 10:
				if sp_t <= 0.0:
					if p and global_position.distance_to(p.global_position) < 2.5:
						_hit(target_pid, cfg["dmg"])
					state = CHASE
					cd = 1.5
			elif sp_phase == 0:
				if p:
					_face(p.global_position - global_position, delta * 5.0)
				if sp_t <= 0.0:
					sp_phase = 1
					sp_t = 2.2
					sp_dir = _fwd().rotated(Vector3.UP, 0.8)
					_event("beam")
			elif sp_phase == 1:
				var k := 1.0 - sp_t / 2.2
				var dir := sp_dir.rotated(Vector3.UP, -1.6 * k)
				yaw = atan2(-dir.x, -dir.z)
				rotation.y = yaw
				world.server_beam(self, _eye() + Vector3(0, -0.2, 0), dir, 12.0, 45.0 * world.dmg_mult() * delta * 2.0)
				if sp_t <= 0.0:
					_event("beam_end")
					state = CHASE
					cd = cfg["cd"]
		"brute":
			if sp_phase == 0:
				_gravity_only(delta)
				world.server_pull(global_position, 7.0, 3.5)
				if sp_t <= 0.0:
					sp_phase = 1
					sp_t = 0.5
					_event("slam")
			elif sp_phase == 1:
				_gravity_only(delta)
				if sp_t <= 0.0:
					world.server_shock(global_position, 3.2, cfg["dmg"] * world.dmg_mult(), self)
					state = CHASE
					cd = cfg["cd"]
		_:
			state = CHASE


# ------------------------------------------------------------------ specific brains

func _gremlin_seek_valuable() -> void:
	var it = _nearest_valuable(global_position, 6.0)
	if it == null:
		return
	if global_position.distance_to(it.global_position) < 0.9 and cd <= 0.0:
		cd = 1.5
		_event("attack")
		world.server_damage_item(it, 0.08)
	else:
		goal = it.global_position
		path = []


func _nearest_valuable(from: Vector3, maxd: float):
	var best = null
	var bd := maxd
	for it in world.items.values():
		if it.base_value <= 0 or it.held > 0 or it.mass > 30.0:
			continue
		var d := from.distance_to(it.global_position)
		if d < bd:
			bd = d
			best = it
	return best


func _brain_eye(delta: float) -> void:
	# ceiling eye: locks the view of anyone who looks at it, then burns them
	for p in _players_alive():
		var pid: int = p.peer_id
		var eye_pos := _eye()
		var to: Vector3 = eye_pos - p.eye_pos()
		var d := to.length()
		var looking: bool = d < cfg["vision"] and p.look_dir().dot(to / maxf(d, 0.01)) > 0.8 and _los(p.eye_pos(), eye_pos)
		var t: float = lock_t.get(pid, 0.0)
		if looking or (t > 0.6 and d < cfg["vision"] + 2.0 and _los(p.eye_pos(), eye_pos)):
			t += delta
			if t > 0.6:
				world.send_effect(pid, "lock", eye_pos, 0.3)
			if t > 3.0:
				world.server_damage_player(pid, cfg["dmg"] * world.dmg_mult() * delta, Vector3.ZERO)
		else:
			t = 0.0
		lock_t[pid] = t
	speed_now = 0.0


func _brain_tick(delta: float) -> void:
	if attached_pid != -1:
		var v = world.players.get(attached_pid)
		if v == null or v.dead or drained >= 100.0:
			attached_pid = -1
			_event("detach")
			stun_t = 3.0
			return
		global_position = v.global_position + Vector3(0, 1.45, 0) + v.look_dir() * 0.28
		var d: float = cfg["dmg"] * delta
		drained += d
		world.server_damage_player(attached_pid, d * world.dmg_mult(), Vector3.ZERO)
		return
	perceive_t -= delta
	if perceive_t <= 0.0:
		perceive_t = 0.2
		for pid in world.grabs:
			var p = world.players.get(pid)
			if p and not p.dead and p.global_position.distance_to(global_position) < 6.0:
				target_pid = pid
				state = CHASE
	if state == CHASE:
		var p = world.players.get(target_pid)
		if p == null or p.dead:
			state = WANDER
			return
		if global_position.distance_to(p.global_position) < 1.4:
			attached_pid = target_pid
			drained = 0.0
			_event("attach")
			return
		_move_to(p.global_position, cfg["chase"], delta)
	else:
		if wait_t > 0.0:
			wait_t -= delta
			_gravity_only(delta)
		elif _move_to(goal, cfg["walk"], delta):
			wait_t = rng.randf_range(2.0, 5.0)
			goal = world.gen.random_point(rng)


func _attach_face(pid: int) -> void:
	attached_pid = pid
	sp_phase = 2
	sp_t = 10.0
	_event("attach")
	world.send_effect(pid, "vomit", global_position, 10.0)


func _detach() -> void:
	if attached_pid != -1:
		world.send_effect(attached_pid, "vomit", global_position, 0.0)
	attached_pid = -1
	state = CHASE
	cd = 4.0
	stun_t = 1.5
	_event("detach")
	global_position += Vector3(0, -0.8, 0)


func _brain_mimic(delta: float) -> void:
	if disguised:
		perceive_t -= delta
		if perceive_t <= 0.0:
			perceive_t = 0.2
			var p = _nearest_player(2.3)
			if p:
				reveal(p.peer_id)
		_gravity_only(delta)
		return
	reveal_t -= delta
	if (reveal_t <= 0.0 and state != ATTACK) or (state != CHASE and state != ATTACK):
		_set_disguise(true)
		_gravity_only(delta)
		return
	_brain_default(delta)


func _set_disguise(on: bool) -> void:
	if disguised == on:
		return
	disguised = on
	if not on:
		reveal_t = 12.0
	else:
		state = WANDER
	_event("hide" if on else "reveal")


func reveal(pid: int) -> void:
	if mtype != "mimic" or state == DEAD:
		return
	_set_disguise(false)
	target_pid = pid
	state = CHASE
	lost_t = 0.0
	reveal_t = 12.0


func _brain_watcher(delta: float) -> void:
	# stalks unseen; a direct look triggers a full-speed hunt
	if state == CHASE:
		sp_t -= delta
		var p = world.players.get(target_pid)
		if p == null or p.dead or sp_t <= 0.0:
			state = WANDER
			path = []
			return
		var d := global_position.distance_to(p.global_position)
		if d < cfg["range"] and cd <= 0.0:
			cd = cfg["cd"]
			_event("attack")
			_hit(target_pid, cfg["dmg"])
			return
		_move_to(p.global_position, cfg["chase"], delta)
		return
	perceive_t -= delta
	if perceive_t <= 0.0:
		perceive_t = 0.15
		var center := global_position + Vector3(0, 1.3, 0)
		for p in _players_alive():
			var eye: Vector3 = p.eye_pos()
			var to := center - eye
			var dd := to.length()
			if dd < 15.0 and p.look_dir().dot(to / maxf(dd, 0.01)) > 0.9 and _los(eye, center):
				target_pid = p.peer_id
				state = CHASE
				sp_t = 8.0
				_event("scream")
				return
	# creep towards the nearest player while not observed
	var n = _nearest_player(30.0)
	if n and global_position.distance_to(n.global_position) > 5.0:
		_move_to(n.global_position, cfg["walk"], delta)
	else:
		_gravity_only(delta)


func _brain_puff(delta: float) -> void:
	if aggro_t > 0.0:
		aggro_t -= delta
		if aggro_t <= 0.0:
			_event("calm")
			state = WANDER
			return
		var p = world.players.get(target_pid)
		if p == null or p.dead:
			p = _nearest_player(20.0)
			if p == null:
				_gravity_only(delta)
				return
			target_pid = p.peer_id
		var to: Vector3 = p.global_position + Vector3(0, 1.2, 0) - global_position
		velocity = to.normalized() * cfg["chase"]
		move_and_slide()
		_face(to, delta * 10.0)
		speed_now = velocity.length()
		if to.length() < 1.3 and cd <= 0.0:
			cd = cfg["cd"]
			_hit(target_pid, cfg["dmg"])
			_event("bite")
		return
	# passive: follow the nearest player at a respectful distance
	var n = _nearest_player(14.0)
	if n and global_position.distance_to(n.global_position) > 2.2:
		_move_to(n.global_position, cfg["walk"], delta)
	else:
		_gravity_only(delta)


func provoke(pid: int) -> void:
	if mtype == "puff" and aggro_t <= 0.0:
		aggro_t = 10.0
		target_pid = pid
		_event("rage")


func _brain_hunter(delta: float) -> void:
	# blind: hunts sounds only and fires at their source
	if sp_phase == 1:
		_gravity_only(delta)
		_face(noise_pos - global_position, delta * 8.0)
		sp_t -= delta
		if sp_t <= 0.0:
			world.server_shotgun(self, _eye(), noise_pos, cfg["dmg"] * world.dmg_mult())
			_event("shoot")
			sp_phase = 0
			cd = cfg["cd"]
		return
	for n in world.noise:
		if n["t"] <= last_noise_t:
			continue
		var d := global_position.distance_to(n["pos"])
		if d < cfg["hear"] * n["loud"]:
			noise_pos = n["pos"]
			goal = n["pos"]
			path = []
			state = INVESTIGATE
			if d < 14.0 and cd <= 0.0:
				sp_phase = 1
				sp_t = 0.7
				_event("grunt")
	last_noise_t = world.game_time
	if state == INVESTIGATE:
		if _move_to(goal, cfg["chase"], delta):
			state = WANDER
	else:
		if wait_t > 0.0:
			wait_t -= delta
			_gravity_only(delta)
		elif _move_to(goal, cfg["walk"], delta):
			wait_t = rng.randf_range(2.0, 4.0)
			goal = world.gen.random_point(rng)


func _brain_hidden(delta: float) -> void:
	# invisible; hears footsteps, grabs a robot and drags it away
	puff_t -= delta
	if puff_t <= 0.0:
		puff_t = 1.2
		_event("breath")
	if carry_pid != -1:
		sp_t -= delta
		var v = world.players.get(carry_pid)
		if v == null or v.dead or sp_t <= 0.0:
			world.send_effect(carry_pid, "carried", Vector3.ZERO, 0.0)
			carry_pid = -1
			cd = cfg["cd"]
			state = WANDER
			goal = world.gen.random_point(rng)
			return
		_move_to(goal, cfg["chase"] * 0.8, delta)
		world.send_effect(carry_pid, "carried", global_position + _fwd() * 0.6 + Vector3(0, 0.3, 0), 0.3)
		return
	if cd <= 0.0:
		_hear()
		for p in _players_alive():
			var d := global_position.distance_to(p.global_position)
			if d < 1.4 and state == INVESTIGATE:
				carry_pid = p.peer_id
				sp_t = 6.0
				goal = world.gen.random_point(rng)
				path = []
				world.server_damage_player(carry_pid, 5.0, Vector3.ZERO)
				_event("grab")
				return
	if state == INVESTIGATE:
		if _move_to(goal, cfg["chase"], delta):
			state = WANDER
	elif wait_t > 0.0:
		wait_t -= delta
		_gravity_only(delta)
	elif _move_to(goal, cfg["walk"], delta):
		wait_t = rng.randf_range(1.0, 3.0)
		goal = world.gen.random_point(rng)


func _bighead_flashlight_check() -> void:
	for p in _players_alive():
		var eye: Vector3 = p.eye_pos()
		var to := global_position + Vector3(0, 1.5, 0) - eye
		var d := to.length()
		if d < 15.0 and p.look_dir().dot(to / maxf(d, 0.01)) > 0.93 and _los(eye, global_position + Vector3(0, 1.5, 0)):
			target_pid = p.peer_id
			state = SPECIAL
			sp_t = 0.9
			sp_phase = 0
			_event("hiss")
			return


func _vanish() -> void:
	_event("smoke")
	_teleport_random()
	state = WANDER


func _teleport_random() -> void:
	var cells: Array = world.gen.monster_cells
	if cells.is_empty():
		return
	var c: Vector2i = cells[rng.randi() % cells.size()]
	global_position = world.gen.cell_center(c) + Vector3(rng.randf_range(-1.5, 1.5), 0.1, rng.randf_range(-1.5, 1.5))
	path = []


func _explode_self() -> void:
	fuse_t = -1.0
	world.server_explosion(global_position + Vector3(0, 0.3, 0), 4.0, 60.0 * world.dmg_mult(), 120.0, self)
	hp = 0.0
	state = DEAD
	world.server_monster_died(self, false)


# ------------------------------------------------------------------ movement

func _move_to(target: Vector3, speed: float, delta: float) -> bool:
	if grab_slow > 0.0:
		speed *= 0.4
	repath_t -= delta
	if path.is_empty() or repath_t <= 0.0:
		path = world.gen.path_points(global_position, target)
		repath_t = 0.7
	var wp: Vector3 = path[0]
	var to := wp - global_position
	to.y = 0.0
	while to.length() < 0.45 and path.size() > 1:
		path.pop_front()
		wp = path[0]
		to = wp - global_position
		to.y = 0.0
	if path.size() == 1 and to.length() < 0.7:
		_gravity_only(delta)
		return true
	var dir := to.normalized()
	velocity.x = dir.x * speed
	velocity.z = dir.z * speed
	if mtype == "bighead" or mtype == "puff" and aggro_t > 0.0:
		velocity.y = (target.y + (0.0 if mtype == "bighead" else 1.0) - global_position.y) * 2.0
	else:
		velocity.y = -1.0 if is_on_floor() else velocity.y - 14.0 * delta
	var before := global_position
	move_and_slide()
	for i in get_slide_collision_count():
		var c := get_slide_collision(i)
		var b = c.get_collider()
		if b is RigidBody3D:
			var n := -c.get_normal()
			n.y = 0.0
			n = n.normalized()
			var vn: float = b.linear_velocity.dot(n)
			if vn < speed:
				b.apply_central_impulse(n * minf((speed - vn) * b.mass * 0.35, 25.0))
	var moved := (global_position - before).length() / maxf(delta, 0.001)
	speed_now = moved
	_face(dir, delta * 8.0)
	if moved < speed * 0.2:
		stuck_t += delta
		if stuck_t > 1.2:
			stuck_t = 0.0
			path = []
			if state == WANDER:
				goal = world.gen.random_point(rng)
			velocity = Vector3(-dir.z, 0, dir.x) * speed
			move_and_slide()
	else:
		stuck_t = 0.0
	return false


# ------------------------------------------------------------------ grabbing & throwing

func can_lift(total_strength: float) -> bool:
	if mtype == "eye":
		return false
	var w := weight()
	return w > 0.0 and total_strength > w * 9.8 * 1.1


func grab_hold(target: Vector3, total_strength: float) -> void:
	if state == DEAD:
		return
	if not can_lift(total_strength):
		grab_slow = 0.3
		if mtype == "puff":
			provoke(-1 if target_pid == -1 else target_pid)
		return
	if state != HELD:
		if mtype == "puff":
			provoke(target_pid)
		if attached_pid != -1 and mtype == "spewer":
			_detach()
		if attached_pid != -1 and mtype == "tick":
			attached_pid = -1
			_event("detach")
		state = HELD
		held_t = 0.0
	held_target = target
	held_t = 0.0


func _held_tick(delta: float) -> void:
	held_t += delta
	if held_t > 0.5:
		state = THROWN
		thrown_t = 0.0
		return
	var to := held_target - (global_position + Vector3(0, cfg["height"] * 0.5, 0))
	velocity = to * 10.0
	if velocity.length() > 10.0:
		velocity = velocity.normalized() * 10.0
	var before_v := velocity
	move_and_slide()
	_check_impact(before_v)
	speed_now = velocity.length()
	# small critters struggle free
	if mtype == "skitter" and rng.randf() < delta * 0.6:
		state = THROWN
		velocity += Vector3(rng.randf_range(-3, 3), 3.0, rng.randf_range(-3, 3))


func release_throw(impulse: Vector3) -> void:
	if state == HELD:
		velocity += impulse
		state = THROWN
		thrown_t = 0.0


func _thrown_tick(delta: float) -> void:
	thrown_t += delta
	velocity.y -= 14.0 * delta
	var before_v := velocity
	move_and_slide()
	_check_impact(before_v)
	if is_on_floor():
		velocity.x *= 0.85
		velocity.z *= 0.85
		if velocity.length() < 0.6 or thrown_t > 4.0:
			state = CHASE if target_pid != -1 else WANDER
			stun_t = 0.6
	speed_now = velocity.length()


func _check_impact(before_v: Vector3) -> void:
	var dv := (before_v - velocity).length()
	if dv > 5.0 and get_slide_collision_count() > 0:
		take_hit(dv * maxf(weight(), 3.0) * 1.3)
		if mtype == "bomber" and state != DEAD:
			_explode_self()


# ------------------------------------------------------------------ damage

func take_hit(dmg: float) -> void:
	if state == DEAD or not server_side:
		return
	if mtype == "mimic" and disguised:
		var near = _nearest_player()
		if near:
			reveal(near.peer_id)
	if mtype == "puff":
		var near2 = _nearest_player()
		provoke(near2.peer_id if near2 else -1)
	hp -= dmg
	dormant = 0.0
	_event("hurt")
	if hp <= 0.0:
		state = DEAD
		if carry_pid != -1:
			world.send_effect(carry_pid, "carried", Vector3.ZERO, 0.0)
		if attached_pid != -1 and mtype == "spewer":
			world.send_effect(attached_pid, "vomit", Vector3.ZERO, 0.0)
		if mtype == "bomber":
			world.server_explosion(global_position + Vector3(0, 0.3, 0), 4.0, 60.0 * world.dmg_mult(), 120.0, self)
		world.server_monster_died(self, cfg["orb"][1] > 0)
		return
	if dmg > 15.0 and state != HELD and state != THROWN:
		stun_t = maxf(stun_t, clampf(dmg / 80.0, 0.3, 2.0))
	if mtype in ["gremlin", "bomber", "hunter", "eye", "watcher", "puff", "tick"]:
		return
	var best = _nearest_player()
	if best and state != SPECIAL:
		target_pid = best.peer_id
		state = CHASE


func stun(sec: float, sleep := false) -> void:
	if state == DEAD:
		return
	stun_t = maxf(stun_t, sec)
	if state == SPECIAL or state == ATTACK:
		state = CHASE
	if carry_pid != -1:
		world.send_effect(carry_pid, "carried", Vector3.ZERO, 0.0)
		carry_pid = -1
	if attached_pid != -1:
		if mtype == "spewer":
			_detach()
		else:
			attached_pid = -1
	if sleep:
		sleeping_mon = true
		_event("sleep")
	else:
		_event("stun")


# ------------------------------------------------------------------ client-side events

func on_event(ev: String) -> void:
	var p := global_position
	match ev:
		"alert":
			match mtype:
				"gremlin", "tick", "skitter":
					Sfx.play("skitter", p, 0.0, 1.3)
				"bomber":
					Sfx.play("beep", p, 0.0, 0.8)
				_:
					Sfx.play("growl", p, 2.0, 0.6 if mtype == "brute" else 0.9)
		"attack":
			attack_anim = 1.0
			Sfx.play("swing", p, 0.0, 0.7 if mtype in ["brute", "butcher"] else 1.0)
		"hurt":
			hurt_flash = 0.25
			Sfx.play("thud", p, 0.0, 0.6)
		"scream":
			Sfx.play("scream", p, 6.0)
			if parts.has("mouth"):
				var tw := create_tween()
				tw.tween_property(parts["mouth"], "scale", Vector3(1.5, 3.0, 1.0), 0.2)
				tw.tween_interval(0.8)
				tw.tween_property(parts["mouth"], "scale", Vector3.ONE, 0.3)
		"fuse":
			Sfx.play("beep_hi", p, 2.0, 0.7)
			if parts.has("fuse"):
				var tw2 := create_tween().set_loops(10)
				tw2.tween_property(parts["fuse"], "scale", Vector3.ONE * 1.6, 0.25)
				tw2.tween_property(parts["fuse"], "scale", Vector3.ONE, 0.25)
		"reveal":
			disguised = false
			Sfx.play("growl", p, 4.0, 1.4)
			if parts.has("lid"):
				create_tween().tween_property(parts["lid"], "rotation:x", -1.1, 0.2)
				if parts.has("tongue"):
					parts["tongue"].visible = true
				for e in parts.get("eyes", []):
					if e:
						e.visible = true
		"hide":
			disguised = true
			if parts.has("lid"):
				create_tween().tween_property(parts["lid"], "rotation:x", 0.0, 0.4)
				if parts.has("tongue"):
					parts["tongue"].visible = false
				for e in parts.get("eyes", []):
					if e:
						e.visible = false
		"rage":
			Sfx.play("growl", p, 3.0, 1.8)
			if parts.has("jaw"):
				parts["jaw"].visible = true
			aggro_t = 10.0
		"calm":
			if parts.has("jaw"):
				parts["jaw"].visible = false
			aggro_t = 0.0
		"bite":
			Sfx.play("thud", p, 2.0, 1.6)
		"lift":
			Sfx.play("growl", p, 2.0, 0.5)
			Fx.burst(world.fx_root, p + Vector3(0, 1.0, 0), Color(0.7, 0.4, 1.0), 30, 1.5, 1.5, 2.0, 0.06, true)
		"slam":
			Sfx.play("break", p, 4.0, 0.5)
		"windup":
			attack_anim = 0.5
			Sfx.play("growl", p, 3.0, 0.5)
		"stumble":
			Sfx.play("thud", p, 2.0, 0.5)
		"laugh":
			Sfx.play("scream", p, 2.0, 1.8)
		"beam":
			Sfx.play("beam", p, 6.0, 2.0)
			_beam_visual(true)
		"beam_end":
			_beam_visual(false)
		"hiss":
			Sfx.play("skitter", p, 6.0, 0.4)
		"smoke":
			Fx.burst(world.fx_root, p + Vector3(0, 1.5, 0), Color(0.05, 0.05, 0.06), 40, 2.0, 0.5, 1.5, 0.15)
		"grunt":
			Sfx.play("growl", p, 3.0, 0.45)
		"shoot":
			Sfx.play("break", p, 8.0, 0.35)
			Fx.burst(world.fx_root, _eye() + _fwd() * 0.8, Color(1.0, 0.8, 0.3), 12, 5.0, 0.0, 0.2, 0.05, true)
		"throw":
			Sfx.play("swing", p, 2.0, 0.6)
		"breath":
			if mtype == "hidden":
				Fx.burst(world.fx_root, p + Vector3(0, 1.7, 0) + _fwd() * 0.3, Color(0.8, 0.85, 0.9), 6, 0.6, 0.3, 1.2, 0.08)
		"grab":
			Sfx.play("scream", p, 2.0, 0.6)
		"attach":
			Sfx.play("skitter", p, 2.0, 1.6)
		"detach":
			pass
		"stun":
			hurt_flash = 0.4
			Fx.burst(world.fx_root, p + Vector3(0, cfg["height"], 0), Color(0.4, 0.7, 1.0), 12, 1.0, 0.0, 0.8, 0.04, true)
		"sleep":
			Fx.float_text(world.fx_root, p + Vector3(0, cfg["height"] + 0.3, 0), "Z z z", Color(0.6, 0.8, 1.0))
		"wake":
			pass
		"lurk":
			model.visible = false
			collision_layer = 0
		"appear":
			collision_layer = 8
			if mtype != "hidden":
				model.visible = true
				var y0 := model.position.y
				model.position.y = y0 - 2.0
				var twa := create_tween()
				twa.tween_property(model, "position:y", y0, 1.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
		"leave":
			state = DEAD
			collision_layer = 0
			collision_mask = 0
			_beam_visual(false)
			var twl := create_tween()
			twl.tween_property(model, "position:y", -2.5, 1.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
			twl.tween_callback(queue_free)
		"dead":
			state = DEAD
			collision_layer = 0
			collision_mask = 0
			_beam_visual(false)
			Sfx.play("mdie", p, 4.0)
			var tw3 := create_tween()
			tw3.set_parallel(true)
			tw3.tween_property(model, "scale", Vector3(1.3, 0.05, 1.3), 0.8)
			tw3.tween_property(model, "rotation:z", 0.8, 0.8)
			tw3.chain().tween_callback(queue_free)


const Fx = preload("res://scripts/game/fx.gd")
var _beam: MeshInstance3D = null


func _beam_visual(on: bool) -> void:
	if on and _beam == null:
		_beam = MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.08, 0.08, 12.0)
		_beam.mesh = bm
		_beam.material_override = ML.plain(Color(1.0, 0.95, 0.6), 0.2, 0.0, 4.0, 0.7)
		_beam.position = Vector3(0, cfg["height"] * 0.85 - 0.2, -6.0)
		add_child(_beam)
	if _beam:
		_beam.visible = on


func _animate(delta: float) -> void:
	anim_t += delta * (1.5 + speed_now * 2.0)
	var sw := sin(anim_t * 2.0) * minf(speed_now / 3.0, 1.0)
	match mtype:
		"skitter", "tick":
			for i in legs.size():
				legs[i].rotation.y = sin(anim_t * 5.0 + i * 1.3) * 0.5 * minf(speed_now / 2.0, 1.0)
		"howler", "bighead":
			model.position.y = 0.15 + sin(anim_t * 1.5) * 0.12
			if parts.has("head"):
				parts["head"].rotation.z = sin(anim_t * 0.7) * 0.15
			if parts.has("jaw") and mtype == "bighead":
				parts["jaw"].rotation.x = 0.3 + 0.3 * sin(anim_t * 3.0) if state == CHASE else 0.05
		"puff":
			model.position.y = absf(sin(anim_t * 3.0)) * 0.1
			if aggro_t > 0.0 and parts.has("jaw"):
				parts["jaw"].rotation.x = 0.5 * absf(sin(anim_t * 9.0))
		"mimic":
			if parts.has("body"):
				parts["body"].position.y = absf(sin(anim_t * 4.0)) * 0.12 * minf(speed_now / 2.0, 1.0)
				if not disguised and parts.has("lid"):
					parts["lid"].rotation.x = -0.9 - 0.3 * sin(anim_t * 6.0)
		"eye":
			if parts.has("head"):
				parts["head"].rotation = Vector3(sin(anim_t * 0.6) * 0.3, sin(anim_t * 0.4) * 0.6, 0)
		"spewer":
			if parts.has("jaw"):
				parts["jaw"].rotation.x = 0.4 * absf(sin(anim_t * 4.0))
		"watcher":
			var moving := speed_now > 0.3
			if _was_moving and not moving:
				for a in arms:
					a.rotation = Vector3(randf_range(-2.2, 0.3), 0, randf_range(-0.4, 0.4))
				if parts.has("head"):
					parts["head"].rotation = Vector3(randf_range(-0.4, 0.4), randf_range(-0.8, 0.8), randf_range(-0.5, 0.5))
			_was_moving = moving
		_:
			var amt := minf(speed_now / 3.0, 1.0)
			if legs.size() == 2:
				legs[0].rotation.x = sw * 0.7
				legs[1].rotation.x = -sw * 0.7
			for i in knees.size():
				var ph := anim_t * 2.0 + (0.0 if i == 0 else PI)
				knees[i].rotation.x = -maxf(0.0, sin(ph + 1.4)) * 1.1 * amt
			if arms.size() == 2:
				if attack_anim > 0.0:
					var a := 2.4 * sin(attack_anim * PI)
					arms[0].rotation.x = a
					arms[1].rotation.x = a
				else:
					arms[0].rotation.x = -sw * 0.5 - 0.15
					arms[1].rotation.x = sw * 0.5 - 0.15
			for i in elbows.size():
				elbows[i].rotation.x = 0.3 + 0.4 * amt + (1.0 * sin(attack_anim * PI) if attack_anim > 0.0 else 0.0)
			# body: step bob, lean into a chase, breathing when idle
			var chasing := state == CHASE or state == ATTACK
			_lean = lerpf(_lean, (0.14 if chasing else 0.05) * amt, minf(1.0, delta * 4.0))
			model.position.y = absf(sin(anim_t * 2.0)) * 0.05 * amt + sin(anim_t * 0.8) * 0.01 * (1.0 - amt)
			if parts.has("body"):
				parts["body"].rotation.x = -_lean
			if parts.has("head"):
				var hy := sin(anim_t * 0.4) * 0.3
				var tp = world.players.get(target_pid) if world and chasing else null
				if tp and is_instance_valid(tp):
					var to: Vector3 = (tp.global_position - global_position).rotated(Vector3.UP, -yaw)
					hy = clampf(atan2(-to.x, -to.z), -0.9, 0.9)
				parts["head"].rotation.y = lerp_angle(parts["head"].rotation.y, hy, minf(1.0, delta * 6.0))
	if state == HELD or state == THROWN:
		model.rotation.x = sin(anim_t * 6.0) * 0.4
	else:
		model.rotation.x = lerpf(model.rotation.x, 0.0, minf(1.0, delta * 8.0))
	if attack_anim > 0.0:
		attack_anim = maxf(0.0, attack_anim - delta * 2.2)
	if hurt_flash > 0.0:
		hurt_flash -= delta
		if _flash_mat == null:
			_flash_mat = StandardMaterial3D.new()
			_flash_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			_flash_mat.albedo_color = Color(1, 0.1, 0.05, 0.55)
			_flash_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		for mi in _meshes:
			mi.material_overlay = _flash_mat if hurt_flash > 0.0 else null
	if state != DEAD:
		sound_t -= delta
		if sound_t <= 0.0:
			sound_t = rng.randf_range(6.0, 12.0)
			match mtype:
				"gremlin", "skitter", "tick":
					Sfx.play("skitter", global_position, -4.0)
				"lurker":
					Sfx.play("skitter", global_position, -2.0, 0.5)
				"brute":
					Sfx.play("growl", global_position, 0.0, 0.35)
				"projector":
					Sfx.play("thud", global_position, 0.0, 0.4)
				"howler", "mimic", "watcher", "eye", "hidden", "puff", "hunter":
					pass
				_:
					Sfx.play("growl", global_position, -6.0, 0.8)
