extends "res://scripts/game/level_gen.gd"
## "Disposal arena" (like the reference game): when the whole crew is wiped out online, everyone
## lands on a round platform above a glowing pit and fights; the rim falls away ring by ring;
## the last robot standing becomes the King of Losers and wears a crown next run.

const RINGS := 5
const RING_W := 1.35
var tiles := {}          # ring index -> Array of [StaticBody3D, MeshInstance3D]
var tile_mat: Material
var warn_mat: StandardMaterial3D


func build(s: int, level: int, parent: Node3D) -> void:
	rng.seed = s
	location = 0
	cells[Vector2i.ZERO] = "arena"
	order.append(Vector2i.ZERO)
	spawn_cell = Vector2i(99, 99)
	truck_pos = Vector3(0, -50, 0)
	root = Node3D.new()
	root.name = "Arena"
	parent.add_child(root)
	body = StaticBody3D.new()
	body.collision_layer = 1
	root.add_child(body)
	tile_mat = surface_material("metal", 0.8, 0.0, 1.0, 0.6, 0.05, 0.0, 1.3)
	warn_mat = StandardMaterial3D.new()
	warn_mat.albedo_color = Color(0.6, 0.08, 0.05)
	warn_mat.emission_enabled = true
	warn_mat.emission = Color(1.0, 0.15, 0.08)
	warn_mat.emission_energy_multiplier = 1.5
	_build_platform()
	_build_pit()
	_build_lights()
	for i in 6:
		var a := TAU * i / 6.0 + 0.3
		spawn_points.append(Vector3(cos(a) * 4.6, 0.3, sin(a) * 4.6))
	for r in range(1, RINGS + 1):
		for k in 3 + r * 2:
			var a := rng.randf() * TAU
			var rad := (r - 0.5) * RING_W + 0.6
			item_spots.append({"pos": Vector3(cos(a) * rad, 0.25, sin(a) * rad), "kind": "floor"})


func _build_platform() -> void:
	# centre disc (never falls) with the crown pedestal
	var cm := CylinderMesh.new()
	cm.top_radius = 0.6 + RING_W * 0.0 + 0.62
	cm.bottom_radius = cm.top_radius
	cm.height = 0.4
	cm.radial_segments = 24
	var center := MeshInstance3D.new()
	center.mesh = cm
	center.material_override = tile_mat
	center.position = Vector3(0, -0.2, 0)
	root.add_child(center)
	var cs := CollisionShape3D.new()
	var csh := CylinderShape3D.new()
	csh.radius = cm.top_radius
	csh.height = 0.4
	cs.shape = csh
	cs.position = Vector3(0, -0.2, 0)
	body.add_child(cs)
	var ped := CylinderMesh.new()
	ped.top_radius = 0.3
	ped.bottom_radius = 0.42
	ped.height = 0.7
	var pmi := MeshInstance3D.new()
	pmi.mesh = ped
	pmi.material_override = ML.plain(Color(0.12, 0.12, 0.14), 0.4, 0.7)
	pmi.position = Vector3(0, 0.35, 0)
	root.add_child(pmi)
	var pcs := CollisionShape3D.new()
	var psh := CylinderShape3D.new()
	psh.radius = 0.36
	psh.height = 0.7
	pcs.shape = psh
	pcs.position = Vector3(0, 0.35, 0)
	body.add_child(pcs)
	var crown := ML.model("crown")
	if crown:
		crown.position = Vector3(0, 0.95, 0)
		crown.scale = Vector3.ONE * 1.4
		root.add_child(crown)
		var tw := crown.create_tween().set_loops()
		tw.tween_property(crown, "rotation:y", TAU, 6.0).from(0.0)
	# rings of plates around it
	var inner := cm.top_radius
	for r in range(1, RINGS + 1):
		var r0 := inner + (r - 1) * RING_W
		var r1 := r0 + RING_W - 0.06
		var mid := (r0 + r1) * 0.5
		var n := int(ceil(TAU * mid / 1.6))
		var arr := []
		for k in n:
			var a := TAU * (k + 0.5) / n
			var arc := TAU * mid / n - 0.06
			var sb := StaticBody3D.new()
			sb.collision_layer = 1
			sb.position = Vector3(cos(a) * mid, -0.2, sin(a) * mid)
			sb.rotation.y = -a
			root.add_child(sb)
			var bm := BoxMesh.new()
			bm.size = Vector3(RING_W - 0.06, 0.4, arc)
			var mi := MeshInstance3D.new()
			mi.mesh = bm
			mi.material_override = tile_mat
			sb.add_child(mi)
			var sh := CollisionShape3D.new()
			var bs := BoxShape3D.new()
			bs.size = bm.size
			sh.shape = bs
			sb.add_child(sh)
			arr.append([sb, mi])
		tiles[r] = arr


func _build_pit() -> void:
	var pm := PlaneMesh.new()
	pm.size = Vector2(80, 80)
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.05, 0.0, 0.0)
	m.emission_enabled = true
	m.emission = Color(0.55, 0.06, 0.02)
	m.emission_energy_multiplier = 1.2
	m.albedo_texture = dirt_texture()
	m.emission_texture = dirt_texture()
	m.uv1_scale = Vector3(6, 6, 6)
	mi.material_override = m
	mi.position = Vector3(0, -14.0, 0)
	root.add_child(mi)
	var glow := OmniLight3D.new()
	glow.light_color = Color(1.0, 0.25, 0.1)
	glow.light_energy = 2.5
	glow.omni_range = 26.0
	glow.position = Vector3(0, -10.0, 0)
	root.add_child(glow)


func _build_lights() -> void:
	for i in 4:
		var a := TAU * i / 4.0
		var l := OmniLight3D.new()
		l.light_color = Color(1.0, 0.85, 0.65)
		l.light_energy = 2.6
		l.omni_range = 13.0
		l.omni_attenuation = 1.2
		l.position = Vector3(cos(a) * 4.0, 5.5, sin(a) * 4.0)
		root.add_child(l)
		lights.append({"light": l, "base": l.light_energy, "flicker": false, "lamp": null})
		var lamp := ML.model("lamp_cage", {}, false)
		if lamp:
			lamp.position = l.position + Vector3(0, 0.6, 0)
			root.add_child(lamp)
	var top := OmniLight3D.new()
	top.light_color = Color(1.0, 0.8, 0.4)
	top.light_energy = 1.2
	top.omni_range = 6.0
	top.position = Vector3(0, 3.0, 0)
	root.add_child(top)


## Called on every peer: 2 s of red warning, then the ring falls into the pit.
func warn_ring(r: int) -> void:
	for t in tiles.get(r, []):
		t[1].material_override = warn_mat


func drop_ring(r: int) -> void:
	for t in tiles.get(r, []):
		var sb: StaticBody3D = t[0]
		if not is_instance_valid(sb):
			continue
		sb.collision_layer = 0
		for c in sb.get_children():
			if c is CollisionShape3D:
				c.disabled = true
		var tw := sb.create_tween()
		tw.set_parallel(true)
		tw.tween_property(sb, "position:y", -16.0, 2.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
		tw.tween_property(sb, "rotation:x", randf_range(-1.2, 1.2), 2.2)
		tw.chain().tween_callback(sb.queue_free)
	tiles.erase(r)
