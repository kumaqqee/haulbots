extends RefCounted
## Shared materials + model loading. Blender material names map to library materials:
## M_<name> library, C_rrggbb plain colour, E_rrggbb emissive, G_rrggbb glass.

static var _mats := {}
static var _tex := {}
static var _scenes := {}


static func tex(n: String) -> Texture2D:
	if _tex.has(n):
		return _tex[n]
	var p := "res://assets/tex/%s.png" % n
	var t: Texture2D = load(p) if ResourceLoader.exists(p) else null
	_tex[n] = t
	return t


static func textured(key: String, tname: String, tint := Color.WHITE, scale := 1.0, rough := 0.8, metal := 0.0, normal := true) -> StandardMaterial3D:
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex(tname)
	m.albedo_color = tint
	if normal and tex(tname + "_n"):
		m.normal_enabled = true
		m.normal_texture = tex(tname + "_n")
		m.normal_scale = 0.8
	m.uv1_triplanar = true
	m.uv1_world_triplanar = false
	m.uv1_scale = Vector3.ONE * scale
	m.roughness = rough
	m.metallic = metal
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	_mats[key] = m
	return m


static func plain(c: Color, rough := 0.7, metal := 0.0, emit := 0.0, alpha := 1.0) -> StandardMaterial3D:
	var key := "p|%s|%.2f|%.2f|%.2f|%.2f" % [c.to_html(), rough, metal, emit, alpha]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(c.r, c.g, c.b, alpha)
	m.roughness = rough
	m.metallic = metal
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emit
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
	_mats[key] = m
	return m


## Baked per-model material (albedo + ORM atlases made by tools/bake.py).
static func baked(model: String) -> Material:
	var key := "T|" + model
	if _mats.has(key):
		return _mats[key]
	var p := "res://assets/mtex/%s.png" % model
	if not ResourceLoader.exists(p):
		_mats[key] = null
		return null
	var m := ORMMaterial3D.new()
	m.albedo_texture = load(p)
	var po := "res://assets/mtex/%s_orm.png" % model
	if ResourceLoader.exists(po):
		m.orm_texture = load(po)
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	_mats[key] = m
	return m


static func named(n: String) -> Material:
	if n.begins_with("T_"):
		return baked(n.substr(2))
	match n:
		"M_wood":
			return textured(n, "wood", Color.WHITE, 2.0, 0.6)
		"M_wood_dark":
			return textured(n, "wood_dark", Color.WHITE, 2.0, 0.55)
		"M_gold":
			return plain(Color(1.0, 0.76, 0.33), 0.28, 0.75)
		"M_metal":
			return textured(n, "metal", Color(0.85, 0.86, 0.9), 2.0, 0.4, 0.6)
		"M_chrome":
			return plain(Color(0.85, 0.86, 0.9), 0.15, 0.85)
		"M_dark_metal":
			return plain(Color(0.14, 0.14, 0.16), 0.4, 0.6)
		"M_marble":
			return textured(n, "marble", Color.WHITE, 1.5, 0.25)
		"M_stone":
			return textured(n, "concrete", Color(0.75, 0.72, 0.68), 1.5, 0.9)
		"M_fabric":
			return textured(n, "fabric", Color(0.6, 0.18, 0.18), 3.0, 0.95)
		"M_rubber":
			return plain(Color(0.05, 0.05, 0.05), 0.9)
		"M_paper":
			return plain(Color(0.88, 0.84, 0.74), 0.9)
		"M_bone":
			return plain(Color(0.9, 0.87, 0.78), 0.6)
		"M_skin_pale":
			return plain(Color(0.8, 0.76, 0.71), 0.5)
		"M_screen":
			return plain(Color(0.04, 0.09, 0.07), 0.2, 0.0, 0.3)
		"M_glass":
			return plain(Color(0.8, 0.9, 1.0), 0.05, 0.0, 0.0, 0.35)
		"M_canvas":
			return plain(Color(0.8, 0.7, 0.5))
		"M_player":
			return plain(Color(0.95, 0.55, 0.12), 0.45, 0.2)
		"M_player_glow":
			return plain(Color(1.0, 0.6, 0.15), 0.3, 0.0, 3.0)
		"M_vase":
			return plain(Color(0.2, 0.35, 0.8), 0.25, 0.1)
		"M_mask":
			return plain(Color(0.8, 0.6, 0.2), 0.35, 0.4)
		"E_upgrade":
			return plain(Color(0.3, 0.8, 1.0), 0.3, 0.0, 2.5)
		"E_zone":
			return plain(Color(0.3, 1.0, 0.45), 0.3, 0.0, 2.5)
		"E_button":
			return plain(Color(1.0, 0.15, 0.1), 0.3, 0.0, 2.0)
		"E_liquid":
			return plain(Color(0.3, 1.0, 0.4), 0.2, 0.0, 1.5, 0.85)
	if n == "E_203a6a":
		return plain(Color(0.12, 0.2, 0.38), 0.1, 0.0, 0.7)
	if n == "C_2b4a6e":
		return plain(Color(0.13, 0.22, 0.33), 0.85, 0.0)
	if n.length() >= 8 and n[1] == "_":
		var c := Color.html(n.substr(2, 6))
		match n[0]:
			"C":
				return plain(c)
			"E":
				return plain(c, 0.3, 0.0, 1.8)
			"G":
				return plain(c, 0.05, 0.0, 0.0, 0.45)
	return null


## Replace imported materials with library materials. `over` maps names to custom materials.
static func apply(root: Node, over := {}, shadows := true) -> void:
	var stack := [root]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		stack.append_array(n.get_children())
		if n is MeshInstance3D:
			var mi := n as MeshInstance3D
			if not shadows:
				mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			var mesh := mi.mesh
			if mesh == null:
				continue
			for i in mesh.get_surface_count():
				var sm := mesh.surface_get_material(i)
				var nm := sm.resource_name if sm else ""
				var dot := nm.find(".")
				if dot > 0:
					nm = nm.substr(0, dot)
				if over.has(nm):
					mi.set_surface_override_material(i, over[nm])
				else:
					var lm := named(nm)
					if lm:
						mi.set_surface_override_material(i, lm)


static func canvas(i: int) -> StandardMaterial3D:
	var key := "canvas%d" % i
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex("painting%d" % (i % 8))
	m.roughness = 0.85
	_mats[key] = m
	return m


static func scene(n: String) -> PackedScene:
	if _scenes.has(n):
		return _scenes[n]
	var p := "res://assets/models/%s.glb" % n
	var s: PackedScene = load(p) if ResourceLoader.exists(p) else null
	_scenes[n] = s
	return s


## Instance a model with library materials applied.
static func model(n: String, over := {}, shadows := true) -> Node3D:
	var s := scene(n)
	if s == null:
		return null
	var inst: Node3D = s.instantiate()
	apply(inst, over, shadows)
	return inst


## Hide far geometry (the fog already hides it); fades over the margin so nothing pops.
static func vis_range(n: Node, dist: float, margin := 3.0) -> void:
	for g in n.find_children("*", "GeometryInstance3D", true, false):
		g.visibility_range_end = dist
		g.visibility_range_end_margin = margin
		g.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
	if n is GeometryInstance3D:
		n.visibility_range_end = dist
		n.visibility_range_end_margin = margin
		n.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF


static func find(root: Node, part: String) -> Node3D:
	var r := root.find_child(part, true, false)
	return r as Node3D
