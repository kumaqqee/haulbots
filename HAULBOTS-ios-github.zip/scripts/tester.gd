extends Node
## Automated smoke tests: godot -- --autotest=solo|host|client|shots

var main: Node
var mode := "solo"
var errors := []


func _ready() -> void:
	print("[TEST] mode=", mode, " startup ms=", Time.get_ticks_msec())
	match mode:
		"solo":
			_solo()
		"host":
			_host()
		"client":
			_client()
		"shots":
			_shots()
		"menu":
			_menu_shots()
		"shopshot":
			_shopshot()
		"gallery":
			_gallery()
		"soak":
			_soak()
		"features":
			_features()
		"locshots":
			_loc_shots()
		"monsters":
			_monsters()
		"portraits":
			_portraits()
		"animshot":
			_animshot()
		"perf":
			_perf()
		"cartshot":
			_cartshot()
		"extrshot":
			_extrshot()
		"surplus":
			_surplus()
		"push":
			_push()
		"depart":
			_depart_test()
		"faces":
			_faces()
		"arena":
			_arena_test()
		"loadshot":
			_loadshot()


func _wait(t: float) -> void:
	await get_tree().create_timer(t).timeout


func _check(cond: bool, msg: String) -> void:
	if cond:
		print("[TEST] OK   ", msg)
	else:
		print("[TEST] FAIL ", msg)
		errors.append(msg)


func _finish() -> void:
	if errors.is_empty():
		print("[TEST] ALL PASSED")
	else:
		print("[TEST] FAILURES: ", errors)
	get_tree().quit(0 if errors.is_empty() else 1)


func _shot(n: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	var p := "user://shot_%s.png" % n
	img.save_png(p)
	print("[TEST] shot ", ProjectSettings.globalize_path(p))


func _solo() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.5)
	var w = main.world
	_check(w != null, "world created")
	_check(w.started, "level started")
	_check(w.items.size() > 10, "items spawned: %d" % w.items.size())
	_check(w.monsters.size() >= 2, "monsters spawned: %d" % w.monsters.size())
	_check(w.extr.size() >= 1, "extraction points: %d" % w.extr.size())
	_check(w.quota_total > 0, "quota: %d" % w.quota_total)
	_check(w.local_player != null, "local player")
	# grab test: teleport next to a light item and pull it up
	var lp = w.local_player
	var target = null
	for it in w.items.values():
		if it.mass < 5.0 and it.base_value > 0 and it.global_position.y < 1.3:
			target = it
			break
	_check(target != null, "found light item")
	# move it to open floor first (few valuables per level now: it may sit inside a shelf)
	var cc0: Vector3 = w.gen.cell_center(w.gen.order[1])
	target.teleport(cc0 + Vector3(0.3, 0.4, -0.5))
	await _wait(1.2)
	var start_y: float = target.global_position.y
	lp.global_position = target.global_position + Vector3(0, 0.2, 1.8)
	await _wait(0.3)
	for i in 60:
		var tp: Vector3 = Vector3(target.global_position.x, start_y + 1.2, target.global_position.z)
		w.rpc_grab_update(target.item_id, tp, Vector3.ZERO)
		await get_tree().physics_frame
	_check(target.global_position.y > start_y + 0.3, "grab beam lifts item (%.2f -> %.2f)" % [start_y, target.global_position.y])
	w.rpc_grab_release(target.item_id, Vector3(0, 0, -1))
	# impact damage test
	await _wait(1.0)
	var v0: int = target.value
	target.global_position = Vector3(target.global_position.x, 2.5, target.global_position.z)
	target.linear_velocity = Vector3(0, -9, 0)
	target.hit_cd = 0.0
	await _wait(1.0)
	var still: bool = is_instance_valid(target) and w.items.has(target.item_id)
	_check(not still or target.value < v0, "impact reduces value (%d -> %s)" % [v0, str(target.value) if still else "broken"])
	# extraction: move enough items into the first zone
	var e: Dictionary = w.extr[0]
	var zone: Vector3 = e["pos"]
	var sum := 0
	var k := 0
	for it in w.items.values():
		if it.base_value <= 0 or it.mass > 15.0:
			continue
		it.linear_velocity = Vector3.ZERO
		it.global_position = zone + Vector3((k % 4) * 0.5 - 0.75, 0.3 + (k / 4) * 0.4, ((k / 2) % 2) * 0.5 - 0.25)
		it.hit_cd = 3.0
		sum += it.value
		k += 1
		if sum > e["goal"] * 1.7:
			break
	await _wait(1.5)
	_check(e["value"] >= e["goal"], "zone value counted %d / %d" % [e["value"], e["goal"]])
	print("[DBG] active=", w.active_extr, " started=", w.started, " goal=", e["goal"], " value=", e["value"])
	w.rpc_interact("extract", 0)
	await _wait(0.2)
	print("[DBG] extracting=", w.extracting)
	await _wait(3.8)
	_check(e["done"], "extraction point 1 done")
	_check(w.level_extracted > 0, "level extracted: %d" % w.level_extracted)
	# force-complete remaining points
	for i in range(1, w.extr.size()):
		w.extr[i]["done"] = true
	w.all_done = true
	w.active_extr = -1
	lp.global_position = w.truck_pos + Vector3(0, 0.2, 0)
	await _wait(0.5)
	w.rpc_interact("truck", 0)
	await _wait(1.0)
	_check(w.leaving, "van departure countdown started")
	var carts := 0
	for it in w.items.values():
		if it.type == "cart":
			carts += 1
	_check(carts == 0, "cart removed after the final extraction")
	await _wait(11.5)
	_check(main.world != null and main.world.shop_mode, "reached shop location")
	_check(Net.money > 0, "money after level: %d" % Net.money)
	_check(Net.has_save(), "save written")
	await _wait(1.0)
	w = main.world
	lp = w.local_player
	var shop_items := []
	for it in w.items.values():
		if it.is_shop():
			shop_items.append(it)
	_check(shop_items.size() >= 10, "shop stocked: %d items" % shop_items.size())
	Net.money = 50600
	var up_item = null
	for it in shop_items:
		if it.type == "up_strength":
			up_item = it
	if up_item == null:
		up_item = shop_items[0]
	var price: int = up_item.value
	var up_type: String = up_item.type
	var up_id: int = up_item.item_id
	up_item.teleport(w.gen.checkout_pos + Vector3(0, 0.4, 0))
	await _wait(1.0)
	_check(w.basket == price, "basket counts item price (%d / %d)" % [w.basket, price])
	w.rpc_interact("buy", 0)
	await _wait(0.3)
	_check(w.buying, "checkout countdown started")
	await _wait(3.2)
	_check(not w.items.has(up_id) and Net.money == 50600 - price, "purchase extracted the goods and took the cash (%d)" % Net.money)
	var found_owned := false
	for oe in Net.owned:
		if oe["t"] == up_type:
			found_owned = true
	_check(found_owned, "bought item is waiting for the van (%d owned)" % Net.owned.size())
	lp.global_position = w.truck_pos + Vector3(0, 0.2, 0)
	await _wait(0.4)
	w.rpc_interact("truck", 0)
	await _wait(2.5)
	_check(main.world != null and main.world.level_num == 2, "level 2 loaded")
	w = main.world
	await _wait(1.0)
	var in_van = null
	for it in w.items.values():
		if it.type == up_type and it.uid > 0:
			in_van = it
	_check(in_van != null and in_van.global_position.distance_to(w.truck_pos) < 4.0, "purchase appeared in the van")
	var crystal := false
	for it in w.items.values():
		if it.type == "i_crystal" and it.uid > 0:
			crystal = true
	_check(crystal, "free energy crystal after level 1")
	if in_van:
		var uk: String = up_type.substr(3) if up_type.begins_with("up_") else ""
		var before := Net.up(1, uk) if uk != "" else 0
		w.local_player.global_position = in_van.global_position + Vector3(0, 0, 1.0)
		w.rpc_use_item(in_van.item_id)
		await _wait(0.3)
		_check(uk == "" or Net.up(1, uk) == before + 1, "using the upgrade applies it (%s -> %d)" % [uk, Net.up(1, uk) if uk != "" else 0])
		var still_owned := false
		for oe2 in Net.owned:
			if oe2["t"] == up_type:
				still_owned = true
		_check(not still_owned or not up_type.begins_with("up_"), "used upgrade leaves the owned list")
	# monster AI sanity: wake all, let them run
	for m in w.monsters.values():
		m.dormant = 0.0
	await _wait(3.0)
	var moved := 0
	for m in w.monsters.values():
		if m.global_position.distance_to(m.net_pos) > 0.3:
			moved += 1
	_check(moved > 0, "monsters move (%d)" % moved)
	# kill a monster with damage
	var mm = w.monsters.values()[0]
	for cand in w.monsters.values():
		if cand.cfg["orb"][1] > 0:
			mm = cand
			break
	print("[TEST] killing ", mm.mtype)
	var mid: int = mm.mid
	mm.take_hit(9999.0)
	await _wait(1.5)
	_check(not w.monsters.has(mid), "monster died")
	var orbs := 0
	for it in w.items.values():
		if it.type == "orb":
			orbs += 1
	_check(orbs > 0, "orb dropped")
	# death -> game over
	w.server_damage_player(1, 99999.0, Vector3.ZERO)
	await _wait(4.0)
	_check(main.screen_name == "gameover", "game over screen (screen=%s)" % main.screen_name)
	_check(not Net.has_save(), "save deleted on game over")
	_finish()


func _host() -> void:
	_check(Net.host_game(), "host started")
	var t := 0.0
	while Net.players.size() < 2 and t < 20.0:
		await _wait(0.5)
		t += 0.5
	_check(Net.players.size() == 2, "client joined")
	Net.start_run()
	await _wait(4.0)
	var w = main.world
	_check(w != null and w.started, "host level started")
	print("[TEST] host items=", w.items.size(), " monsters=", w.monsters.size(), " players=", w.players.size())
	_check(w.players.size() == 2, "host sees 2 players")
	# wait for client to grab something and talk
	await _wait(8.0)
	var cid: int = Net.players.keys().filter(func(k): return k != 1)[0]
	print("[TEST] voice frames from client: ", w.voice.frames_received(cid))
	_check(w.voice.frames_received(cid) > 0 or w.voice._speak_t.has(cid), "voice packets received from client")
	print("[TEST] host grabs=", w.grabs)
	_check(w.get_meta("client_grabbed", false), "client grab reached host")
	var c = w.players.values().filter(func(p): return not p.is_local)[0]
	_check(c.net_pos.distance_to(Vector3.ZERO) > 0.01, "client position replicated: %s" % str(c.net_pos))
	Net.server_level_complete(20000, 10000)
	await _wait(3.0)
	_check(main.world != null and main.world.shop_mode, "host in shop")
	await _wait(8.0)
	_finish()


func _client() -> void:
	await _wait(1.5)
	Net.join_game("127.0.0.1")
	var t := 0.0
	while main.world == null and t < 25.0:
		await _wait(0.5)
		t += 0.5
	_check(main.world != null, "client world loaded")
	await _wait(3.0)
	var w = main.world
	print("[TEST] client items=", w.items.size(), " monsters=", w.monsters.size(), " players=", w.players.size())
	_check(w.items.size() > 10, "client got items")
	_check(w.started, "client knows level started (HUD objective)")
	_check(w.extr.size() > 0 and w.extr[0]["goal"] > 0, "client got extraction goals")
	_check(w.monsters.size() >= 2, "client got monsters")
	_check(w.players.size() == 2, "client sees 2 players")
	# grab an item via rpc (as the real player code does)
	var lp = w.local_player
	var target = null
	var space: PhysicsDirectSpaceState3D = w.get_world_3d().direct_space_state
	for it in w.items.values():
		if it.mass < 5.0 and it.base_value > 0 and it.global_position.y < 1.3:
			var q := PhysicsRayQueryParameters3D.create(it.global_position + Vector3(0, 0.35, 0), it.global_position + Vector3(0, 1.8, 0), 1 | 4)
			q.exclude = [it.get_rid()]
			if space.intersect_ray(q).is_empty():
				target = it
				break
	var y0: float = target.global_position.y
	lp.global_position = target.global_position + Vector3(0, 0.2, 1.8)
	for i in 90:
		w.rpc_id(1, "rpc_grab_update", target.item_id, Vector3(target.net_pos.x, y0 + 1.2, target.net_pos.z) if i > 3 else target.global_position, Vector3.ZERO)
		await get_tree().physics_frame
	await _wait(0.5)
	_check(target.global_position.y > y0 + 0.3, "client sees replicated lift (%.2f -> %.2f)" % [y0, target.global_position.y])
	w.rpc_id(1, "rpc_grab_release", target.item_id, Vector3.ZERO)
	# synthetic voice: 1 s of 440 Hz at the mix rate
	var buf := PackedVector2Array()
	var mr := AudioServer.get_mix_rate()
	for i in int(mr):
		var v := sin(TAU * 440.0 * i / mr) * 0.5
		buf.append(Vector2(v, v))
	for c in 4:
		w.voice.feed(buf.slice(c * int(mr / 4), (c + 1) * int(mr / 4)))
		await _wait(0.1)
	var tt := 0.0
	while not (main.world and main.world.shop_mode) and tt < 25.0:
		await _wait(0.5)
		tt += 0.5
	await _wait(2.0)
	_check(main.world != null and main.world.shop_mode, "client moved to shop")
	var shop_n := 0
	for it in main.world.items.values():
		if it.is_shop():
			shop_n += 1
	_check(shop_n >= 10, "client sees shop stock: %d" % shop_n)
	_check(Net.money > 0, "client got team cash: %d" % Net.money)
	_finish()


func _shots() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(false)
	await _wait(2.5)
	var w = main.world
	var lp = w.local_player
	Net.inv[lp.peer_id] = [{"t": "w_shotgun", "b": 0.7}, null, {"t": "g_explosive", "b": 1.0}]
	await _shot("1_spawn")
	# look at an item room
	lp.global_position = LevelGenCenter(w, 1) + Vector3(0, 0.1, 2.5)
	lp.yaw = 0.0
	await _wait(1.0)
	await _shot("2_room")
	# grab something: bring a vase into the garage and hold it
	var target = null
	for it in w.items.values():
		if it.type in ["vase", "clock", "crystal", "goblet"]:
			target = it
			break
	lp.global_position = w.truck_pos + Vector3(0, 0.1, 0)
	lp.yaw = 0.0
	lp.pitch = -0.1
	target.teleport(w.truck_pos + Vector3(0.3, 1.0, -2.0))
	target.linear_velocity = Vector3.ZERO
	await _wait(0.8)
	lp.grabbed_id = target.item_id
	lp.grab_offset = Vector3.ZERO
	lp.hold_dist = 2.0
	for i in 6:
		await _wait(0.25)
		print("[DBG] item=", w.items.has(target.item_id), " pos=", target.global_position, " grabs=", w.grabs, " beam=", lp.beam.visible, " lp=", lp.global_position, " grabbed=", lp.grabbed_id)
	await _shot("3_grab")
	lp.release(Vector3.ZERO)
	# extraction point view
	var e: Dictionary = w.extr[0]
	lp.global_position = e["pos"] + Vector3(0, 0.05, 3.2)
	lp.yaw = 0.0
	lp.pitch = -0.25
	await _wait(1.0)
	await _shot("4_extraction")
	# monster view
	var m = w.monsters.values()[0]
	m.dormant = 999.0
	lp.global_position = m.global_position + Vector3(0, 0, 3.0)
	lp.yaw = 0.0
	lp.pitch = 0.1
	await _wait(1.0)
	await _shot("5_monster")
	w.hud._toggle_pause()
	await _wait(0.5)
	await _shot("6_pause")
	w.hud._toggle_pause()
	# holding a tracker in the van next to the charger
	lp.global_position = w.truck_pos + Vector3(0, 0.1, 0)
	var tid: int = w.spawn_item("t_extract", 0, lp.eye_pos() + lp.look_dir() * 1.0, Quaternion.IDENTITY, 0)
	await _wait(0.3)
	lp.grab_direct(tid)
	lp.yaw = PI * 0.5
	lp.pitch = -0.3
	await _wait(1.0)
	await _shot("7_tracker")
	get_tree().quit()


func LevelGenCenter(w, idx: int) -> Vector3:
	var c: Vector2i = w.gen.order[mini(idx, w.gen.order.size() - 1)]
	return Vector3(c.x * 8.0, 0.0, c.y * 8.0)


func _menu_shots() -> void:
	main.show_menu()
	await _wait(0.8)
	await _shot("m1_menu")
	main.show_help()
	await _wait(0.5)
	await _shot("m2_help")
	Net.start_solo(false)
	await _wait(1.0)
	Net.server_level_complete(12340, 9000)
	await _wait(0.8)
	await _shot("m3_shop")
	main.show_settings()
	await _wait(0.5)
	await _shot("m4_settings")
	var sp = get_tree().root.find_children("*", "Control", true, false).filter(func(c): return c.has_method("_show") and c.has_method("_build_hd"))
	if not sp.is_empty():
		sp[0]._show("tab_video")
		await _wait(0.3)
		await _shot("m4b_video")
	Net.host_game()
	Net.players[99] = {"name": "Friend", "color": 1}
	Net.players[98] = {"name": "Buddy", "color": 2}
	main.show_lobby()
	await _wait(0.8)
	await _shot("m5_lobby")
	Net.leave()
	main.show_join()
	await _wait(0.5)
	await _shot("m6_join")
	main.show_gameover({"level": 4, "earned": 45600})
	await _wait(0.5)
	await _shot("m7_gameover")
	get_tree().quit()


## Flat, empty test floor far from the level so random layouts can't block tests.
func _arena(w) -> Vector3:
	var c := Vector3(300, 0, 300)
	var sb := StaticBody3D.new()
	sb.collision_layer = 1
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(60, 1, 60)
	cs.shape = bs
	sb.add_child(cs)
	w.add_child(sb)
	sb.global_position = c - Vector3(0, 0.5, 0)
	return c + Vector3(0, 0.05, 0)


## Each monster type gets 8 s alone with a (non-hidden) player in an empty arena.
func _monsters() -> void:
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.level = 3
	Net.begin_level()
	await _wait(1.5)
	var w = main.world
	var lp = w.local_player
	for m in w.monsters.values():
		m.take_hit(99999.0)
	await _wait(1.0)
	var base: Vector3 = _arena(w)
	var MS = load("res://scripts/game/monster.gd")
	var only := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--only="):
			only = a.split("=")[1]
	for t in MS.TYPES.keys():
		if only != "" and t != only:
			continue
		lp.global_position = base + Vector3(0, 0.1, 3.0)
		Net.hp[lp.peer_id] = 100000.0
		lp.hp = 100000.0
		lp.yaw = 0.0
		lp.pitch = 0.0
		var pos := base + Vector3(0, 0.1, -3.0)
		if t == "eye":
			pos = base + Vector3(0, 3.2, -2.0)
		var id: int = w.spawn_monster(t, pos)
		var m = w.monsters[id]
		m.dormant = 0.0
		m.yaw = PI
		m.rotation.y = PI
		m.wait_t = 30.0
		var p0: Vector3 = m.global_position
		var moved := 0.0
		var states := {}
		for i in 40:
			await _wait(0.2)
			if not is_instance_valid(m):
				break
			states[m.state] = true
			moved = maxf(moved, m.global_position.distance_to(p0))
			if only != "":
				print("[DBG] t=%.1f st=%d pos=%s lp=%s cd=%.2f" % [i * 0.2, m.state, m.global_position, lp.global_position, m.cd])
			if lp.dead:
				break
		var dmg: float = 100000.0 - float(Net.hp.get(lp.peer_id, 0.0))
		print("[MON] %-10s moved=%.1f dmg=%.0f dead=%s states=%s" % [t, moved, dmg, lp.dead, states.keys()])
		if is_instance_valid(m) and m.state != 4:
			m.take_hit(99999.0)
		lp.apply_effect("carried", Vector3.ZERO, 0.0)
		await _wait(0.8)
	_finish()


func _features() -> void:
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.level = 2
	Net.begin_level()
	await _wait(1.5)
	var w = main.world
	_check(w.gen.location == 1, "level 2 is museum (loc=%d)" % w.gen.location)
	var types := {}
	for it in w.items.values():
		types[it.type] = true
	print("[TEST] item types: ", types.keys())
	_check(types.has("mask") or types.has("crown") or types.has("statue"), "museum items present")
	var lp = w.local_player
	for m in w.monsters.values():
		m.dormant = 999.0
	# crouch
	lp._set_crouch(true)
	_check(lp.crouching and lp.cap_shape.height < 1.2, "crouch shrinks capsule")
	lp._set_crouch(false)
	_check(not lp.crouching, "stand up")
	# mimic reveal
	var base: Vector3 = _arena(w)
	var mid: int = w.spawn_monster("mimic", base)
	var mm = w.monsters[mid]
	lp.global_position = base + Vector3(0, 0.1, 6.0)
	await _wait(0.6)
	_check(mm.disguised, "mimic disguised at distance")
	lp.global_position = base + Vector3(0, 0.1, 1.5)
	await _wait(0.6)
	_check(not mm.disguised and (mm.state == 2 or mm.state == 3), "mimic reveals when close (state=%d)" % mm.state)
	mm.take_hit(9999.0)
	await _wait(1.2)
	# watcher: creeps while unobserved, a direct look triggers a hunt
	var wid: int = w.spawn_monster("watcher", base + Vector3(0, 0, -4.8))
	var wm = w.monsters[wid]
	wm.dormant = 0.0
	lp.global_position = base + Vector3(0, 0.1, 2.0)
	lp.yaw = PI
	lp.pitch = 0.0
	await _wait(0.3)
	var p0: Vector3 = wm.global_position
	await _wait(1.5)
	print("[DBG] watcher p0=", p0, " now=", wm.global_position, " lp=", lp.global_position, " state=", wm.state, " base=", base)
	_check(wm.global_position.distance_to(p0) > 0.3, "watcher creeps when unobserved (%.2f)" % wm.global_position.distance_to(p0))
	var tow: Vector3 = wm.global_position - lp.global_position
	lp.yaw = atan2(-tow.x, -tow.z)
	await _wait(0.6)
	var ctr: Vector3 = wm.global_position + Vector3(0, 1.3, 0)
	print("[DBG] watcher d=%.2f dot=%.2f los=%s" % [lp.eye_pos().distance_to(ctr), lp.look_dir().dot((ctr - lp.eye_pos()).normalized()), wm._los(lp.eye_pos(), ctr)])
	_check(wm.state == 2, "watcher hunts when looked at (state=%d)" % wm.state)
	await _wait(0.4)
	_check(w.danger > 0.0, "danger level raised (%.2f)" % w.danger)
	wm.take_hit(99999.0)
	await _wait(0.5)
	lp.yaw = 0.0
	# --- hiding under furniture (REPO crawl)
	var roof := StaticBody3D.new()
	roof.collision_layer = 1
	var rcs := CollisionShape3D.new()
	var rbs := BoxShape3D.new()
	rbs.size = Vector3(1.6, 0.06, 1.0)
	rcs.shape = rbs
	roof.add_child(rcs)
	w.add_child(roof)
	var hpos: Vector3 = base + Vector3(0, 0.05, 2.0)
	lp.global_position = hpos
	roof.global_position = hpos + Vector3(0, 0.78, 0)
	lp._set_crouch(true)
	await _wait(0.4)
	_check(lp.under_cover, "crouched under a table counts as cover")
	var hid: int = w.spawn_monster("butcher", hpos + Vector3(0, 0.05, -3.5))
	var hm = w.monsters[hid]
	hm.dormant = 0.0
	hm.yaw = PI
	await _wait(2.5)
	_check(hm.state != 2 and float(hm.sus.get(lp.peer_id, 0.0)) < 0.5, "monster doesn't notice a hidden player (state=%d sus=%.2f)" % [hm.state, float(hm.sus.get(lp.peer_id, 0.0))])
	roof.queue_free()
	await _wait(0.1)
	lp._set_crouch(false)
	hm.global_position = hpos + Vector3(0, 0.05, -4.0)
	var tw: Vector3 = lp.global_position - hm.global_position
	hm.yaw = atan2(-tw.x, -tw.z)
	hm.rotation.y = hm.yaw
	hm.state = 0
	hm.wait_t = 20.0
	var t_spot := 0.0
	while not (hm.state in [2, 3, 5]) and t_spot < 3.0:
		await _wait(0.1)
		t_spot += 0.1
	_check(hm.state in [2, 3, 5] and t_spot > 0.5, "standing player is spotted after a delay (%.1fs)" % t_spot)
	hm.take_hit(99999.0)
	await _wait(0.5)
	# --- gear: inventory slots
	var pid: int = lp.peer_id
	var gid: int = w.spawn_item("w_pistol", 0, lp.eye_pos() + lp.look_dir() * 1.0, Quaternion.IDENTITY, 0)
	await _wait(0.3)
	w.gear.rpc_store(gid, 0)
	await _wait(0.3)
	_check(not w.items.has(gid) and Net.inv_of(pid)[0] != null and Net.inv_of(pid)[0]["t"] == "w_pistol", "store pistol in slot 1")
	w.gear.rpc_take(0)
	await _wait(0.5)
	_check(Net.inv_of(pid)[0] == null and lp.grabbed_id != -1, "take pistol from slot (held id=%d)" % lp.grabbed_id)
	var pistol = w.items.get(lp.grabbed_id)
	_check(pistol != null and pistol.type == "w_pistol", "held item is pistol")
	# --- pistol hitscan damages a monster and drains battery
	var bid: int = w.spawn_monster("brute", lp.global_position + Vector3(0, 0, -5.0))
	var bm = w.monsters[bid]
	bm.dormant = 999.0
	await _wait(0.4)
	var hpb: float = bm.hp
	var eye: Vector3 = lp.eye_pos()
	var aim: Vector3 = (bm.global_position + Vector3(0, 1.0, 0) - eye).normalized()
	if pistol:
		var b0: float = pistol.battery
		w.gear.rpc_use(pistol.item_id, eye, aim)
		await _wait(0.2)
		_check(bm.hp < hpb, "pistol hits monster (%.0f -> %.0f)" % [hpb, bm.hp])
		_check(pistol.battery < b0, "pistol uses battery (%.2f -> %.2f)" % [b0, pistol.battery])
	lp.force_release()
	await _wait(0.2)
	# --- melee
	var sid: int = w.spawn_item("w_sledge", 0, lp.eye_pos() + lp.look_dir() * 0.8, Quaternion.IDENTITY, 0)
	await _wait(0.2)
	bm.global_position = lp.global_position + Vector3(0, 0, -1.4)
	hpb = bm.hp
	w.gear.rpc_use(sid, lp.eye_pos(), Vector3(0, 0, -1))
	await _wait(0.2)
	_check(bm.hp < hpb and bm.stun_t > 0.0, "sledgehammer hits and stuns (%.0f -> %.0f)" % [hpb, bm.hp])
	# --- grenade
	if not is_instance_valid(bm) or bm.state == 4:
		bid = w.spawn_monster("brute", lp.global_position + Vector3(0, 0, -6.0))
		bm = w.monsters[bid]
		bm.dormant = 999.0
	bm.global_position = lp.global_position + Vector3(0, 0, -6.0)
	await _wait(0.2)
	hpb = bm.hp
	var grid: int = w.spawn_item("g_explosive", 0, bm.global_position + Vector3(0.6, 0.4, 0), Quaternion.IDENTITY, 0)
	await _wait(0.2)
	w.gear.rpc_use(grid, lp.eye_pos(), Vector3(0, 0, -1))
	await _wait(3.6)
	_check(not w.items.has(grid), "grenade exploded after fuse")
	_check(not is_instance_valid(bm) or bm.state == 4 or bm.hp < hpb, "explosion damages monster")
	# --- tranq sleeps a monster
	for om in w.monsters.values():
		if om.global_position.distance_to(lp.global_position) < 12.0:
			om.take_hit(99999.0)
	await _wait(1.0)
	var gm_id: int = w.spawn_monster("gremlin", lp.global_position + Vector3(0, 0, -4.0))
	var gm = w.monsters[gm_id]
	gm.dormant = 0.0
	var tq: int = w.spawn_item("w_tranq", 0, lp.eye_pos() + lp.look_dir() * 0.8, Quaternion.IDENTITY, 0)
	await _wait(0.3)
	var tdir: Vector3 = (gm.global_position + Vector3(0, 0.3, 0) - lp.eye_pos()).normalized()
	var tqq := PhysicsRayQueryParameters3D.create(lp.eye_pos(), lp.eye_pos() + tdir * 30.0, 1 | 4 | 8, [lp.get_rid(), w.items[tq].get_rid()])
	var th: Dictionary = lp.get_world_3d().direct_space_state.intersect_ray(tqq)
	print("[DBG] tranq ray hit: ", th.get("collider"), " gm=", gm, " d=", gm.global_position.distance_to(lp.global_position), " layer=", gm.collision_layer)
	w.gear.rpc_use(tq, lp.eye_pos(), tdir)
	await _wait(0.2)
	_check(gm.stun_t > 5.0, "tranquilizer puts monster to sleep (%.1f)" % gm.stun_t)
	# --- monsters can be grabbed and thrown
	var tgt: Vector3 = gm.global_position + Vector3(0, 1.2, 0)
	for i in 20:
		gm.grab_hold(tgt, Net.strength(pid) * 50.0 + 200.0)
		await get_tree().physics_frame
	_check(gm.state == 6, "light monster is lifted (state=%d)" % gm.state)
	gm.release_throw(Vector3(0, 2, -6))
	_check(gm.state == 7, "monster thrown")
	await _wait(1.5)
	# --- crystal feeds the charger
	var e0: float = Net.energy
	var cid: int = w.spawn_item("i_crystal", 0, lp.eye_pos() + lp.look_dir() * 0.8, Quaternion.IDENTITY, 0)
	await _wait(0.2)
	w.gear.rpc_use(cid, lp.eye_pos(), Vector3(0, 0, -1))
	await _wait(0.2)
	_check(Net.energy > e0, "energy crystal adds charges (%.1f -> %.1f)" % [e0, Net.energy])
	# --- tumble
	lp.stamina = 40.0
	lp._toggle_tumble()
	await _wait(0.3)
	_check(lp.tumbling, "tumble mode on")
	lp._toggle_tumble()
	await _wait(0.2)
	_check(not lp.tumbling, "tumble mode off")
	# --- cart value readout
	var cart = null
	for it in w.items.values():
		if it.type == "cart":
			cart = it
	_check(cart != null, "cart present in level")
	# minimap
	w.hud._toggle_map()
	await _wait(0.2)
	_check(w.visited.size() > 0, "visited cells tracked: %d" % w.visited.size())
	# ping
	w.rpc_ping(lp.global_position + Vector3(0, 0, -3))
	await _wait(0.2)
	_check(w.fx_root.get_child_count() > 0, "ping marker spawned")
	Net.level = 3
	Net.begin_level()
	await _wait(1.5)
	_check(main.world.gen.location == 2, "level 3 is lab")
	_finish()


func _loc_shots() -> void:
	Settings.force_touch = true
	Net.delete_save()
	for lvl in [2, 3]:
		Net.start_solo(true)
		Net._new_run()
		Net.level = lvl
		Net.begin_level()
		await _wait(2.0)
		var w = main.world
		for m in w.monsters.values():
			m.dormant = 999.0
		var lp = w.local_player
		var c: Vector2i = w.gen.order[mini(2, w.gen.order.size() - 1)]
		lp.global_position = w.gen.cell_center(c) + Vector3(0, 0.1, 3.0)
		lp.yaw = 0.0
		lp.pitch = -0.1
		await _wait(1.0)
		await _shot("loc%d" % lvl)
		if lvl == 3:
			var base: Vector3 = w.gen.cell_center(c)
			var mid: int = w.spawn_monster("mimic", base + Vector3(-0.8, 0.05, 0))
			var wid: int = w.spawn_monster("watcher", base + Vector3(1.0, 0, -1.0))
			w.monsters[wid].dormant = 999.0
			await _wait(0.8)
			await _shot("monsters2")
			w.monsters[mid].reveal(1)
			await _wait(0.6)
			lp.global_position = base + Vector3(0, 0.1, 3.0)
			await _wait(0.1)
			await _shot("mimic_open")
			w.hud._toggle_map()
			await _wait(0.3)
			await _shot("map")
	get_tree().quit()


func _soak() -> void:
	var t0 := Time.get_ticks_usec()
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.level = 6
	Net.difficulty = 2
	var t1 := Time.get_ticks_usec()
	Net.begin_level()
	print("[TEST] level build ms: ", (Time.get_ticks_usec() - t1) / 1000.0)
	var w = main.world
	await _wait(1.0)
	print("[TEST] rooms=", w.gen.order.size(), " items=", w.items.size(), " monsters=", w.monsters.size())
	for m in w.monsters.values():
		m.dormant = 0.0
	var lp = w.local_player
	lp.hp = 1e9
	Net.hp[1] = 1e9
	var phys := 0.0
	var proc := 0.0
	var n := 0
	var worst := 0.0
	var r := RandomNumberGenerator.new()
	for sec in 60:
		if sec % 5 == 0:
			lp.global_position = w.gen.random_point(r)
		# throw random items around to stress physics
		for it in w.items.values():
			if r.randf() < 0.02 and it.mass < 10.0:
				it.apply_central_impulse(Vector3(r.randf_range(-1, 1), 1.0, r.randf_range(-1, 1)) * it.mass * 3.0)
		for f in 10:
			await get_tree().create_timer(0.1).timeout
			var pp := Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0
			phys += pp
			proc += Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0
			worst = maxf(worst, pp)
			n += 1
	print("[TEST] avg physics ms=%.2f avg process ms=%.2f worst physics ms=%.2f" % [phys / n, proc / n, worst])
	print("[TEST] items left=", w.items.size(), " monsters=", w.monsters.size(), " mem MB=", OS.get_static_memory_usage() / 1048576.0)
	_check(phys / n < 8.0, "physics budget ok")
	_check(w.monsters.size() > 0, "monsters survive soak")
	_finish()


func _gallery() -> void:
	var ML = load("res://scripts/game/matlib.gd")
	var names := []
	var filt := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--filter="):
			filt = a.split("=")[1]
	for f in DirAccess.get_files_at("res://assets/models"):
		if not f.ends_with(".glb"):
			continue
		var ok := filt == ""
		for pre in filt.split(",", false):
			if f.begins_with(pre):
				ok = true
		if ok:
			names.append(f.get_basename())
	names.sort()
	var root := Node3D.new()
	main.add_child(root)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.12, 0.12, 0.14)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.6, 0.6, 0.7)
	env.ambient_light_energy = 0.5
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sky.sky_material = sm
	env.sky = sky
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	we.environment = env
	root.add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation = Vector3(-0.8, 0.6, 0)
	sun.light_energy = 1.2
	root.add_child(sun)
	var cols := int(ceil(sqrt(names.size() * 1.6)))
	var sp := 0.75
	var big := false
	for a in OS.get_cmdline_user_args():
		if a == "--big":
			big = true
			sp = 3.0
	for i in names.size():
		var m: Node3D = ML.model(names[i])
		if m == null:
			continue
		root.add_child(m)
		var x := (i % cols) * sp
		var z := (i / cols) * sp * 0.9
		m.position = Vector3(x, 0.0, z)
		m.rotation.y = 0.5
		var l := Label3D.new()
		l.text = names[i]
		l.font_size = 28 if not big else 64
		l.pixel_size = 0.003
		l.position = Vector3(x, -0.4 if not big else -0.3, z + 0.3)
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		root.add_child(l)
	var cam := Camera3D.new()
	root.add_child(cam)
	var w := (cols - 1) * sp
	var rows := int(ceil(names.size() / float(cols)))
	var d := (rows - 1) * sp * 0.9
	cam.position = Vector3(w / 2.0, max(w, d) * 0.32 + 0.5, d + max(w, d) * 0.3 + 0.7)
	cam.look_at(Vector3(w / 2.0, 0, d / 2.0))
	cam.current = true
	await _wait(1.0)
	await _shot("gallery")
	get_tree().quit()


## One framed 3/4 shot per model: --filter=a,b,c  -> user://por_<name>.png
func _portraits() -> void:
	var ML = load("res://scripts/game/matlib.gd")
	var names := []
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--filter="):
			names = Array(a.split("=")[1].split(",", false))
	var root := Node3D.new()
	main.add_child(root)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.16, 0.16, 0.19)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.55, 0.56, 0.62)
	env.ambient_light_energy = 0.6
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	we.environment = env
	root.add_child(we)
	var key := DirectionalLight3D.new()
	key.rotation = Vector3(-0.7, 0.5, 0)
	key.light_energy = 1.5
	key.shadow_enabled = true
	root.add_child(key)
	var rim := DirectionalLight3D.new()
	rim.rotation = Vector3(-0.3, PI + 0.6, 0)
	rim.light_energy = 0.7
	rim.light_color = Color(0.7, 0.8, 1.0)
	root.add_child(rim)
	var floor_mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(20, 20)
	floor_mi.mesh = pm
	floor_mi.material_override = ML.plain(Color(0.22, 0.22, 0.25), 0.9)
	root.add_child(floor_mi)
	var cam := Camera3D.new()
	cam.fov = 35
	root.add_child(cam)
	cam.current = true
	for n in names:
		var m: Node3D = ML.model(n)
		if m == null:
			continue
		root.add_child(m)
		await get_tree().process_frame
		var aabb := AABB()
		var first := true
		for mi in m.find_children("*", "MeshInstance3D", true, false):
			var b: AABB = mi.global_transform * mi.get_aabb()
			aabb = b if first else aabb.merge(b)
			first = false
		var c := aabb.get_center()
		var r := maxf(aabb.size.length() * 0.5, 0.1)
		floor_mi.position.y = aabb.position.y
		var dir := Vector3(0.55, 0.35, -1.0).normalized()
		cam.position = c + dir * r / tan(deg_to_rad(cam.fov * 0.5)) * 1.05
		cam.look_at(c)
		await _wait(0.4)
		await _shot("por_" + n)
		m.queue_free()
		await get_tree().process_frame
	get_tree().quit()


func _animshot() -> void:
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.level = 3
	Net.begin_level()
	await _wait(1.5)
	var w = main.world
	var lp = w.local_player
	for m in w.monsters.values():
		m.take_hit(99999.0)
	await _wait(0.8)
	var base: Vector3 = _arena(w)
	var lt := OmniLight3D.new()
	lt.omni_range = 20.0
	lt.light_energy = 3.0
	w.add_child(lt)
	lt.global_position = base + Vector3(0, 4, 2)
	lp.global_position = base + Vector3(0, 0.1, 6.0)
	lp.yaw = 0.0
	Net.hp[lp.peer_id] = 100000.0
	lp.hp = 100000.0
	var types := ["butcher", "brute", "projector", "watcher", "lurker"]
	for i in types.size():
		var id: int = w.spawn_monster(types[i], base + Vector3(-4.0 + i * 2.0, 0.1, -4.0))
		var m = w.monsters[id]
		m.dormant = 0.0
	await _wait(1.3)
	await _shot("anim1")
	await _wait(0.25)
	await _shot("anim2")
	get_tree().quit()


func _shopshot() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.money = 42000
	Net.level = 2
	Net.begin_shop({"level": 1, "extracted": 42000, "quota": 30000})
	await _wait(2.0)
	var w = main.world
	var lp = w.local_player
	var cc: Vector3 = w.gen.cell_center(Vector2i(1, 0))
	lp.global_position = cc + Vector3(-3.0, 0.1, 0)
	lp.yaw = -PI / 2
	lp.pitch = -0.05
	await _wait(1.0)
	await _shot("shop1")
	lp.global_position = w.gen.checkout_pos + Vector3(-3.5, 0.1, 1.0)
	lp.yaw = -PI / 2 + 0.25
	await _wait(0.2)
	var n := 0
	for it in w.items.values():
		if it.is_shop() and n < 3:
			it.teleport(w.gen.checkout_pos + Vector3(-0.5 + n * 0.5, 0.4, 0))
			n += 1
	await _wait(1.2)
	await _shot("shop2")
	w._try_buy()
	await _wait(2.3)
	await _shot("shop2b")
	await _wait(1.5)
	lp.global_position = w.gen.spawn_points[0]
	lp.yaw = w.gen.truck_back.signed_angle_to(Vector3.FORWARD, Vector3.UP) + PI
	await _wait(0.8)
	await _shot("shop3")
	get_tree().quit()


## Render cost probe: draw calls / objects / primitives at several spots, occlusion on vs off.
func _perf() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(3.0)
	var w = main.world
	var lp = w.local_player
	var cells: Array = w.gen.order
	var tot := {true: [0, 0, 0], false: [0, 0, 0]}
	var n := 0
	for i in mini(8, cells.size()):
		var c: Vector2i = cells[(i * 3) % cells.size()]
		lp.global_position = w.gen.cell_center(c) + Vector3(0.5, 0.1, 0.5)
		for yaw in [0.0, PI / 2, PI, -PI / 2]:
			lp.yaw = yaw
			for occ in [true, false]:
				get_viewport().use_occlusion_culling = occ
				await get_tree().process_frame
				await get_tree().process_frame
				await get_tree().process_frame
				var dc := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
				var ob := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME)
				var pr := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)
				tot[occ][0] += dc
				tot[occ][1] += ob
				tot[occ][2] += pr
			n += 1
	for occ in [true, false]:
		print("[PERF] occlusion=%s  draw_calls=%d objects=%d primitives=%d" % [occ, tot[occ][0] / n, tot[occ][1] / n, tot[occ][2] / n])
	get_viewport().use_occlusion_culling = true
	_finish()


func _cartshot() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(false)
	await _wait(2.5)
	var w = main.world
	var lp = w.local_player
	var cart = null
	for it in w.items.values():
		if it.type == "cart":
			cart = it
	var n := 0
	for it in w.items.values():
		if it.base_value > 0 and n < 2 and it.type in ["goblet", "vase", "clock", "jewelbox", "crystal", "lamp"]:
			it.teleport(cart.global_position + Vector3(-0.2 + n * 0.4, 0.4, 0))
			n += 1
	await _wait(1.5)
	var cx: Vector3 = cart.global_transform.basis.x
	lp.global_position = cart.global_position + Vector3(0, 0.1, 0) + cart.global_transform.basis.z * 2.0 - cx * 0.6
	lp.yaw = atan2(cart.global_transform.basis.z.x, cart.global_transform.basis.z.z)
	lp.pitch = -0.45
	await _wait(1.0)
	await _shot("cart1")
	lp.global_position = cart.global_position - cx * 1.9 + Vector3(0, 0.1, 0)
	lp.yaw = atan2(-cx.x, -cx.z)
	lp.pitch = -0.4
	await _wait(0.6)
	await _shot("cart2")
	_finish()


func _extrshot() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.difficulty = 1
	Net.start_solo(false)
	await _wait(2.5)
	var w = main.world
	var lp = w.local_player
	var e: Dictionary = w.extr[0]
	lp.global_position = e["pos"] + Vector3(-3.6, 0.1, 2.6)
	lp.yaw = atan2(-(e["pos"].x - lp.global_position.x), -(e["pos"].z - lp.global_position.z)) + PI
	lp.yaw = atan2(lp.global_position.x - e["pos"].x, lp.global_position.z - e["pos"].z)
	lp.pitch = -0.12
	await _wait(1.0)
	await _shot("x1_idle")
	var k := 0
	for it in w.items.values():
		if it.base_value > 0:
			it.teleport(e["pos"] + Vector3(-0.8 + (k % 4) * 0.5, 0.5 + (k / 4) * 0.4, -0.6 + (k % 3) * 0.5))
			k += 1
	await _wait(2.0)
	await _shot("x2_ready")
	w._try_extract(0)
	await _wait(3.0)
	await _shot("x3_tube")
	await _wait(1.2)
	await _shot("x4_after")
	_finish()


func _surplus() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.5)
	Net.level = 3
	Net.begin_level()
	await _wait(3.0)
	var w = main.world
	_check(w.extr.size() >= 2, "level 3 has %d points" % w.extr.size())
	var e: Dictionary = w.extr[0]
	var k := 0
	for it in w.items.values():
		if it.base_value > 0:
			it.teleport(e["pos"] + Vector3(-0.8 + (k % 4) * 0.5, 0.5 + (k / 4) * 0.4, -0.6 + (k % 3) * 0.5))
			k += 1
	await _wait(2.5)
	var v: int = e["value"]
	var goal: int = e["goal"]
	_check(v > goal, "overshoot %d > %d" % [v, goal])
	w._try_extract(0)
	await _wait(4.5)
	var bag = null
	for it in w.items.values():
		if it.type == "moneybag":
			bag = it
	_check(bag != null, "surplus money bag spawned")
	if bag:
		_check(bag.value > 0 and bag.value <= v - goal + 50, "bag value %d ~ surplus %d (items that slid off the pad don't count)" % [bag.value, v - goal])
	_check(w.level_extracted == goal, "only goal counted so far (%d)" % w.level_extracted)
	_check(w.active_extr == 1, "next point active")
	# protection: a valuable dropped onto the active pad or into the cart keeps its value
	var e2: Dictionary = w.extr[1]
	var vic = null
	for it in w.items.values():
		if it.base_value > 0 and it.type != "moneybag" and it.fragility > 0.5:
			vic = it
			break
	if vic == null:
		var vid: int = w.spawn_item("vase", 3000, e2["pos"] + Vector3(0, 2.2, 0), Quaternion.IDENTITY, 0)
		vic = w.items[vid]
	var v0: int = vic.value
	vic.teleport(e2["pos"] + Vector3(0.3, 2.2, 0.2))
	vic.linear_velocity = Vector3(0, -6.0, 0)
	await _wait(2.0)
	_check(vic.value == v0, "no damage on the pad (%d -> %d)" % [v0, vic.value])
	var cart = null
	for it in w.items.values():
		if it.type == "cart":
			cart = it
	vic.teleport(cart.global_position + Vector3(0, 1.8, 0))
	vic.linear_velocity = Vector3(0, -6.0, 0)
	await _wait(2.0)
	_check(vic.value == v0, "no damage in the cart (%d -> %d)" % [v0, vic.value])
	vic.teleport(w.gen.cell_center(w.gen.order[1]) + Vector3(0.2, 2.2, 0.3))
	vic.linear_velocity = Vector3(0, -6.0, 0)
	await _wait(2.0)
	_check(not w.items.has(vic.item_id) or vic.value < v0, "control: the same drop on a normal floor does damage")
	_finish()


## Walking into an item shoves it (body hitboxes).
func _push() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(3.0)
	var w = main.world
	var lp = w.local_player
	var it = null
	for x in w.items.values():
		if x.base_value > 0 and x.mass <= 4.0:
			it = x
			break
	var cc: Vector3 = w.gen.cell_center(w.gen.order[1])
	for x in w.items.values():
		if x != it and x.global_position.distance_to(cc) < 2.5:
			x.teleport(x.global_position + Vector3(0, 0, 0) + (x.global_position - cc).normalized() * 3.0)
	it.teleport(cc + Vector3(0, 0.4, -0.6))
	await _wait(1.0)
	var p0: Vector3 = it.global_position
	lp.global_position = it.global_position + Vector3(0, 0.1, 1.5)
	lp.global_position.y = cc.y + 0.1
	var dv: Vector3 = it.global_position - lp.global_position
	lp.yaw = atan2(-dv.x, -dv.z)
	Input.action_press("move_forward")
	for q in 8:
		await _wait(0.2)
		print("[DBG] lp=", lp.global_position, " it=", it.global_position, " vel=", lp.velocity, " coll=", lp.get_slide_collision_count())
	Input.action_release("move_forward")
	await _wait(0.5)
	var moved: float = Vector2(it.global_position.x - p0.x, it.global_position.z - p0.z).length()
	_check(moved > 0.3, "walking shoves the item (%.2f m)" % moved)
	_finish()


## Van leaves after 10 s; a robot left outside explodes.
func _depart_test() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(3.0)
	var w = main.world
	var e: Dictionary = w.extr[0]
	for it in w.items.values():
		if it.base_value > 0:
			it.teleport(e["pos"] + Vector3(randf_range(-0.8, 0.8), 0.6, randf_range(-0.8, 0.8)))
	await _wait(2.0)
	w._try_extract(0)
	await _wait(4.5)
	_check(w.all_done, "all points done")
	var lp = w.local_player
	lp.global_position = w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.1, 0)
	w._try_truck()
	await _wait(11.0)
	_check(lp.dead or main.world == null or Net.hp.get(1, 1.0) <= 0.0, "robot left outside exploded")
	_finish()


func _faces() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(false)
	await _wait(2.5)
	var w = main.world
	var lp = w.local_player
	Net.players[99] = {"name": "Buddy", "color": 1}
	w._add_player(99, 1)
	var bud = w.players[99]
	var base: Vector3 = w.gen.cell_center(w.gen.order[1])
	lp.global_position = base + Vector3(0, 0.25, 1.35)
	lp.yaw = 0.0
	lp.pitch = -0.05
	lp.flashlight.light_energy = 3.0
	bud.global_position = base + Vector3(0, 0.05, 0.0)
	bud.net_pos = bud.global_position
	bud.yaw = PI
	bud.net_yaw = PI
	bud.yaw = PI
	var shots := [0, 1, 2, 8, 16, 32]
	var names := ["neutral", "angry", "sad", "closed", "crazy", "happy"]
	for i in shots.size():
		bud.expr = shots[i]
		bud._blink_t = 99.0
		await _wait(0.6)
		await _shot("face_" + names[i])
	w.hud.expr_bar.visible = true
	lp.set_expr_bit(0)
	lp.set_expr_bit(5)
	await _wait(0.3)
	await _shot("face_hud")
	_finish()


func _arena_test() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.5)
	Net.players[99] = {"name": "Buddy", "color": 1}
	Net._init_player_run(99)
	Net._load_arena(1234, 3)
	await _wait(0.5)
	var w = main.world
	w.ready_peers[99] = true
	w._try_start()
	for q in 6:
		await _wait(0.3)
		print("[DBG] lp=", w.local_player.global_position, " dead=", w.local_player.dead, " hp=", Net.hp.get(1))
	_check(w != null and w.arena_mode, "arena loaded")
	_check(w.gen.tiles.size() == 5, "5 rings of plates (%d)" % w.gen.tiles.size())
	var weapons := 0
	for it in w.items.values():
		if it.type.begins_with("w_") or it.type.begins_with("g_") or it.type.begins_with("m_"):
			weapons += 1
	_check(weapons >= 6, "weapons scattered: %d" % weapons)
	var lp = w.local_player
	lp.global_position = Vector3(0, 0.3, 1.8)
	lp.yaw = PI
	lp.pitch = -0.3
	for q in 5:
		await _wait(0.15)
		print("[DBG2] lp=", lp.global_position, " dead=", lp.dead, " hp=", Net.hp.get(1), " vel=", lp.velocity)
	await _shot("arena1")
	w.arena_t = 16.0
	await _wait(0.8)
	await _shot("arena2")
	await _wait(2.5)
	_check(not w.gen.tiles.has(5), "outer ring dropped")
	_check(w.players.has(99) and not w.players[99].dead, "second robot alive")
	w.players[99].global_position = Vector3(0, -6.0, 0)
	w.players[99].net_pos = Vector3(0, -6.0, 0)
	await _wait(0.6)
	_check(w.players[99].dead, "falling into the pit kills")
	await _wait(1.0)
	_check(Settings.crown_name == Settings.player_name, "last robot standing gets the crown (%s)" % Settings.crown_name)
	await _shot("arena3")
	Settings.crown_name = ""
	Settings.save_cfg()
	_finish()


func _loadshot() -> void:
	main._boot_loading()
	await _wait(0.6)
	await _shot("load1")
	await _wait(1.0)
	await _shot("load2")
	await _wait(2.5)
	await _shot("load3")
	_finish()
