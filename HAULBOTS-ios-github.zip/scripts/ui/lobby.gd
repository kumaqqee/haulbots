extends Control
## Co-op lobby: panel on the left, the team of robots by the van on the right.

const UI = preload("res://scripts/ui/ui.gd")

var main: Node
var list: VBoxContainer
var title: Label
var start_btn: Button


func _ready() -> void:
	UI.full(self)
	var margin := MarginContainer.new()
	UI.full(margin)
	margin.add_theme_constant_override("margin_left", 48)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	add_child(margin)
	var pc := PanelContainer.new()
	pc.custom_minimum_size.x = 600
	pc.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	pc.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	margin.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	pc.add_child(vb)
	vb.add_theme_constant_override("separation", 8)
	var t := UI.title(Settings.t("lobby"), 44)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	vb.add_child(t)
	if Net.is_host():
		var ips := Net.local_ips()
		var ipc := PanelContainer.new()
		ipc.theme_type_variation = "Card"
		var ipl := UI.label(Settings.t("your_ip") % (", ".join(ips) if ips.size() > 0 else "?"), 24, UI.GOOD, HORIZONTAL_ALIGNMENT_LEFT)
		ipc.add_child(ipl)
		vb.add_child(ipc)
	vb.add_child(UI.label(Settings.t("difficulty") + ": " + Settings.t("diff_%d" % (Settings.difficulty if Net.is_host() else Net.difficulty)), 20, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	title = UI.label("", 24, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	vb.add_child(title)
	list = VBoxContainer.new()
	list.add_theme_constant_override("separation", 8)
	vb.add_child(list)
	vb.add_child(UI.sep())
	if Net.is_host():
		start_btn = UI.button(Settings.t("start"), func(): Net.start_run(), 540, 66, true)
		vb.add_child(start_btn)
	else:
		vb.add_child(UI.label(Settings.t("waiting_host"), 22, UI.DIM))
	vb.add_child(UI.button(Settings.t("leave"), _leave, 540))
	Net.players_changed.connect(_refresh)
	_refresh()


func _refresh() -> void:
	for c in list.get_children():
		c.queue_free()
	title.text = Settings.t("players_n") % Net.players.size()
	var ids := Net.players.keys()
	ids.sort()
	for id in ids:
		var p: Dictionary = Net.players[id]
		var col: Color = Net.COLORS[int(p["color"]) % 4]
		var card := PanelContainer.new()
		card.theme_type_variation = "Card"
		var hb := HBoxContainer.new()
		card.add_child(hb)
		var dot := ColorRect.new()
		dot.color = col
		dot.custom_minimum_size = Vector2(14, 34)
		hb.add_child(dot)
		dot.custom_minimum_size = Vector2(10, 26)
		var nl := UI.label(str(p["name"]), 23, col.lightened(0.2), HORIZONTAL_ALIGNMENT_LEFT)
		nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(nl)
		if id == 1:
			var hl := UI.label("★ HOST", 18, UI.ACCENT2)
			hl.autowrap_mode = TextServer.AUTOWRAP_OFF
			hl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			hb.add_child(hl)
		list.add_child(card)
	for i in range(Net.players.size(), 4):
		var empty := PanelContainer.new()
		empty.theme_type_variation = "Card"
		empty.modulate.a = 0.4
		empty.add_child(UI.label("— " + Settings.t("slot_empty") + " —", 17, UI.DIM))
		list.add_child(empty)
	if main and main.menu_bg:
		var arr := []
		for id in ids:
			arr.append(Net.players[id])
		main.menu_bg.set_players(arr)


func _leave() -> void:
	Net.leave()
	main.show_menu()


func _exit_tree() -> void:
	if Net.players_changed.is_connected(_refresh):
		Net.players_changed.disconnect(_refresh)
