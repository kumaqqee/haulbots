extends RefCounted
## Theme and widget helpers for code-built UI.

const ACCENT := Color(1.0, 0.55, 0.1)
const ACCENT2 := Color(1.0, 0.78, 0.3)
const BG := Color(0.07, 0.07, 0.09)
const PANEL_BG := Color(0.055, 0.06, 0.075, 0.93)
const TEXT := Color(0.94, 0.92, 0.88)
const DIM := Color(0.62, 0.62, 0.66)
const GOOD := Color(0.35, 0.95, 0.5)
const BAD := Color(1.0, 0.32, 0.25)

static var _fonts := {}


static func font(n: String) -> Font:
	if _fonts.has(n):
		return _fonts[n]
	var p := "res://assets/fonts/%s.ttf" % n
	var f: Font = load(p) if ResourceLoader.exists(p) else ThemeDB.fallback_font
	_fonts[n] = f
	return f


static func title_font() -> Font:
	return font("RussoOne")


static func sb(bg: Color, border: Color = Color(0, 0, 0, 0), bw := 0, radius := 10, margin := Vector4(18, 10, 18, 10)) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.content_margin_left = margin.x
	s.content_margin_top = margin.y
	s.content_margin_right = margin.z
	s.content_margin_bottom = margin.w
	s.anti_aliasing = true
	return s


static func _btn_sb(bg: Color, border: Color, bottom: Color) -> StyleBoxFlat:
	var s := sb(bg, border, 2, 12, Vector4(20, 10, 20, 12))
	s.border_width_bottom = 5
	s.border_color = border
	# darker lip at the bottom gives a pressable, chunky feel
	s.shadow_color = Color(0, 0, 0, 0.35)
	s.shadow_size = 4
	s.shadow_offset = Vector2(0, 3)
	if bottom.a > 0.0:
		s.border_color = bottom
		s.border_width_left = 2
		s.border_width_right = 2
		s.border_width_top = 2
	return s


static func _menu_sb(bg: Color, bar: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = bar
	s.border_width_left = 7
	s.content_margin_left = 26
	s.content_margin_right = 20
	s.content_margin_top = 4
	s.content_margin_bottom = 4
	s.skew = Vector2(0.18, 0)
	s.set_corner_radius_all(3)
	return s


static func make_theme() -> Theme:
	var th := Theme.new()
	th.default_font = font("Rubik-Medium")
	th.default_font_size = 24
	# buttons
	th.set_stylebox("normal", "Button", _btn_sb(Color(0.13, 0.135, 0.16, 0.96), Color(0.3, 0.3, 0.36), Color(0.05, 0.05, 0.06)))
	th.set_stylebox("hover", "Button", _btn_sb(Color(0.2, 0.15, 0.1, 0.98), ACCENT, ACCENT.darkened(0.45)))
	var pr := _btn_sb(ACCENT.darkened(0.1), ACCENT.lightened(0.25), ACCENT.darkened(0.5))
	pr.border_width_bottom = 2
	pr.content_margin_top = 13
	pr.content_margin_bottom = 9
	th.set_stylebox("pressed", "Button", pr)
	th.set_stylebox("disabled", "Button", _btn_sb(Color(0.08, 0.08, 0.09, 0.7), Color(0.18, 0.18, 0.2), Color(0, 0, 0, 0)))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_font("font", "Button", title_font())
	th.set_color("font_color", "Button", TEXT)
	th.set_color("font_hover_color", "Button", ACCENT2)
	th.set_color("font_pressed_color", "Button", Color(0.06, 0.04, 0.02))
	th.set_color("font_disabled_color", "Button", Color(0.45, 0.45, 0.45))
	# accent (primary) button
	th.set_type_variation("Primary", "Button")
	th.set_stylebox("normal", "Primary", _btn_sb(ACCENT.darkened(0.05), ACCENT.lightened(0.2), ACCENT.darkened(0.5)))
	th.set_stylebox("hover", "Primary", _btn_sb(ACCENT.lightened(0.12), ACCENT2, ACCENT.darkened(0.4)))
	th.set_stylebox("pressed", "Primary", pr)
	th.set_color("font_color", "Primary", Color(0.08, 0.05, 0.02))
	th.set_color("font_hover_color", "Primary", Color(0.05, 0.03, 0.0))
	# segmented tab buttons
	th.set_type_variation("Tab", "Button")
	th.set_stylebox("normal", "Tab", sb(Color(0.1, 0.1, 0.12, 0.9), Color(0.25, 0.25, 0.3), 2, 10, Vector4(16, 8, 16, 8)))
	th.set_stylebox("hover", "Tab", sb(Color(0.16, 0.13, 0.1, 0.95), ACCENT.darkened(0.2), 2, 10, Vector4(16, 8, 16, 8)))
	th.set_stylebox("pressed", "Tab", sb(ACCENT.darkened(0.1), ACCENT.lightened(0.2), 2, 10, Vector4(16, 8, 16, 8)))
	th.set_stylebox("focus", "Tab", StyleBoxEmpty.new())
	th.set_color("font_pressed_color", "Tab", Color(0.08, 0.05, 0.02))
	th.set_color("font_hover_pressed_color", "Tab", Color(0.08, 0.05, 0.02))
	# REPO-style text menu entries
	th.set_type_variation("MenuButton2", "Button")
	th.set_stylebox("normal", "MenuButton2", _menu_sb(Color(0, 0, 0, 0.0), Color(0, 0, 0, 0)))
	th.set_stylebox("hover", "MenuButton2", _menu_sb(Color(1.0, 0.55, 0.1, 0.16), ACCENT))
	th.set_stylebox("pressed", "MenuButton2", _menu_sb(Color(1.0, 0.55, 0.1, 0.35), ACCENT.lightened(0.3)))
	th.set_stylebox("focus", "MenuButton2", StyleBoxEmpty.new())
	th.set_color("font_color", "MenuButton2", Color(0.93, 0.9, 0.85))
	th.set_color("font_hover_color", "MenuButton2", Color(1.0, 0.72, 0.28))
	th.set_color("font_pressed_color", "MenuButton2", Color(1, 1, 1))
	th.set_color("font_outline_color", "MenuButton2", Color(0, 0, 0, 0.85))
	th.set_constant("outline_size", "MenuButton2", 8)
	# panels
	var pnl := sb(PANEL_BG, Color(1, 1, 1, 0.07), 1, 16, Vector4(28, 24, 28, 24))
	pnl.border_width_top = 4
	pnl.border_color = Color(ACCENT, 0.85)
	pnl.shadow_color = Color(0, 0, 0, 0.5)
	pnl.shadow_size = 18
	th.set_stylebox("panel", "PanelContainer", pnl)
	th.set_stylebox("panel", "Panel", pnl)
	th.set_type_variation("Card", "PanelContainer")
	th.set_stylebox("panel", "Card", sb(Color(1, 1, 1, 0.045), Color(1, 1, 1, 0.08), 1, 12, Vector4(18, 12, 18, 12)))
	th.set_type_variation("Pill", "PanelContainer")
	th.set_stylebox("panel", "Pill", sb(Color(0.03, 0.035, 0.045, 0.72), Color(1, 1, 1, 0.1), 1, 22, Vector4(20, 6, 20, 8)))
	# inputs
	th.set_stylebox("normal", "LineEdit", sb(Color(0.03, 0.03, 0.04, 0.95), Color(0.3, 0.3, 0.36), 2, 10, Vector4(14, 8, 14, 8)))
	th.set_stylebox("focus", "LineEdit", sb(Color(0.03, 0.03, 0.04, 0.95), ACCENT, 2, 10, Vector4(14, 8, 14, 8)))
	th.set_color("caret_color", "LineEdit", ACCENT)
	th.set_color("font_color", "Label", TEXT)
	th.set_color("font_outline_color", "Label", Color(0, 0, 0, 0.7))
	th.set_constant("outline_size", "Label", 4)
	th.set_constant("separation", "VBoxContainer", 12)
	th.set_constant("separation", "HBoxContainer", 12)
	# sliders
	var slider := sb(Color(0.2, 0.2, 0.24), Color(0, 0, 0, 0), 0, 6, Vector4(0, 5, 0, 5))
	th.set_stylebox("slider", "HSlider", slider)
	var area := slider.duplicate()
	area.bg_color = ACCENT
	th.set_stylebox("grabber_area", "HSlider", area)
	th.set_stylebox("grabber_area_highlight", "HSlider", area)
	var gi := _knob_tex(40, Color(1, 1, 1), ACCENT)
	th.set_icon("grabber", "HSlider", gi)
	th.set_icon("grabber_highlight", "HSlider", _knob_tex(44, Color(1, 1, 1), ACCENT2))
	# toggles
	th.set_icon("checked", "CheckButton", _pill_tex(true))
	th.set_icon("unchecked", "CheckButton", _pill_tex(false))
	th.set_icon("checked_disabled", "CheckButton", _pill_tex(true))
	th.set_icon("unchecked_disabled", "CheckButton", _pill_tex(false))
	for st in ["normal", "hover", "pressed", "hover_pressed", "focus"]:
		th.set_stylebox(st, "CheckButton", StyleBoxEmpty.new())
	# option buttons
	th.set_stylebox("normal", "OptionButton", sb(Color(0.12, 0.12, 0.15, 0.96), Color(0.3, 0.3, 0.36), 2, 10, Vector4(16, 8, 36, 8)))
	th.set_stylebox("hover", "OptionButton", sb(Color(0.18, 0.14, 0.1, 0.98), ACCENT, 2, 10, Vector4(16, 8, 36, 8)))
	th.set_stylebox("pressed", "OptionButton", sb(Color(0.18, 0.14, 0.1, 0.98), ACCENT, 2, 10, Vector4(16, 8, 36, 8)))
	th.set_stylebox("focus", "OptionButton", StyleBoxEmpty.new())
	th.set_font("font", "OptionButton", font("Rubik-Medium"))
	# progress bars
	var bar_bg := sb(Color(0, 0, 0, 0.55), Color(1, 1, 1, 0.12), 1, 6, Vector4(0, 0, 0, 0))
	th.set_stylebox("background", "ProgressBar", bar_bg)
	var bar_fg := sb(Color(0.3, 0.9, 0.4), Color(0, 0, 0, 0), 0, 6, Vector4(0, 0, 0, 0))
	th.set_stylebox("fill", "ProgressBar", bar_fg)
	th.set_stylebox("panel", "PopupMenu", sb(Color(0.08, 0.08, 0.1, 0.98), ACCENT, 2, 12, Vector4(10, 10, 10, 10)))
	th.set_font_size("font_size", "PopupMenu", 26)
	th.set_constant("v_separation", "PopupMenu", 14)
	th.set_stylebox("hover", "PopupMenu", sb(Color(ACCENT, 0.3), Color(0, 0, 0, 0), 0, 8))
	# scrollbars: slim
	var sgrab := sb(Color(1, 1, 1, 0.25), Color(0, 0, 0, 0), 0, 4, Vector4(4, 4, 4, 4))
	th.set_stylebox("grabber", "VScrollBar", sgrab)
	th.set_stylebox("grabber_highlight", "VScrollBar", sb(Color(ACCENT, 0.7), Color(0, 0, 0, 0), 0, 4, Vector4(4, 4, 4, 4)))
	th.set_stylebox("grabber_pressed", "VScrollBar", sb(ACCENT, Color(0, 0, 0, 0), 0, 4, Vector4(4, 4, 4, 4)))
	th.set_stylebox("scroll", "VScrollBar", sb(Color(1, 1, 1, 0.04), Color(0, 0, 0, 0), 0, 4, Vector4(4, 0, 4, 0)))
	return th


static func menu_entry(text: String, cb: Callable, size := 40) -> Button:
	var b := Button.new()
	b.text = text
	b.theme_type_variation = "MenuButton2"
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_size_override("font_size", size)
	b.custom_minimum_size = Vector2(480, size + 16)
	b.focus_mode = Control.FOCUS_NONE
	b.pivot_offset = Vector2(0, (size + 16) / 2.0)
	b.mouse_entered.connect(func():
		Sfx.play("ui", null, -14.0, 1.4)
		b.create_tween().tween_property(b, "position:x", 14.0, 0.12))
	b.mouse_exited.connect(func(): b.create_tween().tween_property(b, "position:x", 0.0, 0.12))
	b.pressed.connect(func(): Sfx.play("ui"))
	b.pressed.connect(cb)
	return b


static func title(text: String, size := 48, color := ACCENT) -> Label:
	var l := label(text, size, color)
	l.add_theme_font_override("font", title_font())
	l.add_theme_color_override("font_outline_color", Color(0.12, 0.04, 0.0))
	l.add_theme_constant_override("outline_size", maxi(8, size / 7))
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.5))
	l.add_theme_constant_override("shadow_offset_y", maxi(2, size / 16))
	return l


static func _circle_tex(sz: int, c: Color) -> ImageTexture:
	var img := Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var r := sz / 2.0
	for y in sz:
		for x in sz:
			var d := Vector2(x + 0.5 - r, y + 0.5 - r).length()
			var a := clampf(r - d, 0.0, 1.0)
			img.set_pixel(x, y, Color(c.r, c.g, c.b, a))
	return ImageTexture.create_from_image(img)


static func _knob_tex(sz: int, fill: Color, ring: Color) -> ImageTexture:
	var img := Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var r := sz / 2.0
	for y in sz:
		for x in sz:
			var d := Vector2(x + 0.5 - r, y + 0.5 - r).length()
			var a := clampf(r - 1.0 - d, 0.0, 1.0)
			var c := ring if d > r - 6.0 else fill
			var sh := clampf((r - d) / 3.0, 0.0, 1.0)
			img.set_pixel(x, y, Color(c.r, c.g, c.b, a * sh + (1.0 - sh) * a * 0.0))
	return ImageTexture.create_from_image(img)


static func _pill_tex(on: bool) -> ImageTexture:
	var w := 76
	var h := 40
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	var track := ACCENT if on else Color(0.25, 0.25, 0.3)
	var kx := w - h / 2.0 if on else h / 2.0
	for y in h:
		for x in w:
			var p := Vector2(x + 0.5, y + 0.5)
			# capsule distance
			var cx := clampf(p.x, h / 2.0, w - h / 2.0)
			var d := p.distance_to(Vector2(cx, h / 2.0))
			var a := clampf(h / 2.0 - d, 0.0, 1.0)
			var col := track
			var kd := p.distance_to(Vector2(kx, h / 2.0))
			if kd < h / 2.0 - 4.0:
				col = Color(1, 1, 1)
				a = clampf(h / 2.0 - 4.0 - kd, 0.0, 1.0) * 1.0 + a * (1.0 - clampf(h / 2.0 - 4.0 - kd, 0.0, 1.0))
			img.set_pixel(x, y, Color(col.r, col.g, col.b, a))
	return ImageTexture.create_from_image(img)


static func full(c: Control) -> Control:
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	return c


static func backdrop() -> Control:
	var tr := TextureRect.new()
	var gt := GradientTexture2D.new()
	var g := Gradient.new()
	g.set_color(0, Color(0.16, 0.08, 0.04, 0.45))
	g.set_color(1, Color(0.02, 0.02, 0.03, 0.88))
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.35)
	gt.fill_to = Vector2(1.1, 1.1)
	gt.width = 256
	gt.height = 256
	tr.texture = gt
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return full(tr)


static func dim(parent: Control, a := 0.6) -> ColorRect:
	var d := ColorRect.new()
	full(d)
	d.color = Color(0, 0, 0, a)
	var m := ShaderMaterial.new()
	m.shader = load("res://assets/shaders/blur_dim.gdshader")
	m.set_shader_parameter("dim", a * 0.85)
	d.material = m
	parent.add_child(d)
	d.modulate.a = 0.0
	d.create_tween().tween_property(d, "modulate:a", 1.0, 0.2)
	return d


static func label(text: String, size := 24, color := TEXT, align := HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = align
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l


static func button(text: String, cb: Callable, min_w := 420, min_h := 64, primary := false) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(min_w, min_h)
	b.add_theme_font_size_override("font_size", 26)
	b.focus_mode = Control.FOCUS_NONE
	if primary:
		b.theme_type_variation = "Primary"
	b.pressed.connect(func(): Sfx.play("ui"))
	b.pressed.connect(cb)
	return b


## Centered floating panel; returns the inner VBox.
static func panel_column(parent: Control, width := 620, max_h := 0) -> VBoxContainer:
	var cc := CenterContainer.new()
	full(cc)
	parent.add_child(cc)
	var pc := PanelContainer.new()
	pc.custom_minimum_size.x = width
	cc.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	if max_h > 0:
		var sc := ScrollContainer.new()
		sc.custom_minimum_size = Vector2(width - 56, max_h)
		sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		pc.add_child(sc)
		vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		sc.add_child(vb)
	else:
		pc.add_child(vb)
	# pop-in animation
	pc.modulate.a = 0.0
	pc.scale = Vector2(0.96, 0.96)
	pc.resized.connect(func(): pc.pivot_offset = pc.size / 2.0)
	var tw := pc.create_tween().set_parallel(true)
	tw.tween_property(pc, "modulate:a", 1.0, 0.18)
	tw.tween_property(pc, "scale", Vector2.ONE, 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	return vb


static func centered_column(parent: Control, width := 560) -> VBoxContainer:
	var cc := CenterContainer.new()
	full(cc)
	parent.add_child(cc)
	var vb := VBoxContainer.new()
	vb.custom_minimum_size.x = width
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	cc.add_child(vb)
	return vb


static func scroll_column(parent: Control, width := 760) -> VBoxContainer:
	return panel_column(parent, width, 560)


static func sep() -> Control:
	var c := ColorRect.new()
	c.color = Color(1, 1, 1, 0.08)
	c.custom_minimum_size.y = 2
	return c
