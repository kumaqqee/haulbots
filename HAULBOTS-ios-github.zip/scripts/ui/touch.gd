extends Control
## Multi-touch controls: floating joystick (left), look area (right), icon action buttons.
## Size and opacity follow Settings.btn_scale / Settings.btn_alpha.

const Icons = preload("res://scripts/ui/icons.gd")
const UI = preload("res://scripts/ui/ui.gd")

var move_vec := Vector2.ZERO
var sprint_on := false
var crouch_on := false
var tumble_on := false
var grabbing := false
var _look_acc := Vector2.ZERO
var _joy_idx := -1
var _joy_center := Vector2.ZERO
var _joy_pos := Vector2.ZERO
var _joy_home := Vector2.ZERO
var _look_idx := -1
var _look_last := Vector2.ZERO
var _u := 1.0
var buttons := {}
var _btn_touch := {}
var _pressed := {}
var _press_anim := {}

const ICON := {"grab": "grab", "jump": "jump", "throw": "throw", "use": "use", "pull": "up", "push": "down",
	"sprint": "run", "crouch": "crouch", "ping": "ping", "tumble": "tumble"}


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	resized.connect(_layout)
	Settings.changed.connect(_layout)
	_layout()


func _exit_tree() -> void:
	if Settings.changed.is_connected(_layout):
		Settings.changed.disconnect(_layout)


func _layout() -> void:
	var s := size
	if s.x < 10:
		s = get_viewport_rect().size
	_u = s.y / 720.0
	var u := _u
	var k := Settings.btn_scale
	buttons = {
		"grab": {"pos": Vector2(s.x - 150 * u, s.y - 175 * u), "r": 80 * u * k, "label": "btn_grab"},
		"jump": {"pos": Vector2(s.x - 325 * u, s.y - 95 * u), "r": 52 * u * k, "label": "btn_jump"},
		"throw": {"pos": Vector2(s.x - 320 * u, s.y - 255 * u), "r": 50 * u * k, "label": "btn_throw"},
		"use": {"pos": Vector2(s.x - 112 * u, s.y - 365 * u), "r": 50 * u * k, "label": "btn_use"},
		"pull": {"pos": Vector2(s.x - 455 * u, s.y - 262 * u), "r": 40 * u * k, "label": ""},
		"push": {"pos": Vector2(s.x - 455 * u, s.y - 160 * u), "r": 40 * u * k, "label": ""},
		"ping": {"pos": Vector2(s.x - 112 * u, s.y - 478 * u), "r": 40 * u * k, "label": "btn_ping"},
		"sprint": {"pos": Vector2(110 * u, s.y - 345 * u), "r": 48 * u * k, "label": "btn_run"},
		"crouch": {"pos": Vector2(110 * u, s.y - 462 * u), "r": 44 * u * k, "label": "btn_crouch"},
		"tumble": {"pos": Vector2(228 * u, s.y - 408 * u), "r": 40 * u * k, "label": "btn_tumble"},
	}
	# invisible hit areas over the HUD inventory slots (bottom centre, drawn by the HUD)
	var sw := 104.0 * 3 + 24.0
	for i in 3:
		var cx := s.x / 2.0 - sw / 2.0 + 52.0 + i * 116.0
		buttons["slot%d" % i] = {"pos": Vector2(cx, s.y - 12 - 39), "r": 48.0, "label": "", "hidden": true}
	for b in buttons:
		buttons[b]["down"] = false
	_joy_home = Vector2(200 * u, s.y - 180 * u)
	if _joy_idx == -1:
		_joy_center = _joy_home
		_joy_pos = _joy_home
	queue_redraw()


func _visible_btn(k: String) -> bool:
	if k in ["throw", "pull", "push"]:
		return grabbing
	return true


func _hit_button(p: Vector2) -> String:
	var best := ""
	var bd := 1e9
	for k in buttons:
		if not _visible_btn(k):
			continue
		var b: Dictionary = buttons[k]
		var d := p.distance_to(b["pos"])
		if d <= b["r"] * 1.18 and d < bd:
			bd = d
			best = k
	return best


func take(k: String) -> bool:
	if _pressed.get(k, false):
		_pressed[k] = false
		return true
	return false


func held(k: String) -> bool:
	return buttons.has(k) and buttons[k]["down"]


func consume_look() -> Vector2:
	var v := _look_acc
	_look_acc = Vector2.ZERO
	return v


func reset() -> void:
	_joy_idx = -1
	_look_idx = -1
	move_vec = Vector2.ZERO
	_btn_touch.clear()
	_pressed.clear()
	for k in buttons:
		buttons[k]["down"] = false


func _process(delta: float) -> void:
	var any := false
	for k in _press_anim.keys():
		_press_anim[k] = maxf(0.0, _press_anim[k] - delta * 4.0)
		any = true
		if _press_anim[k] <= 0.0:
			_press_anim.erase(k)
	if any:
		queue_redraw()


func _input(e: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if e is InputEventScreenTouch:
		if e.pressed:
			var b := _hit_button(e.position)
			if b != "":
				_btn_touch[e.index] = b
				buttons[b]["down"] = true
				_pressed[b] = true
				_press_anim[b] = 1.0
				if Settings.vibration:
					Sfx.vibrate(12)
				if b == "sprint":
					sprint_on = not sprint_on
			elif e.position.x < size.x * 0.42 and e.position.y > size.y * 0.25 and _joy_idx == -1:
				_joy_idx = e.index
				_joy_center = e.position
				_joy_pos = e.position
				move_vec = Vector2.ZERO
			elif _look_idx == -1 and e.position.y > 70 * _u:
				_look_idx = e.index
				_look_last = e.position
		else:
			if _btn_touch.has(e.index):
				buttons[_btn_touch[e.index]]["down"] = false
				_btn_touch.erase(e.index)
			if e.index == _joy_idx:
				_joy_idx = -1
				move_vec = Vector2.ZERO
				_joy_center = _joy_home
				_joy_pos = _joy_home
			if e.index == _look_idx:
				_look_idx = -1
		queue_redraw()
	elif e is InputEventScreenDrag:
		if e.index == _joy_idx:
			_joy_pos = e.position
			var r := 105.0 * _u
			var d: Vector2 = _joy_pos - _joy_center
			if d.length() > r:
				_joy_center += d.normalized() * (d.length() - r)
				d = d.normalized() * r
			move_vec = d / r
			queue_redraw()
		elif e.index == _look_idx:
			_look_acc += e.position - _look_last
			_look_last = e.position


func set_crouch(c: bool) -> void:
	if c != crouch_on:
		crouch_on = c
		queue_redraw()


func set_tumble(t: bool) -> void:
	if t != tumble_on:
		tumble_on = t
		queue_redraw()


func set_grabbing(g: bool) -> void:
	if g != grabbing:
		grabbing = g
		queue_redraw()


func _draw() -> void:
	var A := Settings.btn_alpha
	var font := UI.font("Rubik-Medium")
	# joystick: soft base, ring with tick marks, glossy knob
	var r := 105.0 * _u
	var active := _joy_idx != -1
	draw_circle(_joy_center, r, Color(0, 0, 0, 0.18 * A + (0.1 if active else 0.0)))
	draw_arc(_joy_center, r, 0, TAU, 64, Color(1, 1, 1, 0.35 * A), 3.0 * _u, true)
	for i in 4:
		var a := i * PI / 2.0
		var d := Vector2(cos(a), sin(a))
		draw_line(_joy_center + d * (r - 14 * _u), _joy_center + d * (r - 4 * _u), Color(1, 1, 1, 0.3 * A), 3.0 * _u)
	var knob := _joy_center + move_vec * r
	draw_circle(knob, 44 * _u, Color(0, 0, 0, 0.25 * A))
	draw_circle(knob, 40 * _u, Color(1, 1, 1, 0.3 * A + (0.15 if active else 0.0)))
	draw_arc(knob, 40 * _u, 0, TAU, 40, Color(1, 1, 1, 0.6 * A), 2.0 * _u, true)
	for k in buttons:
		if not _visible_btn(k) or buttons[k].get("hidden", false):
			continue
		var b: Dictionary = buttons[k]
		var rr: float = b["r"]
		var pa: float = _press_anim.get(k, 0.0)
		var col := Color(0.04, 0.045, 0.06, 0.42 * A)
		var ring := Color(1, 1, 1, 0.55 * A)
		var ic := Color(1, 1, 1, 0.95 * maxf(A, 0.55))
		var on := false
		if k == "grab":
			ring = Color(UI.ACCENT, 0.95 * maxf(A, 0.6))
			on = grabbing
		elif k == "sprint":
			on = sprint_on
		elif k == "crouch":
			on = crouch_on
		elif k == "tumble":
			on = tumble_on
		if on:
			col = Color(UI.ACCENT, 0.5 * maxf(A, 0.6))
			ring = Color(UI.ACCENT2, maxf(A, 0.7))
		if b["down"]:
			col = Color(col.r + 0.15, col.g + 0.1, col.b + 0.05, col.a + 0.25)
			rr *= 0.94
		# shadow, body, ring, press ripple
		draw_circle(b["pos"] + Vector2(0, 3 * _u), rr, Color(0, 0, 0, 0.25 * A))
		draw_circle(b["pos"], rr, col)
		draw_arc(b["pos"], rr - 1.5 * _u, 0, TAU, 48, ring, 3.0 * _u, true)
		draw_arc(b["pos"], rr - 7 * _u, PI * 1.1, PI * 1.9, 16, Color(1, 1, 1, 0.12 * A), 3.0 * _u, true)
		if pa > 0.0:
			draw_arc(b["pos"], rr + (1.0 - pa) * 18 * _u, 0, TAU, 48, Color(UI.ACCENT2, pa * 0.8), 3.0 * _u, true)
		var icon: String = ICON.get(k, "")
		if k == "grab" and grabbing:
			icon = "drop"
		var has_label: bool = str(b["label"]) != ""
		var isz := rr * (0.78 if not has_label else 0.62)
		var ipos: Vector2 = b["pos"] + Vector2(0, -rr * 0.12 if has_label else 0.0)
		Icons.draw(self, icon, ipos, isz, ic)
		if has_label:
			var text := Settings.t(b["label"])
			if k == "grab" and grabbing:
				text = Settings.t("btn_drop")
			var fs := int(clampf(rr * 0.27, 11.0, 20.0))
			var w := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
			draw_string(font, b["pos"] + Vector2(-w / 2.0, rr * 0.62), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.85 * maxf(A, 0.55)))
