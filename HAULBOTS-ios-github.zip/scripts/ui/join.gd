extends Control
## Join screen: LAN discovery list + manual IP.

const UI = preload("res://scripts/ui/ui.gd")

var main: Node
var list: VBoxContainer
var status: Label
var ip_edit: LineEdit


func _ready() -> void:
	UI.full(self)
	add_child(UI.backdrop())
	var vb := UI.panel_column(self, 760)
	vb.add_child(UI.title(Settings.t("join"), 44))
	status = UI.label(Settings.t("searching"), 22, UI.DIM)
	vb.add_child(status)
	list = VBoxContainer.new()
	vb.add_child(list)
	var hb := HBoxContainer.new()
	ip_edit = LineEdit.new()
	ip_edit.placeholder_text = Settings.t("ip_hint")
	ip_edit.text = Settings.last_ip
	ip_edit.custom_minimum_size = Vector2(400, 60)
	ip_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ip_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER_DECIMAL
	hb.add_child(ip_edit)
	hb.add_child(UI.button(Settings.t("connect"), _manual, 220, 60, true))
	vb.add_child(hb)
	var back := UI.button(Settings.t("back"), _back)
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(back)
	Net.hosts_changed.connect(_refresh)
	Net.start_listen()
	_refresh()


func _refresh() -> void:
	for c in list.get_children():
		c.queue_free()
	if Net.found_hosts.is_empty():
		status.text = Settings.t("searching") + "\n" + Settings.t("no_games")
		return
	status.text = Settings.t("searching")
	for ip in Net.found_hosts:
		var h: Dictionary = Net.found_hosts[ip]
		list.add_child(UI.button("▶  %s   (%d/4)   %s" % [h["name"], h["count"], ip], _join.bind(ip), 680, 64, true))


func _join(ip: String) -> void:
	Settings.last_ip = ip
	Settings.save_cfg()
	Net.stop_listen()
	main.show_connecting()
	Net.join_game(ip)


func _manual() -> void:
	var ip := ip_edit.text.strip_edges()
	if ip.is_valid_ip_address():
		_join(ip)
	else:
		main.toast(Settings.t("conn_failed"))


func _back() -> void:
	Net.stop_listen()
	main.show_menu()


func _exit_tree() -> void:
	if Net.hosts_changed.is_connected(_refresh):
		Net.hosts_changed.disconnect(_refresh)
