extends Control
## Game over screen.

const UI = preload("res://scripts/ui/ui.gd")

var main: Node
var stats := {}


func _ready() -> void:
	UI.full(self)
	add_child(UI.backdrop())
	var vb := UI.panel_column(self, 640)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(UI.title(Settings.t("game_over"), 68, UI.BAD))
	if stats.get("record", false):
		vb.add_child(UI.label("★ " + Settings.t("new_record") + " ★", 28, Color(1.0, 0.85, 0.3)))
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 16)
	vb.add_child(row)
	row.add_child(_stat(str(maxi(0, int(stats.get("level", 1)) - 1)), Settings.t("go_levels").replace("%d", "").strip_edges().trim_suffix(":")))
	row.add_child(_stat("$" + Settings.money(int(stats.get("earned", 0))), Settings.t("go_earned").replace("$%s", "").strip_edges().trim_suffix(":")))
	vb.add_child(UI.sep())
	if Net.solo or not Net.online:
		vb.add_child(UI.button(Settings.t("to_menu"), _menu, 420, 64, true))
	elif Net.is_host():
		vb.add_child(UI.button(Settings.t("to_lobby"), func(): Net.back_to_lobby(), 420, 64, true))
		vb.add_child(UI.button(Settings.t("to_menu"), _menu))
	else:
		vb.add_child(UI.label(Settings.t("waiting_host"), 22, UI.DIM))
		vb.add_child(UI.button(Settings.t("to_menu"), _menu))
	for c in vb.get_children():
		if c is Button:
			c.size_flags_horizontal = Control.SIZE_SHRINK_CENTER


func _stat(big: String, small: String) -> Control:
	var card := PanelContainer.new()
	card.theme_type_variation = "Card"
	card.custom_minimum_size = Vector2(250, 120)
	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 2)
	card.add_child(v)
	var b := UI.label(big, 40, UI.ACCENT2)
	b.add_theme_font_override("font", UI.title_font())
	v.add_child(b)
	v.add_child(UI.label(small, 18, UI.DIM))
	return card


func _menu() -> void:
	Net.leave()
	main.show_menu()
