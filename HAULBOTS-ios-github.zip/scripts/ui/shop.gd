extends Control
## Between-level workshop: buy upgrades with shared team cash.

const UI = preload("res://scripts/ui/ui.gd")

var main: Node
var vb: VBoxContainer
var money_lbl: Label
var hp_lbl: Label
var rows := {}


func _ready() -> void:
	UI.full(self)
	add_child(UI.backdrop())
	vb = UI.scroll_column(self, 820)
	vb.add_child(UI.label(Settings.t("shop"), 44, UI.ACCENT))
	var st: Dictionary = Net.last_stats
	if st.has("extracted"):
		vb.add_child(UI.label(Settings.t("level_done") % [int(st["level"]), Settings.money(int(st["extracted"])), Settings.money(int(st["quota"]))], 24, Color(0.6, 1.0, 0.6)))
	money_lbl = UI.label("", 30, Color(1.0, 0.85, 0.4))
	vb.add_child(money_lbl)
	hp_lbl = UI.label("", 22, Color(0.85, 0.85, 0.85))
	vb.add_child(hp_lbl)
	for k in ["hp", "stamina", "strength", "range", "speed", "heal"]:
		_add_row(k)
	vb.add_child(UI.label(Settings.t("next_quota") % Net.level, 22, Color(0.8, 0.8, 0.8)))
	if Net.is_host():
		var nb := UI.button(Settings.t("next_level"), func(): Net.begin_level())
		nb.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		vb.add_child(nb)
	else:
		vb.add_child(UI.label(Settings.t("waiting_host"), 22, Color(0.8, 0.8, 0.8)))
	var lb := UI.button(Settings.t("to_menu"), _leave)
	lb.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(lb)
	Net.run_changed.connect(_refresh)
	_refresh()


func _add_row(k: String) -> void:
	var panel := PanelContainer.new()
	var hb := HBoxContainer.new()
	panel.add_child(hb)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_theme_constant_override("separation", 2)
	var key := "heal" if k == "heal" else "up_" + k
	var name_l := UI.label(Settings.t(key), 26, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_LEFT)
	info.add_child(name_l)
	info.add_child(UI.label(Settings.t(key + "_d"), 18, Color(0.7, 0.7, 0.7), HORIZONTAL_ALIGNMENT_LEFT))
	hb.add_child(info)
	var lvl := UI.label("", 22, Color(0.6, 0.85, 1.0))
	lvl.custom_minimum_size.x = 90
	hb.add_child(lvl)
	var btn := UI.button("", func(): Net.request_buy(k), 220, 56)
	hb.add_child(btn)
	vb.add_child(panel)
	rows[k] = {"lvl": lvl, "btn": btn}


func _refresh() -> void:
	var id := Net.my_id()
	money_lbl.text = Settings.t("team_money") % Settings.money(Net.money)
	hp_lbl.text = Settings.t("hp_now") % [int(Net.hp.get(id, 0.0)), int(Net.max_hp(id))]
	for k in rows:
		var r: Dictionary = rows[k]
		var p := Net.price(id, k)
		var btn: Button = r["btn"]
		if k == "heal":
			r["lvl"].text = ""
			btn.text = "$" + Settings.money(p)
			btn.disabled = Net.money < p or float(Net.hp.get(id, 0.0)) >= Net.max_hp(id) - 0.5
		else:
			var lv := Net.up(id, k)
			r["lvl"].text = Settings.t("lvl_short") % lv
			if lv >= Net.MAX_UPGRADE:
				btn.text = Settings.t("maxed")
				btn.disabled = true
			else:
				btn.text = "$" + Settings.money(p)
				btn.disabled = Net.money < p


func _leave() -> void:
	Net.leave()
	main.show_menu()


func _exit_tree() -> void:
	if Net.run_changed.is_connected(_refresh):
		Net.run_changed.disconnect(_refresh)
