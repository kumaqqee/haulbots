extends RefCounted
## Vector icons drawn with CanvasItem primitives (no image assets needed, crisp at any size).
## Usage: Icons.draw(ci, "jump", center, size, color)

static func draw(ci: CanvasItem, name: String, c: Vector2, s: float, col: Color, w := -1.0) -> void:
	if w < 0.0:
		w = maxf(2.0, s * 0.11)
	var h := s * 0.5
	match name:
		"heart":
			var pts := PackedVector2Array()
			for i in 33:
				var t := TAU * i / 32.0
				var x := 16.0 * pow(sin(t), 3)
				var y := -(13.0 * cos(t) - 5.0 * cos(2 * t) - 2.0 * cos(3 * t) - cos(4 * t))
				pts.append(c + Vector2(x, y) * s / 34.0)
			ci.draw_colored_polygon(pts, col)
		"bolt":
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0.12, -0.5) * s, c + Vector2(-0.3, 0.08) * s, c + Vector2(-0.02, 0.08) * s,
				c + Vector2(-0.14, 0.5) * s, c + Vector2(0.3, -0.1) * s, c + Vector2(0.02, -0.1) * s]), col)
		"pause":
			ci.draw_rect(Rect2(c + Vector2(-0.3, -0.35) * s, Vector2(0.2, 0.7) * s), col)
			ci.draw_rect(Rect2(c + Vector2(0.1, -0.35) * s, Vector2(0.2, 0.7) * s), col)
		"map":
			var p := [c + Vector2(-0.45, -0.3) * s, c + Vector2(-0.15, -0.4) * s, c + Vector2(0.15, -0.3) * s, c + Vector2(0.45, -0.4) * s,
				c + Vector2(0.45, 0.3) * s, c + Vector2(0.15, 0.4) * s, c + Vector2(-0.15, 0.3) * s, c + Vector2(-0.45, 0.4) * s]
			ci.draw_polyline(PackedVector2Array(p + [p[0]]), col, w, true)
			ci.draw_line(p[1], p[6], col, w * 0.7, true)
			ci.draw_line(p[2], p[5], col, w * 0.7, true)
		"mic":
			ci.draw_rect(Rect2(c + Vector2(-0.14, -0.45) * s, Vector2(0.28, 0.55) * s), col, true)
			ci.draw_arc(c + Vector2(0, 0.0) * s, 0.28 * s, 0.1, PI - 0.1, 12, col, w, true)
			ci.draw_line(c + Vector2(0, 0.28) * s, c + Vector2(0, 0.45) * s, col, w, true)
		"gear":
			ci.draw_arc(c, 0.26 * s, 0, TAU, 20, col, w * 1.3, true)
			for i in 8:
				var a := TAU * i / 8.0
				ci.draw_line(c + Vector2(cos(a), sin(a)) * 0.3 * s, c + Vector2(cos(a), sin(a)) * 0.45 * s, col, w * 1.4, true)
		"jump":
			ci.draw_polyline(PackedVector2Array([c + Vector2(-0.35, 0.05) * s, c + Vector2(0, -0.3) * s, c + Vector2(0.35, 0.05) * s]), col, w * 1.3, true)
			ci.draw_line(c + Vector2(-0.3, 0.35) * s, c + Vector2(0.3, 0.35) * s, col, w, true)
		"crouch":
			ci.draw_polyline(PackedVector2Array([c + Vector2(-0.35, -0.25) * s, c + Vector2(0, 0.1) * s, c + Vector2(0.35, -0.25) * s]), col, w * 1.3, true)
			ci.draw_line(c + Vector2(-0.35, 0.35) * s, c + Vector2(0.35, 0.35) * s, col, w, true)
		"run":
			for k in [-0.18, 0.14]:
				ci.draw_polyline(PackedVector2Array([c + Vector2(k - 0.14, -0.32) * s, c + Vector2(k + 0.14, 0) * s, c + Vector2(k - 0.14, 0.32) * s]), col, w * 1.2, true)
		"grab":
			ci.draw_arc(c, 0.16 * s, 0, TAU, 16, col, w, true)
			for i in 3:
				var r := (0.26 + i * 0.1) * s
				ci.draw_arc(c, r, -0.6, 0.6, 8, Color(col, col.a * (1.0 - i * 0.25)), w * 0.8, true)
				ci.draw_arc(c, r, PI - 0.6, PI + 0.6, 8, Color(col, col.a * (1.0 - i * 0.25)), w * 0.8, true)
		"drop":
			ci.draw_line(c + Vector2(-0.3, -0.3) * s, c + Vector2(0.3, 0.3) * s, col, w * 1.2, true)
			ci.draw_line(c + Vector2(0.3, -0.3) * s, c + Vector2(-0.3, 0.3) * s, col, w * 1.2, true)
		"throw":
			ci.draw_arc(c + Vector2(0, 0.25) * s, 0.4 * s, PI * 1.1, PI * 1.85, 12, col, w * 1.1, true)
			var tip := c + Vector2(0.4 * cos(PI * 1.85), 0.25 + 0.4 * sin(PI * 1.85)) * s
			ci.draw_colored_polygon(PackedVector2Array([tip + Vector2(0.14, 0.02) * s, tip + Vector2(-0.1, -0.12) * s, tip + Vector2(-0.04, 0.14) * s]), col)
		"use":
			ci.draw_arc(c, 0.36 * s, 0, TAU, 24, col, w, true)
			ci.draw_circle(c, 0.14 * s, col)
		"ping":
			ci.draw_circle(c + Vector2(0, -0.12) * s, 0.24 * s, col)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-0.2, -0.02) * s, c + Vector2(0.2, -0.02) * s, c + Vector2(0, 0.45) * s]), col)
			ci.draw_circle(c + Vector2(0, -0.12) * s, 0.09 * s, Color(0, 0, 0, col.a * 0.6))
		"tumble":
			ci.draw_arc(c, 0.32 * s, 0.3, TAU - 0.5, 20, col, w * 1.1, true)
			var a0 := 0.3
			var e := c + Vector2(cos(a0), sin(a0)) * 0.32 * s
			ci.draw_colored_polygon(PackedVector2Array([e + Vector2(0.16, -0.02) * s, e + Vector2(-0.12, -0.02) * s, e + Vector2(0.02, 0.18) * s]), col)
		"up":
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -0.32) * s, c + Vector2(0.32, 0.2) * s, c + Vector2(-0.32, 0.2) * s]), col)
		"down":
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, 0.32) * s, c + Vector2(0.32, -0.2) * s, c + Vector2(-0.32, -0.2) * s]), col)
		"eye":
			var up := PackedVector2Array()
			for i in 13:
				var t := -1.0 + 2.0 * i / 12.0
				up.append(c + Vector2(t * 0.48, -0.26 * (1.0 - t * t)) * s)
			for i in 13:
				var t := 1.0 - 2.0 * i / 12.0
				up.append(c + Vector2(t * 0.48, 0.26 * (1.0 - t * t)) * s)
			up.append(up[0])
			ci.draw_polyline(up, col, w, true)
			ci.draw_circle(c, 0.13 * s, col)
		"gun":
			ci.draw_rect(Rect2(c + Vector2(-0.42, -0.2) * s, Vector2(0.8, 0.18) * s), col)
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-0.3, -0.04) * s, c + Vector2(-0.08, -0.04) * s, c + Vector2(-0.16, 0.36) * s, c + Vector2(-0.38, 0.36) * s]), col)
		"melee":
			ci.draw_line(c + Vector2(-0.32, 0.36) * s, c + Vector2(0.3, -0.3) * s, col, w * 1.8, true)
			ci.draw_line(c + Vector2(-0.4, 0.44) * s, c + Vector2(-0.24, 0.28) * s, col, w * 2.6, true)
		"grenade":
			ci.draw_circle(c + Vector2(0, 0.08) * s, 0.3 * s, col)
			ci.draw_rect(Rect2(c + Vector2(-0.1, -0.36) * s, Vector2(0.2, 0.14) * s), col)
			ci.draw_arc(c + Vector2(0.2, -0.3) * s, 0.1 * s, 0, TAU, 10, col, w * 0.7, true)
		"mine":
			ci.draw_rect(Rect2(c + Vector2(-0.42, 0.05) * s, Vector2(0.84, 0.2) * s), col)
			ci.draw_rect(Rect2(c + Vector2(-0.25, -0.1) * s, Vector2(0.5, 0.16) * s), col)
			ci.draw_circle(c + Vector2(0, -0.2) * s, 0.07 * s, col)
		"drone":
			ci.draw_circle(c, 0.14 * s, col)
			for k in [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]:
				ci.draw_line(c, c + k * 0.26 * s, col, w, true)
				ci.draw_arc(c + k * 0.3 * s, 0.13 * s, 0, TAU, 12, col, w * 0.7, true)
		"tracker":
			ci.draw_arc(c, 0.38 * s, 0, TAU, 24, col, w * 0.8, true)
			ci.draw_arc(c, 0.2 * s, 0, TAU, 16, col, w * 0.6, true)
			ci.draw_line(c, c + Vector2(0.27, -0.27) * s, col, w, true)
		"crystal":
			ci.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -0.45) * s, c + Vector2(0.25, -0.05) * s, c + Vector2(0, 0.45) * s, c + Vector2(-0.25, -0.05) * s]), col)
		"med":
			ci.draw_rect(Rect2(c + Vector2(-0.12, -0.38) * s, Vector2(0.24, 0.76) * s), col)
			ci.draw_rect(Rect2(c + Vector2(-0.38, -0.12) * s, Vector2(0.76, 0.24) * s), col)
		"cart":
			ci.draw_polyline(PackedVector2Array([c + Vector2(-0.46, -0.3) * s, c + Vector2(-0.3, -0.3) * s, c + Vector2(-0.18, 0.14) * s, c + Vector2(0.36, 0.14) * s, c + Vector2(0.44, -0.18) * s, c + Vector2(-0.24, -0.18) * s]), col, w, true)
			ci.draw_circle(c + Vector2(-0.12, 0.32) * s, 0.08 * s, col)
			ci.draw_circle(c + Vector2(0.3, 0.32) * s, 0.08 * s, col)
		"star":
			var sp := PackedVector2Array()
			for i in 10:
				var a := -PI / 2 + TAU * i / 10.0
				var r := 0.45 if i % 2 == 0 else 0.2
				sp.append(c + Vector2(cos(a), sin(a)) * r * s)
			ci.draw_colored_polygon(sp, col)
		_:
			ci.draw_circle(c, 0.2 * s, col)


## Icon for an inventory item type.
static func for_item(t: String) -> String:
	if t.begins_with("w_"):
		return "gun" if t in ["w_pistol", "w_shotgun", "w_tranq"] else "melee"
	if t.begins_with("g_"):
		return "grenade"
	if t.begins_with("m_"):
		return "mine"
	if t.begins_with("d_"):
		return "drone"
	if t.begins_with("t_"):
		return "tracker"
	if t.begins_with("med_"):
		return "med"
	if t == "i_crystal":
		return "crystal"
	if t == "i_pocketcart":
		return "cart"
	return "star"
