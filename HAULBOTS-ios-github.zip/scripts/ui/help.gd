extends Control
## How-to-play screen: help text split into titled cards.

const UI = preload("res://scripts/ui/ui.gd")

var main: Node


func _ready() -> void:
	UI.full(self)
	add_child(UI.backdrop())
	var vb := UI.panel_column(self, 980, 560)
	vb.add_child(UI.title(Settings.t("help_title"), 46))
	var parts: PackedStringArray = Settings.t("help_text").split("[b]", false)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 14)
	grid.add_theme_constant_override("v_separation", 14)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_child(grid)
	for p in parts:
		var k := p.find("[/b]")
		if k < 0:
			continue
		var head := p.substr(0, k)
		var body := p.substr(k + 4).strip_edges()
		var card := PanelContainer.new()
		card.theme_type_variation = "Card"
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.custom_minimum_size.x = 440
		var cv := VBoxContainer.new()
		cv.add_theme_constant_override("separation", 6)
		card.add_child(cv)
		var h := UI.label(head, 24, UI.ACCENT2, HORIZONTAL_ALIGNMENT_LEFT)
		h.add_theme_font_override("font", UI.title_font())
		cv.add_child(h)
		var rt := RichTextLabel.new()
		rt.bbcode_enabled = true
		rt.fit_content = true
		rt.scroll_active = false
		rt.custom_minimum_size.x = 400
		rt.add_theme_font_size_override("normal_font_size", 19)
		rt.add_theme_color_override("default_color", Color(0.86, 0.85, 0.82))
		rt.text = body
		cv.add_child(rt)
		grid.add_child(card)
	var b := UI.button(Settings.t("back"), func(): main.show_menu(), 320, 64, true)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(b)
