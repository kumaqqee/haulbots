extends Control
## Main menu: logo + text entries on the left, 3D scene (robot by the van) on the right.

const UI = preload("res://scripts/ui/ui.gd")

var main: Node


func _ready() -> void:
	UI.full(self)
	if main and main.menu_bg:
		main.menu_bg.set_players([{"color": 0}])
	# left-side dark gradient so the text reads over the 3D scene
	var shade := TextureRect.new()
	var gt := GradientTexture2D.new()
	var g := Gradient.new()
	g.set_color(0, Color(0, 0, 0, 0.82))
	g.set_color(1, Color(0, 0, 0, 0.0))
	gt.gradient = g
	gt.fill_from = Vector2(0.0, 0.5)
	gt.fill_to = Vector2(0.62, 0.5)
	gt.width = 256
	gt.height = 8
	shade.texture = gt
	shade.stretch_mode = TextureRect.STRETCH_SCALE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UI.full(shade)
	add_child(shade)
	var margin := MarginContainer.new()
	UI.full(margin)
	margin.add_theme_constant_override("margin_left", 70)
	margin.add_theme_constant_override("margin_top", 40)
	margin.add_theme_constant_override("margin_bottom", 30)
	add_child(margin)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	margin.add_child(vb)
	var logo := TextureRect.new()
	logo.texture = preload("res://assets/ui/title.png")
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
	logo.custom_minimum_size = Vector2(470, 82)
	logo.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	vb.add_child(logo)
	var tag := UI.label(Settings.t("tagline"), 24, Color(0.9, 0.85, 0.78), HORIZONTAL_ALIGNMENT_LEFT)
	tag.autowrap_mode = TextServer.AUTOWRAP_OFF
	vb.add_child(tag)
	if Settings.best_level > 0:
		var rp := PanelContainer.new()
		rp.theme_type_variation = "Pill"
		rp.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		var rec := UI.label("★ " + Settings.t("record") % [Settings.best_level, Settings.money(Settings.best_earned)], 19, Color(1.0, 0.82, 0.45), HORIZONTAL_ALIGNMENT_LEFT)
		rec.autowrap_mode = TextServer.AUTOWRAP_OFF
		rp.add_child(rec)
		vb.add_child(rp)
	var sp := Control.new()
	sp.custom_minimum_size.y = 18
	vb.add_child(sp)
	if Net.has_save():
		vb.add_child(UI.menu_entry((Settings.t("continue") % Net.save_level()).to_upper(), func(): Net.start_solo(true)))
	vb.add_child(UI.menu_entry(Settings.t("new_game").to_upper(), func(): Net.start_solo(false)))
	vb.add_child(UI.menu_entry(Settings.t("host").to_upper(), _host))
	vb.add_child(UI.menu_entry(Settings.t("join").to_upper(), func(): main.show_join()))
	vb.add_child(UI.menu_entry(Settings.t("settings").to_upper(), func(): main.show_settings()))
	vb.add_child(UI.menu_entry(Settings.t("how_to_play").to_upper(), func(): main.show_help()))
	vb.add_child(UI.menu_entry(Settings.t("quit").to_upper(), func(): get_tree().quit()))
	# name tag bottom-right
	var card := PanelContainer.new()
	card.theme_type_variation = "Pill"
	card.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	card.position += Vector2(-500, -96)
	var nb := HBoxContainer.new()
	card.add_child(nb)
	var nl := UI.label(Settings.t("name"), 22, UI.DIM)
	nl.autowrap_mode = TextServer.AUTOWRAP_OFF
	nb.add_child(nl)
	var name_edit := LineEdit.new()
	name_edit.text = Settings.player_name
	name_edit.max_length = 16
	name_edit.custom_minimum_size = Vector2(300, 52)
	name_edit.text_changed.connect(func(t):
		Settings.player_name = t.strip_edges() if t.strip_edges() != "" else "Bot"
		Settings.save_cfg())
	nb.add_child(name_edit)
	add_child(card)
	var ver := UI.label("v" + Settings.VERSION + ("  •  HD" if HD.active() else ""), 16, Color(0.55, 0.55, 0.55), HORIZONTAL_ALIGNMENT_RIGHT)
	ver.autowrap_mode = TextServer.AUTOWRAP_OFF
	ver.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	ver.position += Vector2(-90, -24)
	add_child(ver)


func _host() -> void:
	if Net.host_game():
		main.show_lobby()
	else:
		main.toast(Settings.t("host_failed"))
