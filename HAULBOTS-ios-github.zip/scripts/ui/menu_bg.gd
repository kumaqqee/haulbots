extends Node3D
## 3D backdrop for menus: the crew of robots idling in front of the van in the garage.

const LevelGen = preload("res://scripts/game/level_gen.gd")
const ML = preload("res://scripts/game/matlib.gd")
const MonsterScript = preload("res://scripts/game/monster.gd")

var gen
var cam: Camera3D
var robots := []
var t := 0.0
var center := Vector3.ZERO
var back := Vector3.FORWARD
var side := Vector3.RIGHT
var lurker: Node3D = null


func _ready() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.01, 0.01, 0.015)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.5, 0.5, 0.62)
	env.ambient_light_energy = 0.25
	env.tonemap_mode = Environment.TONE_MAPPER_AGX
	env.tonemap_exposure = 1.3
	env.fog_enabled = true
	env.fog_light_color = Color(0.03, 0.03, 0.045)
	env.fog_density = 0.03
	env.glow_enabled = true
	env.glow_intensity = 0.7
	env.glow_hdr_threshold = 0.9
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.1
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.18, 0.16, 0.14)
	sm.sky_horizon_color = Color(0.35, 0.3, 0.25)
	sky.sky_material = sm
	env.sky = sky
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	we.environment = env
	add_child(we)
	gen = LevelGen.new()
	gen.build(4242, 1, self)
	back = gen.truck_back
	side = gen.truck_side
	center = gen.truck_pos - Vector3(0, 0.5, 0) - back * 3.6
	# warm key light on the crew
	var key := SpotLight3D.new()
	key.light_color = Color(1.0, 0.85, 0.65)
	key.light_energy = 4.5
	key.shadow_blur = 1.5
	key.light_size = 0.1
	key.spot_range = 9.0
	key.spot_angle = 38.0
	key.shadow_enabled = true
	add_child(key)
	key.global_position = center - back * 2.5 + side * 2.0 + Vector3(0, 3.2, 0)
	key.look_at(center + Vector3(0, 0.8, 0), Vector3.UP)
	# film look over the menu scene
	var cl := CanvasLayer.new()
	cl.layer = -1
	add_child(cl)
	var pr := ColorRect.new()
	pr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var pm := ShaderMaterial.new()
	pm.shader = load("res://assets/shaders/postfx.gdshader")
	pm.set_shader_parameter("grain", 0.035)
	pr.material = pm
	cl.add_child(pr)
	cam = Camera3D.new()
	cam.fov = 55
	add_child(cam)
	cam.current = true
	set_players([{"color": 0}])
	# something watching from the doorway
	lurker = MonsterScript.new()
	lurker.mtype = "lurker"
	lurker.server_side = false
	add_child(lurker)
	var door := LevelGen.cell_center(gen.spawn_cell) - back * 4.4
	lurker.global_position = door + side * 0.2
	lurker.net_pos = lurker.global_position
	lurker.net_yaw = atan2(back.x, back.z)
	lurker.visible = false


func set_players(list: Array) -> void:
	for r in robots:
		r["node"].queue_free()
	robots.clear()
	var n := list.size()
	for i in n:
		var col: Color = Net.COLORS[int(list[i].get("color", 0)) % 4]
		var m := ML.model("robot", {"M_player": ML.plain(col, 0.45, 0.25), "M_player_glow": ML.plain(col.lightened(0.2), 0.3, 0.0, 3.0)})
		if m == null:
			continue
		add_child(m)
		var off := (i - (n - 1) / 2.0) * 0.85
		m.global_position = center + side * off
		m.basis = Basis.looking_at(-back.rotated(Vector3.UP, 0.35 - off * 0.2), Vector3.UP)
		robots.append({"node": m, "head": ML.find(m, "head"), "arm": ML.find(m, "arm_r"), "body": ML.find(m, "body"), "phase": i * 1.7})


func _process(delta: float) -> void:
	t += delta
	var focus := center + Vector3(0, 0.9, 0)
	var orbit := sin(t * 0.12) * 0.35
	var dir := (-back).rotated(Vector3.UP, 0.3 + orbit * 0.6)
	cam.global_position = focus + dir * 3.6 + Vector3(0, 0.5, 0)
	cam.look_at(focus, Vector3.UP)
	cam.h_offset = -1.35 if robots.size() <= 1 else -1.7
	for r in robots:
		var ph: float = t + r["phase"]
		if r["body"]:
			r["body"].position.y = 0.55 + sin(ph * 2.0) * 0.012
		if r["head"]:
			r["head"].rotation = Vector3(sin(ph * 0.7) * 0.12, sin(ph * 0.45) * 0.5, sin(ph * 0.9) * 0.06)
		if r["arm"]:
			var wave := fmod(ph, 9.0)
			r["arm"].rotation = Vector3(0, 0, -2.3 - sin(wave * 9.0) * 0.35) if wave < 1.4 else Vector3(sin(ph) * 0.08, 0, 0)
	if lurker:
		lurker.visible = fmod(t, 26.0) > 18.0
	for l in gen.lights:
		if l["flicker"]:
			l["light"].light_energy = l["base"] * (randf_range(0.7, 1.0) if randf() > 0.05 else 0.05)
