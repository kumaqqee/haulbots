extends CanvasLayer
## In-game HUD: status card, objective, tracker compass, prompts, messages, slots, pause, touch controls.

const UI = preload("res://scripts/ui/ui.gd")
const Icons = preload("res://scripts/ui/icons.gd")
const Touch = preload("res://scripts/ui/touch.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")
const ItemDefs = preload("res://scripts/game/item_defs.gd")

const SLOT_W := 104.0
const SLOT_H := 78.0
const SLOT_GAP := 12.0

var world: Node = null
var root: Control
var touch = null
var status: Control
var obj_ctrl: Control
var compass: Control
var crosshair: Control
var look_pill: PanelContainer
var lbl_look: Label
var msg_box: VBoxContainer
var vignette: TextureRect
var fx_overlay: ColorRect
var dead_panel: Control
var pause_btn: Button
var pause_menu: Control
var settings_panel: Control = null
var map_btn: Button
var expr_btn: Button
var expr_bar: HBoxContainer
const Expr = preload("res://scripts/game/expressions.gd")
var mic_btn: Button
var map_ctrl: Control
var map_on := false
var tut_pill: PanelContainer
var tut_lbl: Label
var tut_step := -1
var tut_t := 0.0
var _tut_start := Vector3.ZERO
var slot_bar: Control
var fps_lbl: Label
var _vig := 0.0
var _paused := false
var _hp_shown := 100.0
var _hp_ghost := 100.0
var _obj_text := ""
var _obj_sub := ""
var _obj_prog := -1.0
var _obj_col := Color.WHITE
var _alert := 0.0


func setup(w: Node) -> void:
	world = w
	layer = 5
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	UI.full(root)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = get_tree().root.get_node("Main").theme
	add_child(root)

	# damage vignette: red radial edges
	vignette = TextureRect.new()
	var gt := GradientTexture2D.new()
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	g.colors = PackedColorArray([Color(0.8, 0, 0, 0), Color(0.8, 0, 0, 0.0), Color(0.75, 0.0, 0.0, 0.95)])
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.05, 1.05)
	gt.width = 256
	gt.height = 256
	vignette.texture = gt
	vignette.stretch_mode = TextureRect.STRETCH_SCALE
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vignette.modulate.a = 0.0
	UI.full(vignette)
	root.add_child(vignette)
	fx_overlay = ColorRect.new()
	UI.full(fx_overlay)
	fx_overlay.color = Color(0, 0, 0, 0)
	fx_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(fx_overlay)

	# status card (top-left)
	status = Control.new()
	status.position = Vector2(16, 12)
	status.size = Vector2(330, 104)
	status.mouse_filter = Control.MOUSE_FILTER_IGNORE
	status.draw.connect(_draw_status)
	root.add_child(status)

	# objective (top-centre) + tracker compass + messages
	var top := VBoxContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	top.custom_minimum_size.x = 640
	top.position = Vector2(-320, 10)
	top.add_theme_constant_override("separation", 6)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(top)
	obj_ctrl = Control.new()
	obj_ctrl.custom_minimum_size = Vector2(640, 64)
	obj_ctrl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	obj_ctrl.draw.connect(_draw_objective)
	top.add_child(obj_ctrl)
	compass = Control.new()
	compass.custom_minimum_size = Vector2(640, 40)
	compass.mouse_filter = Control.MOUSE_FILTER_IGNORE
	compass.draw.connect(_draw_compass)
	top.add_child(compass)
	msg_box = VBoxContainer.new()
	msg_box.alignment = BoxContainer.ALIGNMENT_BEGIN
	msg_box.add_theme_constant_override("separation", 6)
	msg_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(msg_box)

	# crosshair + detection eye + look label
	crosshair = Control.new()
	crosshair.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	crosshair.draw.connect(_draw_crosshair)
	root.add_child(crosshair)
	look_pill = PanelContainer.new()
	look_pill.theme_type_variation = "Pill"
	look_pill.set_anchors_preset(Control.PRESET_CENTER)
	look_pill.grow_horizontal = Control.GROW_DIRECTION_BOTH
	look_pill.grow_vertical = Control.GROW_DIRECTION_END
	look_pill.offset_left = 0
	look_pill.offset_right = 0
	look_pill.offset_top = 34
	look_pill.offset_bottom = 34
	look_pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lbl_look = UI.label("", 21)
	lbl_look.autowrap_mode = TextServer.AUTOWRAP_OFF
	lbl_look.mouse_filter = Control.MOUSE_FILTER_IGNORE
	look_pill.add_child(lbl_look)
	root.add_child(look_pill)

	# inventory slots (bottom centre)
	slot_bar = Control.new()
	slot_bar.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	var sw := SLOT_W * 3 + SLOT_GAP * 2
	slot_bar.custom_minimum_size = Vector2(sw, SLOT_H)
	slot_bar.size = Vector2(sw, SLOT_H)
	slot_bar.position = Vector2(-sw / 2.0, -SLOT_H - 12)
	slot_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	slot_bar.draw.connect(_draw_slots)
	root.add_child(slot_bar)

	# tutorial hint
	tut_pill = PanelContainer.new()
	tut_pill.theme_type_variation = "Pill"
	tut_pill.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	tut_pill.grow_horizontal = Control.GROW_DIRECTION_BOTH
	tut_pill.grow_vertical = Control.GROW_DIRECTION_BEGIN
	tut_pill.offset_left = 0
	tut_pill.offset_right = 0
	tut_pill.offset_top = -SLOT_H - 30
	tut_pill.offset_bottom = -SLOT_H - 30
	tut_pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tut_lbl = UI.label("", 22, Color(0.65, 1.0, 0.95))
	tut_lbl.custom_minimum_size.x = 600
	tut_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tut_pill.add_child(tut_lbl)
	tut_pill.visible = false
	root.add_child(tut_pill)

	# touch controls
	touch = Touch.new()
	root.add_child(touch)
	touch.visible = Settings.is_touch()

	# top-right icon buttons
	pause_btn = _icon_btn("pause", Vector2(-86, 12), _toggle_pause)
	map_btn = _icon_btn("map", Vector2(-164, 12), _toggle_map)
	if Net.online:
		mic_btn = _icon_btn("mic", Vector2(-242, 12), _toggle_mic)
	_build_expr(Vector2(-320 if Net.online else -242, 12))
	fps_lbl = UI.label("", 16, UI.DIM, HORIZONTAL_ALIGNMENT_RIGHT)
	fps_lbl.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	fps_lbl.position = Vector2(-120, 80)
	fps_lbl.custom_minimum_size.x = 100
	fps_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(fps_lbl)

	map_ctrl = Control.new()
	map_ctrl.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	map_ctrl.custom_minimum_size = Vector2(380, 380)
	map_ctrl.size = Vector2(380, 380)
	map_ctrl.position = Vector2(-190, 118)
	map_ctrl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	map_ctrl.draw.connect(_draw_map)
	map_ctrl.visible = false
	root.add_child(map_ctrl)
	if world.level_num == 1 and not Settings.tutorial_done:
		tut_step = 0
	_build_dead_panel()
	_build_pause_menu()
	if not Settings.is_touch():
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _icon_btn(icon: String, pos: Vector2, cb: Callable) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(66, 60)
	b.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	b.position = pos
	b.focus_mode = Control.FOCUS_NONE
	var flat := UI.sb(Color(0.03, 0.035, 0.045, 0.7), Color(1, 1, 1, 0.14), 1, 14)
	b.add_theme_stylebox_override("normal", flat)
	b.add_theme_stylebox_override("hover", UI.sb(Color(0.12, 0.09, 0.05, 0.85), UI.ACCENT, 2, 14))
	b.add_theme_stylebox_override("pressed", UI.sb(Color(UI.ACCENT, 0.6), UI.ACCENT, 2, 14))
	b.pressed.connect(cb)
	b.draw.connect(func():
		var on: bool = icon == "mic" and world.voice != null and world.voice.talking
		Icons.draw(b, icon, b.size / 2.0, 30.0, UI.GOOD if on else Color(1, 1, 1, 0.92)))
	root.add_child(b)
	return b


## Expressions: a face button opens a row of six toggles (keys 5-0 on PC).
func _build_expr(pos: Vector2) -> void:
	expr_btn = _icon_btn("map", pos, func(): expr_bar.visible = not expr_bar.visible)
	for c in expr_btn.draw.get_connections():
		expr_btn.draw.disconnect(c["callable"])
	expr_btn.draw.connect(func():
		var m: int = world.local_player.expr if world.local_player else 0
		Expr.draw_face(expr_btn, expr_btn.size / 2.0, 44.0, m, Color(1, 1, 1, 0.92), Color(0.03, 0.035, 0.045)))
	expr_bar = HBoxContainer.new()
	expr_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	expr_bar.position = Vector2(pos.x - 5 * 70 + 66, 80)
	expr_bar.add_theme_constant_override("separation", 6)
	expr_bar.visible = false
	root.add_child(expr_bar)
	for i in Expr.COUNT:
		var b := Button.new()
		b.custom_minimum_size = Vector2(64, 64)
		b.focus_mode = Control.FOCUS_NONE
		b.toggle_mode = true
		b.tooltip_text = Settings.t(Expr.KEYS[i])
		b.add_theme_stylebox_override("normal", UI.sb(Color(0.03, 0.035, 0.045, 0.8), Color(1, 1, 1, 0.14), 1, 14))
		b.add_theme_stylebox_override("hover", UI.sb(Color(0.12, 0.09, 0.05, 0.85), UI.ACCENT, 2, 14))
		b.add_theme_stylebox_override("pressed", UI.sb(Color(0.25, 0.14, 0.04, 0.9), UI.ACCENT, 2, 14))
		b.add_theme_stylebox_override("hover_pressed", UI.sb(Color(0.25, 0.14, 0.04, 0.9), UI.ACCENT, 2, 14))
		b.toggled.connect(func(_on):
			if world.local_player and ((world.local_player.expr >> i) & 1) != int(_on):
				world.local_player.set_expr_bit(i))
		b.draw.connect(func():
			Expr.draw_face(b, b.size / 2.0, 44.0, 1 << i, UI.ACCENT2 if b.button_pressed else Color(1, 1, 1, 0.85), Color(0.03, 0.035, 0.045) if not b.button_pressed else Color(0.25, 0.14, 0.04)))
		expr_bar.add_child(b)


func expr_changed(mask: int) -> void:
	if expr_bar:
		for i in expr_bar.get_child_count():
			var b: Button = expr_bar.get_child(i)
			b.set_pressed_no_signal(((mask >> i) & 1) == 1)
			b.queue_redraw()
	if expr_btn:
		expr_btn.queue_redraw()


func _toggle_map() -> void:
	map_on = not map_on
	map_ctrl.visible = map_on


func _toggle_mic() -> void:
	if world.voice:
		world.voice.set_talking(not world.voice.talking)
	if mic_btn:
		mic_btn.queue_redraw()


func _build_dead_panel() -> void:
	dead_panel = PanelContainer.new()
	dead_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	dead_panel.custom_minimum_size = Vector2(720, 0)
	dead_panel.position = Vector2(-360, 50)
	dead_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dead_panel.add_child(vb)
	var t := UI.title(Settings.t("dead_title"), 44, UI.BAD)
	vb.add_child(t)
	var h := UI.label(Settings.t("dead_hint"), 21, UI.TEXT)
	vb.add_child(h)
	dead_panel.visible = false
	root.add_child(dead_panel)


func _build_pause_menu() -> void:
	pause_menu = Control.new()
	UI.full(pause_menu)
	UI.dim(pause_menu, 0.62)
	pause_menu.visible = false
	root.add_child(pause_menu)


func _fill_pause_menu() -> void:
	for c in pause_menu.get_children():
		if not (c is ColorRect):
			c.queue_free()
	var vb := UI.panel_column(pause_menu, 500)
	vb.add_child(UI.title(Settings.t("pause"), 52))
	var info := UI.label("%s   ·   %s" % [Settings.t("hud_level") % world.level_num, Settings.t("hud_cash") % Settings.money(Net.money)], 20, UI.DIM)
	vb.add_child(info)
	vb.add_child(UI.button(Settings.t("resume"), _toggle_pause, 420, 66, true))
	vb.add_child(UI.button(Settings.t("settings"), _open_settings))
	vb.add_child(UI.button(Settings.t("leave_game"), _leave))
	for c in vb.get_children():
		if c is Button:
			c.size_flags_horizontal = Control.SIZE_SHRINK_CENTER


func is_paused() -> bool:
	return _paused


func _toggle_pause() -> void:
	_paused = not _paused
	if _paused:
		_fill_pause_menu()
	pause_menu.visible = _paused
	if touch:
		touch.reset()
	if Net.solo:
		get_tree().paused = _paused
	if not Settings.is_touch():
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if _paused else Input.MOUSE_MODE_CAPTURED


func _open_settings() -> void:
	if settings_panel:
		return
	settings_panel = SettingsPanel.new()
	settings_panel.on_close = _close_settings
	root.add_child(settings_panel)


func _close_settings() -> void:
	if settings_panel:
		settings_panel.queue_free()
		settings_panel = null
	if world.local_player and world.local_player.cam:
		world.local_player.cam.fov = Settings.fov
	touch.visible = Settings.is_touch()
	touch.queue_redraw()


func _leave() -> void:
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	Net.leave()
	get_tree().root.get_node("Main").show_menu()


func _unhandled_input(e: InputEvent) -> void:
	if e.is_action_pressed("pause"):
		_toggle_pause()
	elif e.is_action_pressed("map"):
		_toggle_map()
	elif e.is_action_pressed("talk"):
		_toggle_mic()


func message(text: String) -> void:
	if msg_box == null:
		return
	var pill := PanelContainer.new()
	pill.theme_type_variation = "Pill"
	pill.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l := UI.label(text, 21, Color(1.0, 0.9, 0.6))
	l.autowrap_mode = TextServer.AUTOWRAP_OFF if text.length() < 58 else TextServer.AUTOWRAP_WORD_SMART
	if text.length() >= 58:
		l.custom_minimum_size.x = 600
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pill.add_child(l)
	msg_box.add_child(pill)
	while msg_box.get_child_count() > 3:
		var c := msg_box.get_child(0)
		msg_box.remove_child(c)
		c.queue_free()
	pill.modulate.a = 0.0
	var tw := pill.create_tween()
	tw.tween_property(pill, "modulate:a", 1.0, 0.2)
	tw.tween_interval(4.0)
	tw.tween_property(pill, "modulate:a", 0.0, 0.8)
	tw.tween_callback(pill.queue_free)


var _hits := []


func flash_damage(knock := Vector3.ZERO, dmg := 10.0) -> void:
	_vig = clampf(0.4 + dmg / 60.0, 0.4, 1.0)
	if knock.length() > 0.01:
		_hits.append({"dir": -knock.normalized(), "t": 1.2})
		if _hits.size() > 4:
			_hits.pop_front()


## Big level title at the start of a level.
func intro_card(title: String, sub: String) -> void:
	var box := VBoxContainer.new()
	box.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	box.grow_vertical = Control.GROW_DIRECTION_BOTH
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", 0)
	var t := UI.title(title.to_upper(), 64)
	t.autowrap_mode = TextServer.AUTOWRAP_OFF
	var bar := ColorRect.new()
	bar.color = UI.ACCENT
	bar.custom_minimum_size = Vector2(0, 4)
	var s := UI.label(sub, 28, UI.TEXT)
	s.autowrap_mode = TextServer.AUTOWRAP_OFF
	box.add_child(t)
	box.add_child(bar)
	box.add_child(s)
	root.add_child(box)
	box.position.y -= 120
	box.modulate.a = 0.0
	var tw := box.create_tween()
	tw.tween_property(box, "modulate:a", 1.0, 0.5)
	tw.tween_interval(2.2)
	tw.tween_property(box, "modulate:a", 0.0, 0.8)
	tw.tween_callback(box.queue_free)


## End-of-level report shown when the crew arrives at the shop.
func summary_card(st: Dictionary) -> void:
	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.055, 0.07, 0.94)
	sb.border_color = UI.ACCENT
	sb.set_border_width_all(0)
	sb.border_width_top = 4
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(22)
	sb.shadow_color = Color(0, 0, 0, 0.5)
	sb.shadow_size = 12
	panel.add_theme_stylebox_override("panel", sb)
	panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	panel.custom_minimum_size = Vector2(560, 0)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	vb.custom_minimum_size = Vector2(520, 0)
	panel.add_child(vb)
	var ttl := UI.title(Settings.t("sum_title") % int(st.get("level", 1)), 44)
	ttl.autowrap_mode = TextServer.AUTOWRAP_OFF
	vb.add_child(ttl)
	var bar := ColorRect.new()
	bar.color = UI.ACCENT
	bar.custom_minimum_size = Vector2(0, 3)
	vb.add_child(bar)
	var rows := [
		[Settings.t("sum_haul"), "$" + Settings.money(int(st.get("extracted", 0))), UI.GOOD],
		[Settings.t("sum_quota"), "$" + Settings.money(int(st.get("quota", 0))), UI.TEXT],
		[Settings.t("sum_broken"), "%d  (−$%s)" % [int(st.get("broken", 0)), Settings.money(int(st.get("lost", 0)))], UI.BAD if int(st.get("lost", 0)) > 0 else UI.TEXT],
		[Settings.t("sum_kills"), str(int(st.get("kills", 0))), UI.TEXT],
		[Settings.t("sum_deaths"), str(int(st.get("deaths", 0))), UI.BAD if int(st.get("deaths", 0)) > 0 else UI.TEXT],
		[Settings.t("sum_cash"), "$" + Settings.money(Net.money), UI.ACCENT2],
	]
	for rw in rows:
		var hb := HBoxContainer.new()
		var a := UI.label(rw[0], 24, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT)
		a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		a.autowrap_mode = TextServer.AUTOWRAP_OFF
		var b := UI.label(rw[1], 26, rw[2], HORIZONTAL_ALIGNMENT_RIGHT)
		b.autowrap_mode = TextServer.AUTOWRAP_OFF
		hb.add_child(a)
		hb.add_child(b)
		vb.add_child(hb)
	var hint := UI.label(Settings.t("sum_tap"), 18, UI.DIM)
	hint.autowrap_mode = TextServer.AUTOWRAP_OFF
	vb.add_child(hint)
	root.add_child(panel)
	panel.reset_size()
	panel.position = (root.size - panel.size) * 0.5 + Vector2(0, 50)
	panel.modulate.a = 0.0
	var tw := panel.create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.4)
	tw.tween_interval(9.0)
	tw.tween_property(panel, "modulate:a", 0.0, 0.6)
	tw.tween_callback(panel.queue_free)
	panel.gui_input.connect(func(e):
		if (e is InputEventMouseButton or e is InputEventScreenTouch) and e.pressed and is_instance_valid(panel):
			panel.queue_free())


## "+$12,400" rising in the middle of the screen after a successful extraction.
func money_popup(v: int) -> void:
	var l := UI.title("+$" + Settings.money(v), 54, UI.GOOD)
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	l.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	l.grow_horizontal = Control.GROW_DIRECTION_BOTH
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(l)
	l.position.y -= 60
	l.scale = Vector2(0.6, 0.6)
	l.resized.connect(func(): l.pivot_offset = l.size / 2.0)
	var tw := l.create_tween().set_parallel(true)
	tw.tween_property(l, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "position:y", l.position.y - 90, 2.2)
	tw.tween_property(l, "modulate:a", 0.0, 0.8).set_delay(1.6)
	tw.chain().tween_callback(l.queue_free)


var _ui_t := 0.0
var _ui_slow_t := 0.0


func _process(delta: float) -> void:
	if world == null:
		return
	var lp = world.local_player
	_vig = maxf(0.0, _vig - delta * 1.2)
	for h in _hits:
		h["t"] -= delta
	_hits = _hits.filter(func(h): return h["t"] > 0.0)
	var low := 0.0
	if lp and not lp.dead:
		var mh := Net.max_hp(lp.peer_id)
		if lp.hp < mh * 0.3:
			low = 0.28 + 0.12 * sin(Time.get_ticks_msec() * 0.006)
		_hp_shown = lerpf(_hp_shown, lp.hp, minf(1.0, delta * 10.0))
		if _hp_ghost > lp.hp:
			_hp_ghost = move_toward(_hp_ghost, lp.hp, delta * 25.0)
		else:
			_hp_ghost = lp.hp
	vignette.modulate.a = maxf(_vig, low)
	_alert = lerpf(_alert, world.alert, minf(1.0, delta * 6.0))
	if lp:
		dead_panel.visible = lp.dead
		crosshair.visible = not lp.dead
		if touch:
			touch.set_grabbing(lp.grabbed_id != -1)
			touch.set_crouch(lp.crouching)
			touch.set_tumble(lp.tumbling)
		_tutorial(lp, delta)
		_update_look(lp)
		_update_overlay(lp)
	_update_objective()
	fps_lbl.visible = Settings.show_fps
	if Settings.show_fps:
		fps_lbl.text = "%d FPS" % Engine.get_frames_per_second()
	if mic_btn and world.voice:
		mic_btn.queue_redraw()
	if map_on:
		map_ctrl.queue_redraw()
	# vector widgets redraw at 30/15 Hz instead of every frame (saves CPU on weak phones)
	_ui_t += delta
	_ui_slow_t += delta
	if _ui_t >= 0.033:
		_ui_t = 0.0
		status.queue_redraw()
		crosshair.queue_redraw()
	if _ui_slow_t >= 0.066:
		_ui_slow_t = 0.0
		obj_ctrl.queue_redraw()
		slot_bar.queue_redraw()
		compass.queue_redraw()


# ------------------------------------------------------------------ status card

func _bar(ci: CanvasItem, r: Rect2, frac: float, col: Color, ghost := -1.0) -> void:
	var bg := UI.sb(Color(0, 0, 0, 0.55), Color(1, 1, 1, 0.12), 1, int(r.size.y / 2.0), Vector4.ZERO)
	ci.draw_style_box(bg, r)
	if ghost > frac:
		var gr := Rect2(r.position + Vector2(2, 2), Vector2(maxf(0.0, (r.size.x - 4) * clampf(ghost, 0.0, 1.0)), r.size.y - 4))
		ci.draw_style_box(UI.sb(Color(1, 1, 1, 0.45), Color(0, 0, 0, 0), 0, int(gr.size.y / 2.0), Vector4.ZERO), gr)
	if frac > 0.0:
		var fr := Rect2(r.position + Vector2(2, 2), Vector2(maxf(r.size.y - 4, (r.size.x - 4) * clampf(frac, 0.0, 1.0)), r.size.y - 4))
		ci.draw_style_box(UI.sb(col, Color(0, 0, 0, 0), 0, int(fr.size.y / 2.0), Vector4.ZERO), fr)
		ci.draw_rect(Rect2(fr.position + Vector2(fr.size.y * 0.4, 1), Vector2(maxf(0.0, fr.size.x - fr.size.y * 0.8), fr.size.y * 0.3)), Color(1, 1, 1, 0.22))


func _draw_status() -> void:
	var lp = world.local_player
	if lp == null:
		return
	var font := UI.title_font()
	var card := UI.sb(Color(0.03, 0.035, 0.045, 0.62), Color(1, 1, 1, 0.1), 1, 16, Vector4.ZERO)
	status.draw_style_box(card, Rect2(Vector2.ZERO, status.size))
	var mh := Net.max_hp(lp.peer_id)
	var hpf := _hp_shown / maxf(mh, 1.0)
	var hc := Color(0.35, 0.95, 0.5).lerp(Color(1.0, 0.3, 0.25), clampf(1.0 - hpf * 2.2 + 0.3, 0.0, 1.0))
	Icons.draw(status, "heart", Vector2(28, 28), 26.0, Color(1.0, 0.35, 0.35))
	_bar(status, Rect2(48, 17, 206, 22), hpf, hc, _hp_ghost / maxf(mh, 1.0))
	status.draw_string(font, Vector2(262, 37), str(int(ceil(lp.hp))), HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(1, 1, 1))
	var ms := Net.max_stamina(lp.peer_id)
	var sf: float = lp.stamina / maxf(ms, 1.0)
	var sc := Color(0.35, 0.75, 1.0) if lp.stam_block <= 0.0 else Color(0.5, 0.5, 0.55)
	Icons.draw(status, "bolt", Vector2(28, 60), 26.0, Color(1.0, 0.85, 0.3))
	_bar(status, Rect2(48, 51, 206, 16), sf, sc)
	status.draw_string(font, Vector2(262, 67), str(int(lp.stamina)), HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color(0.85, 0.9, 1.0))
	var info := "%s  ·  $%s" % [Settings.t("hud_level") % world.level_num, Settings.money(Net.money)]
	status.draw_string(UI.font("Rubik-Medium"), Vector2(16, 94), info, HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color(1.0, 0.82, 0.5))
	if lp.under_cover:
		status.draw_string(font, Vector2(226, 94), Settings.t("hidden_tag"), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, UI.GOOD)


# ------------------------------------------------------------------ objective

func _update_objective() -> void:
	_obj_prog = -1.0
	_obj_sub = ""
	_obj_col = Color(1, 1, 1)
	if world.shop_mode:
		_obj_text = Settings.t("obj_shop") % [Settings.money(Net.money)]
		if world.basket > 0:
			_obj_sub = Settings.t("basket") + ": $" + Settings.money(world.basket)
		_obj_col = UI.ACCENT2
		return
	if world.arena_mode:
		var alive := 0
		for p in world.players.values():
			if not p.dead:
				alive += 1
		_obj_text = Settings.t("arena_obj") % alive
		_obj_col = Color(1.0, 0.4, 0.3)
		return
	if not world.started:
		_obj_text = Settings.t("obj_wait")
	elif world.all_done:
		_obj_text = Settings.t("obj_truck")
		_obj_col = Color(1.0, 0.85, 0.3)
	elif world.extracting:
		_obj_text = Settings.t("obj_extracting")
		_obj_col = UI.GOOD
	elif world.active_extr >= 0 and world.active_extr < world.extr.size():
		var e: Dictionary = world.extr[world.active_extr]
		_obj_text = Settings.t("obj_extract") % [world.active_extr + 1, world.extr.size(), Settings.money_k(e["value"]), Settings.money_k(e["goal"])]
		if e["goal"] > 0:
			_obj_prog = clampf(float(e["value"]) / float(e["goal"]), 0.0, 1.0)
		if e["value"] >= e["goal"] and e["goal"] > 0:
			_obj_sub = Settings.t("obj_ready")
			_obj_col = UI.GOOD


func _draw_objective() -> void:
	var font := UI.title_font()
	var fs := 22
	var tw := font.get_string_size(_obj_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var sub_w := 0.0
	if _obj_sub != "":
		sub_w = UI.font("Rubik-Medium").get_string_size(_obj_sub, HORIZONTAL_ALIGNMENT_LEFT, -1, 17).x
	var w := clampf(maxf(tw, sub_w) + 48.0, 260.0, 640.0)
	var h := 38.0 + (14.0 if _obj_prog >= 0.0 else 0.0) + (22.0 if _obj_sub != "" else 0.0)
	var r := Rect2(Vector2((obj_ctrl.size.x - w) / 2.0, 0), Vector2(w, h))
	obj_ctrl.draw_style_box(UI.sb(Color(0.03, 0.035, 0.045, 0.66), Color(1, 1, 1, 0.1), 1, 18, Vector4.ZERO), r)
	obj_ctrl.draw_string(font, Vector2(r.position.x, 27), _obj_text, HORIZONTAL_ALIGNMENT_CENTER, w, fs, _obj_col)
	var y := 36.0
	if _obj_prog >= 0.0:
		_bar(obj_ctrl, Rect2(r.position.x + 20, y, w - 40, 10), _obj_prog, UI.GOOD if _obj_prog >= 1.0 else UI.ACCENT)
		y += 14.0
	if _obj_sub != "":
		var pulse := 0.75 + 0.25 * sin(Time.get_ticks_msec() * 0.008)
		obj_ctrl.draw_string(UI.font("Rubik-Medium"), Vector2(r.position.x, y + 16), _obj_sub, HORIZONTAL_ALIGNMENT_CENTER, w, 17, Color(_obj_col, pulse))


# ------------------------------------------------------------------ look prompt & overlays

func _update_look(lp) -> void:
	var txt := ""
	if lp.dead:
		txt = ""
	elif lp.grabbed_id > 0:
		var it = world.items.get(lp.grabbed_id)
		if it:
			txt = it.display_name()
			if it.base_value > 0:
				txt += "   $" + Settings.money(it.value)
			elif it.type == "cart" or it.type == "i_pocketcart":
				txt += "   $" + Settings.money(it.cart_total)
				txt += "\n" + Settings.t("cart_strong" if (lp.grab_offset.x < (-0.45 if it.type == "cart" else -0.28)) else "cart_weak")
			if lp.heavy_warn_t > 0.0:
				txt += "\n" + Settings.t("too_heavy")
			if it.owned:
				txt += "\n" + Settings.t("press_use_item")
			if ItemDefs.is_gear(it.type) and _uses_battery(it.type):
				txt += "\n⚡ %s %d%%" % [Settings.t("battery"), int(round(it.battery * 100.0))]
				if it.battery < 0.05:
					txt += "  " + Settings.t("to_charge")
	elif lp.look_item != null and is_instance_valid(lp.look_item):
		var it = lp.look_item
		txt = it.display_name()
		if it.owned:
			txt += "  [" + Settings.t("owned_tag") + "]\n" + Settings.t("press_use_item")
		elif it.base_value > 0:
			txt += "   $" + Settings.money(it.value)
		elif it.type == "cart" or it.type == "i_pocketcart":
			txt += "   $" + Settings.money(it.cart_total) + "\n" + Settings.t("cart_hint")
	elif lp.look_mimic != null and is_instance_valid(lp.look_mimic):
		txt = Settings.t("item_chest") + "   $????"
	elif lp.look_interact != null and is_instance_valid(lp.look_interact):
		var what := str(lp.look_interact.get_meta("interact"))
		txt = Settings.t("press_extract") if what == "extract" else (Settings.t("press_buy") if what == "buy" else Settings.t("press_truck"))
	lbl_look.text = txt
	look_pill.visible = txt != ""
	if look_pill.visible:
		look_pill.reset_size()


static func _uses_battery(t: String) -> bool:
	return not (t.begins_with("g_") or t.begins_with("m_") or t.begins_with("med_") or t == "i_crystal" or t == "i_pocketcart")


func _update_overlay(lp) -> void:
	var c := Color(0, 0, 0, 0)
	if lp.eff_vomit_t > 0.0:
		c = Color(0.35, 0.6, 0.05, 0.35)
	elif lp.eff_lock_t > 0.0:
		c = Color(0.9, 0.1, 0.5, 0.22 + 0.08 * sin(Time.get_ticks_msec() * 0.02))
	elif lp.eff_stun_t > 0.0:
		c = Color(0.8, 0.9, 1.0, 0.3)
	elif lp.eff_carry_t > 0.0:
		c = Color(0.1, 0.0, 0.2, 0.45)
	elif lp.tumbling:
		c = Color(0.0, 0.0, 0.0, 0.12)
	fx_overlay.color = fx_overlay.color.lerp(c, 0.2)


func _draw_crosshair() -> void:
	var lp = world.local_player
	if lp == null:
		return
	var col := Color(1, 1, 1, 0.85)
	var r := 3.0
	var ring := 0.0
	if lp.look_item != null or lp.look_interact != null:
		col = Color(1.0, 0.62, 0.18)
		r = 4.0
		ring = 11.0
	if lp.grabbed_id != -1:
		col = UI.ACCENT
		ring = 14.0
	crosshair.draw_circle(Vector2.ZERO, r + 1.5, Color(0, 0, 0, 0.45))
	crosshair.draw_circle(Vector2.ZERO, r, col)
	if ring > 0.0:
		crosshair.draw_arc(Vector2.ZERO, ring, 0, TAU, 32, Color(0, 0, 0, 0.35), 4.0, true)
		crosshair.draw_arc(Vector2.ZERO, ring, 0, TAU, 32, col, 2.0, true)
	# damage direction wedges around the crosshair
	if lp.cam:
		var fwd: Vector3 = -lp.cam.global_basis.z
		fwd.y = 0.0
		for h in _hits:
			var dir: Vector3 = h["dir"]
			dir.y = 0.0
			if fwd.length() < 0.01 or dir.length() < 0.01:
				continue
			var ang: float = fwd.normalized().signed_angle_to(dir.normalized(), Vector3.UP)
			var a0: float = -PI / 2 - ang
			var alpha: float = clampf(h["t"], 0.0, 1.0)
			crosshair.draw_arc(Vector2.ZERO, 150.0, a0 - 0.35, a0 + 0.35, 24, Color(1.0, 0.15, 0.1, 0.85 * alpha), 10.0, true)
			crosshair.draw_arc(Vector2.ZERO, 150.0, a0 - 0.2, a0 + 0.2, 16, Color(1.0, 0.6, 0.5, 0.6 * alpha), 4.0, true)
	# detection eye: fills while a monster is noticing you, red when hunted
	if Settings.show_detect and _alert > 0.05 and not lp.dead:
		var c := Vector2(0, -48)
		var hunted := _alert > 1.2
		var a := clampf(_alert, 0.0, 1.0)
		var ec := Color(1.0, 0.85, 0.3, 0.35 + 0.6 * a)
		if hunted:
			ec = Color(1.0, 0.25, 0.2, 0.75 + 0.25 * sin(Time.get_ticks_msec() * 0.015))
		crosshair.draw_circle(c, 22.0, Color(0, 0, 0, 0.35))
		if not hunted:
			crosshair.draw_arc(c, 22.0, -PI / 2, -PI / 2 + TAU * a, 32, ec, 3.0, true)
		else:
			crosshair.draw_arc(c, 22.0, 0, TAU, 32, ec, 3.0, true)
		Icons.draw(crosshair, "eye", c, 30.0, ec, 2.5)


# ------------------------------------------------------------------ tracker compass

## Direction finder: shown in the shop and while holding a charged tracker (the level itself has no compass).
func _tracker_target(lp) -> Array:
	if world.shop_mode:
		return [world.objective_pos(), Color(0.35, 1.0, 0.5)]
	if lp.grabbed_id <= 0:
		return []
	var it = world.items.get(lp.grabbed_id)
	if it == null or it.battery <= 0.0:
		return []
	if it.type == "t_extract":
		return [world.objective_pos(), Color(1.0, 0.85, 0.2) if world.all_done else Color(0.35, 1.0, 0.5)]
	if it.type == "t_valuable":
		var best = null
		var bd := 1e9
		for o in world.items.values():
			if o.base_value <= 0 or o.type == "orb" or o.type == "head" or ItemDefs.is_gear(o.type):
				continue
			if world.item_in_zone(o):
				continue
			var d: float = o.global_position.distance_to(lp.global_position)
			if d < bd and d > 1.5:
				bd = d
				best = o
		if best:
			return [best.global_position, Color(1.0, 0.8, 0.25)]
	return []


func _draw_compass() -> void:
	var lp = world.local_player
	if lp == null or lp.cam == null or not world.started:
		return
	var tr := _tracker_target(lp)
	if tr.is_empty():
		return
	var target: Vector3 = tr[0]
	var cam: Camera3D = lp.cam
	var fwd := -cam.global_basis.z
	fwd.y = 0.0
	var to := target - cam.global_position
	var distm := to.length()
	to.y = 0.0
	if fwd.length() < 0.01 or to.length() < 0.01:
		return
	var ang := fwd.normalized().signed_angle_to(to.normalized(), Vector3.UP)
	var c := compass.size / 2.0
	var x := clampf(-ang / PI, -1.0, 1.0) * 250.0
	var col: Color = tr[1]
	compass.draw_style_box(UI.sb(Color(0.03, 0.035, 0.045, 0.5), Color(0, 0, 0, 0), 0, 14, Vector4.ZERO), Rect2(c.x - 270, c.y - 14, 540, 28))
	for i in range(-4, 5):
		compass.draw_line(Vector2(c.x + i * 62.5, c.y - 4), Vector2(c.x + i * 62.5, c.y + 4), Color(1, 1, 1, 0.25), 2.0)
	compass.draw_line(Vector2(c.x, c.y - 10), Vector2(c.x, c.y + 10), Color(1, 1, 1, 0.5), 2.0)
	var p := Vector2(c.x + x, c.y)
	compass.draw_colored_polygon(PackedVector2Array([p + Vector2(0, -12), p + Vector2(10, 7), p + Vector2(-10, 7)]), col)
	compass.draw_string(UI.title_font(), p + Vector2(14, 8), "%d m" % int(distm), HORIZONTAL_ALIGNMENT_LEFT, -1, 17, col)


# ------------------------------------------------------------------ slots

func slot_rect(i: int) -> Rect2:
	var o := slot_bar.global_position
	return Rect2(o + Vector2(i * (SLOT_W + SLOT_GAP), 0), Vector2(SLOT_W, SLOT_H))


func _draw_slots() -> void:
	var lp = world.local_player
	if lp == null or lp.dead:
		return
	var inv: Array = Net.inv_of(lp.peer_id)
	var font := UI.font("Rubik-Medium")
	var held_store := false
	if lp.grabbed_id > 0:
		var hi = world.items.get(lp.grabbed_id)
		held_store = hi != null and ItemDefs.can_store(hi.type)
	var pulse := 0.6 + 0.4 * sin(Time.get_ticks_msec() * 0.008)
	for i in 3:
		var r := Rect2(Vector2(i * (SLOT_W + SLOT_GAP), 0), Vector2(SLOT_W, SLOT_H))
		var e = inv[i] if i < inv.size() else null
		var border := Color(1, 1, 1, 0.16)
		var bw := 1
		if e == null and held_store:
			border = Color(UI.ACCENT, pulse)
			bw = 2
		elif e != null:
			border = Color(1.0, 0.8, 0.35, 0.6)
			bw = 2
		slot_bar.draw_style_box(UI.sb(Color(0.03, 0.035, 0.045, 0.62), border, bw, 14, Vector4.ZERO), r)
		slot_bar.draw_circle(r.position + Vector2(14, 14), 10.0, Color(1, 1, 1, 0.14))
		slot_bar.draw_string(UI.title_font(), r.position + Vector2(8.5, 20), str(i + 1), HORIZONTAL_ALIGNMENT_CENTER, 11, 14, Color(1, 1, 1, 0.8))
		if e == null:
			Icons.draw(slot_bar, "star", r.get_center() + Vector2(0, -4), 18.0, Color(1, 1, 1, 0.07))
			continue
		var t: String = e["t"]
		var col := Color(1.0, 0.86, 0.55)
		Icons.draw(slot_bar, Icons.for_item(t), r.position + Vector2(SLOT_W / 2.0, 30), 32.0, col)
		var nm: String = Settings.t("item_" + t)
		var fs := 13 if nm.length() < 14 else 11
		slot_bar.draw_string(font, r.position + Vector2(4, 60), nm, HORIZONTAL_ALIGNMENT_CENTER, SLOT_W - 8, fs, Color(0.95, 0.92, 0.85))
		if _uses_battery(t):
			var b := float(e.get("b", 1.0))
			var br := Rect2(r.position + Vector2(12, SLOT_H - 11), Vector2(SLOT_W - 24, 6))
			var bc := Color(0.3, 0.95, 0.4) if b > 0.35 else (Color(1.0, 0.8, 0.2) if b > 0.1 else Color(1.0, 0.25, 0.2))
			slot_bar.draw_rect(br, Color(0, 0, 0, 0.6))
			slot_bar.draw_rect(Rect2(br.position, Vector2(br.size.x * clampf(b, 0.0, 1.0), br.size.y)), bc)


# ------------------------------------------------------------------ tutorial

func _tutorial(lp, delta: float) -> void:
	if tut_step < 0:
		tut_pill.visible = false
		return
	var keys := ["tut_move", "tut_grab", "tut_carry", "tut_button", "tut_hide"]
	if tut_step == 0 and _tut_start == Vector3.ZERO:
		_tut_start = lp.global_position
	match tut_step:
		0:
			if lp.global_position.distance_to(_tut_start) > 3.0:
				tut_step = 1
		1:
			if lp.grabbed_ever:
				tut_step = 2
		2:
			if world.active_extr >= 0 and world.extr[world.active_extr]["value"] > 0:
				tut_step = 3
		3:
			if world.active_extr != 0 or world.all_done:
				tut_step = 4
				tut_t = 9.0
		4:
			tut_t -= delta
			if tut_t <= 0.0:
				tut_step = -1
				Settings.tutorial_done = true
				Settings.save_cfg()
				tut_pill.visible = false
				return
	tut_lbl.text = Settings.t(keys[tut_step])
	tut_pill.visible = true
	tut_pill.reset_size()
	tut_pill.modulate.a = 0.8 + 0.2 * sin(Time.get_ticks_msec() * 0.005)


# ------------------------------------------------------------------ map

func _draw_map() -> void:
	var g = world.gen
	if g == null:
		return
	var sz := map_ctrl.size
	map_ctrl.draw_style_box(UI.sb(Color(0.03, 0.035, 0.045, 0.82), Color(UI.ACCENT, 0.7), 2, 16, Vector4.ZERO), Rect2(Vector2.ZERO, sz))
	var mn := Vector2i(999, 999)
	var mx := Vector2i(-999, -999)
	for c in g.order:
		mn = Vector2i(mini(mn.x, c.x), mini(mn.y, c.y))
		mx = Vector2i(maxi(mx.x, c.x), maxi(mx.y, c.y))
	var span := maxi(mx.x - mn.x + 1, mx.y - mn.y + 1)
	var cell := (sz.x - 28.0) / span
	var off := Vector2(14, 14) + Vector2((span - (mx.x - mn.x + 1)) * cell * 0.5, (span - (mx.y - mn.y + 1)) * cell * 0.5)
	var to_map := func(p: Vector3) -> Vector2:
		return off + Vector2((p.x / 8.0 - mn.x + 0.5) * cell, (p.z / 8.0 - mn.y + 0.5) * cell)
	for k in g.conn:
		var a: Vector2i = g.conn[k]["a"]
		var b: Vector2i = g.conn[k]["b"]
		if world.visited.has(a) or world.visited.has(b):
			map_ctrl.draw_line(to_map.call(g.cell_center(a)), to_map.call(g.cell_center(b)), Color(0.8, 0.8, 0.8, 0.5), maxf(2.0, cell * 0.2))
	for c in g.order:
		var r := Rect2(off + Vector2((c.x - mn.x) * cell + cell * 0.12, (c.y - mn.y) * cell + cell * 0.12), Vector2(cell * 0.76, cell * 0.76))
		if world.visited.has(c):
			map_ctrl.draw_style_box(UI.sb(Color(0.32, 0.33, 0.38, 0.95), Color(1, 1, 1, 0.15), 1, 4, Vector4.ZERO), r)
		else:
			map_ctrl.draw_rect(r, Color(0.3, 0.3, 0.35, 0.25), false, 1.0)
	for i in world.extr.size():
		var e: Dictionary = world.extr[i]
		var col := Color(0.3, 0.6, 1.0) if e["done"] else (UI.GOOD if i == world.active_extr else Color(0.5, 0.5, 0.5))
		map_ctrl.draw_circle(to_map.call(e["pos"]), cell * 0.2, col)
	var tp: Vector2 = to_map.call(world.truck_pos)
	map_ctrl.draw_rect(Rect2(tp - Vector2(cell, cell) * 0.16, Vector2(cell, cell) * 0.32), Color(1.0, 0.8, 0.2))
	for p in world.players.values():
		if p.dead:
			continue
		var pp: Vector2 = to_map.call(p.global_position)
		if p.is_local:
			var fw := Vector2(-sin(p.yaw), -cos(p.yaw))
			var sd := Vector2(fw.y, -fw.x)
			map_ctrl.draw_colored_polygon(PackedVector2Array([pp + fw * 10.0, pp - fw * 6.0 + sd * 7.0, pp - fw * 6.0 - sd * 7.0]), Color(1, 1, 1))
		else:
			map_ctrl.draw_circle(pp, 6.0, p.color)


func _exit_tree() -> void:
	get_tree().paused = false
