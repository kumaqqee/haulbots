extends Control
## Animated loading screen: key art with a slow push-in, flickering work lamp, drifting dust and
## fog, the rusty HAULBOTS logo and a striped progress bar. Used at boot (warms up the resource
## cache with real progress) and as a short cover between levels.

signal finished

const BG_PATH := "res://assets/ui/loading_bg.jpg"
const TITLE := preload("res://assets/ui/title.png")
const UI = preload("res://scripts/ui/ui.gd")
const LAMP_UV := Vector2(462.0 / 1376.0, 190.0 / 768.0)   # the caged lamp in the key art

var min_time := 2.4
var paths: Array = []

var _bg: TextureRect
var _glow: TextureRect
var _title: TextureRect
var _fill: ColorRect
var _pct: Label
var _tip: Label
var _bar: Panel
var _t := 0.0
var _shown := 0.0
var _done := 0
var _pending := []
var _loaded := []
var _flicker := 1.0
var _flick_t := 0.0
var _finishing := false
static var _bg_tex: Texture2D = null


static func bg_texture() -> Texture2D:
	if _bg_tex == null:
		# the jpg is exported as-is ("keep" import): read the raw bytes
		var bytes := FileAccess.get_file_as_bytes(BG_PATH)
		var img := Image.new()
		if not bytes.is_empty() and img.load_jpg_from_buffer(bytes) == OK:
			_bg_tex = ImageTexture.create_from_image(img)
	return _bg_tex


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var black := ColorRect.new()
	black.color = Color(0.01, 0.01, 0.012)
	black.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(black)
	_bg = TextureRect.new()
	_bg.texture = bg_texture()
	_bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_bg)
	# fog drifting across the scene
	var fog := ColorRect.new()
	fog.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fog.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fm := ShaderMaterial.new()
	var fs := Shader.new()
	fs.code = """shader_type canvas_item;
uniform sampler2D noise_tex : repeat_enable, filter_linear;
void fragment() {
	vec2 uv = UV * vec2(1.6, 0.9);
	float n = texture(noise_tex, uv * 0.7 + vec2(TIME * 0.012, TIME * 0.004)).r;
	float n2 = texture(noise_tex, uv * 1.3 - vec2(TIME * 0.02, -TIME * 0.006)).r;
	float f = smoothstep(0.35, 0.95, n * 0.6 + n2 * 0.5);
	float low = smoothstep(0.2, 1.0, UV.y);
	COLOR = vec4(0.55, 0.45, 0.38, f * 0.16 * (0.4 + low));
}"""
	fm.shader = fs
	var nt := NoiseTexture2D.new()
	nt.width = 256
	nt.height = 256
	nt.seamless = true
	var fn := FastNoiseLite.new()
	fn.frequency = 0.012
	fn.fractal_octaves = 4
	nt.noise = fn
	fm.set_shader_parameter("noise_tex", nt)
	fog.material = fm
	add_child(fog)
	# warm glow of the lamp (additive, flickers)
	_glow = TextureRect.new()
	var g := Gradient.new()
	g.set_color(0, Color(1.0, 0.62, 0.3, 0.55))
	g.add_point(0.35, Color(1.0, 0.5, 0.2, 0.18))
	g.set_color(g.get_point_count() - 1, Color(1.0, 0.45, 0.15, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 128
	gt.height = 128
	_glow.texture = gt
	_glow.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_glow.size = Vector2(520, 520)
	_glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var add := CanvasItemMaterial.new()
	add.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_glow.material = add
	add_child(_glow)
	# dust motes in the lamp light
	var dust := CPUParticles2D.new()
	dust.amount = 70
	dust.lifetime = 7.0
	dust.preprocess = 7.0
	dust.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	dust.emission_rect_extents = Vector2(420, 260)
	dust.direction = Vector2(0.4, -1.0)
	dust.spread = 50.0
	dust.initial_velocity_min = 4.0
	dust.initial_velocity_max = 16.0
	dust.gravity = Vector2(3, -2)
	dust.scale_amount_min = 1.0
	dust.scale_amount_max = 2.6
	dust.color = Color(1.0, 0.8, 0.55, 0.55)
	var ramp := Gradient.new()
	ramp.set_color(0, Color(1, 1, 1, 0))
	ramp.add_point(0.25, Color(1, 1, 1, 1))
	ramp.set_color(ramp.get_point_count() - 1, Color(1, 1, 1, 0))
	dust.color_ramp = ramp
	dust.name = "Dust"
	add_child(dust)
	# darken the bottom for the bar
	var shade := TextureRect.new()
	var sg := Gradient.new()
	sg.set_color(0, Color(0, 0, 0, 0))
	sg.set_color(sg.get_point_count() - 1, Color(0, 0, 0, 0.8))
	var sgt := GradientTexture2D.new()
	sgt.gradient = sg
	sgt.fill_from = Vector2(0, 0.55)
	sgt.fill_to = Vector2(0, 1.0)
	sgt.width = 8
	sgt.height = 64
	shade.texture = sgt
	shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)
	# logo
	_title = TextureRect.new()
	_title.texture = TITLE
	_title.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_title.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_title)
	# progress bar: rusty frame, striped orange fill
	_bar = Panel.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.03, 0.035, 0.85)
	sb.border_color = Color(0.38, 0.22, 0.12)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(4)
	_bar.add_theme_stylebox_override("panel", sb)
	add_child(_bar)
	_fill = ColorRect.new()
	var bm := ShaderMaterial.new()
	var bs := Shader.new()
	bs.code = """shader_type canvas_item;
void fragment() {
	float s = step(0.5, fract((FRAGCOORD.x - FRAGCOORD.y) / 22.0 - TIME * 0.9));
	vec3 a = vec3(0.95, 0.46, 0.08);
	vec3 b = vec3(0.78, 0.33, 0.05);
	vec3 c = mix(b, a, s);
	float edge = smoothstep(0.0, 0.25, UV.y) * smoothstep(1.0, 0.7, UV.y);
	c *= 0.7 + 0.5 * edge;
	COLOR = vec4(c * 1.15, 1.0);
}"""
	bm.shader = bs
	_fill.material = bm
	_bar.add_child(_fill)
	_pct = UI.label("", 20, Color(0.95, 0.8, 0.6), HORIZONTAL_ALIGNMENT_LEFT)
	_pct.autowrap_mode = TextServer.AUTOWRAP_OFF
	add_child(_pct)
	_tip = UI.label(_random_tip(), 18, Color(0.75, 0.72, 0.68))
	_tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(_tip)
	for p in paths:
		if ResourceLoader.exists(p):
			if ResourceLoader.load_threaded_request(p, "", true) == OK:
				_pending.append(p)
	resized.connect(_layout)
	_layout()
	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.25)


func _random_tip() -> String:
	var n := 0
	while Settings.t("tip_%d" % n) != "tip_%d" % n:
		n += 1
	if n == 0:
		return ""
	return Settings.t("tip_%d" % (randi() % n))


func _layout() -> void:
	var vs := size
	var bw := minf(vs.x * 0.56, 760.0)
	_bar.size = Vector2(bw, 20)
	_bar.position = Vector2((vs.x - bw) * 0.5, vs.y * 0.86)
	_pct.position = _bar.position + Vector2(0, -32)
	_pct.size = Vector2(bw, 28)
	_tip.size = Vector2(bw + 120, 50)
	_tip.position = Vector2((vs.x - bw - 120) * 0.5, _bar.position.y + 30)
	var tw := minf(vs.x * 0.62, 900.0)
	_title.size = Vector2(tw, tw * 0.175)
	_title.position = Vector2((vs.x - tw) * 0.5, vs.y * 0.07)
	var d := get_node_or_null("Dust")
	if d:
		d.position = _lamp_screen_pos() + Vector2(180, 160)


## Where the lamp of the (covered, zoomed) background ends up on screen.
func _lamp_screen_pos() -> Vector2:
	var tex := _bg.texture
	if tex == null:
		return size * 0.35
	var ts := Vector2(tex.get_width(), tex.get_height())
	var sc := maxf(size.x / ts.x, size.y / ts.y) * _bg.scale.x
	var drawn := ts * sc
	var origin := (size - drawn) * 0.5 + (_bg.position - Vector2.ZERO)
	return origin + LAMP_UV * drawn


func _process(delta: float) -> void:
	_t += delta
	# slow push-in (Ken Burns)
	var z := 1.0 + minf(_t, 14.0) * 0.005
	_bg.pivot_offset = size * Vector2(0.42, 0.4)
	_bg.scale = Vector2(z, z)
	# lamp flicker: mostly steady, occasional stutter
	_flick_t -= delta
	if _flick_t <= 0.0:
		_flick_t = randf_range(0.04, 0.18) if randf() < 0.25 else randf_range(0.5, 2.2)
		_flicker = randf_range(0.35, 0.8) if randf() < 0.3 else randf_range(0.92, 1.05)
	var lp := _lamp_screen_pos()
	_glow.position = lp - _glow.size * 0.5
	_glow.modulate = Color(1, 1, 1, _flicker)
	_bg.modulate = Color(1, 1, 1).lerp(Color(0.86, 0.84, 0.82), 1.0 - _flicker)
	_title.modulate = Color(1, 1, 1).lerp(Color(0.8, 0.78, 0.76), 1.0 - _flicker)
	# real progress from threaded loads, never faster than min_time
	for p in _pending.duplicate():
		var st := ResourceLoader.load_threaded_get_status(p)
		if st == ResourceLoader.THREAD_LOAD_LOADED:
			_loaded.append(ResourceLoader.load_threaded_get(p))
			_pending.erase(p)
			_done += 1
		elif st == ResourceLoader.THREAD_LOAD_FAILED or st == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			_pending.erase(p)
			_done += 1
	var total := _done + _pending.size()
	var real := 1.0 if total == 0 else float(_done) / float(total)
	var target := minf(real, _t / min_time)
	_shown = move_toward(_shown, target, delta * 1.4)
	_fill.position = Vector2(3, 3)
	_fill.size = Vector2(maxf(0.0, (_bar.size.x - 6) * _shown), _bar.size.y - 6)
	var dots := ".".repeat(int(_t * 2.0) % 4)
	_pct.text = "%s%s   %d%%" % [Settings.t("loading"), dots, int(round(_shown * 100.0))]
	if _shown >= 0.999 and _pending.is_empty() and not _finishing:
		_finishing = true
		finished.emit()
		var tw := create_tween()
		tw.tween_interval(0.15)
		tw.tween_property(self, "modulate:a", 0.0, 0.45)
		tw.tween_callback(queue_free)


## Resources kept alive after the boot warm-up (so levels don't hitch loading them).
func loaded_resources() -> Array:
	return _loaded
