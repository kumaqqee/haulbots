"""Furniture, props, truck, extraction and shop fixtures. Origin at floor, footprint centred, front faces +Y."""
import sys, os, math, random
sys.path.insert(0, os.path.dirname(__file__))
from blib import *
import bmesh
from mathutils import Vector

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "models")
R = random.Random(11)


import bake as BK
BAKE = {"canister": 128, "medkit_s": 128, "medkit_m": 128, "medkit_l": 128, "button": 256, "extractor": 256, "sconce": 128,
        "lamp_chandelier": 256, "lamp_pendant": 128, "lamp_cage": 128, "plant": 256, "chair": 256, "crate": 256}


def save(name, parts):
    o = join(parts, name)
    if name in BAKE:
        BK.bake(name, [o], BAKE[name], ao_dist=0.15)
    export(os.path.join(OUT, name + ".glb"), [o])
    print("EXPORT", name, tris())


def save_multi(name, objs):
    export(os.path.join(OUT, name + ".glb"), objs)
    print("EXPORT", name, tris())


def turned_leg(x, y, h, material="M_wood", r=0.04):
    return lathe([(r * 0.8, 0), (r, 0.03), (r * 0.6, 0.12), (r * 0.9, 0.3 * h), (r * 0.55, 0.6 * h), (r * 0.8, 0.85 * h), (r, h)], material, 12, pos=(x, y, 0), cap_top=True)


def table():
    reset()
    p = [box((1.5, 0.8, 0.065), (0, 0, 0.79), "M_wood", 0.015)]
    p.append(box((1.36, 0.66, 0.045), (0, 0, 0.74), "M_wood_dark", 0.008))
    p.append(box((1.3, 0.6, 0.012), (0, 0, 0.828), "M_fabric", 0.004))
    for x in (-0.66, 0.66):
        for y in (-0.32, 0.32):
            p.append(turned_leg(x, y, 0.76))
    save("table", p)


def chair():
    reset()
    p = [box((0.46, 0.46, 0.06), (0, 0, 0.46), "M_wood", 0.012), box((0.4, 0.4, 0.05), (0, 0, 0.5), "M_fabric", 0.02)]
    for x in (-0.2, 0.2):
        for y in (-0.2, 0.2):
            p.append(turned_leg(x, y, 0.44, r=0.025))
    for x in (-0.2, 0.2):
        p.append(cyl(0.02, 0.55, (x, -0.21, 0.76), "M_wood", 8))
    p.append(box((0.44, 0.04, 0.2), (0, -0.21, 0.92), "M_wood", 0.015))
    p.append(box((0.3, 0.03, 0.18), (0, -0.21, 0.72), "M_wood_dark", 0.01))
    save("chair", p)


def bookshelf():
    reset()
    W = "M_wood_dark"
    p = [box((1.6, 0.04, 2.0), (0, -0.19, 1.0), W)]
    for x in (-0.78, 0.78):
        p.append(box((0.05, 0.42, 2.02), (x, 0, 1.01), W, 0.01))
    for z in (0.06, 0.7, 1.35, 1.98):
        p.append(box((1.6, 0.42, 0.04), (0, 0, z), W, 0.005))
    p.append(box((1.7, 0.46, 0.08), (0, 0.01, 2.04), W, 0.02))
    cols = ["C_6b1c1c", "C_1c3b6b", "C_2d5a2d", "C_7a5a1c", "C_3a2a4a", "C_8a8070", "C_1f1f1f"]
    for zb in (0.08,):
        x = -0.72
        while x < 0.7:
            w = R.uniform(0.04, 0.08)
            h = R.uniform(0.2, 0.3)
            if R.random() < 0.85:
                p.append(box((w, R.uniform(0.22, 0.3), h), (x + w / 2, 0.02, zb + h / 2), R.choice(cols), 0.004))
            x += w + 0.005
    # a few leaning books on the top board
    x = -0.7
    while x < -0.1:
        w = R.uniform(0.04, 0.07)
        h = R.uniform(0.22, 0.28)
        p.append(box((w, 0.24, h), (x, 0.02, 1.37 + h / 2), R.choice(cols), 0.004))
        x += w + 0.004
    save("bookshelf", p)


def cabinet():
    reset()
    p = [box((1.1, 0.5, 0.86), (0, 0, 0.52), "M_wood", 0.02)]
    p.append(box((1.16, 0.54, 0.05), (0, 0, 0.97), "M_wood_dark", 0.015))
    for x in (-0.27, 0.27):
        p.append(box((0.5, 0.02, 0.72), (x, 0.255, 0.52), "M_wood_dark", 0.01))
        p.append(sphere(0.02, (x - 0.19 * (1 if x > 0 else -1), 0.28, 0.6), "M_gold", 8, 4))
    for x in (-0.5, 0.5):
        for y in (-0.2, 0.2):
            p.append(cyl(0.03, 0.1, (x, y, 0.05), "M_wood_dark", 8, r2=0.02))
    save("cabinet", p)


def fireplace():
    reset()
    S = "M_stone"
    p = [box((0.35, 0.65, 1.2), (-0.65, 0, 0.6), S, 0.02), box((0.35, 0.65, 1.2), (0.65, 0, 0.6), S, 0.02),
         box((1.65, 0.65, 0.25), (0, 0, 1.1), S, 0.02), box((1.9, 0.75, 0.08), (0, 0.02, 1.26), "M_wood_dark", 0.02),
         box((1.0, 0.2, 0.95), (0, -0.25, 0.5), "C_0d0b0a"), box((1.0, 0.5, 0.05), (0, 0.05, 0.03), "C_1a1512")]
    for i in range(3):
        p.append(cyl(0.05, 0.6, (0, 0.0 + i * 0.05, 0.1 + i * 0.07), "M_wood_dark", 8, rot=(0, math.pi / 2, 0.3 * i)))
    p.append(box((0.7, 0.3, 0.05), (0, 0.02, 0.07), "E_ff5a10", 0.02))
    save("fireplace", p)


def bed():
    reset()
    # raised four-poster frame: there is room to crawl underneath
    p = [box((1.5, 2.0, 0.2), (0, 0.0, 0.86), "M_wood_dark", 0.03),
         box((1.4, 1.9, 0.16), (0, 0.02, 1.03), "C_e8e4da", 0.06, 3),
         box((1.46, 1.3, 0.08), (0, 0.35, 1.12), "M_fabric", 0.04, 3),
         box((1.52, 1.25, 0.25), (0, 0.35, 0.96), "M_fabric", 0.02),
         box((1.6, 0.1, 1.6), (0, -0.95, 0.8), "M_wood_dark", 0.03),
         box((1.3, 0.12, 0.35), (0, -0.95, 1.35), "M_wood", 0.04),
         box((1.6, 0.08, 0.5), (0, 0.97, 0.95), "M_wood_dark", 0.02),
         box((0.55, 0.3, 0.14), (-0.33, -0.7, 1.16), "C_f0ede5", 0.06, 3),
         box((0.55, 0.3, 0.14), (0.33, -0.7, 1.16), "C_f0ede5", 0.06, 3)]
    for x in (-0.7, 0.7):
        for y in (-0.93, 0.93):
            p.append(turned_leg(x, y, 0.78, "M_wood_dark", 0.05))
    for x in (-0.72, 0.72):
        p.append(cyl(0.045, 1.8, (x, -0.95, 0.9), "M_wood_dark", 12))
        p.append(sphere(0.065, (x, -0.95, 1.83), "M_gold", 12, 6))
    save("bed", p)


def crate():
    reset()
    p = [box((0.8, 0.8, 0.8), (0, 0, 0.4), "M_wood", 0.01)]
    for z in (0.05, 0.75):
        for y in (-0.4, 0.4):
            p.append(box((0.84, 0.04, 0.1), (0, y, z), "M_wood_dark", 0.005))
        for x in (-0.4, 0.4):
            p.append(box((0.04, 0.84, 0.1), (x, 0, z), "M_wood_dark", 0.005))
    for x in (-0.4, 0.4):
        for y in (-0.4, 0.4):
            p.append(box((0.1, 0.1, 0.8), (x, y, 0.4), "M_wood_dark", 0.005))
    p.append(box((0.9, 0.04, 0.1), (0, 0.41, 0.4), "M_wood_dark", rot=(0, 0.78, 0)))
    save("crate", p)


def sofa():
    reset()
    F = "M_fabric"
    p = [box((1.9, 0.8, 0.3), (0, 0, 0.25), F, 0.06, 3),
         box((1.9, 0.22, 0.7), (0, -0.3, 0.6), F, 0.08, 3)]
    for x in (-0.46, 0.46):
        p.append(box((0.9, 0.62, 0.16), (x, 0.08, 0.47), F, 0.07, 3))
        p.append(box((0.85, 0.16, 0.45), (x, -0.16, 0.72), F, 0.07, 3))
    for x in (-0.92, 0.92):
        p.append(box((0.18, 0.8, 0.55), (x, 0, 0.45), F, 0.08, 3))
    for x in (-0.85, 0.85):
        for y in (-0.33, 0.33):
            p.append(cyl(0.03, 0.1, (x, y, 0.05), "M_wood_dark", 8))
    save("sofa", p)


def piano():
    reset()
    B = "C_0c0b0b"
    p = [box((1.5, 0.6, 1.2), (0, -0.05, 0.62), B, 0.02),
         box((1.5, 0.3, 0.08), (0, 0.3, 0.76), B, 0.01),
         box((1.3, 0.2, 0.03), (0, 0.32, 0.8), "C_f2f0ea"),
         box((1.52, 0.62, 0.05), (0, -0.05, 1.24), B, 0.02),
         box((0.8, 0.02, 0.3), (0, 0.26, 1.0), "M_wood_dark", 0.01)]
    for i in range(18):
        p.append(box((0.03, 0.12, 0.025), (-0.6 + i * 0.07 + 0.035, 0.28, 0.82), B))
    for x in (-0.68, 0.68):
        p.append(box((0.08, 0.35, 0.72), (x, 0.2, 0.36), B, 0.01))
    p.append(box((0.8, 0.35, 0.08), (0, 0.9, 0.46), B, 0.02))
    for x in (-0.35, 0.35):
        p.append(cyl(0.025, 0.44, (x, 0.9, 0.22), B, 8))
    save("piano", p)


def pedestal():
    reset()
    p = [lathe([(0.35, 0), (0.35, 0.1), (0.28, 0.12), (0.25, 0.16), (0.24, 0.84), (0.27, 0.88), (0.34, 0.92), (0.35, 1.0), (0.0, 1.0)], "M_marble", 32)]
    save("pedestal", p)


def bench():
    reset()
    p = [box((1.6, 0.5, 0.07), (0, 0, 0.44), "M_wood", 0.015)]
    for x in (-0.7, 0.7):
        p.append(box((0.08, 0.45, 0.4), (x, 0, 0.2), "M_dark_metal", 0.01))
    save("bench", p)


def display_case():
    reset()
    p = [box((1.2, 0.6, 0.88), (0, 0, 0.44), "M_wood_dark", 0.02),
         box((1.26, 0.66, 0.04), (0, 0, 0.9), "M_gold", 0.01),
         box((1.1, 0.02, 0.5), (0, 0.305, 0.45), "G_d8eaff")]
    save("case", p)


def labbench():
    reset()
    p = [box((1.84, 0.8, 0.1), (0, 0, 0.84), "C_1e2226", 0.01),
         box((1.8, 0.06, 0.8), (0, -0.36, 0.45), "C_d9dde2", 0.01),
         box((0.07, 0.72, 0.8), (-0.86, 0, 0.4), "C_d9dde2", 0.01),
         box((0.07, 0.72, 0.8), (0.86, 0, 0.4), "C_d9dde2", 0.01),
         box((1.7, 0.7, 0.04), (0, 0, 0.77), "C_bfc5cc", 0.005),
         box((0.4, 0.3, 0.06), (0.55, 0, 0.87), "M_metal", 0.01),
         cyl(0.015, 0.3, (0.55, -0.12, 1.03), "M_chrome", 8),
         box((0.02, 0.15, 0.02), (0.55, -0.05, 1.18), "M_chrome")]
    for x in (-0.7, 0.7):
        p.append(box((0.06, 0.05, 0.05), (x, 0.38, 0.72), "M_chrome", 0.01))
    save("labbench", p)


def rack():
    reset()
    p = [box((0.8, 0.8, 2.1), (0, 0, 1.05), "C_111317", 0.015)]
    for i in range(12):
        z = 0.2 + i * 0.15
        p.append(box((0.7, 0.02, 0.11), (0, 0.4, z), "C_22262c", 0.004))
        for k in range(3):
            p.append(box((0.02, 0.01, 0.015), (-0.28 + k * 0.03, 0.412, z), "E_33ff66" if (i + k) % 3 else "E_3399ff"))
    save("rack", p)


def desk():
    reset()
    p = [box((1.4, 0.7, 0.05), (0, 0, 0.73), "M_wood", 0.01),
         box((0.08, 0.66, 0.7), (-0.64, 0, 0.36), "M_wood_dark"),
         box((0.42, 0.66, 0.7), (0.47, 0, 0.36), "M_wood_dark", 0.01),
         box((0.5, 0.05, 0.34), (-0.2, -0.2, 0.98), "C_101012", 0.01),
         box((0.46, 0.01, 0.3), (-0.2, -0.17, 0.98), "E_1b3b5a"),
         box((0.06, 0.08, 0.2), (-0.2, -0.22, 0.83), "C_101012"),
         box((0.4, 0.14, 0.02), (-0.15, 0.08, 0.765), "C_2a2a2e", 0.004)]
    save("desk", p)


def plant():
    reset()
    p = [lathe([(0.14, 0), (0.18, 0.35), (0.2, 0.38), (0.17, 0.38)], "C_8a4a2a", 16, cap_bottom=True)]
    for i in range(9):
        a = i * 2.4
        l = sphere(0.12, (math.cos(a) * 0.12, math.sin(a) * 0.12, 0.55 + (i % 3) * 0.12), "C_2a5a24", 8, 4, (1.6, 0.5, 0.35))
        l.rotation_euler = (0.4, 0, a)
        p.append(l)
    save("plant", p)


def lamps():
    # chandelier (mansion)
    reset()
    p = [cyl(0.015, 0.5, (0, 0, -0.25), "M_gold", 8), sphere(0.08, (0, 0, -0.5), "M_gold", 12, 6)]
    ring = lathe([(0.35, -0.56), (0.37, -0.56), (0.37, -0.53), (0.35, -0.53)], "M_gold", 24, cap_bottom=False)
    p.append(ring)
    for i in range(6):
        a = i * math.pi / 3
        x, y = math.cos(a) * 0.36, math.sin(a) * 0.36
        p.append(cyl(0.02, 0.1, (x, y, -0.49), "C_f2ead5", 8))
        p.append(sphere(0.025, (x, y, -0.42), "E_ffcc66", 8, 4, (1, 1, 1.6)))
    save("lamp_chandelier", p)
    reset()
    save("lamp_pendant", [cyl(0.01, 0.4, (0, 0, -0.2), "C_222222", 6),
                          lathe([(0.03, -0.4), (0.25, -0.62), (0.26, -0.63)], "C_2a2a2a", 20, cap_bottom=False),
                          sphere(0.07, (0, 0, -0.55), "E_fff0cc", 10, 5)])
    reset()
    save("lamp_tube", [box((1.2, 0.2, 0.06), (0, 0, -0.05), "C_d0d4d8", 0.01), box((1.1, 0.12, 0.03), (0, 0, -0.09), "E_e8f4ff", 0.01)])
    reset()
    save("lamp_cage", [cyl(0.12, 0.1, (0, 0, -0.05), "M_dark_metal", 12), sphere(0.08, (0, 0, -0.16), "E_fff6dd", 10, 5)] +
         [box((0.01, 0.01, 0.16), (math.cos(a) * 0.1, math.sin(a) * 0.1, -0.16), "M_dark_metal") for a in [0, 1.57, 3.14, 4.71]])
    reset()
    save("sconce", [box((0.12, 0.05, 0.2), (0, -0.02, 0), "M_gold", 0.01), cyl(0.012, 0.15, (0, 0.06, 0.05), "M_gold", 6, rot=(1.2, 0, 0)),
                    lathe([(0.04, 0.08), (0.08, 0.2), (0.085, 0.21)], "C_f0dcaa", 16, pos=(0, 0.12, 0.0), cap_bottom=False),
                    sphere(0.03, (0, 0.12, 0.12), "E_ffd080", 8, 4)])


def window():
    reset()
    p = [box((1.4, 0.12, 1.5), (0, 0, 0), "M_wood_dark", 0.02),
         box((1.2, 0.13, 1.3), (0, 0.005, 0), "E_203a6a"),
         box((0.05, 0.14, 1.3), (0, 0.01, 0), "M_wood_dark"), box((1.2, 0.14, 0.05), (0, 0.01, 0), "M_wood_dark"),
         box((1.5, 0.22, 0.06), (0, 0.06, -0.78), "M_wood_dark", 0.01)]
    save("window", p)


def truck():
    reset()
    B = "C_2b4a6e"
    p = []
    # cargo box (open at +Y), floor at z 0.45
    p.append(box((2.4, 3.2, 0.12), (0, 0, 0.45), "M_metal"))
    p.append(box((0.08, 3.2, 2.2), (-1.2, 0, 1.6), B, 0.02))
    p.append(box((0.08, 3.2, 2.2), (1.2, 0, 1.6), B, 0.02))
    p.append(box((2.48, 3.2, 0.08), (0, 0, 2.7), B, 0.02))
    p.append(box((2.4, 0.08, 2.2), (0, -1.6, 1.6), B))
    for z in (0.9, 1.5, 2.1):
        p.append(box((0.03, 3.1, 0.04), (-1.15, 0, z), "M_chrome"))
        p.append(box((0.03, 3.1, 0.04), (1.15, 0, z), "M_chrome"))
    # stripe + logo panel
    p.append(box((0.1, 3.0, 0.2), (1.25, 0, 1.9), "C_f08a18"))
    p.append(box((0.1, 3.0, 0.2), (-1.25, 0, 1.9), "C_f08a18"))
    # cab
    p.append(box((2.3, 1.5, 1.4), (0, -2.45, 1.15), B, 0.08, 3))
    p.append(box((2.2, 1.2, 0.8), (0, -2.6, 2.1), B, 0.1, 3))
    p.append(box((2.0, 0.05, 0.6), (0, -3.18, 2.1), "E_203048", 0.02))
    p.append(box((2.3, 0.2, 0.3), (0, -3.25, 0.7), "M_chrome", 0.05))
    for x in (-0.85, 0.85):
        p.append(box((0.3, 0.05, 0.15), (x, -3.22, 1.15), "E_fff4c8", 0.02))
    # wheels
    for x in (-1.15, 1.15):
        for y in (-2.4, -0.2, 1.0):
            p.append(cyl(0.42, 0.3, (x, y, 0.42), "M_rubber", 20, rot=(0, math.pi / 2, 0), bevel=0.04))
            p.append(cyl(0.22, 0.32, (x, y, 0.42), "M_chrome", 12, rot=(0, math.pi / 2, 0)))
    # inside: a small monitor on the front wall for quota
    p.append(box((0.9, 0.08, 0.55), (0, -1.54, 1.9), "C_101012", 0.02))
    p.append(box((0.8, 0.02, 0.45), (0, -1.5, 1.9), "E_12302a"))
    # rear lights
    for x in (-1.1, 1.1):
        p.append(box((0.1, 0.05, 0.25), (x, 1.62, 0.8), "E_ff2010"))
    save("truck", p)


def extractor():
    """Console that stands next to an extraction zone; screen faces +Y."""
    reset()
    p = [box((0.5, 0.45, 0.12), (0, 0, 0.06), "M_dark_metal", 0.02),
         box((0.36, 0.32, 0.9), (0, 0, 0.55), "C_3a3f46", 0.04),
         box((0.4, 0.36, 0.08), (0, 0.02, 1.02), "M_dark_metal", 0.02),
         box((0.3, 0.02, 0.22), (0, 0.17, 0.7), "E_14402a", 0.01),
         box((0.04, 0.34, 0.9), (0.2, 0, 0.55), "C_f0b418"), box((0.04, 0.34, 0.9), (-0.2, 0, 0.55), "C_f0b418")]
    save("extractor", p)


def zone_ring():
    """Ceiling suction ring above an extraction zone."""
    reset()
    ring = lathe([(1.3, 0.0), (1.45, 0.0), (1.45, 0.12), (1.3, 0.12)], "M_dark_metal", 32, cap_bottom=False, smooth=False)
    lights = [box((0.2, 0.06, 0.03), (math.cos(a) * 1.38, math.sin(a) * 1.38, -0.01), "E_zone") for a in [i * math.pi / 4 for i in range(8)]]
    tube = cyl(0.25, 0.8, (0, 0, 0.5), "M_dark_metal", 16)
    struts = [box((1.3, 0.06, 0.06), (math.cos(a) * 0.7, math.sin(a) * 0.7, 0.1), "M_dark_metal", rot=(0, 0, a)) for a in [0, 2.09, 4.19]]
    save("zone_ring", [ring, tube] + lights + struts)


def store_shelf():
    reset()
    M = "C_c8ccd2"
    p = []
    for x in (-0.95, 0.95):
        for y in (-0.25, 0.25):
            p.append(box((0.05, 0.05, 1.9), (x, y, 0.95), "C_40454c"))
    for z in (0.12, 0.72, 1.32, 1.88):
        p.append(box((1.95, 0.55, 0.04), (0, 0, z), M, 0.005))
        p.append(box((1.95, 0.02, 0.07), (0, 0.28, z - 0.02), "C_f08a18"))
    p.append(box((1.95, 0.02, 1.8), (0, -0.27, 0.95), "C_8a9098"))
    save("store_shelf", p)


def counter():
    reset()
    p = [box((1.8, 0.7, 1.0), (0, 0, 0.5), "C_2b4a6e", 0.03), box((1.9, 0.8, 0.05), (0, 0, 1.02), "C_1a1c20", 0.01),
         box((0.5, 0.35, 0.3), (-0.5, -0.05, 1.2), "C_1a1c20", 0.03), box((0.4, 0.02, 0.2), (-0.5, 0.13, 1.22), "E_14402a"),
         box((1.8, 0.02, 0.15), (0, 0.36, 0.8), "C_f08a18")]
    save("counter", p)


def canister():
    """Upgrade canister (tinted per type via E_upgrade / G_upgrade)."""
    reset()
    p = [cyl(0.12, 0.05, (0, 0, -0.17), "M_dark_metal", 20, bevel=0.01), cyl(0.12, 0.05, (0, 0, 0.17), "M_dark_metal", 20, bevel=0.01),
         cyl(0.1, 0.3, (0, 0, 0), "M_glass", 20), cyl(0.06, 0.26, (0, 0, 0), "E_upgrade", 16),
         cyl(0.04, 0.03, (0, 0, 0.21), "M_chrome", 12)]
    for a in (0, 2.09, 4.19):
        p.append(box((0.02, 0.02, 0.3), (math.cos(a) * 0.11, math.sin(a) * 0.11, 0), "M_dark_metal"))
    save("canister", p)


def medkit():
    for nm, s in (("medkit_s", 0.7), ("medkit_m", 1.0), ("medkit_l", 1.3)):
        reset()
        p = [box((0.3 * s, 0.2 * s, 0.14 * s), (0, 0, 0), "C_d8d8d8", 0.02 * s),
             box((0.32 * s, 0.21 * s, 0.03 * s), (0, 0, 0.02 * s), "C_c01a1a", 0.005),
             box((0.1 * s, 0.03 * s, 0.03 * s), (0, 0.1 * s, 0.0), "E_ff3030"), box((0.03 * s, 0.03 * s, 0.1 * s), (0, 0.1 * s, 0.0), "E_ff3030"),
             box((0.12 * s, 0.03 * s, 0.03 * s), (0, 0, 0.085 * s), "M_dark_metal", 0.01)]
        save(nm, p)


def tv_screen():
    reset()
    save("tv", [box((1.6, 0.1, 0.95), (0, 0, 0), "C_111114", 0.03), box((1.5, 0.02, 0.85), (0, 0.05, 0), "E_0a1a14"),
                box((0.1, 0.3, 0.1), (0, -0.15, 0.4), "C_111114")])


def button():
    reset()
    save("button", [box((0.45, 0.45, 1.0), (0, 0, 0.5), "C_2e3238", 0.04), box((0.5, 0.5, 0.08), (0, 0, 1.02), "M_dark_metal", 0.02),
                    cyl(0.14, 0.05, (0, 0, 1.07), "C_f0b418", 20, bevel=0.01), cyl(0.1, 0.08, (0, 0, 1.12), "E_button", 20, bevel=0.02)])


def door_frame():
    reset()
    save("doorframe", [box((0.14, 0.4, 2.45), (-0.97, 0, 1.225), "M_wood_dark", 0.02), box((0.14, 0.4, 2.45), (0.97, 0, 1.225), "M_wood_dark", 0.02),
                       box((2.08, 0.4, 0.16), (0, 0, 2.47), "M_wood_dark", 0.02)])


for f in [table, chair, bookshelf, cabinet, fireplace, bed, crate, sofa, piano, pedestal, bench, display_case, labbench, rack, desk,
          plant, lamps, window, truck, extractor, zone_ring, store_shelf, counter, canister, medkit, tv_screen, button, door_frame]:
    f()
