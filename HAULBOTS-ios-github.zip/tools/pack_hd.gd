extends SceneTree
## Packs imported HD resources of an already-imported project copy into
## HAULBOTS-HD-<ver>-<n>.pck parts (each <= MAX bytes).
## Run inside the HD project copy:
##   godot --headless --path <hdproj> -s res://tools/pack_hd.gd -- <out_dir> <ver> <list.txt>
## list.txt: one res:// source path per line (e.g. res://assets/tex/wood.png).

const MAX := 29 * 1024 * 1024


func _init() -> void:
	var args := OS.get_cmdline_user_args()
	var out_dir: String = args[0]
	var ver: String = args[1]
	var srcs := FileAccess.get_file_as_string(args[2]).split("\n", false)
	var tmp := "user://hdpack_tmp"
	DirAccess.make_dir_recursive_absolute(tmp)
	var entries: Array = []   # [target, source, size]
	var i := 0
	for src in srcs:
		src = src.strip_edges()
		if src == "":
			continue
		var cf := ConfigFile.new()
		if cf.load(src + ".import") != OK:
			push_error("no import for " + src)
			continue
		var remap := ConfigFile.new()
		var group: Array = []
		for k in cf.get_section_keys("remap"):
			var v = cf.get_value("remap", k)
			if k == "generator_parameters":
				continue
			remap.set_value("remap", k, v)
			if k.begins_with("path"):
				group.append([String(v), ProjectSettings.globalize_path(String(v))])
		i += 1
		var rp := "%s/%d.import" % [tmp, i]
		remap.save(rp)
		group.append([src + ".import", ProjectSettings.globalize_path(rp)])
		var total := 0
		for g in group:
			var f := FileAccess.open(g[1], FileAccess.READ)
			if f == null:
				push_error("missing " + g[1])
				continue
			total += f.get_length()
		entries.append([group, total])
	var part := 0
	var cur := 0
	var pk: PCKPacker = null
	var summary := []
	for e in entries:
		if pk == null or cur + e[1] > MAX:
			if pk:
				pk.flush()
			part += 1
			var name := "%s/HAULBOTS-HD-%s-%d.pck" % [out_dir, ver, part]
			pk = PCKPacker.new()
			pk.pck_start(name)
			summary.append(name)
			cur = 0
		for g in e[0]:
			pk.add_file(g[0], g[1])
		cur += e[1]
	if pk:
		pk.flush()
	print("[HD] wrote ", summary)
	quit()
