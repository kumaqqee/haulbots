"""Shrink the launcher icons inside an exported APK (Godot writes full-colour PNGs for every
density; a photographic icon then costs ~1 MB) and re-sign it.
Usage: python3 tools/postbuild.py <in.apk> <out.apk> [keystore] [alias] [pass]"""
import sys, os, io, zipfile, subprocess, shutil, tempfile
from PIL import Image

src, dst = sys.argv[1], sys.argv[2]
ks = sys.argv[3] if len(sys.argv) > 3 else "/opt/keys/release.keystore"
alias = sys.argv[4] if len(sys.argv) > 4 else "haulbots"
pw = sys.argv[5] if len(sys.argv) > 5 else "haulbots123"
ROOT = os.path.join(os.path.dirname(__file__), "..")
SOURCES = {
    "icon.png": os.path.join(ROOT, "icon_192.png"),
    "icon_foreground.png": os.path.join(ROOT, "icon_fg.png"),
}


def small_png(path_src, size, colors):
    im = Image.open(path_src).convert("RGB").resize((size, size), Image.LANCZOS)
    q = im.quantize(colors=colors, method=Image.MEDIANCUT, dither=Image.FLOYDSTEINBERG)
    b = io.BytesIO()
    q.save(b, "PNG", optimize=True)
    return b.getvalue()


tmp = tempfile.mkdtemp()
unsigned = os.path.join(tmp, "u.apk")
saved = 0
with zipfile.ZipFile(src) as zi, zipfile.ZipFile(unsigned, "w") as zo:
    for info in zi.infolist():
        if info.filename.startswith("META-INF/"):
            continue   # old signature
        data = zi.read(info.filename)
        base = os.path.basename(info.filename)
        if info.filename.startswith("res/mipmap") and base in SOURCES:
            w = Image.open(io.BytesIO(data)).size[0]
            new = small_png(SOURCES[base], w, 128 if w > 200 else 96)
            if len(new) < len(data):
                saved += len(data) - len(new)
                data = new
        ni = zipfile.ZipInfo(info.filename, date_time=info.date_time)
        ni.compress_type = info.compress_type
        ni.external_attr = info.external_attr
        zo.writestr(ni, data)
aligned = os.path.join(tmp, "a.apk")
subprocess.check_call(["zipalign", "-f", "-p", "4", unsigned, aligned])
subprocess.check_call(["apksigner", "sign", "--ks", ks, "--ks-key-alias", alias, "--ks-pass", "pass:" + pw,
                       "--key-pass", "pass:" + pw, "--out", dst, aligned])
shutil.rmtree(tmp)
print("icons saved %d bytes -> %s (%d bytes)" % (saved, dst, os.path.getsize(dst)))
