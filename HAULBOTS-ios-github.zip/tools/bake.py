"""Texture baking for game models (Blender 4.0, Cycles, headless).

Every non-emissive, non-glass material slot is replaced with a procedural "look" (wood grain,
skin mottling, scratched metal, cloth weave, ...) plus cavity/edge shading, then baked into
one shared albedo atlas + one ORM atlas (R=ambient occlusion, G=roughness, B=metallic) per model.
The model then exports with a single material called T_<name>; the game's matlib maps it to an
ORMMaterial3D that uses assets/mtex/<name>.png and <name>_orm.png.

Material naming understood here:
  L_<look>_<rrggbb>  explicit look with base colour, e.g. L_skin_d9a38a, L_metal_8a8f99
  M_<lib>            library names (M_wood, M_gold, M_fabric ...)
  C_<rrggbb>         painted surface
  E_... / G_...      emissive / glass: left untouched (not baked)
"""
import bpy, bmesh, math, os
import numpy as np

MTEX = os.path.join(os.path.dirname(__file__), "..", "assets", "mtex")

LIB = {
    "M_wood": ("wood", (0.42, 0.25, 0.12)), "M_wood_dark": ("wood", (0.2, 0.11, 0.055)),
    "M_gold": ("gold", (1.0, 0.72, 0.3)), "M_metal": ("metal", (0.62, 0.63, 0.66)),
    "M_dark_metal": ("metal", (0.14, 0.145, 0.16)), "M_marble": ("marble", (0.9, 0.88, 0.85)),
    "M_fabric": ("fabric", (0.55, 0.14, 0.14)), "M_rubber": ("rubber", (0.04, 0.04, 0.045)),
    "M_canvas": ("fabric", (0.78, 0.68, 0.5)), "M_player": ("plastic", (0.95, 0.52, 0.1)),
    "M_stone": ("stone", (0.45, 0.43, 0.4)), "M_paper": ("paper", (0.86, 0.81, 0.7)),
    "M_skin_pale": ("skin", (0.8, 0.74, 0.68)), "M_screen": ("plastic", (0.03, 0.06, 0.05)),
    "M_chrome": ("chrome", (0.82, 0.83, 0.86)), "M_bone": ("bone", (0.88, 0.84, 0.74)),
    "M_vase": ("ceramic", (0.2, 0.35, 0.8)), "M_mask": ("gold", (0.8, 0.6, 0.2)),
}


def _lin(v):
    return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4


def _hex(h, default=(0.6, 0.6, 0.6)):
    """sRGB hex -> linear rgb (the bake writes sRGB again, so textures match the hex colour)."""
    try:
        return tuple(_lin(int(h[i:i + 2], 16) / 255.0) for i in (0, 2, 4))
    except (ValueError, IndexError):
        return default


def classify(name):
    """-> (look, rgb) or None for materials that must not be baked."""
    n = name.split(".")[0]
    if n.startswith("E_") or n.startswith("G_") or n.endswith("glow") or n == "M_glass" or n == "M_player_glow":
        return None
    # materials the game recolours / retextures at runtime stay separate
    if n in ("M_player", "M_vase", "M_mask", "M_canvas") or n.startswith("K_"):
        return None
    if n.startswith("L_"):
        parts = n.split("_")
        return parts[1], _hex(parts[2] if len(parts) > 2 else "999999")
    if n in LIB:
        lk, c = LIB[n]
        return lk, tuple(_lin(x) for x in c)
    if n.startswith("C_"):
        return "paint", _hex(n[2:8])
    if n.startswith("M_"):
        return "paint", (0.6, 0.6, 0.6)
    return "paint", (0.6, 0.6, 0.6)


# ------------------------------------------------------------------ node helpers

class NB:
    def __init__(self, mat):
        mat.use_nodes = True
        self.nt = mat.node_tree
        self.nt.nodes.clear()
        self.x = -1400

    def node(self, t, **kw):
        n = self.nt.nodes.new(t)
        n.location = (self.x, 0)
        self.x += 160
        for k, v in kw.items():
            if hasattr(n, k):
                setattr(n, k, v)
        return n

    def link(self, a, b):
        self.nt.links.new(a, b)

    def val(self, v):
        n = self.node("ShaderNodeValue")
        n.outputs[0].default_value = v
        return n.outputs[0]

    def rgb(self, c):
        n = self.node("ShaderNodeRGB")
        n.outputs[0].default_value = (c[0], c[1], c[2], 1.0)
        return n.outputs[0]

    def coord(self, scale=(1, 1, 1)):
        tc = self.node("ShaderNodeTexCoord")
        mp = self.node("ShaderNodeMapping")
        mp.inputs["Scale"].default_value = scale
        self.link(tc.outputs["Object"], mp.inputs["Vector"])
        return mp.outputs["Vector"]

    def noise(self, scale, detail=4.0, rough=0.5, vec=None, distort=0.0):
        n = self.node("ShaderNodeTexNoise")
        n.inputs["Scale"].default_value = scale
        n.inputs["Detail"].default_value = detail
        n.inputs["Roughness"].default_value = rough
        n.inputs["Distortion"].default_value = distort
        if vec is not None:
            self.link(vec, n.inputs["Vector"])
        return n.outputs["Fac"]

    def voronoi(self, scale, vec=None, feature="F1", out="Distance"):
        n = self.node("ShaderNodeTexVoronoi")
        n.feature = feature
        n.inputs["Scale"].default_value = scale
        if vec is not None:
            self.link(vec, n.inputs["Vector"])
        return n.outputs[out]

    def math(self, op, a, b=None, clamp=False):
        n = self.node("ShaderNodeMath")
        n.operation = op
        n.use_clamp = clamp
        self._in(n.inputs[0], a)
        if b is not None:
            self._in(n.inputs[1], b)
        return n.outputs[0]

    def _in(self, sock, v):
        if isinstance(v, (int, float)):
            sock.default_value = v
        else:
            self.link(v, sock)

    def ramp(self, fac, stops):
        """stops: [(pos, (r,g,b)), ...] -> colour output"""
        n = self.node("ShaderNodeValToRGB")
        cr = n.color_ramp
        while len(cr.elements) > 1:
            cr.elements.remove(cr.elements[-1])
        cr.elements[0].position = stops[0][0]
        cr.elements[0].color = (*stops[0][1], 1.0)
        for p, c in stops[1:]:
            e = cr.elements.new(p)
            e.color = (*c, 1.0)
        self.link(fac, n.inputs["Fac"])
        return n.outputs["Color"]

    def mix(self, fac, a, b, blend="MIX"):
        n = self.node("ShaderNodeMix")
        n.data_type = "RGBA"
        n.blend_type = blend
        self._in(n.inputs[0], fac)
        self._in_col(n.inputs[6], a)
        self._in_col(n.inputs[7], b)
        return n.outputs[2]

    def _in_col(self, sock, v):
        if isinstance(v, tuple):
            sock.default_value = (*v[:3], 1.0)
        else:
            self.link(v, sock)

    def scale_col(self, col, fac):
        """col * fac (fac socket/float)"""
        n = self.node("ShaderNodeMix")
        n.data_type = "RGBA"
        n.blend_type = "MULTIPLY"
        n.inputs[0].default_value = 1.0
        self._in_col(n.inputs[6], col)
        cv = self.node("ShaderNodeCombineXYZ")
        self._in(cv.inputs[0], fac)
        self._in(cv.inputs[1], fac)
        self._in(cv.inputs[2], fac)
        self.link(cv.outputs[0], n.inputs[7])
        return n.outputs[2]

    def geo(self, out):
        return self.node("ShaderNodeNewGeometry").outputs[out]


def _dark(c, k):
    return (c[0] * k, c[1] * k, c[2] * k)


def _tint(c, t, k):
    return tuple(c[i] * (1 - k) + t[i] * k for i in range(3))


def build_look(nb, look, c):
    """Returns (colour socket, roughness socket, metallic float)."""
    v = nb.coord()
    # cavity / edge from pointiness: <0.5 concave, >0.5 convex
    pt = nb.geo("Pointiness")
    edge = nb.math("MULTIPLY", nb.math("SUBTRACT", pt, 0.5), 6.0)       # ~[-3, 3]
    edge_k = nb.math("ADD", nb.math("MULTIPLY", edge, 0.08), 1.0, clamp=False)   # 0.76..1.24
    edge_k = nb.math("MAXIMUM", nb.math("MINIMUM", edge_k, 1.18), 0.72)
    rough = None
    metal = 0.0
    if look == "wood":
        warp = nb.noise(3.0, 3.0, 0.5, v)
        wv = nb.node("ShaderNodeTexWave")
        wv.wave_type = "RINGS"
        wv.inputs["Scale"].default_value = 3.0
        wv.inputs["Distortion"].default_value = 6.0
        wv.inputs["Detail"].default_value = 3.0
        mp = nb.coord((1.0, 1.0, 0.12))
        nb.link(mp, wv.inputs["Vector"])
        grain = nb.math("ADD", wv.outputs["Fac"], nb.math("MULTIPLY", warp, 0.4))
        col = nb.ramp(nb.math("FRACT", grain), [(0.0, _dark(c, 0.62)), (0.45, c), (0.8, _dark(c, 1.15)), (1.0, _dark(c, 0.7))])
        fine = nb.noise(90.0, 2.0, 0.5, nb.coord((1, 1, 0.05)))
        col = nb.scale_col(col, nb.math("ADD", nb.math("MULTIPLY", fine, 0.25), 0.88))
        rough = nb.math("ADD", nb.math("MULTIPLY", fine, 0.2), 0.5)
    elif look in ("metal", "chrome", "gold"):
        scr = nb.noise(4.0, 8.0, 0.7, nb.coord((60.0, 3.0, 3.0)))
        blot = nb.noise(5.0, 4.0, 0.6, v)
        base_r = {"metal": 0.38, "chrome": 0.12, "gold": 0.24}[look]
        rough = nb.math("ADD", nb.math("MULTIPLY", nb.math("ADD", scr, nb.math("MULTIPLY", blot, 0.5)), 0.25), base_r - 0.12)
        col = nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", blot, 0.18), 0.9))
        grime = _tint(_dark(c, 0.35), (0.12, 0.09, 0.05), 0.4)
        cav = nb.math("SUBTRACT", 1.0, nb.math("MULTIPLY", nb.math("SUBTRACT", pt, 0.3), 5.0), clamp=True)
        col = nb.mix(cav, col, grime)
        metal = 1.0
    elif look == "rust":
        n1 = nb.noise(3.0, 6.0, 0.65, v)
        rustm = nb.math("GREATER_THAN", n1, 0.52)
        rc = nb.ramp(nb.noise(18.0, 4.0, 0.6, v), [(0.0, (0.28, 0.1, 0.03)), (0.6, (0.55, 0.25, 0.08)), (1.0, (0.35, 0.14, 0.05))])
        col = nb.mix(rustm, c, rc)
        rough = nb.math("ADD", nb.math("MULTIPLY", rustm, 0.5), 0.4)
        metal = 0.6
    elif look == "skin":
        vor = nb.voronoi(28.0, v)
        mott = nb.noise(5.0, 5.0, 0.6, v)
        red = _tint(c, (0.75, 0.25, 0.22), 0.35)
        col = nb.mix(nb.math("MULTIPLY", mott, 0.9), _dark(c, 0.88), red)
        col = nb.scale_col(col, nb.math("ADD", nb.math("MULTIPLY", vor, 0.22), 0.86))
        spots = nb.math("GREATER_THAN", nb.noise(40.0, 2.0, 0.5, v), 0.68)
        col = nb.mix(nb.math("MULTIPLY", spots, 0.35), col, _dark(red, 0.6))
        cav = nb.math("SUBTRACT", 1.0, nb.math("MULTIPLY", nb.math("SUBTRACT", pt, 0.35), 5.0), clamp=True)
        col = nb.mix(nb.math("MULTIPLY", cav, 0.8), col, _tint(_dark(c, 0.35), (0.4, 0.05, 0.05), 0.5))
        rough = nb.math("ADD", nb.math("MULTIPLY", mott, 0.2), 0.45)
    elif look == "slime":
        n1 = nb.noise(6.0, 6.0, 0.6, v)
        col = nb.ramp(n1, [(0.2, _dark(c, 0.55)), (0.55, c), (0.8, _tint(c, (1, 1, 0.8), 0.3))])
        rough = nb.math("ADD", nb.math("MULTIPLY", n1, 0.15), 0.12)
    elif look == "fur":
        st = nb.noise(6.0, 6.0, 0.7, nb.coord((4.0, 4.0, 70.0)))
        col = nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", st, 0.5), 0.72))
        rough = nb.val(0.92)
    elif look == "fabric":
        weave = nb.node("ShaderNodeTexChecker")
        weave.inputs["Scale"].default_value = 260.0
        weave.inputs["Color1"].default_value = (1, 1, 1, 1)
        weave.inputs["Color2"].default_value = (0.82, 0.82, 0.82, 1)
        nb.link(v, weave.inputs["Vector"])
        n1 = nb.noise(7.0, 4.0, 0.5, v)
        col = nb.mix(1.0, nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", n1, 0.22), 0.88)), weave.outputs["Color"], "MULTIPLY")
        rough = nb.val(0.95)
    elif look == "leather":
        cr = nb.voronoi(60.0, v, "DISTANCE_TO_EDGE")
        cracks = nb.math("LESS_THAN", cr, 0.04)
        n1 = nb.noise(6.0, 4.0, 0.5, v)
        col = nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", n1, 0.3), 0.82))
        col = nb.mix(nb.math("MULTIPLY", cracks, 0.5), col, _dark(c, 0.4))
        rough = nb.math("ADD", nb.math("MULTIPLY", n1, 0.2), 0.5)
    elif look in ("marble", "stone"):
        m = nb.node("ShaderNodeTexMusgrave")
        m.musgrave_type = "RIDGED_MULTIFRACTAL"
        m.inputs["Scale"].default_value = 3.0 if look == "marble" else 9.0
        m.inputs["Detail"].default_value = 8.0
        nb.link(nb.coord((1.0, 1.0, 0.6)), m.inputs["Vector"])
        vein = nb.math("POWER", nb.math("MULTIPLY", m.outputs[0], 0.5, clamp=True), 3.0)
        n1 = nb.noise(12.0, 6.0, 0.6, v)
        if look == "marble":
            col = nb.mix(vein, nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", n1, 0.08), 0.95)), _tint(_dark(c, 0.45), (0.3, 0.32, 0.35), 0.5))
            rough = nb.val(0.22)
        else:
            col = nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", n1, 0.45), 0.72))
            col = nb.mix(nb.math("MULTIPLY", vein, 0.5), col, _dark(c, 0.55))
            rough = nb.val(0.9)
    elif look in ("bone", "ceramic"):
        n1 = nb.noise(9.0, 4.0, 0.5, v)
        col = nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", n1, 0.14), 0.92))
        cav = nb.math("SUBTRACT", 1.0, nb.math("MULTIPLY", nb.math("SUBTRACT", pt, 0.35), 5.0), clamp=True)
        col = nb.mix(nb.math("MULTIPLY", cav, 0.7), col, _tint(_dark(c, 0.45), (0.35, 0.25, 0.1), 0.4))
        rough = nb.val(0.25 if look == "ceramic" else 0.6)
    elif look == "rubber":
        n1 = nb.noise(30.0, 3.0, 0.5, v)
        col = nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", n1, 0.3), 0.85))
        rough = nb.val(0.88)
    elif look == "paper":
        fib = nb.noise(70.0, 6.0, 0.7, nb.coord((1, 1, 1)))
        col = nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", fib, 0.12), 0.92))
        stain = nb.noise(3.0, 4.0, 0.5, v)
        col = nb.mix(nb.math("MULTIPLY", nb.math("GREATER_THAN", stain, 0.62), 0.25), col, (0.5, 0.38, 0.2))
        rough = nb.val(0.95)
    elif look == "plastic":
        n1 = nb.noise(8.0, 3.0, 0.5, v)
        col = nb.scale_col(c, nb.math("ADD", nb.math("MULTIPLY", n1, 0.06), 0.97))
        rough = nb.math("ADD", nb.math("MULTIPLY", n1, 0.1), 0.3)
    else:  # paint / generic
        n1 = nb.noise(6.0, 4.0, 0.55, v)
        n2 = nb.noise(55.0, 2.0, 0.5, v)
        col = nb.scale_col(c, nb.math("ADD", nb.math("ADD", nb.math("MULTIPLY", n1, 0.16), nb.math("MULTIPLY", n2, 0.06)), 0.89))
        rough = nb.math("ADD", nb.math("MULTIPLY", n2, 0.2), 0.5)
    col = nb.scale_col(col, edge_k)
    if rough is None:
        rough = nb.val(0.6)
    return col, rough, metal


# ------------------------------------------------------------------ baking

def _meshes(objs):
    out = []
    for o in objs:
        for x in [o] + list(o.children_recursive):
            if x.type == "MESH" and x not in out:
                out.append(x)
    return out


def _img(name, size, color=(0, 0, 0, 1), alpha=False):
    if name in bpy.data.images:
        bpy.data.images.remove(bpy.data.images[name])
    im = bpy.data.images.new(name, size, size, alpha=alpha, float_buffer=False)
    im.generated_color = color
    im.colorspace_settings.name = "Non-Color"
    return im


def _pix(im):
    a = np.empty(len(im.pixels), dtype=np.float32)
    im.pixels.foreach_get(a)
    return a.reshape(-1, 4)


def _push_pull(img, mask):
    """Fill unbaked texels with smoothly spread neighbouring colours (smaller, seam-free textures)."""
    h, w, _ = img.shape
    if mask.all() or not mask.any():
        return img
    levels = []
    c = np.where(mask[..., None], img, 0.0)
    wgt = mask.astype(np.float32)
    while c.shape[0] > 1:
        levels.append((c, wgt))
        hh, ww = c.shape[0] // 2, c.shape[1] // 2
        c2 = c[:hh * 2, :ww * 2].reshape(hh, 2, ww, 2, 3).sum(axis=(1, 3))
        w2 = wgt[:hh * 2, :ww * 2].reshape(hh, 2, ww, 2).sum(axis=(1, 3))
        c = c2
        wgt = w2
    avg = np.where(wgt[..., None] > 0, c / np.maximum(wgt[..., None], 1e-6), 0.5)
    for c_l, w_l in reversed(levels):
        up = np.repeat(np.repeat(avg, 2, axis=0), 2, axis=1)[:c_l.shape[0], :c_l.shape[1]]
        cur = np.where(w_l[..., None] > 0, c_l / np.maximum(w_l[..., None], 1e-6), up)
        avg = cur
    return np.where(mask[..., None], img, avg)


def _save_rgb(fn, arr, cs):
    h, w, _ = arr.shape
    nm = "OUT_" + fn
    if nm in bpy.data.images:
        bpy.data.images.remove(bpy.data.images[nm])
    im = bpy.data.images.new(nm, w, h, alpha=False, float_buffer=False)
    im.colorspace_settings.name = cs
    px = np.ones((h, w, 4), dtype=np.float32)
    px[..., :3] = np.clip(arr, 0.0, 1.0)
    im.pixels.foreach_set(px.ravel())
    im.filepath_raw = os.path.join(MTEX, fn)
    im.file_format = "PNG"
    im.save()


def bake(name, objs, size=512, ao_dist=0.35, ao_samples=48, dry=False, orm_div=4):
    os.makedirs(MTEX, exist_ok=True)
    scn = bpy.context.scene
    scn.render.engine = "CYCLES"
    scn.cycles.device = "CPU"
    scn.cycles.use_denoising = False
    scn.cycles.samples = 1
    scn.render.bake.margin = max(2, size // 128)
    scn.render.bake.use_clear = True
    if scn.world is None:
        scn.world = bpy.data.worlds.new("W")
    scn.world.light_settings.distance = ao_dist
    meshes = _meshes(objs)
    # which slots bake
    slot_info = {}
    for o in meshes:
        info = []
        for i, ms in enumerate(o.material_slots):
            info.append(classify(ms.material.name) if ms.material else ("paint", (0.6, 0.6, 0.6)))
        slot_info[o.name] = info
    # UV unwrap bakeable faces of all parts into one shared atlas
    bpy.ops.object.mode_set(mode="OBJECT") if bpy.context.object and bpy.context.object.mode != "OBJECT" else None
    for o in bpy.context.selected_objects:
        o.select_set(False)
    any_face = False
    for o in meshes:
        if not o.data.uv_layers:
            o.data.uv_layers.new(name="UVMap")
        info = slot_info[o.name]
        for p in o.data.polygons:
            ok = info and p.material_index < len(info) and info[p.material_index] is not None
            p.select = bool(ok)
            any_face = any_face or bool(ok)
        o.select_set(True)
    if not any_face:
        return False
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_mode(type="FACE")
    bpy.ops.uv.smart_project(angle_limit=math.radians(62), island_margin=0.012, area_weight=0.0, correct_aspect=True, scale_to_bounds=False)
    bpy.ops.uv.pack_islands(rotate=True, margin=0.006)
    bpy.ops.object.mode_set(mode="OBJECT")
    # procedural bake materials, one per (original material)
    alb = _img(name + "_alb", size, (0, 0, 0, 0), True)
    alb.colorspace_settings.name = "sRGB"
    orm = _img(name + "_orm", size)
    ao = _img(name + "_ao", size, (1, 1, 1, 1))
    bake_mats = {}
    originals = {}
    for o in meshes:
        info = slot_info[o.name]
        for i, ms in enumerate(o.material_slots):
            if i >= len(info) or info[i] is None:
                continue
            orig = ms.material
            key = orig.name if orig else "none"
            if key not in bake_mats:
                look, c = info[i]
                m = bpy.data.materials.new("BK_" + key)
                nb = NB(m)
                col, rough, metal = build_look(nb, look, c)
                em = nb.node("ShaderNodeEmission")
                nb.link(col, em.inputs["Color"])
                out = nb.node("ShaderNodeOutputMaterial")
                nb.link(em.outputs[0], out.inputs["Surface"])
                orm_c = nb.node("ShaderNodeCombineXYZ")
                orm_c.inputs[0].default_value = 1.0
                nb.link(rough, orm_c.inputs[1])
                orm_c.inputs[2].default_value = metal
                tex = nb.node("ShaderNodeTexImage")
                tex.image = alb
                nb.nt.nodes.active = tex
                bake_mats[key] = (m, col, orm_c, em, tex)
            originals.setdefault(o.name, {})[i] = orig
            ms.material = bake_mats[key][0]
    if dry:
        return True
    # pass 1: albedo (emission of procedural colour)
    bpy.ops.object.bake(type="EMIT")
    # pass 2: roughness/metal
    for key, (m, col, orm_c, em, tex) in bake_mats.items():
        m.node_tree.links.new(orm_c.outputs[0], em.inputs["Color"])
        tex.image = orm
    bpy.ops.object.bake(type="EMIT")
    # pass 3: ambient occlusion
    scn.cycles.samples = ao_samples
    for key, (m, col, orm_c, em, tex) in bake_mats.items():
        tex.image = ao
    bpy.ops.object.bake(type="AO")
    # combine
    A = _pix(alb)
    O = _pix(orm)
    AO = _pix(ao)[:, :1]
    mask = A[:, 3] > 0.5
    A[:, :3] *= (0.45 + 0.55 * AO)
    O[:, 0:1] = 0.35 + 0.65 * AO
    n = size
    A3 = _push_pull(A[:, :3].reshape(n, n, 3), mask.reshape(n, n))
    O3 = _push_pull(O[:, :3].reshape(n, n, 3), mask.reshape(n, n))
    osz = max(64, size // orm_div)
    O3 = O3.reshape(osz, n // osz, osz, n // osz, 3).mean(axis=(1, 3))
    _save_rgb(name + ".png", A3, "sRGB")
    _save_rgb(name + "_orm.png", O3, "Non-Color")
    # final: one exported material named T_<name>
    tm = bpy.data.materials.new("T_" + name)
    tm.use_nodes = True
    for o in meshes:
        info = slot_info[o.name]
        for i, ms in enumerate(o.material_slots):
            if i < len(info) and info[i] is not None:
                ms.material = tm
    for key, (m, *_r) in bake_mats.items():
        bpy.data.materials.remove(m)
    return True
