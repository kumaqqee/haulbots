"""Decorative clutter (no gameplay): books, candles, bottles, papers, boxes, buckets, lab glassware,
curtains and open door leaves. Z-up, origin at the base, front +Y. Baked like the other models."""
import sys, os, math, random
sys.path.insert(0, os.path.dirname(__file__))
from blib import *
from organic import cloth, decimate, meta, displace
import bake as BK

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "models")
rnd = random.Random(5)


def save(name, parts, tex=128, maxtris=1500, ao=0.08):
    o = join(parts, name)
    decimate(o, maxtris)
    o.data.use_auto_smooth = True
    o.data.auto_smooth_angle = math.radians(50)
    BK.bake(name, [o], tex, ao_dist=ao)
    export(os.path.join(OUT, name + ".glb"), [o])
    print("EXPORT", name, tris())


BOOK_COLS = ["6b1c1c", "1c3b6b", "2d5a2d", "7a5a1c", "3a2a4a", "8a8070", "4a2a1a", "1f4a4a", "5a1a3a"]


def book(x, y, z, w, d, h, rot=0.0, lay=False):
    c = BOOK_COLS[rnd.randrange(len(BOOK_COLS))]
    if lay:
        b = box((h, d, w), (x, y, z + w / 2), "L_leather_" + c, 0.004)
        pages = box((h * 0.96, d * 0.9, w * 0.8), (x, y + 0.004, z + w / 2), "L_paper_e8dcc0", 0.0)
    else:
        b = box((w, d, h), (x, y, z + h / 2), "L_leather_" + c, 0.004)
        pages = box((w * 0.8, d * 0.9, h * 0.96), (x, y + 0.004, z + h / 2), "L_paper_e8dcc0", 0.0)
    b.rotation_euler = (0, 0, rot)
    pages.rotation_euler = (0, 0, rot)
    band = box((w * 1.02 if not lay else h * 0.2, d * 1.02, h * 0.06 if not lay else w * 1.02), (x, y, z + (h * 0.8 if not lay else w / 2)), "M_gold", 0.0)
    band.rotation_euler = (0, 0, rot)
    return [b, pages, band]


def book_stack():
    reset()
    p = []
    z = 0.0
    for i in range(5):
        w = rnd.uniform(0.03, 0.05)
        p += book(rnd.uniform(-0.01, 0.01), rnd.uniform(-0.01, 0.01), z, w, rnd.uniform(0.15, 0.2), rnd.uniform(0.2, 0.26), rnd.uniform(-0.3, 0.3), lay=True)
        z += w
    save("prop_bookstack", p)


def books_row():
    reset()
    p = []
    x = -0.3
    while x < 0.3:
        w = rnd.uniform(0.025, 0.05)
        h = rnd.uniform(0.18, 0.26)
        lean = rnd.random() < 0.12
        p += book(x + w / 2, 0, 0, w, rnd.uniform(0.14, 0.19), h, 0)
        if lean:
            for o in p[-3:]:
                o.rotation_euler = (0, 0.35, 0)
        x += w + 0.002
    save("prop_booksrow", p, 128, 2500)


def candle():
    reset()
    holder = lathe([(0.05, 0.0), (0.055, 0.01), (0.03, 0.02), (0.012, 0.03), (0.012, 0.11), (0.03, 0.12), (0.035, 0.13), (0.0, 0.13)], "M_gold", 20)
    c1 = cyl(0.016, 0.12, (0, 0, 0.19), "L_ceramic_efe6d0", 12)
    drip = skin([(0.016, 0.0, 0.24, 0.006), (0.018, 0.0, 0.2, 0.005), (0.017, 0.0, 0.17, 0.003)], material="L_ceramic_efe6d0", subdiv=1)
    wick = cyl(0.002, 0.012, (0, 0, 0.256), "C_111111", 4)
    flame = sphere(0.01, (0, 0, 0.27), "E_ffb040", 8, 4, (0.8, 0.8, 1.8))
    save("prop_candle", [holder, c1, drip, wick, flame])


def bottles():
    reset()
    p = []
    for i, (x, y) in enumerate([(-0.06, 0.0), (0.02, 0.03), (0.07, -0.03)]):
        h = rnd.uniform(0.22, 0.3)
        c = ["G_2a5a2a", "G_5a3a1a", "G_2a3a5a"][i]
        prof = [(0.035, 0.0), (0.037, 0.01), (0.037, h * 0.62), (0.014, h * 0.8), (0.012, h), (0.0, h)]
        b = lathe(prof, c, 16, pos=(x, y, 0))
        lab = cyl(0.0375, 0.06, (x, y, h * 0.35), "L_paper_d8c8a0", 16)
        cork = cyl(0.011, 0.02, (x, y, h + 0.005), "L_wood_a07850", 8)
        p += [b, lab, cork]
    save("prop_bottles", p)


def papers():
    reset()
    p = []
    for i in range(6):
        s = box((0.21, 0.297, 0.002), (rnd.uniform(-0.08, 0.08), rnd.uniform(-0.06, 0.06), 0.001 + i * 0.0015), "L_paper_ece4d0", 0.0)
        s.rotation_euler = (0, 0, rnd.uniform(-0.8, 0.8))
        p.append(s)
    for i in range(3):
        p.append(box((0.15, 0.004, 0.001), (rnd.uniform(-0.05, 0.05), rnd.uniform(-0.05, 0.05), 0.0105 + i * 0.001), "C_3a3a4a", 0.0))
    save("prop_papers", p)


def cardboard():
    reset()
    b = box((0.5, 0.4, 0.35), (0, 0, 0.175), "L_paper_a0784a", 0.01)
    flaps = [box((0.5, 0.2, 0.004), (0, 0.1, 0.36), "L_paper_a0784a", 0.0, rot=(0.9, 0, 0)), box((0.5, 0.2, 0.004), (0, -0.1, 0.36), "L_paper_a0784a", 0.0, rot=(-0.7, 0, 0))]
    tape = box((0.06, 0.41, 0.352), (0, 0, 0.176), "L_plastic_c8b890", 0.0)
    label = box((0.12, 0.002, 0.08), (0.12, 0.201, 0.2), "L_paper_f0f0f0", 0.0)
    save("prop_box", [b, tape, label] + flaps)


def bucket():
    reset()
    b = lathe([(0.12, 0.0), (0.125, 0.005), (0.15, 0.3), (0.155, 0.31), (0.145, 0.31), (0.14, 0.03), (0.0, 0.03)], "L_metal_8a9098", 24)
    handle = skin([(-0.15, 0, 0.3, 0.004), (-0.1, 0, 0.42, 0.004), (0.0, 0, 0.46, 0.004), (0.1, 0, 0.42, 0.004), (0.15, 0, 0.3, 0.004)], material="L_metal_5a5a60", subdiv=1)
    water = cyl(0.14, 0.01, (0, 0, 0.2), "G_3a4a3a", 20)
    mop = [cyl(0.012, 1.1, (0.08, 0.05, 0.6), "L_wood_a07850", 8, rot=(0.12, 0.2, 0))]
    save("prop_bucket", [b, handle, water] + mop)


def flasks():
    reset()
    rack = [box((0.34, 0.1, 0.012), (0, 0, 0.0), "L_wood_8a6a40", 0.003), box((0.34, 0.1, 0.012), (0, 0, 0.08), "L_wood_8a6a40", 0.003)]
    for x in (-0.16, 0.16):
        rack.append(box((0.012, 0.1, 0.1), (x, 0, 0.045), "L_wood_8a6a40", 0.002))
    for i, x in enumerate([-0.11, -0.04, 0.03, 0.1]):
        c = ["E_40ff70", "E_ffb030", "E_40a0ff", "E_ff40a0"][i]
        rack.append(cyl(0.014, 0.16, (x, 0, 0.08), "G_e0f0ff", 10))
        rack.append(cyl(0.012, 0.06 + i * 0.015, (x, 0, 0.03 + (0.06 + i * 0.015) / 2), c, 8))
    erl = lathe([(0.06, 0.0), (0.06, 0.005), (0.018, 0.12), (0.018, 0.17), (0.022, 0.175)], "G_d8f0ff", 20, pos=(0.3, 0, 0))
    liq = lathe([(0.055, 0.004), (0.035, 0.06), (0.0, 0.06)], "E_60ff90", 16, pos=(0.3, 0, 0))
    save("prop_flasks", rack + [erl, liq])


def clipboard():
    reset()
    b = box((0.23, 0.32, 0.006), (0, 0, 0.003), "L_wood_6a4a2a", 0.002)
    paper = box((0.21, 0.28, 0.002), (0, -0.01, 0.007), "L_paper_f0ece0", 0.0)
    clip = box((0.08, 0.03, 0.012), (0, 0.14, 0.01), "M_chrome", 0.003)
    lines = [box((0.15, 0.003, 0.001), (0, 0.08 - i * 0.025, 0.0085), "C_3a3a4a", 0.0) for i in range(7)]
    save("prop_clipboard", [b, paper, clip] + lines)


def paintcans():
    reset()
    p = []
    for i, (x, y, z) in enumerate([(-0.1, 0.0, 0.0), (0.1, 0.02, 0.0), (0.0, 0.0, 0.2)]):
        c = ["L_metal_c8ccd0", "L_metal_c8ccd0", "L_metal_c8ccd0"][i]
        p.append(cyl(0.09, 0.2, (x, y, z + 0.1), c, 20))
        p.append(cyl(0.091, 0.1, (x, y, z + 0.1), ["L_paint_b03020", "L_paint_2050a0", "L_paint_e8c020"][i], 20))
        p.append(cyl(0.085, 0.01, (x, y, z + 0.205), "L_metal_8a8f99", 20))
        drip = box((0.02, 0.002, 0.06), (x, y + 0.091, z + 0.17), ["L_paint_b03020", "L_paint_2050a0", "L_paint_e8c020"][i], 0.0)
        p.append(drip)
    save("prop_paintcans", p)


def curtain():
    reset()
    rod = cyl(0.015, 1.9, (0, 0, 2.42), "M_gold", 10, rot=(0, math.pi / 2, 0))
    ends = [sphere(0.03, (x, 0, 2.42), "M_gold", 10, 5) for x in (-0.95, 0.95)]
    parts = [rod] + ends
    for s in (-1, 1):
        # hanging pleated panel, gathered at the tie-back
        import bmesh
        bm = bmesh.new()
        cols, rows = 24, 12
        verts = []
        for j in range(rows + 1):
            z = 2.4 - j * 2.4 / rows
            row = []
            gather = 1.0 - 0.45 * math.exp(-((z - 1.1) ** 2) * 6)
            for i in range(cols + 1):
                t = i / cols
                x = s * (0.95 - t * 0.4 * gather)
                y = 0.04 * math.sin(t * math.pi * 7) * (0.5 + 0.5 * (1 - z / 2.4))
                row.append(bm.verts.new((x, y + 0.02, z)))
            verts.append(row)
        for j in range(rows):
            for i in range(cols):
                bm.faces.new((verts[j][i], verts[j][i + 1], verts[j + 1][i + 1], verts[j + 1][i]))
        o = mesh_obj("panel", bm, "L_fabric_6a1a20", smooth=True, angle=80)
        md = o.modifiers.new("sol", "SOLIDIFY")
        md.thickness = 0.01
        apply_mods(o)
        tie = lathe([(0.06, 1.05), (0.075, 1.1), (0.06, 1.15)], "M_gold", 12, cap_bottom=False, pos=(s * 0.72, 0.02, 0))
        tie.scale = (0.8, 0.5, 1.0)
        parts += [o, tie]
    save("prop_curtain", parts, 256, 3000)


def door_leaf():
    reset()
    W = "L_wood_4a2a14"
    leaf = box((0.9, 0.05, 2.3), (0.45, 0, 1.15), W, 0.01)
    panels = []
    for zc in (0.6, 1.7):
        for y in (0.026, -0.026):
            panels.append(box((0.62, 0.012, 0.8), (0.45, y, zc), "L_wood_3a1c0c", 0.02))
    knob = [sphere(0.03, (0.82, s * 0.05, 1.05), "M_gold", 10, 5) for s in (1, -1)]
    plate = [box((0.05, 0.01, 0.14), (0.82, s * 0.03, 1.05), "M_gold", 0.004) for s in (1, -1)]
    hinges = [box((0.02, 0.06, 0.1), (0.0, 0, z), "L_metal_5a5a60", 0.003) for z in (0.3, 2.0)]
    save("prop_door", [leaf] + panels + knob + plate + hinges, 256, 1500)


ALL = [book_stack, books_row, candle, bottles, papers, cardboard, bucket, flasks, clipboard, paintcans, curtain, door_leaf]
ONLY = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
for f in ALL:
    if not ONLY or f.__name__ in ONLY:
        f()
