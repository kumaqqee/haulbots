"""Produce a lighter copy of a .glb (for the base APK; full meshes ship in the HD pack).
Run: blender -b -P tools/decimate_glb.py -- in.glb out.glb ratio"""
import bpy, sys, math

argv = sys.argv[sys.argv.index("--") + 1:]
src, dst, ratio = argv[0], argv[1], float(argv[2])

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=src, merge_vertices=True)

before = after = 0
for o in list(bpy.context.scene.objects):
    if o.type != "MESH":
        continue
    me = o.data
    n = sum(len(p.vertices) - 2 for p in me.polygons)
    before += n
    # glTF import stores split normals; drop them so shading is recomputed after collapse
    bpy.context.view_layer.objects.active = o
    for s in bpy.context.selected_objects:
        s.select_set(False)
    o.select_set(True)
    if me.has_custom_normals:
        bpy.ops.mesh.customdata_custom_splitnormals_clear()
    for p in me.polygons:
        p.use_smooth = True
    if hasattr(me, "use_auto_smooth"):
        me.use_auto_smooth = True
        me.auto_smooth_angle = math.radians(38)
    if n > 300:
        m = o.modifiers.new("dec", "DECIMATE")
        m.decimate_type = "COLLAPSE"
        m.ratio = ratio
        m.use_collapse_triangulate = True
        bpy.ops.object.modifier_apply(modifier=m.name)
    after += sum(len(p.vertices) - 2 for p in me.polygons)

for o in bpy.context.selected_objects:
    o.select_set(False)
for o in bpy.context.scene.objects:
    o.select_set(True)
bpy.ops.export_scene.gltf(filepath=dst, export_format="GLB", use_selection=True, export_apply=True,
                          export_yup=True, export_materials="EXPORT", export_normals=True,
                          export_texcoords=True, export_cameras=False, export_lights=False,
                          export_animations=False)
print("DECIMATED", src, before, "->", after)
