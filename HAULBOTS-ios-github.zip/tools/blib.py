"""Tiny modelling helpers for Blender 4.0 (headless)."""
import bpy, bmesh, math, random
from mathutils import Vector, Matrix, Euler

MATS = {}


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    MATS.clear()


def mat(name):
    """Material names encode appearance for the in-game material library:
    M_<lib>  -> library material (wood, gold, metal...)
    C_rrggbb -> plain colour, E_rrggbb -> emissive colour, G_rrggbb -> glass tint
    """
    if name in MATS:
        return MATS[name]
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    c = (0.7, 0.7, 0.7)
    presets = {
        "M_wood": (0.45, 0.27, 0.13), "M_wood_dark": (0.2, 0.1, 0.05), "M_gold": (1.0, 0.75, 0.3),
        "M_metal": (0.6, 0.6, 0.62), "M_dark_metal": (0.15, 0.15, 0.17), "M_marble": (0.9, 0.88, 0.85),
        "M_fabric": (0.6, 0.2, 0.2), "M_rubber": (0.05, 0.05, 0.05), "M_canvas": (0.8, 0.7, 0.5),
        "M_player": (0.9, 0.5, 0.1), "M_player_glow": (1.0, 0.6, 0.1), "M_stone": (0.45, 0.43, 0.4),
        "M_paper": (0.85, 0.8, 0.7), "M_skin_pale": (0.8, 0.75, 0.7), "M_screen": (0.05, 0.1, 0.08),
        "M_glass": (0.8, 0.9, 1.0), "M_chrome": (0.8, 0.8, 0.82), "M_bone": (0.9, 0.87, 0.78),
    }
    if name in presets:
        c = presets[name]
    elif len(name) > 2 and name[1] == "_":
        h = name[2:8]
        try:
            c = tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
        except ValueError:
            pass
    bsdf.inputs["Base Color"].default_value = (c[0], c[1], c[2], 1.0)
    if name.startswith("E_") or name.endswith("glow"):
        bsdf.inputs["Emission Color"].default_value = (c[0], c[1], c[2], 1.0)
        bsdf.inputs["Emission Strength"].default_value = 3.0
    if name in ("M_gold", "M_metal", "M_chrome", "M_dark_metal"):
        bsdf.inputs["Metallic"].default_value = 1.0
        bsdf.inputs["Roughness"].default_value = 0.3
    MATS[name] = m
    return m


def _link(obj):
    bpy.context.scene.collection.objects.link(obj)
    return obj


def mesh_obj(name, bm, material=None, smooth=False, angle=35):
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    obj = bpy.data.objects.new(name, me)
    _link(obj)
    if material:
        obj.data.materials.append(mat(material))
    if smooth:
        for p in me.polygons:
            p.use_smooth = True
        me.use_auto_smooth = True
        me.auto_smooth_angle = math.radians(angle)
    return obj


def apply_mods(obj):
    bpy.context.view_layer.objects.active = obj
    for o in bpy.context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    for m in list(obj.modifiers):
        bpy.ops.object.modifier_apply(modifier=m.name)


def box(size, pos=(0, 0, 0), material="C_808080", bevel=0.0, segs=2, name="box", rot=(0, 0, 0)):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bmesh.ops.scale(bm, vec=Vector(size), verts=bm.verts)
    obj = mesh_obj(name, bm, material, smooth=bevel > 0, angle=40)
    if bevel > 0:
        md = obj.modifiers.new("bev", "BEVEL")
        md.width = bevel
        md.segments = segs
        md.limit_method = "ANGLE"
        apply_mods(obj)
    obj.location = pos
    obj.rotation_euler = rot
    return obj


def cyl(r, h, pos=(0, 0, 0), material="C_808080", verts=16, r2=None, rot=(0, 0, 0), name="cyl", bevel=0.0, smooth=True):
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=verts, radius1=r, radius2=r if r2 is None else r2, depth=h)
    obj = mesh_obj(name, bm, material, smooth=smooth, angle=40)
    if bevel > 0:
        md = obj.modifiers.new("bev", "BEVEL")
        md.width = bevel
        md.segments = 2
        md.limit_method = "ANGLE"
        apply_mods(obj)
    obj.location = pos
    obj.rotation_euler = rot
    return obj


def sphere(r, pos=(0, 0, 0), material="C_808080", segs=16, rings=8, scale=(1, 1, 1), name="sph"):
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=segs, v_segments=rings, radius=r)
    bmesh.ops.scale(bm, vec=Vector(scale), verts=bm.verts)
    obj = mesh_obj(name, bm, material, smooth=True, angle=80)
    obj.location = pos
    return obj


def lathe(profile, material="C_808080", segs=24, pos=(0, 0, 0), name="lathe", cap_bottom=True, cap_top=False, smooth=True):
    """profile: list of (radius, z) from bottom to top."""
    bm = bmesh.new()
    rings = []
    for (r, z) in profile:
        ring = []
        for i in range(segs):
            a = 2 * math.pi * i / segs
            ring.append(bm.verts.new((math.cos(a) * r, math.sin(a) * r, z)))
        rings.append(ring)
    for j in range(len(rings) - 1):
        for i in range(segs):
            a, b = rings[j][i], rings[j][(i + 1) % segs]
            c, d = rings[j + 1][(i + 1) % segs], rings[j + 1][i]
            try:
                bm.faces.new((a, b, c, d))
            except ValueError:
                pass
    if cap_bottom and profile[0][0] > 0.001:
        bm.faces.new(list(reversed(rings[0])))
    if cap_top and profile[-1][0] > 0.001:
        bm.faces.new(rings[-1])
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.0005)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    obj = mesh_obj(name, bm, material, smooth=smooth, angle=50)
    obj.location = pos
    return obj


def skin(points, edges=None, material="C_808080", subdiv=2, name="skin", pos=(0, 0, 0)):
    """points: [(x,y,z,radius)]; edges default: chain."""
    me = bpy.data.meshes.new(name)
    verts = [(p[0], p[1], p[2]) for p in points]
    if edges is None:
        edges = [(i, i + 1) for i in range(len(points) - 1)]
    me.from_pydata(verts, edges, [])
    obj = bpy.data.objects.new(name, me)
    _link(obj)
    obj.modifiers.new("skin", "SKIN")
    for i, p in enumerate(points):
        obj.data.skin_vertices[0].data[i].radius = (p[3], p[3])
    obj.data.skin_vertices[0].data[0].use_root = True
    if subdiv > 0:
        sub = obj.modifiers.new("sub", "SUBSURF")
        sub.levels = subdiv
        sub.render_levels = subdiv
    apply_mods(obj)
    obj.data.materials.append(mat(material))
    for pl in obj.data.polygons:
        pl.use_smooth = True
    obj.location = pos
    return obj


def subsurf(obj, levels=1):
    md = obj.modifiers.new("sub", "SUBSURF")
    md.levels = levels
    apply_mods(obj)
    for pl in obj.data.polygons:
        pl.use_smooth = True
    return obj


def join(objs, name):
    objs = [o for o in objs if o is not None]
    for o in bpy.context.selected_objects:
        o.select_set(False)
    for o in objs:
        o.select_set(True)
    bpy.context.view_layer.objects.active = objs[0]
    if len(objs) > 1:
        bpy.ops.object.join()
    o = bpy.context.view_layer.objects.active
    o.name = name
    o.data.name = name
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    return o


def set_origin(obj, point):
    """Move object origin to world `point` without moving geometry."""
    mw = obj.matrix_world.copy()
    delta = Vector(point) - mw.translation
    local = mw.inverted().to_3x3() @ delta
    obj.data.transform(Matrix.Translation(-local))
    obj.location = Vector(point)


def bake_transforms(obj):
    for o in bpy.context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)


def parent(child, par):
    mw = child.matrix_world.copy()
    child.parent = par
    child.matrix_world = mw


def empty(name, pos=(0, 0, 0)):
    e = bpy.data.objects.new(name, None)
    _link(e)
    e.location = pos
    return e


def export(path, objs=None):
    for o in bpy.context.selected_objects:
        o.select_set(False)
    targets = objs if objs is not None else list(bpy.context.scene.objects)
    for o in targets:
        o.select_set(True)
        for c in o.children_recursive:
            c.select_set(True)
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", use_selection=True, export_apply=True,
                              export_yup=True, export_materials="EXPORT", export_normals=True,
                              export_texcoords=True, export_cameras=False, export_lights=False,
                              export_animations=False)


def tris():
    n = 0
    for o in bpy.context.scene.objects:
        if o.type == "MESH":
            for p in o.data.polygons:
                n += len(p.vertices) - 2
    return n
