"""Valuables. Blender Z-up, models centred like the in-game collision shapes. Faces +Y (= Godot -Z).
Each model is baked (tools/bake.py) into its own small albedo + ORM atlas."""
import sys, os, math, random
sys.path.insert(0, os.path.dirname(__file__))
from blib import *
from organic import meta, displace, decimate, snap_objs, cloth
import bake as BK
import bmesh
from mathutils import Vector

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "models")
random.seed(7)


def canvas(w, h, pos, name="canvas"):
    bm = bmesh.new()
    bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=0.5, calc_uvs=True)
    bmesh.ops.scale(bm, vec=Vector((w, h, 1)), verts=bm.verts)
    o = mesh_obj(name, bm, "M_canvas")
    o.rotation_euler = (math.pi / 2, 0, 0)
    o.location = pos
    return o


def save(name, parts, tex=256, tris=2500, ao=0.12):
    o = join(parts, name)
    decimate(o, tris)
    o.data.use_auto_smooth = True
    o.data.auto_smooth_angle = math.radians(60)
    for pl in o.data.polygons:
        pl.use_smooth = True
    BK.bake(name, [o], tex, ao_dist=ao)
    export(os.path.join(OUT, name + ".glb"), [o])
    print("EXPORT", name, tris_n())


def tris_n():
    return tris()


def ring(r, z, h, t, material, segs=32, pos=(0, 0, 0)):
    return lathe([(r, z - h / 2), (r + t, z - h / 2 + t * 0.3), (r + t, z + h / 2 - t * 0.3), (r, z + h / 2)], material, segs, cap_bottom=False, pos=pos)


def goblet():
    reset()
    p = lathe([(0.055, -0.12), (0.058, -0.113), (0.05, -0.105), (0.02, -0.1), (0.014, -0.07), (0.024, -0.05), (0.024, -0.04), (0.014, -0.025),
               (0.03, 0.0), (0.06, 0.03), (0.075, 0.08), (0.078, 0.12), (0.072, 0.12), (0.068, 0.05), (0.045, 0.02)],
              "M_gold", 32, cap_top=False)
    rings = [ring(0.058, -0.11, 0.008, 0.004, "M_gold"), ring(0.076, 0.1, 0.012, 0.004, "M_gold")]
    gems = [sphere(0.012, (math.cos(a) * 0.068, math.sin(a) * 0.068, 0.065), "E_d0203a" if i % 2 else "E_2a60d8", 10, 5) for i, a in enumerate([i * math.tau / 6 for i in range(6)])]
    settings = [lathe([(0.014, -0.004), (0.017, 0.0), (0.014, 0.004)], "M_gold", 10, cap_bottom=False, pos=(math.cos(a) * 0.066, math.sin(a) * 0.066, 0.065)) for a in [i * math.tau / 6 for i in range(6)]]
    for s_, a in zip(settings, [i * math.tau / 6 for i in range(6)]):
        s_.rotation_euler = (math.pi / 2, 0, a + math.pi / 2)
    wine = cyl(0.066, 0.004, (0, 0, 0.1), "C_5a0a18", 24)
    save("goblet", [p, wine] + rings + gems + settings)


def jewelbox():
    reset()
    V = "L_leather_7a1520"
    b = box((0.26, 0.18, 0.1), (0, 0, -0.025), V, 0.012)
    lid = box((0.265, 0.185, 0.05), (0, 0, 0.05), V, 0.018)
    dome = cyl(0.09, 0.26, (0, 0, 0.075), V, 24, rot=(0, math.pi / 2, 0))
    dome.scale = (0.35, 1.0, 1.0)
    trim = box((0.272, 0.192, 0.012), (0, 0, 0.025), "M_gold", 0.004)
    corners = [box((0.03, 0.03, 0.14), (x, y, 0.005), "M_gold", 0.006) for x in (-0.125, 0.125) for y in (-0.085, 0.085)]
    lock = box((0.045, 0.014, 0.05), (0, 0.097, 0.02), "M_gold", 0.005)
    key = cyl(0.006, 0.02, (0, 0.105, 0.02), "C_111111", 6, rot=(math.pi / 2, 0, 0))
    gem = sphere(0.022, (0, 0, 0.11), "E_2a9df4", 12, 6, (1, 1, 0.6))
    pearls = [sphere(0.008, (x, y, 0.08), "L_ceramic_f2eee4", 8, 4) for x in [i * 0.03 - 0.105 for i in range(8)] for y in (-0.08, 0.08)]
    feet = [sphere(0.016, (x, y, -0.08), "M_gold", 10, 5) for x in (-0.11, 0.11) for y in (-0.07, 0.07)]
    save("jewelbox", [b, lid, dome, trim, lock, key, gem] + corners + pearls + feet)


def crystal():
    reset()
    ball = sphere(0.125, (0, 0, 0.04), "G_7fe8ff", 28, 14)
    core = sphere(0.05, (0, 0, 0.04), "E_9ff4ff", 14, 7)
    stand = lathe([(0.085, -0.14), (0.09, -0.13), (0.085, -0.12), (0.06, -0.105), (0.05, -0.085), (0.07, -0.075), (0.078, -0.062), (0.06, -0.05)], "L_wood_3a1e0e", 28, cap_top=True)
    band = ring(0.086, -0.128, 0.01, 0.003, "M_gold")
    claws = []
    for a in [0.3, 2.4, 4.5]:
        claws.append(skin([(math.cos(a) * 0.06, math.sin(a) * 0.06, -0.06, 0.01), (math.cos(a) * 0.095, math.sin(a) * 0.095, -0.02, 0.008), (math.cos(a) * 0.105, math.sin(a) * 0.105, 0.02, 0.005)], material="M_gold", subdiv=1))
    save("crystal", [ball, core, stand, band] + claws)


def vase():
    for v in range(3):
        reset()
        if v == 0:
            prof = [(0.07, -0.23), (0.09, -0.22), (0.12, -0.14), (0.13, -0.06), (0.11, 0.04), (0.06, 0.12), (0.05, 0.17), (0.07, 0.22), (0.075, 0.23), (0.065, 0.23), (0.045, 0.15)]
        elif v == 1:
            prof = [(0.06, -0.23), (0.07, -0.22), (0.1, -0.16), (0.12, -0.02), (0.1, 0.1), (0.07, 0.17), (0.085, 0.22), (0.09, 0.23), (0.08, 0.23), (0.06, 0.17)]
        else:
            prof = [(0.09, -0.23), (0.1, -0.2), (0.12, -0.05), (0.125, 0.05), (0.1, 0.17), (0.1, 0.23), (0.09, 0.23), (0.085, 0.17)]
        body = lathe(prof, "M_vase", 36)
        subsurf(body, 1)
        band = lathe([(0.121, -0.1), (0.126, -0.08), (0.126, -0.06), (0.121, -0.04)] if v != 1 else [(0.118, -0.05), (0.122, -0.03), (0.121, 0.0), (0.117, 0.02)], "M_gold", 36, cap_bottom=False)
        foot = lathe([(prof[0][0] + 0.005, -0.232), (prof[0][0] + 0.01, -0.225), (prof[0][0], -0.215)], "M_gold", 36, cap_bottom=False)
        lip = ring(prof[-3][0] - 0.004, prof[-3][1], 0.012, 0.004, "M_gold", 36)
        extra = []
        if v == 2:
            for s in (1, -1):
                extra.append(skin([(0.1 * s, 0, 0.19, 0.012), (0.15 * s, 0, 0.17, 0.011), (0.155 * s, 0, 0.08, 0.01), (0.12 * s, 0, 0.04, 0.009)], material="M_gold", subdiv=1))
        save("vase%d" % v, [body, band, foot, lip] + extra)


def clock():
    reset()
    W = "L_wood_5a3219"
    body = box((0.34, 0.12, 0.26), (0, 0, -0.04), W, 0.014)
    top = cyl(0.17, 0.12, (0, 0, 0.09), W, 32, rot=(math.pi / 2, 0, 0), bevel=0.012)
    moulding = box((0.36, 0.13, 0.02), (0, 0, -0.165), W, 0.006)
    face = cyl(0.12, 0.01, (0, 0.062, 0.05), "L_paper_f2ead5", 36, rot=(math.pi / 2, 0, 0))
    rim = lathe([(0.12, 0), (0.132, 0.0), (0.132, 0.014), (0.12, 0.014)], "M_gold", 36, cap_bottom=False)
    rim.rotation_euler = (-math.pi / 2, 0, 0)
    rim.location = (0, 0.06, 0.05)
    ticks = []
    for i in range(12):
        a = i * math.tau / 12
        big = i % 3 == 0
        t = box((0.006 if not big else 0.01, 0.004, 0.022 if not big else 0.03), (math.sin(a) * 0.1, 0.069, 0.05 + math.cos(a) * 0.1), "C_1a1a1a", 0.0, rot=(0, -a, 0))
        ticks.append(t)
    h1 = box((0.01, 0.004, 0.075), (0, 0.073, 0.08), "C_111111", 0.0)
    h2 = box((0.06, 0.004, 0.008), (0.028, 0.073, 0.05), "C_111111", 0.0)
    hub = cyl(0.01, 0.01, (0, 0.074, 0.05), "M_gold", 10, rot=(math.pi / 2, 0, 0))
    finial = [sphere(0.018, (0, 0, 0.27), "M_gold", 10, 5), cyl(0.008, 0.03, (0, 0, 0.245), "M_gold", 8)]
    feet = [sphere(0.022, (x, y, -0.18), "M_gold", 10, 5, (1, 1, 0.6)) for x in (-0.14, 0.14) for y in (-0.04, 0.04)]
    panel = box((0.2, 0.01, 0.08), (0, 0.061, -0.1), "L_wood_3a1e0e", 0.005)
    save("clock", [body, top, moulding, face, rim, h1, h2, hub, panel] + ticks + finial + feet)


def painting():
    reset()
    fr = box((0.8, 0.06, 0.6), (0, 0, 0), "M_gold", 0.02)
    inner = box((0.68, 0.065, 0.48), (0, 0, 0), "C_2a1a10")
    bead = box((0.7, 0.07, 0.5), (0, 0.002, 0), "L_wood_3a2010", 0.005)
    cv = canvas(0.66, 0.46, (0, 0.037, 0))
    orn = [sphere(0.035, (x, 0.03, z), "M_gold", 10, 5) for x in (-0.38, 0.38) for z in (-0.28, 0.28)]
    crest = sphere(0.05, (0, 0.03, 0.3), "M_gold", 12, 6, (1.6, 0.5, 0.8))
    save("painting", [fr, bead, inner, cv, crest] + orn)


def lamp():
    reset()
    base = lathe([(0.1, -0.28), (0.106, -0.27), (0.1, -0.26), (0.09, -0.25), (0.03, -0.23), (0.024, -0.215), (0.018, -0.2)], "M_gold", 32, cap_top=True)
    pole = cyl(0.014, 0.36, (0, 0, -0.03), "M_gold", 12)
    knots = [lathe([(0.014, z - 0.012), (0.024, z), (0.014, z + 0.012)], "M_gold", 16, cap_bottom=False) for z in (-0.12, 0.02)]
    shade = cloth([(0.17, 0.1), (0.14, 0.17), (0.11, 0.24), (0.088, 0.29)], "L_fabric_e8cf9a", 14, 0.008, 48, 2, 0.0)
    trim = ring(0.168, 0.102, 0.012, 0.004, "L_fabric_8a5a2a", 48)
    bulb = sphere(0.04, (0, 0, 0.15), "E_fff2c0", 12, 6)
    save("lamp", [base, pole, shade, trim, bulb] + knots)


def radio():
    reset()
    W = "L_wood_6a3a1a"
    body = box((0.45, 0.2, 0.3), (0, 0, 0), W, 0.03, 3)
    arch = cyl(0.11, 0.2, (-0.06, 0, 0.08), W, 28, rot=(math.pi / 2, 0, 0))
    grill = box((0.24, 0.01, 0.18), (-0.06, 0.1, -0.01), "L_fabric_c9b27a", 0.005)
    grill_top = cyl(0.1, 0.01, (-0.06, 0.1, 0.08), "L_fabric_c9b27a", 24, rot=(math.pi / 2, 0, 0))
    bars = [box((0.012, 0.012, 0.26), (-0.06 + x * 0.04, 0.108, 0.0), "L_wood_3a1e0e", 0.003) for x in (-2, -1, 0, 1, 2)]
    dial = cyl(0.045, 0.012, (0.15, 0.104, 0.05), "L_paper_f0e6c8", 24, rot=(math.pi / 2, 0, 0))
    dial_ring = lathe([(0.045, 0), (0.052, 0), (0.052, 0.01), (0.045, 0.01)], "M_gold", 24, cap_bottom=False)
    dial_ring.rotation_euler = (-math.pi / 2, 0, 0)
    dial_ring.location = (0.15, 0.1, 0.05)
    needle = box((0.004, 0.004, 0.04), (0.15, 0.112, 0.06), "C_b01818", 0.0, rot=(0, 0.4, 0))
    knobs = [cyl(0.024, 0.03, (0.15, 0.11, z), "L_plastic_3a2a1a", 16, rot=(math.pi / 2, 0, 0), bevel=0.004) for z in (-0.04, -0.1)]
    feet = [box((0.06, 0.16, 0.02), (x, 0, -0.16), "L_wood_3a1e0e", 0.006) for x in (-0.17, 0.17)]
    save("radio", [body, arch, grill, grill_top, dial, dial_ring, needle] + bars + knobs + feet)


def gramophone():
    reset()
    W = "L_wood_5a2c12"
    base = box((0.4, 0.4, 0.16), (0, 0, -0.16), W, 0.015)
    trim = box((0.42, 0.42, 0.02), (0, 0, -0.235), W, 0.006)
    plate_trim = box((0.36, 0.36, 0.01), (0, 0, -0.078), "M_gold", 0.003)
    plat = cyl(0.16, 0.02, (0, 0, -0.065), "L_rubber_141414", 36)
    grooves = [ring(r, -0.054, 0.002, 0.002, "C_2a2a2a", 36) for r in (0.07, 0.1, 0.13)]
    label = cyl(0.035, 0.024, (0, 0, -0.063), "L_paper_c23b2b", 18)
    arm = skin([(0.14, -0.12, -0.05, 0.01), (0.14, -0.12, 0.0, 0.01), (0.08, -0.04, 0.01, 0.009), (0.05, 0.02, -0.03, 0.008)], material="M_gold", subdiv=1)
    crank = [cyl(0.008, 0.08, (0.23, 0.05, -0.16), "M_gold", 8, rot=(0, math.pi / 2, 0)), cyl(0.012, 0.05, (0.27, 0.05, -0.13), "L_wood_2a1408", 8)]
    horn_neck = skin([(0.14, -0.14, -0.04, 0.02), (0.14, -0.16, 0.05, 0.022), (0.1, -0.12, 0.12, 0.025)], material="M_gold", subdiv=1)
    horn = lathe([(0.025, 0), (0.028, 0.06), (0.04, 0.14), (0.07, 0.22), (0.13, 0.28), (0.2, 0.315), (0.215, 0.322), (0.21, 0.328)], "M_gold", 40, cap_bottom=False)
    horn.rotation_euler = (-1.0, 0, 0.35)
    horn.location = (0.1, -0.12, 0.12)
    save("gramophone", [base, trim, plate_trim, plat, label, arm, horn_neck, horn] + grooves + crank)


def statue():
    """Classical marble figure holding a torch, on a stone plinth."""
    reset()
    M = "M_marble"
    ped = box((0.5, 0.5, 0.3), (0, 0, -0.55), "M_stone", 0.02)
    mould = [box((0.54, 0.54, 0.04), (0, 0, -0.41), "M_stone", 0.01), box((0.54, 0.54, 0.04), (0, 0, -0.69), "M_stone", 0.01)]
    plinth = box((0.42, 0.42, 0.06), (0, 0, -0.36), M, 0.01)
    robe = cloth([(0.2, -0.33), (0.17, -0.1), (0.14, 0.08), (0.12, 0.14)], M, 12, 0.012, 40, 4, 0.0)
    fig = meta("fig", [("ell", (0, 0, 0.22), 0.12, (1.1, 0.75, 1.3)), ("ell", (0, 0.05, 0.28), 0.07, (1.4, 0.8, 0.7)),
                       ("ell", (0, 0, 0.1), 0.12, (1.1, 0.8, 0.6)), ("cap", (0, 0, 0.37), 0.04, (0.04, 1, 1), (0, math.pi / 2, 0))], M, 0.012)
    head = meta("head", [("ell", (0, 0.01, 0.47), 0.085, (0.85, 0.95, 1.1)), ("ell", (0, -0.02, 0.5), 0.09, (0.95, 0.95, 0.85)),
                         ("ell", (0, 0.085, 0.465), 0.015, (0.6, 1.0, 1.6))], M, 0.008)
    bun = sphere(0.045, (0, -0.07, 0.5), M, 12, 6)
    arm_l = skin([(-0.13, 0, 0.3, 0.04), (-0.17, 0.03, 0.14, 0.035), (-0.08, 0.1, 0.07, 0.03)], material=M, subdiv=1)
    arm_r = skin([(0.13, 0, 0.3, 0.04), (0.19, 0.02, 0.46, 0.035), (0.17, 0.0, 0.62, 0.03)], material=M, subdiv=1)
    sash = skin([(-0.12, 0.08, 0.32, 0.02), (0.0, 0.11, 0.2, 0.02), (0.12, 0.09, 0.06, 0.02)], material=M, subdiv=1)
    torch = lathe([(0.018, 0.6), (0.026, 0.64), (0.05, 0.7), (0.055, 0.72), (0.0, 0.72)], "M_gold", 16, pos=(0.17, 0.0, 0.0), cap_bottom=True)
    flame = sphere(0.04, (0.17, 0.0, 0.77), "E_ffb030", 12, 6, (1, 1, 1.6))
    save("statue", [ped, plinth, robe, fig, head, bun, arm_l, arm_r, sash, torch, flame] + mould, tex=512, tris=4000, ao=0.2)


def grandclock():
    reset()
    W = "L_wood_3a1c0c"
    body = box((0.5, 0.33, 1.6), (0, 0, -0.15), W, 0.015)
    pil = [cyl(0.025, 1.5, (x, 0.16, -0.15), W, 12) for x in (-0.23, 0.23)]
    head = box((0.56, 0.36, 0.42), (0, 0, 0.75), W, 0.02)
    crown = cyl(0.28, 0.36, (0, 0, 0.95), W, 32, rot=(math.pi / 2, 0, 0))
    cornice = box((0.62, 0.4, 0.05), (0, 0, 0.55), W, 0.01)
    finials = [sphere(0.03, (x, 0, 1.25 if x == 0 else 1.0), "M_gold", 10, 5) for x in (-0.24, 0.0, 0.24)]
    base = box((0.58, 0.38, 0.14), (0, 0, -0.9), W, 0.02)
    plinth = box((0.62, 0.42, 0.04), (0, 0, -0.96), W, 0.01)
    face = cyl(0.17, 0.01, (0, 0.185, 0.72), "L_paper_efe4c8", 40, rot=(math.pi / 2, 0, 0))
    ring_ = cyl(0.19, 0.008, (0, 0.18, 0.72), "M_gold", 40, rot=(math.pi / 2, 0, 0))
    ticks = [box((0.008 if i % 3 else 0.014, 0.004, 0.03), (math.sin(i * math.tau / 12) * 0.145, 0.193, 0.72 + math.cos(i * math.tau / 12) * 0.145), "C_1a1a1a", 0.0, rot=(0, -i * math.tau / 12, 0)) for i in range(12)]
    window = box((0.28, 0.01, 0.8), (0, 0.166, -0.05), "G_302418")
    frame = [box((0.3, 0.02, 0.03), (0, 0.17, z), "M_gold", 0.004) for z in (-0.46, 0.36)] + [box((0.03, 0.02, 0.82), (x, 0.17, -0.05), "M_gold", 0.004) for x in (-0.15, 0.15)]
    pend = cyl(0.06, 0.012, (0, 0.16, -0.3), "M_gold", 24, rot=(math.pi / 2, 0, 0))
    rod = box((0.012, 0.005, 0.5), (0, 0.16, -0.03), "M_gold")
    weights = [cyl(0.02, 0.18, (x, 0.12, 0.1), "M_gold", 10) for x in (-0.07, 0.07)]
    hands = [box((0.01, 0.004, 0.12), (0, 0.192, 0.76), "C_111111"), box((0.08, 0.004, 0.01), (0.03, 0.192, 0.72), "C_111111")]
    save("grandclock", [body, head, crown, cornice, base, plinth, face, ring_, window, pend, rod] + pil + finials + ticks + frame + weights + hands, tex=512, tris=4000, ao=0.2)


def crown():
    reset()
    band = lathe([(0.1, -0.08), (0.106, -0.08), (0.112, 0.02), (0.106, 0.022), (0.095, -0.07)], "M_gold", 40, cap_bottom=False)
    ermine = ring(0.1, -0.085, 0.03, 0.012, "L_fur_f2eee4", 40)
    spots = [sphere(0.006, (math.cos(a) * 0.113, math.sin(a) * 0.113, -0.085), "C_111111", 6, 3) for a in [i * math.tau / 14 for i in range(14)]]
    spikes = []
    for i in range(8):
        a = i * math.pi / 4
        spikes.append(cyl(0.024, 0.08, (math.cos(a) * 0.106, math.sin(a) * 0.106, 0.06), "M_gold", 4, r2=0.0, smooth=False))
        spikes.append(sphere(0.014, (math.cos(a) * 0.106, math.sin(a) * 0.106, 0.105), "L_ceramic_f4f0ea", 10, 5))
        spikes.append(sphere(0.016, (math.cos(a + 0.4) * 0.11, math.sin(a + 0.4) * 0.11, -0.03), "E_d11a3a" if i % 2 else "E_1a6bd1", 10, 5))
    arches = [skin([(math.cos(a) * 0.1, math.sin(a) * 0.1, 0.02, 0.008), (math.cos(a) * 0.06, math.sin(a) * 0.06, 0.1, 0.007), (0, 0, 0.13, 0.007)], material="M_gold", subdiv=1) for a in [i * math.pi / 2 for i in range(4)]]
    orb_ = sphere(0.022, (0, 0, 0.15), "M_gold", 12, 6)
    cross = [box((0.01, 0.01, 0.05), (0, 0, 0.19), "M_gold", 0.002), box((0.035, 0.01, 0.01), (0, 0, 0.195), "M_gold", 0.002)]
    velvet = sphere(0.09, (0, 0, -0.02), "L_fabric_6b0f1e", 18, 9, (1, 1, 0.8))
    save("crown", [band, ermine, velvet, orb_] + spots + spikes + arches + cross)


def mask():
    reset()
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=28, v_segments=16, radius=0.14)
    bmesh.ops.scale(bm, vec=Vector((1.0, 0.55, 1.15)), verts=bm.verts)
    bmesh.ops.delete(bm, geom=[v for v in bm.verts if v.co.y < -0.01], context="VERTS")
    shell = mesh_obj("mask", bm, "M_mask", smooth=True, angle=80)
    md = shell.modifiers.new("sol", "SOLIDIFY")
    md.thickness = 0.012
    apply_mods(shell)
    eyes = [sphere(0.028, (x, 0.07, 0.03), "C_050505", 10, 6, (1.4, 0.4, 0.8)) for x in (-0.05, 0.05)]
    rims = [lathe([(0.03, -0.003), (0.036, 0.0), (0.03, 0.003)], "M_gold", 14, cap_bottom=False, pos=(x, 0.072, 0.03)) for x in (-0.05, 0.05)]
    for r_ in rims:
        r_.rotation_euler = (math.pi / 2, 0, 0)
        r_.scale = (1.4, 0.8, 1.0)
    mouth = sphere(0.03, (0, 0.074, -0.075), "C_050505", 10, 6, (1.7, 0.35, 0.5))
    brow = [box((0.08, 0.02, 0.018), (x, 0.074, 0.075), "M_gold", 0.006, rot=(0, -x * 5, 0)) for x in (-0.05, 0.05)]
    gems = [sphere(0.012, (0, 0.078, 0.11), "E_2ad1ff", 8, 4)]
    plume = [cyl(0.018, 0.2, (x, -0.02, 0.2), "L_fur_1e7a4a" if x < 0 else ("L_fur_c2a01e" if x == 0 else "L_fur_7a1e5a"), 6, r2=0.004, rot=(0, x * 3, 0)) for x in (-0.07, 0.0, 0.07)]
    save("mask", [shell, mouth] + eyes + rims + brow + gems + plume)


def beaker():
    reset()
    glass = lathe([(0.065, -0.11), (0.07, -0.1), (0.07, 0.05), (0.035, 0.09), (0.03, 0.11), (0.034, 0.115)], "G_d8f0ff", 28, cap_bottom=True)
    liquid = lathe([(0.062, -0.105), (0.066, -0.1), (0.066, 0.0), (0.0, 0.0)], "E_liquid", 24, cap_bottom=True)
    marks = [box((0.02, 0.003, 0.003), (0.0, 0.07, -0.08 + i * 0.03), "C_ffffff", 0.0) for i in range(5)]
    cork = cyl(0.03, 0.03, (0, 0, 0.125), "L_wood_a07850", 12, r2=0.034)
    save("beaker", [glass, liquid, cork] + marks)


def microscope():
    reset()
    base = box((0.24, 0.28, 0.04), (0, 0, -0.2), "L_metal_222428", 0.012)
    arm = skin([(0, -0.1, -0.18, 0.03), (0, -0.1, 0.0, 0.028), (0, -0.04, 0.12, 0.025)], material="L_plastic_e6e6ea", subdiv=1)
    stage = box((0.16, 0.14, 0.015), (0, 0.02, -0.08), "L_metal_222428", 0.004)
    clips = [box((0.01, 0.05, 0.005), (x, 0.02, -0.07), "M_chrome", 0.001) for x in (-0.05, 0.05)]
    tube = cyl(0.03, 0.2, (0, 0.02, 0.08), "L_plastic_e6e6ea", 20, rot=(0.35, 0, 0))
    eye = cyl(0.02, 0.06, (0, -0.02, 0.19), "L_metal_222428", 14, rot=(0.35, 0, 0))
    obj = [cyl(0.014, 0.05, (dx, 0.04, -0.035), "M_chrome", 12) for dx in (-0.02, 0.02)]
    knobs = [cyl(0.03, 0.02, (s * 0.04, -0.1, -0.06), "L_metal_222428", 16, rot=(0, math.pi / 2, 0), bevel=0.003) for s in (-1, 1)]
    save("microscope", [base, arm, stage, tube, eye] + clips + obj + knobs)


def powercell():
    reset()
    core = cyl(0.085, 0.34, (0, 0, 0), "E_33ff88", 24)
    glass = cyl(0.1, 0.34, (0, 0, 0), "G_9fffc8", 24)
    caps = [cyl(0.12, 0.05, (0, 0, z), "L_metal_3a3d42", 24, bevel=0.01) for z in (-0.19, 0.19)]
    bolts = [sphere(0.01, (math.cos(a) * 0.1, math.sin(a) * 0.1, z), "M_chrome", 6, 3) for a in [i * math.tau / 6 for i in range(6)] for z in (-0.216, 0.216)]
    bars = [box((0.015, 0.015, 0.34), (math.cos(a) * 0.105, math.sin(a) * 0.105, 0), "L_metal_3a3d42", 0.003) for a in [0, 2.1, 4.2]]
    stripes = [box((0.03, 0.005, 0.03), (0.0, 0.121, z), "C_e8c020", 0.0) for z in (-0.19, 0.19)]
    term = cyl(0.03, 0.03, (0, 0, 0.225), "M_chrome", 12)
    save("powercell", [core, glass, term] + caps + bolts + bars + stripes)


def server():
    reset()
    body = box((0.6, 0.6, 1.5), (0, 0, 0), "L_metal_1c1e24", 0.015)
    parts = [body]
    for i in range(10):
        z = -0.62 + i * 0.135
        parts.append(box((0.54, 0.02, 0.1), (0, 0.3, z), "L_metal_2c2f36", 0.004))
        parts.append(box((0.03, 0.01, 0.015), (-0.2 + (i % 3) * 0.02, 0.312, z), "E_33ff66" if i % 2 else "E_3399ff"))
        parts.append(box((0.2, 0.01, 0.05), (0.12, 0.312, z), "C_0d0e10"))
        parts.append(box((0.02, 0.012, 0.06), (-0.24, 0.312, z), "M_chrome", 0.003))
    save("server", parts, tex=256, ao=0.15)


def orb():
    reset()
    shell = sphere(0.22, (0, 0, 0), "G_b04dff", 28, 14)
    core = sphere(0.11, (0, 0, 0), "E_f0c8ff", 16, 8)
    rings = []
    for k in range(3):
        r = lathe([(0.2, -0.01), (0.23, -0.01), (0.23, 0.01), (0.2, 0.01)], "E_b04dff", 40, cap_bottom=False)
        r.rotation_euler = (k * 1.0, k * 0.7, 0)
        rings.append(r)
    save("orb", [shell, core] + rings, tex=64)


def head():
    reset()
    h = sphere(0.2, (0, 0, 0), "M_player", 28, 14, (1, 0.95, 0.92))
    visor = sphere(0.16, (0, 0.07, 0.01), "M_screen", 24, 12, (1.05, 0.6, 0.62))
    eyes = [sphere(0.03, (x, 0.165, 0.02), "M_player_glow", 10, 6, (1, 0.4, 1.2)) for x in (-0.055, 0.055)]
    ears = [cyl(0.06, 0.05, (s * 0.2, 0, 0.0), "L_metal_2a2c30", 18, rot=(0, math.pi / 2, 0), bevel=0.006) for s in (1, -1)]
    ant = cyl(0.008, 0.12, (0.08, -0.02, 0.23), "L_metal_2a2c30", 8)
    tip = sphere(0.022, (0.08, -0.02, 0.3), "M_player_glow", 8, 4)
    crack = box((0.12, 0.01, 0.01), (0.03, 0.17, 0.08), "C_111111", rot=(0, 0.6, 0))
    wires = [skin([(x, -0.02, -0.17, 0.012), (x * 1.5, 0.0, -0.24, 0.01), (x * 2.0, 0.03, -0.26, 0.006)], material="L_rubber_b02020" if x > 0 else "L_rubber_2050b0", subdiv=1) for x in (-0.04, 0.04)]
    save("head", [h, visor, ant, tip, crack] + eyes + ears + wires)


def cart():
    """C.A.R.T.-style trolley: open tub (no lid!), rubber rim, handle with a value screen facing the pusher (-X)."""
    reset()
    parts = []
    MT = "L_metal_7a8088"
    parts.append(box((1.2, 0.8, 0.05), (0, 0, -0.2), MT, 0.01))                     # floor
    for x in (-0.6, 0.6):                                                             # end walls
        parts.append(box((0.03, 0.8, 0.4), (x, 0, 0.0), MT, 0.004))
    for y in (-0.4, 0.4):                                                             # side walls
        parts.append(box((1.2, 0.03, 0.4), (0, y, 0.0), MT, 0.004))
    for x in (-0.3, 0.0, 0.3):                                                        # side ribs
        for y in (-0.415, 0.415):
            parts.append(box((0.04, 0.012, 0.36), (x, y, 0.0), "M_dark_metal", 0.003))
    for x in (-0.6, 0.6):
        for y in (-0.4, 0.4):
            parts.append(cyl(0.025, 0.42, (x, y, 0.0), "M_chrome", 10))
    # rubber rim: four strips around the opening
    for y in (-0.41, 0.41):
        parts.append(box((1.26, 0.05, 0.04), (0, y, 0.215), "L_rubber_2a2a2e", 0.012))
    for x in (-0.61, 0.61):
        parts.append(box((0.05, 0.84, 0.04), (x, 0, 0.215), "L_rubber_2a2a2e", 0.012))
    # handle + struts
    parts.append(cyl(0.022, 0.9, (-0.8, 0, 0.3), "L_rubber_e0551a", 14, rot=(math.pi / 2, 0, 0)))
    for y in (-0.4, 0.4):
        parts.append(box((0.24, 0.03, 0.03), (-0.69, y, 0.26), "M_chrome", 0.006, rot=(0, 0.45, 0)))
    # value screen on the handle, tilted towards the pusher
    parts.append(box((0.05, 0.32, 0.17), (-0.74, 0, 0.4), "C_1b1d22", 0.012, rot=(0, 0.35, 0)))
    parts.append(box((0.006, 0.28, 0.13), (-0.767, 0, 0.408), "E_0c2a18", 0.002, rot=(0, 0.35, 0)))
    parts.append(box((0.03, 0.06, 0.12), (-0.73, 0, 0.3), "M_dark_metal", 0.005))
    parts.append(box((0.02, 0.4, 0.18), (0.61, 0, 0.0), "C_e8c020", 0.004))            # yellow plate
    for x in (-0.45, 0.45):
        for y in (-0.33, 0.33):
            parts.append(cyl(0.08, 0.05, (x, y, -0.26), "M_rubber", 20, rot=(math.pi / 2, 0, 0), bevel=0.008))
            parts.append(cyl(0.035, 0.055, (x, y, -0.26), "M_chrome", 12, rot=(math.pi / 2, 0, 0)))
            parts.append(box((0.04, 0.05, 0.08), (x, y, -0.2), MT, 0.005))
    save("cart", parts, tex=256, tris=3000, ao=0.2)


ALL = [goblet, jewelbox, crystal, vase, clock, painting, lamp, radio, gramophone, statue, grandclock, crown, mask, beaker, microscope, powercell, server, orb, head, cart]
ONLY = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
for f in ALL:
    if not ONLY or f.__name__ in ONLY:
        f()
