#!/bin/sh
# Force lossy (WebP) import with mipmaps for baked model atlases; run after new PNGs appear.
cd "$(dirname "$0")/.."
timeout 400 godot --headless --path . --import > /dev/null 2>&1
for f in assets/mtex/*.png.import; do
  sed -i 's/^compress\/mode=[0-9]/compress\/mode=1/; s/^compress\/lossy_quality=.*/compress\/lossy_quality=0.8/; s/^mipmaps\/generate=false/mipmaps\/generate=true/; s/^detect_3d\/compress_to=[0-9]/detect_3d\/compress_to=0/; s/^process\/size_limit=.*/process\/size_limit=224/' "$f"
done
timeout 400 godot --headless --path . --import > /dev/null 2>&1
