"""Characters: player robot + monsters. Z-up, facing +Y (Godot -Z). Origin at feet.
Animated parts are separate objects whose origin is the joint pivot."""
import sys, os, math, random
sys.path.insert(0, os.path.dirname(__file__))
from blib import *
import bmesh
from mathutils import Vector

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "models")


def part(objs, name, pivot):
    o = join(objs, name)
    set_origin(o, pivot)
    return o


def _decimate_all(limit=1400):
    for o in list(bpy.context.scene.objects):
        if o.type != "MESH":
            continue
        n = sum(len(p.vertices) - 2 for p in o.data.polygons)
        if n > limit:
            md = o.modifiers.new("dec", "DECIMATE")
            md.ratio = max(0.3, limit / n)
            apply_mods(o)


import bake as BK
TEX_SIZE = {"robot": 512}


def save(name, parts):
    from organic import split_limb
    for o in list(parts):
        if o.type == "MESH" and o.name in ("leg_l", "leg_r", "arm_l", "arm_r"):
            split_limb(o, 0.5)
    _decimate_all()
    BK.bake(name, parts, TEX_SIZE.get(name, 512), ao_dist=0.25)
    export(os.path.join(OUT, name + ".glb"), parts)
    print("EXPORT", name, tris())


# ---------------------------------------------------------------- robot
def robot():
    reset()
    P = "M_player"
    D = "M_dark_metal"
    body = part([
        box((0.5, 0.38, 0.46), (0, 0, 0.82), P, 0.1, 3),
        box((0.36, 0.05, 0.22), (0, 0.19, 0.8), D, 0.03),
        box((0.26, 0.02, 0.03), (0, 0.215, 0.88), "M_player_glow", 0.01),
        box((0.3, 0.16, 0.34), (0, -0.25, 0.84), D, 0.05),
        box((0.04, 0.02, 0.22), (0.08, -0.335, 0.84), "M_player_glow"),
        box((0.04, 0.02, 0.22), (-0.08, -0.335, 0.84), "M_player_glow"),
        box((0.4, 0.3, 0.14), (0, 0, 0.55), D, 0.05),
        cyl(0.07, 0.14, (0, 0, 1.1), D, 12),
        # details: belt, bolts, vents, backpack pipes, number plate
        box((0.52, 0.4, 0.05), (0, 0, 0.62), "L_rubber_1a1a1e", 0.02),
        box((0.1, 0.03, 0.06), (0, 0.2, 0.62), "M_chrome", 0.01),
        *[sphere(0.012, (x, 0.19, z), "M_chrome", 6, 3) for x in (-0.2, 0.2) for z in (0.7, 0.98)],
        *[box((0.2, 0.015, 0.012), (0, 0.215, 0.73 + i * 0.022), D) for i in range(3)],
        skin([(0.1, -0.33, 0.98, 0.018), (0.2, -0.3, 1.05, 0.016), (0.24, -0.1, 1.02, 0.014)], material="L_rubber_2a2a30", subdiv=1),
        skin([(-0.1, -0.33, 0.98, 0.018), (-0.2, -0.3, 1.05, 0.016), (-0.24, -0.1, 1.02, 0.014)], material="L_rubber_2a2a30", subdiv=1),
        cyl(0.05, 0.12, (0, -0.35, 1.03), "L_metal_8a8f99", 12, rot=(0, math.pi / 2, 0), bevel=0.01),
        box((0.12, 0.012, 0.06), (0.14, 0.2, 0.96), "L_paint_e8e4da", 0.005),
    ], "body", (0, 0, 0.55))
    head = part([
        sphere(0.26, (0, 0, 1.38), P, 28, 14, (1.0, 0.95, 0.9)),
        sphere(0.2, (0, 0.1, 1.37), "M_screen", 24, 12, (1.05, 0.62, 0.66)),
        sphere(0.035, (-0.07, 0.225, 1.39), "M_player_glow", 12, 6, (1.0, 0.4, 1.5)),
        sphere(0.035, (0.07, 0.225, 1.39), "M_player_glow", 12, 6, (1.0, 0.4, 1.5)),
        cyl(0.07, 0.06, (0.26, 0, 1.38), D, 16, rot=(0, math.pi / 2, 0)),
        cyl(0.07, 0.06, (-0.26, 0, 1.38), D, 16, rot=(0, math.pi / 2, 0)),
        cyl(0.01, 0.22, (0.1, -0.05, 1.68), D, 8),
        sphere(0.03, (0.1, -0.05, 1.8), "M_player_glow", 10, 5),
    ], "head", (0, 0, 1.15))
    arms = []
    for side, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.33 * side
        arms.append(part([
            sphere(0.1, (x, 0, 1.03), P, 16, 8, (1.1, 1.0, 0.8)),
            sphere(0.085, (x, 0, 1.0), D, 14, 7),
            cyl(0.055, 0.26, (x, 0, 0.84), P, 12, bevel=0.01),
            sphere(0.06, (x, 0, 0.7), D, 12, 6),
            cyl(0.05, 0.22, (x, 0.02, 0.58), P, 12, bevel=0.01),
            box((0.1, 0.1, 0.06), (x, 0.02, 0.45), D, 0.02),
            box((0.025, 0.04, 0.1), (x + 0.03, 0.05, 0.38), D, 0.01),
            box((0.025, 0.04, 0.1), (x - 0.03, 0.05, 0.38), D, 0.01),
        ], nm, (x, 0, 1.0)))
    legs = []
    for side, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.13 * side
        legs.append(part([
            cyl(0.07, 0.22, (x, 0, 0.4), D, 12),
            sphere(0.07, (x, 0.0, 0.28), P, 12, 6),
            cyl(0.06, 0.2, (x, 0, 0.16), D, 12),
            box((0.14, 0.24, 0.08), (x, 0.04, 0.04), P, 0.03),
            box((0.15, 0.25, 0.025), (x, 0.04, 0.005), "L_rubber_141418", 0.01),
            sphere(0.075, (x, 0.04, 0.29), D, 12, 6, (1.0, 0.8, 1.0)),
        ], nm, (x, 0, 0.5)))
    save("robot", [body, head] + arms + legs)


# ---------------------------------------------------------------- lurker
def lurker():
    reset()
    S = "C_16161b"
    body = part([
        skin([(0, 0, 1.0, 0.13), (0, 0.02, 1.25, 0.11), (0, 0.0, 1.5, 0.14), (0, -0.03, 1.75, 0.16), (0, 0.03, 1.92, 0.07)], material=S, subdiv=1),
        skin([(-0.26, -0.02, 1.8, 0.05), (0, -0.03, 1.82, 0.08), (0.26, -0.02, 1.8, 0.05)], material=S, subdiv=1),
        skin([(-0.14, 0, 1.02, 0.07), (0.14, 0, 1.02, 0.07)], material=S, subdiv=1),
    ], "body", (0, 0, 1.0))
    head = part([
        sphere(0.15, (0, 0.06, 2.08), S, 20, 10, (0.85, 1.0, 1.35)),
        sphere(0.03, (-0.06, 0.18, 2.12), "E_ff2a10", 10, 5, (1.2, 0.6, 0.8)),
        sphere(0.03, (0.06, 0.18, 2.12), "E_ff2a10", 10, 5, (1.2, 0.6, 0.8)),
        sphere(0.05, (0, 0.17, 1.99), "C_000000", 10, 5, (1.2, 0.6, 1.6)),
    ], "head", (0, 0.02, 1.93))
    arms = []
    for side, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.28 * side
        fingers = []
        for f in range(4):
            fx = x + (f - 1.5) * 0.025 * side
            fingers.append(skin([(fx, 0.02, 0.62, 0.015), (fx, 0.06, 0.5, 0.012), (fx, 0.08, 0.4, 0.006)], material=S, subdiv=1))
        arms.append(part([skin([(x, 0, 1.8, 0.06), (x + 0.05 * side, 0.02, 1.3, 0.045), (x + 0.04 * side, 0.03, 0.85, 0.04), (x, 0.02, 0.63, 0.035)], material=S, subdiv=2)] + fingers, nm, (x, 0, 1.8)))
    legs = []
    for side, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.12 * side
        legs.append(part([skin([(x, 0, 1.0, 0.07), (x, 0.06, 0.55, 0.05), (x, -0.02, 0.12, 0.04), (x, 0.12, 0.02, 0.035)], material=S, subdiv=2)], nm, (x, 0, 1.0)))
    save("lurker", [body, head] + arms + legs)


# ---------------------------------------------------------------- brute
def brute():
    reset()
    S = "C_4a2418"
    body = part([
        skin([(0, 0, 1.0, 0.36), (0, 0.05, 1.45, 0.5), (0, 0.12, 1.95, 0.55), (0, 0.2, 2.2, 0.3)], material=S, subdiv=2),
        box((0.9, 0.2, 0.2), (0, -0.3, 2.15), "C_2b1510", 0.08),
    ], "body", (0, 0, 1.0))
    head = part([
        sphere(0.2, (0, 0.38, 2.28), S, 18, 9, (1.1, 1.0, 0.9)),
        box((0.28, 0.05, 0.05), (0, 0.56, 2.32), "E_ff7a00", 0.02),
        box((0.26, 0.12, 0.08), (0, 0.5, 2.17), "C_1a0c08", 0.03),
    ], "head", (0, 0.3, 2.2))
    arms = []
    for side, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.7 * side
        arms.append(part([
            skin([(x * 0.85, 0.1, 2.05, 0.2), (x, 0.15, 1.55, 0.17), (x * 1.05, 0.25, 1.05, 0.16)], material=S, subdiv=2),
            sphere(0.26, (x * 1.05, 0.28, 0.82), "C_3a1c12", 16, 8),
        ], nm, (x * 0.85, 0.1, 2.05)))
    legs = []
    for side, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.32 * side
        legs.append(part([skin([(x, 0, 1.0, 0.2), (x, 0.05, 0.5, 0.17), (x, 0.0, 0.1, 0.15), (x, 0.18, 0.06, 0.12)], material=S, subdiv=2)], nm, (x, 0, 1.0)))
    save("brute", [body, head] + arms + legs)


# ---------------------------------------------------------------- skitter
def skitter():
    reset()
    S = "C_9e8474"
    body = part([
        sphere(0.26, (0, -0.05, 0.32), S, 20, 10, (1.0, 1.25, 0.6)),
        sphere(0.14, (0, 0.28, 0.33), S, 16, 8, (1.0, 1.0, 0.8)),
        sphere(0.035, (-0.05, 0.4, 0.38), "E_ffe01a", 8, 4),
        sphere(0.035, (0.05, 0.4, 0.38), "E_ffe01a", 8, 4),
        sphere(0.025, (-0.09, 0.37, 0.36), "E_ffe01a", 8, 4),
        sphere(0.025, (0.09, 0.37, 0.36), "E_ffe01a", 8, 4),
        skin([(-0.05, 0.38, 0.28, 0.02), (-0.03, 0.46, 0.22, 0.01)], material="C_3a2a20", subdiv=1),
        skin([(0.05, 0.38, 0.28, 0.02), (0.03, 0.46, 0.22, 0.01)], material="C_3a2a20", subdiv=1),
    ], "body", (0, 0, 0.3))
    legs = []
    for i in range(6):
        side = -1 if i < 3 else 1
        y = -0.18 + (i % 3) * 0.18
        x = 0.18 * side
        legs.append(part([skin([(x, y, 0.32, 0.035), (x + 0.22 * side, y + 0.02, 0.45, 0.028), (x + 0.42 * side, y + 0.04, 0.0, 0.015)], material=S, subdiv=1)], "leg%d" % i, (x, y, 0.32)))
    save("skitter", [body] + legs)


# ---------------------------------------------------------------- howler
def howler():
    reset()
    head = part([
        sphere(0.28, (0, 0, 1.5), "M_bone", 22, 11, (0.95, 0.8, 1.1)),
        sphere(0.07, (-0.1, 0.2, 1.56), "C_000000", 10, 5, (1.0, 0.6, 1.2)),
        sphere(0.07, (0.1, 0.2, 1.56), "C_000000", 10, 5, (1.0, 0.6, 1.2)),
        sphere(0.02, (-0.1, 0.25, 1.56), "E_d0e8ff", 6, 3),
        sphere(0.02, (0.1, 0.25, 1.56), "E_d0e8ff", 6, 3),
        box((0.05, 0.06, 0.12), (0, 0.24, 1.47), "M_bone", 0.02),
    ], "head", (0, 0, 1.5))
    mouth = sphere(0.08, (0, 0.21, 1.34), "C_000000", 12, 6, (1.0, 0.5, 0.9))
    mouth.name = "mouth"
    set_origin(mouth, (0, 0.21, 1.34))
    bm = bmesh.new()
    segs = 20
    prof = [(0.2, 1.3), (0.28, 1.05), (0.38, 0.7), (0.46, 0.35)]
    rings = []
    rnd = random.Random(3)
    for (r, z) in prof:
        ring = []
        for i in range(segs):
            a = 2 * math.pi * i / segs
            rr = r * (1.0 + (0.12 * rnd.random() if z < 0.5 else 0))
            zz = z - (rnd.random() * 0.25 if z < 0.5 else 0)
            ring.append(bm.verts.new((math.cos(a) * rr, math.sin(a) * rr, zz)))
        rings.append(ring)
    for j in range(len(rings) - 1):
        for i in range(segs):
            bm.faces.new((rings[j][i], rings[j][(i + 1) % segs], rings[j + 1][(i + 1) % segs], rings[j + 1][i]))
    robe = mesh_obj("robe", bm, "C_141016", smooth=True, angle=80)
    sl = [skin([(sx * 0.22, 0.02, 1.25, 0.06), (sx * 0.38, 0.12, 0.95, 0.05), (sx * 0.34, 0.22, 0.72, 0.03)], material="C_141016", subdiv=1) for sx in (-1, 1)]
    body = part([robe] + sl, "body", (0, 0, 0.8))
    save("howler", [head, mouth, body])


def halfcyl(r, length, pos, material, segs=12):
    bm = bmesh.new()
    front, back = [], []
    for i in range(segs + 1):
        a = math.pi * i / segs
        y, z = math.cos(a) * r, math.sin(a) * r
        front.append(bm.verts.new((length / 2, y, z)))
        back.append(bm.verts.new((-length / 2, y, z)))
    for i in range(segs):
        bm.faces.new((back[i], back[i + 1], front[i + 1], front[i]))
    bm.faces.new(front)
    bm.faces.new(list(reversed(back)))
    bm.faces.new((front[0], front[-1], back[-1], back[0]))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    o = mesh_obj("hc", bm, material, smooth=True, angle=40)
    o.location = pos
    return o


# ---------------------------------------------------------------- mimic
def mimic():
    reset()
    W = "M_wood"
    body_parts = [box((0.72, 0.46, 0.32), (0, 0, 0.2), W, 0.015)]
    for x in (-0.3, 0.3):
        body_parts.append(box((0.04, 0.48, 0.34), (x, 0, 0.2), "M_dark_metal", 0.008))
    body_parts.append(box((0.74, 0.48, 0.03), (0, 0, 0.365), "M_gold", 0.006))
    for i in range(8):
        body_parts.append(cyl(0.022, 0.06, (-0.28 + i * 0.08, 0.2, 0.38), "M_bone", 4, r2=0.0, smooth=False))
    tongue = part([skin([(0, 0.0, 0.36, 0.05), (0, 0.15, 0.37, 0.045), (0, 0.3, 0.33, 0.03)], material="C_b3162a", subdiv=1)], "tongue", (0, 0.0, 0.36))
    body = part(body_parts, "body", (0, 0, 0.0))
    lid_parts = [
        halfcyl(0.23, 0.72, (0, 0, 0.37), W),
        box((0.04, 0.48, 0.2), (-0.3, 0, 0.44), "M_dark_metal", 0.008),
        box((0.04, 0.48, 0.2), (0.3, 0, 0.44), "M_dark_metal", 0.008),
        box((0.08, 0.03, 0.1), (0, 0.235, 0.42), "M_gold", 0.01),
    ]
    for i in range(8):
        c = cyl(0.022, 0.06, (-0.28 + i * 0.08, 0.2, 0.36), "M_bone", 4, r2=0.0, smooth=False)
        c.rotation_euler = (math.pi, 0, 0)
        lid_parts.append(c)
    lid = part(lid_parts, "lid", (0, -0.23, 0.38))
    # cut the lower half of the lid cylinder: scale it so it reads as a curved lid
    eyes = []
    for x, nm in ((-0.14, "eye_l"), (0.14, "eye_r")):
        e = sphere(0.04, (x, 0.18, 0.52), "E_ff2a10", 10, 5)
        e.name = nm
        eyes.append(e)
        parent(e, lid)
    save("mimic", [body, lid, tongue] + eyes)


# ---------------------------------------------------------------- watcher
def watcher():
    reset()
    S = "M_skin_pale"
    J = "C_8a7f74"
    body = part([
        skin([(0, 0, 1.0, 0.12), (0, 0, 1.2, 0.1), (0, 0, 1.45, 0.14), (0, 0, 1.65, 0.16)], material=S, subdiv=2),
        cyl(0.04, 0.12, (0, 0, 1.78), S, 10),
        sphere(0.06, (0.26, 0, 1.72), J, 10, 5),
        sphere(0.06, (-0.26, 0, 1.72), J, 10, 5),
        sphere(0.07, (0.11, 0, 1.0), J, 10, 5),
        sphere(0.07, (-0.11, 0, 1.0), J, 10, 5),
    ], "body", (0, 0, 1.0))
    head = part([sphere(0.13, (0, 0, 1.97), S, 18, 9, (0.85, 0.9, 1.25))], "head", (0, 0, 1.84))
    arms = []
    for side, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.26 * side
        arms.append(part([
            cyl(0.04, 0.34, (x, 0, 1.52), S, 10),
            sphere(0.045, (x, 0, 1.34), J, 10, 5),
            cyl(0.035, 0.32, (x, 0, 1.16), S, 10),
            box((0.05, 0.08, 0.14), (x, 0.01, 0.95), S, 0.02),
        ], nm, (x, 0, 1.72)))
    legs = []
    for side, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.11 * side
        legs.append(part([
            cyl(0.055, 0.45, (x, 0, 0.75), S, 10),
            sphere(0.055, (x, 0, 0.5), J, 10, 5),
            cyl(0.045, 0.42, (x, 0, 0.26), S, 10),
            box((0.09, 0.22, 0.05), (x, 0.05, 0.03), S, 0.02),
        ], nm, (x, 0, 1.0)))
    save("watcher", [body, head] + arms + legs)



def humanoid_limbs(S, arm_x, shoulder_z, hand_z, hip_x, hip_z, arm_r=0.05, leg_r=0.06, foot=True):
    arms, legs = [], []
    for side, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = arm_x * side
        arms.append(part([skin([(x, 0, shoulder_z, arm_r), (x * 1.1, 0.03, (shoulder_z + hand_z) / 2, arm_r * 0.85), (x, 0.05, hand_z, arm_r * 0.8)], material=S, subdiv=1)], nm, (x, 0, shoulder_z)))
    for side, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = hip_x * side
        pts = [(x, 0, hip_z, leg_r), (x, 0.03, hip_z * 0.5, leg_r * 0.85), (x, 0.0, 0.05, leg_r * 0.8)]
        if foot:
            pts.append((x, 0.1, 0.03, leg_r * 0.7))
        legs.append(part([skin(pts, material=S, subdiv=1)], nm, (x, 0, hip_z)))
    return arms, legs


def gremlin():
    reset()
    S = "C_5a7a3a"
    body = part([sphere(0.13, (0, 0, 0.32), S, 14, 7, (1, 0.8, 1.2)), box((0.2, 0.14, 0.12), (0, 0, 0.26), "C_6b3a1a", 0.03)], "body", (0, 0, 0.25))
    head = part([sphere(0.13, (0, 0.02, 0.58), S, 16, 8), sphere(0.025, (-0.05, 0.12, 0.6), "E_ffe01a", 8, 4), sphere(0.025, (0.05, 0.12, 0.6), "E_ffe01a", 8, 4),
                 cyl(0.04, 0.16, (-0.16, 0, 0.62), S, 6, r2=0.0, rot=(0, -1.2, 0)), cyl(0.04, 0.16, (0.16, 0, 0.62), S, 6, r2=0.0, rot=(0, 1.2, 0)),
                 box((0.1, 0.03, 0.02), (0, 0.13, 0.53), "C_f0f0e0")], "head", (0, 0, 0.45))
    arms, legs = humanoid_limbs(S, 0.13, 0.42, 0.2, 0.06, 0.2, 0.03, 0.035)
    save("gremlin", [body, head] + arms + legs)


def bomber():
    reset()
    body = part([sphere(0.2, (0, 0, 0.3), "C_1c1c1f", 18, 9), box((0.05, 0.05, 0.08), (0, 0, 0.53), "M_dark_metal"),
                 sphere(0.035, (-0.07, 0.17, 0.35), "E_ff3a10", 8, 4), sphere(0.035, (0.07, 0.17, 0.35), "E_ff3a10", 8, 4),
                 lathe([(0.201, 0.22), (0.205, 0.22), (0.205, 0.26), (0.201, 0.26)], "C_d8b020", 18, cap_bottom=False)], "body", (0, 0, 0.3))
    fuse = part([cyl(0.01, 0.1, (0, 0, 0.61), "C_a08050", 6), sphere(0.02, (0, 0, 0.67), "E_ffb020", 8, 4)], "fuse", (0, 0, 0.56))
    legs = [part([skin([(x, 0, 0.15, 0.03), (x, 0.03, 0.05, 0.025), (x, 0.08, 0.02, 0.02)], material="C_1c1c1f", subdiv=1)], "leg_" + ("r" if x > 0 else "l"), (x, 0, 0.15)) for x in (0.1, -0.1)]
    save("bomber", [body, fuse] + legs)


def eye():
    reset()
    stalk = skin([(0, 0, 0.0, 0.08), (0.02, 0.0, -0.2, 0.06), (0, 0.02, -0.4, 0.05)], material="C_6a2a30", subdiv=1)
    body = part([stalk], "body", (0, 0, 0.0))
    ball = part([sphere(0.2, (0, 0, -0.58), "C_efe8e0", 20, 10), sphere(0.1, (0, 0.13, -0.58), "C_b01818", 14, 7, (1, 0.5, 1)),
                 sphere(0.05, (0, 0.19, -0.58), "C_050505", 10, 5, (1, 0.4, 1)), sphere(0.015, (0.02, 0.215, -0.56), "E_ffffff", 6, 3)], "head", (0, 0, -0.45))
    veins = [box((0.01, 0.02, 0.16), (math.cos(a) * 0.19, math.sin(a) * 0.19, -0.58), "C_c02030", rot=(0, 0, a)) for a in (0.5, 2.0, 3.6, 5.0)]
    save("eye", [body, ball] + veins)


def tick():
    reset()
    body = part([sphere(0.07, (0, -0.02, 0.07), "C_4a2a22", 12, 6, (1, 1.3, 0.7)), sphere(0.035, (0, 0.08, 0.07), "C_2a1a14", 8, 4),
                 sphere(0.01, (-0.015, 0.11, 0.08), "E_ff2a10", 6, 3), sphere(0.01, (0.015, 0.11, 0.08), "E_ff2a10", 6, 3)], "body", (0, 0, 0.06))
    legs = []
    for i in range(6):
        side = -1 if i < 3 else 1
        y = -0.05 + (i % 3) * 0.05
        legs.append(part([skin([(side * 0.05, y, 0.07, 0.01), (side * 0.11, y + 0.01, 0.1, 0.008), (side * 0.15, y + 0.02, 0.0, 0.005)], material="C_2a1a14", subdiv=0)], "leg%d" % i, (side * 0.05, y, 0.07)))
    save("tick", [body] + legs)


def spewer():
    reset()
    S = "C_6a8a2a"
    body = part([sphere(0.22, (0, 0, 0.24), S, 16, 8, (1.1, 1.0, 0.85)), sphere(0.04, (-0.1, 0.16, 0.36), "E_ffe01a", 8, 4), sphere(0.04, (0.1, 0.16, 0.36), "E_ffe01a", 8, 4)] +
                [sphere(0.03, (0.15 * math.cos(a), 0.15 * math.sin(a) - 0.05, 0.4), "C_8aa03a", 6, 3) for a in (0.5, 1.8, 3.0, 4.2)], "body", (0, 0, 0.2))
    jaw = part([sphere(0.15, (0, 0.12, 0.14), "C_4a1a1a", 12, 6, (1.2, 0.8, 0.4))], "jaw", (0, 0.05, 0.18))
    legs = [part([skin([(x, 0.02, 0.12, 0.05), (x * 1.5, 0.08, 0.04, 0.04), (x * 1.6, 0.15, 0.02, 0.03)], material=S, subdiv=1)], "leg_" + ("r" if x > 0 else "l"), (x, 0.02, 0.12)) for x in (0.13, -0.13)]
    save("spewer", [body, jaw] + legs)


def rugrat():
    reset()
    S = "C_e8b8a0"
    body = part([sphere(0.28, (0, -0.1, 0.45), "C_f0f0f0", 16, 8, (1, 1.2, 1)), box((0.4, 0.3, 0.2), (0, -0.1, 0.3), "C_e8e8e8", 0.08)], "body", (0, 0, 0.35))
    head = part([sphere(0.36, (0, 0.2, 0.95), S, 20, 10), sphere(0.05, (-0.12, 0.5, 1.0), "C_101010", 8, 4), sphere(0.05, (0.12, 0.5, 1.0), "C_101010", 8, 4),
                 sphere(0.06, (0, 0.52, 0.82), "C_8a2020", 8, 4, (1.6, 0.5, 0.6))], "head", (0, 0.05, 0.7))
    arms, legs = humanoid_limbs(S, 0.3, 0.6, 0.25, 0.14, 0.3, 0.07, 0.08)
    save("rugrat", [body, head] + arms + legs)


def puff():
    reset()
    body = part([sphere(0.25, (0, 0, 0.26), "C_f0e6a0", 18, 9)] + [sphere(0.07, (0.24 * math.cos(a), 0.24 * math.sin(a), 0.26 + 0.1 * math.sin(a * 3)), "C_f0e6a0", 6, 3) for a in [i * 0.7 for i in range(9)]] +
                [sphere(0.035, (-0.08, 0.22, 0.34), "C_101010", 8, 4), sphere(0.035, (0.08, 0.22, 0.34), "C_101010", 8, 4), cyl(0.05, 0.04, (0, 0.25, 0.27), "C_f09020", 8, r2=0.02, rot=(math.pi / 2, 0, 0))], "body", (0, 0, 0.25))
    jaw = part([sphere(0.2, (0, 0.1, 0.2), "C_7a1010", 14, 7, (1, 1, 0.5))] + [cyl(0.02, 0.07, (-0.15 + i * 0.05, 0.22, 0.23), "M_bone", 4, r2=0.0, smooth=False) for i in range(7)], "jaw", (0, 0, 0.26))
    save("puff", [body, jaw])


def levitator():
    reset()
    S = "C_8a9ab0"
    body = part([skin([(0, 0, 0.35, 0.1), (0, 0, 0.6, 0.13), (0, 0, 0.8, 0.07)], material=S, subdiv=1), lathe([(0.2, 0.2), (0.16, 0.5), (0.1, 0.75)], "C_3a2a5a", 16)], "body", (0, 0, 0.4))
    head = part([sphere(0.24, (0, 0, 1.05), S, 18, 9, (1, 1, 1.15)), sphere(0.05, (-0.08, 0.2, 1.0), "E_c080ff", 8, 4, (1, 0.5, 1.4)), sphere(0.05, (0.08, 0.2, 1.0), "E_c080ff", 8, 4, (1, 0.5, 1.4))] +
                [box((0.3, 0.005, 0.01), (0, 0.1, 1.15 + i * 0.04), "C_6a7a90") for i in range(3)], "head", (0, 0, 0.85))
    arms, legs = humanoid_limbs(S, 0.16, 0.72, 0.38, 0.07, 0.35, 0.025, 0.03)
    save("levitator", [body, head] + arms + legs)


def butcher():
    reset()
    S = "C_a07a6a"
    body = part([skin([(0, 0, 0.9, 0.2), (0, 0.05, 1.2, 0.24), (0, 0.12, 1.45, 0.2)], material=S, subdiv=2), lathe([(0.26, 0.75), (0.25, 1.1), (0.2, 1.35)], "C_d8d0c0", 16, cap_bottom=False)], "body", (0, 0, 0.9))
    head = part([sphere(0.15, (0, 0.22, 1.62), S, 14, 7), box((0.18, 0.04, 0.05), (0, 0.36, 1.66), "C_000000", 0.01), cyl(0.12, 0.2, (0, 0.2, 1.8), "C_f0f0f0", 12, r2=0.14)], "head", (0, 0.18, 1.5))
    arms, legs = humanoid_limbs(S, 0.3, 1.38, 0.85, 0.13, 0.85, 0.07, 0.08)
    cleaver = [box((0.02, 0.3, 0.16), (0.33, 0.28, 0.82), "M_chrome", 0.005), cyl(0.02, 0.14, (0.33, 0.08, 0.82), "M_wood_dark", 8, rot=(math.pi / 2, 0, 0))]
    for c in cleaver:
        parent(c, arms[0])
    save("butcher", [body, head] + arms + legs + cleaver)


def bighead():
    reset()
    S = "C_d0b8a0"
    head = part([sphere(0.5, (0, 0, 1.5), S, 22, 11, (1, 0.95, 1.05)), sphere(0.07, (-0.17, 0.44, 1.62), "C_0a0a0a", 10, 5), sphere(0.07, (0.17, 0.44, 1.62), "C_0a0a0a", 10, 5),
                 sphere(0.015, (-0.17, 0.5, 1.63), "E_ffffff", 6, 3), sphere(0.015, (0.17, 0.5, 1.63), "E_ffffff", 6, 3), sphere(0.06, (0, 0.5, 1.48), S, 8, 4)], "head", (0, 0, 1.5))
    jaw = part([sphere(0.3, (0, 0.25, 1.22), "C_5a1010", 16, 8, (1.1, 0.6, 0.45))] + [cyl(0.03, 0.09, (-0.24 + i * 0.06, 0.4, 1.28), "M_bone", 4, r2=0.0, smooth=False) for i in range(9)], "jaw", (0, 0.1, 1.3))
    wisps = [cyl(0.08, 0.5, (x, -0.1, 1.0), "C_101014", 8, r2=0.0) for x in (-0.15, 0.1)]
    body = part(wisps, "body", (0, 0, 1.0))
    save("bighead", [head, jaw, body])


def projector():
    reset()
    S = "C_2a2226"
    body = part([skin([(0, 0, 1.2, 0.14), (0, 0, 1.6, 0.18), (0, 0, 1.95, 0.12)], material=S, subdiv=1), box((0.5, 0.3, 0.1), (0, 0, 1.9), "C_c02020", 0.03)], "body", (0, 0, 1.2))
    lamp = part([cyl(0.22, 0.36, (0, 0.05, 2.25), "M_dark_metal", 18, rot=(math.pi / 2, 0, 0), bevel=0.02), cyl(0.18, 0.02, (0, 0.24, 2.25), "E_fff4c0", 18, rot=(math.pi / 2, 0, 0)),
                 cyl(0.05, 0.12, (0, 0, 2.02), "M_dark_metal", 8)], "head", (0, 0, 2.05))
    arms, legs = humanoid_limbs(S, 0.3, 1.9, 1.1, 0.12, 1.2, 0.05, 0.07)
    save("projector", [body, lamp] + arms + legs)


def hunter():
    reset()
    S = "C_3a3226"
    body = part([skin([(0, 0, 1.1, 0.18), (0, 0, 1.5, 0.22), (0, 0.04, 1.8, 0.15)], material=S, subdiv=1), lathe([(0.3, 0.3), (0.25, 0.9), (0.2, 1.3)], "C_2a2a1e", 16)], "body", (0, 0, 1.1))
    head = part([sphere(0.17, (0, 0.05, 2.0), "C_4a3a2a", 14, 7, (0.9, 1, 1.1)), lathe([(0.24, 1.9), (0.2, 2.05), (0.1, 2.25), (0.02, 2.3)], "C_1e1a14", 14, pos=(0, 0.0, 0)),
                 box((0.28, 0.06, 0.07), (0, 0.19, 2.02), "C_d8d0c0", 0.02)], "head", (0, 0, 1.85))
    arms, legs = humanoid_limbs(S, 0.3, 1.75, 1.2, 0.13, 1.1, 0.06, 0.08)
    gun = [cyl(0.03, 0.9, (0.25, 0.45, 1.3), "M_dark_metal", 10, rot=(math.pi / 2, 0, 0)), cyl(0.03, 0.9, (0.31, 0.45, 1.3), "M_dark_metal", 10, rot=(math.pi / 2, 0, 0)),
           box((0.1, 0.35, 0.1), (0.28, -0.05, 1.28), "M_wood_dark", 0.02)]
    g = join(gun, "gun")
    parent(g, arms[0])
    save("hunter", [body, head] + arms + legs + [g])


ONLY = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
for f in [robot]:  # monsters now live in models_monsters.py
    if not ONLY or f.__name__ in ONLY:
        f()
