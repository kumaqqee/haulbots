#!/bin/bash
# Builds the optional HD content pack(s): 2048 px PBR surfaces (Basis Universal),
# 512 px model atlases and full-poly models (hd_src/models).
# Usage: tools/build_hd.sh <version> <out_dir> [work_dir]
set -e
VER=${1:-1.5}
OUT=$(realpath -m ${2:-build})
ROOT=$(cd "$(dirname "$0")/.." && pwd)
WORK=$(realpath -m ${3:-/tmp/haulbots_hd})
HDP=$WORK/proj
mkdir -p "$OUT" "$WORK"

echo "== project copy"
mkdir -p "$HDP"
( cd "$ROOT" && tar cf - --exclude=./build --exclude=./hd_src . ) | ( cd "$HDP" && tar xf - )

echo "== full-poly models"
cp "$ROOT"/hd_src/models/*.glb "$HDP/assets/models/"

echo "== 2048 surfaces"
if [ ! -f "$WORK/tex2048/wood.png" ]; then
  python3 "$ROOT/tools/gen_textures2.py" 2048 "$WORK/tex2048"
fi
cp "$WORK"/tex2048/*.png "$HDP/assets/tex/"

LIST=$WORK/list.txt
: > "$LIST"
set_basis() {  # file limit
  local f=$1.import
  sed -i 's/^compress\/mode=.*/compress\/mode=4/; s/^compress\/rdo_quality_loss=.*/compress\/rdo_quality_loss=1.6/; s/^compress\/normal_map=.*/compress\/normal_map=0/; s/^mipmaps\/generate=.*/mipmaps\/generate=true/; s/^process\/size_limit=.*/process\/size_limit='"$2"'/' "$f"
  grep -q '^compress/rdo_quality_loss' "$f" || sed -i 's/^compress\/mode=4/compress\/mode=4\ncompress\/rdo_quality_loss=1.6\ncompress\/uastc_level=1/' "$f"
  echo "res://${1#$HDP/}" >> "$LIST"
}
for p in "$WORK"/tex2048/*.png; do
  n=$(basename "$p")
  case $n in
    *_r.png) set_basis "$HDP/assets/tex/$n" 1024 ;;
    *) set_basis "$HDP/assets/tex/$n" 0 ;;
  esac
done
for p in "$HDP"/assets/mtex/*.png; do
  case $p in *_orm.png) continue ;; esac
  set_basis "$p" 0
done
for p in "$ROOT"/hd_src/models/*.glb; do
  echo "res://assets/models/$(basename "$p")" >> "$LIST"
done

echo "== import ($(wc -l < "$LIST") resources)"
godot --headless --path "$HDP" --import > "$WORK/import.log" 2>&1 || true
grep -E "ERROR" "$WORK/import.log" | grep -v ALSA | head -5 || true

echo "== pack"
rm -f "$OUT"/HAULBOTS-HD-"$VER"-*.pck
godot --headless --path "$HDP" -s res://tools/pack_hd.gd -- "$OUT" "$VER" "$LIST" 2>&1 | grep -E "HD\]|ERROR" | grep -v ALSA
ls -l "$OUT"/HAULBOTS-HD-"$VER"-*.pck
