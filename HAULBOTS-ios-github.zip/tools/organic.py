"""Organic / sculpt-like modelling helpers on top of blib (metaballs, displacement, smoothing)."""
import bpy, bmesh, math, random
from mathutils import Vector, Euler, Quaternion
from blib import mat, _link, apply_mods, join, set_origin


BLOAT = 0.55   # 0 = raw metaball radii (surface ~0.58r), 1 = isolated element surface == authored radius


_META_N = [0]


def meta(name, elems, material, res=0.03, thresh=0.6):
    """Build a smooth blobby mesh from metaball elements.
    elems: list of tuples/dicts: ("ball"|"ell"|"cap"|"cube", (x,y,z), radius, size=(sx,sy,sz), rot=(rx,ry,rz), neg=False, stiff=2.0)
    """
    _META_N[0] += 1
    uname = "MB%04d" % _META_N[0]      # unique base name: same-prefix metaballs would merge into one family
    mb = bpy.data.metaballs.new(uname)
    mb.resolution = res
    mb.render_resolution = res
    mb.threshold = thresh
    ob = bpy.data.objects.new(uname, mb)
    _link(ob)
    kinds = {"ball": "BALL", "ell": "ELLIPSOID", "cap": "CAPSULE", "cube": "CUBE", "plane": "PLANE"}
    for e in elems:
        if isinstance(e, dict):
            d = e
        else:
            d = {"t": e[0], "co": e[1], "r": e[2]}
            if len(e) > 3:
                d["s"] = e[3]
            if len(e) > 4:
                d["rot"] = e[4]
            if len(e) > 5:
                d["neg"] = e[5]
        el = mb.elements.new(type=kinds[d["t"]])
        el.co = d["co"]
        st = d.get("stiff", 2.0)
        # authored radius = visible surface radius of an isolated element
        # (field = stiffness * (1 - (d/R)^2)^3 crosses the threshold at d = R * k)
        k = math.sqrt(max(0.05, 1.0 - (thresh / st) ** (1.0 / 3.0)))
        el.radius = d["r"] * (1.0 + (1.0 / k - 1.0) * BLOAT)
        s = d.get("s", (1, 1, 1))
        el.size_x, el.size_y, el.size_z = s
        rot = d.get("rot", (0, 0, 0))
        el.rotation = Euler(rot).to_quaternion()
        el.use_negative = d.get("neg", False)
        el.stiffness = d.get("stiff", 2.0)
    for o in bpy.context.selected_objects:
        o.select_set(False)
    bpy.context.view_layer.objects.active = ob
    ob.select_set(True)
    bpy.ops.object.convert(target="MESH")
    me_ob = bpy.context.view_layer.objects.active
    me_ob.name = name
    me_ob.data.materials.clear()
    me_ob.data.materials.append(mat(material))
    for p in me_ob.data.polygons:
        p.use_smooth = True
    # remove the leftover metaball datablock users
    return me_ob


def displace(o, strength=0.01, size=0.08, kind="CLOUDS", depth=2, seed=0):
    tex = bpy.data.textures.new("dtex%d" % random.randint(0, 99999), type=kind)
    if kind in ("CLOUDS",):
        tex.noise_scale = size
        tex.noise_depth = depth
    elif kind == "VORONOI":
        tex.noise_scale = size
    elif kind == "MUSGRAVE":
        tex.noise_scale = size
    md = o.modifiers.new("disp", "DISPLACE")
    md.texture = tex
    md.strength = strength
    md.mid_level = 0.5
    md.texture_coords = "OBJECT" if False else "LOCAL"
    apply_mods(o)
    return o


def smooth(o, iters=2, factor=0.5):
    md = o.modifiers.new("sm", "SMOOTH")
    md.iterations = iters
    md.factor = factor
    apply_mods(o)
    return o


def decimate(o, target_tris):
    n = sum(len(p.vertices) - 2 for p in o.data.polygons)
    if n > target_tris:
        md = o.modifiers.new("dec", "DECIMATE")
        md.ratio = max(0.05, target_tris / n)
        apply_mods(o)
    for p in o.data.polygons:
        p.use_smooth = True
    return o


def assign_by(o, material, test):
    """Assign `material` to faces whose centre satisfies test(Vector) (object local coords)."""
    m = mat(material)
    if m.name not in [s.material.name for s in o.material_slots if s.material]:
        o.data.materials.append(m)
    idx = [s.material.name for s in o.material_slots].index(m.name)
    for p in o.data.polygons:
        if test(p.center):
            p.material_index = idx
    return o


def tube(points, material, verts=10, name="tube", cap=True):
    """Smooth tapered tube along points [(x,y,z,r)] (skin + subsurf)."""
    from blib import skin
    return skin(points, material=material, subdiv=1, name=name)


def spikes(o_center, n, radius, length, material, base_r=0.02, seed=1, up_only=False):
    from blib import cyl
    rnd = random.Random(seed)
    out = []
    for i in range(n):
        th = rnd.uniform(0, math.tau)
        ph = rnd.uniform(0.2, 1.3) if up_only else rnd.uniform(0.2, math.pi - 0.2)
        d = Vector((math.sin(ph) * math.cos(th), math.sin(ph) * math.sin(th), math.cos(ph)))
        p = Vector(o_center) + d * radius
        c = cyl(base_r, length, (0, 0, 0), material, 6, r2=0.0, smooth=False)
        c.location = p + d * length * 0.5
        c.rotation_euler = d.to_track_quat("Z", "Y").to_euler()
        out.append(c)
    return out


def _closest(surf, p):
    mw = surf.matrix_world
    inv = mw.inverted()
    ok, loc, nor, idx = surf.closest_point_on_mesh(inv @ Vector(p))
    if not ok:
        return None, None
    return mw @ loc, (mw.to_3x3() @ nor).normalized()


def snap_objs(objs, surf, sink=0.3):
    """Move each object's origin onto the nearest point of `surf` (sinking by `sink` x its half-size)."""
    bpy.context.view_layer.update()
    for o in objs:
        p, n = _closest(surf, o.matrix_world.translation)
        if p is None:
            continue
        r = max(o.dimensions) * 0.5
        o.location = p - n * r * sink
    return objs


def snap_verts(o, surf, lift=0.002):
    """Project every vertex of `o` onto `surf` (veins, cracks, stitches drawn on skin)."""
    bpy.context.view_layer.update()
    mw = o.matrix_world
    inv = mw.inverted()
    for v in o.data.vertices:
        p, n = _closest(surf, mw @ v.co)
        if p is not None:
            v.co = inv @ (p + n * lift)
    return o


def ring_radius(surf, z, cx=0.0, cy=0.0, samples=12):
    """Average distance from the vertical axis (cx,cy) to the surface at height z."""
    bpy.context.view_layer.update()
    mw = surf.matrix_world
    inv = mw.inverted()
    tot, n = 0.0, 0
    for i in range(samples):
        a = math.tau * i / samples
        far = Vector((cx + math.cos(a) * 5.0, cy + math.sin(a) * 5.0, z))
        d = Vector((-math.cos(a), -math.sin(a), 0.0))
        ok, loc, nor, idx = surf.ray_cast(inv @ far, (inv.to_3x3() @ d).normalized())
        if ok:
            w = mw @ loc
            tot += math.hypot(w.x - cx, w.y - cy)
            n += 1
    return tot / n if n else 0.0


def cloth(profile, material, folds=9, amp=0.02, segs=48, seed=0, hem_ragged=0.04):
    """Lathed garment with vertical folds that deepen towards the hem and a ragged hem."""
    from blib import lathe
    o = lathe(profile, material, segs, cap_bottom=False)
    z0 = min(p[1] for p in profile)
    z1 = max(p[1] for p in profile)
    rnd = random.Random(seed)
    ph = [rnd.uniform(0, math.tau) for _ in range(3)]
    for v in o.data.vertices:
        x, y, z = v.co
        r = math.hypot(x, y)
        if r < 1e-4:
            continue
        a = math.atan2(y, x)
        t = 1.0 - (z - z0) / max(1e-4, z1 - z0)      # 1 at hem, 0 at top
        f = math.sin(a * folds + ph[0]) * 0.7 + math.sin(a * folds * 2.3 + ph[1]) * 0.3
        k = 1.0 + f * amp * t / max(r, 0.05)
        v.co.x = x * k
        v.co.y = y * k
        if z - z0 < 0.02:
            v.co.z = z + (math.sin(a * 7 + ph[2]) * 0.5 + 0.5) * hem_ragged
    for p in o.data.polygons:
        p.use_smooth = True
    return o




def split_limb(o, frac=0.5, joint_mat=None, joint_r=0.0):
    """Split a limb object (origin = shoulder/hip pivot, hanging down) into an upper part and a
    '<name>_lo' child whose origin is the knee/elbow, so the game can bend it."""
    import bmesh as _bm
    from blib import sphere as _sphere, join as _join
    bpy.context.view_layer.update()
    mw = o.matrix_world
    zs = [(mw @ v.co).z for v in o.data.vertices]
    if not zs:
        return None
    top = mw.translation.z
    bot = min(zs)
    if top - bot < 0.08:
        return None
    kz = top - (top - bot) * frac
    # the knee sits on the limb's own centre line at that height
    near = [mw @ v.co for v in o.data.vertices if abs((mw @ v.co).z - kz) < (top - bot) * 0.08]
    if not near:
        return None
    kx = sum(p.x for p in near) / len(near)
    ky = sum(p.y for p in near) / len(near)
    knee = Vector((kx, ky, kz))
    bm = _bm.new()
    bm.from_mesh(o.data)
    inv = mw.inverted()
    kz_local = (inv @ knee).z
    lower_faces = [f for f in bm.faces if f.calc_center_median().z < kz_local]
    if not lower_faces or len(lower_faces) == len(bm.faces):
        bm.free()
        return None
    lo_bm = _bm.new()
    # copy lower faces into a new mesh
    vmap = {}
    for f in lower_faces:
        vs = []
        for v in f.verts:
            if v not in vmap:
                vmap[v] = lo_bm.verts.new(v.co)
            vs.append(vmap[v])
        try:
            nf = lo_bm.faces.new(vs)
            nf.material_index = f.material_index
            nf.smooth = f.smooth
        except ValueError:
            pass
    _bm.ops.delete(bm, geom=lower_faces, context="FACES")
    bm.to_mesh(o.data)
    bm.free()
    me = bpy.data.meshes.new(o.name + "_lo")
    lo_bm.to_mesh(me)
    lo_bm.free()
    for m in o.data.materials:
        me.materials.append(m)
    lo = bpy.data.objects.new(o.name + "_lo", me)
    bpy.context.scene.collection.objects.link(lo)
    lo.matrix_world = mw.copy()
    set_origin(lo, knee)
    if joint_r > 0.0 and joint_mat:
        j = _sphere(joint_r, tuple(knee), joint_mat, 10, 5)
        lo = _join([lo, j], o.name + "_lo")
        set_origin(lo, knee)
    mwl = lo.matrix_world.copy()
    lo.parent = o
    lo.matrix_world = mwl
    return lo
