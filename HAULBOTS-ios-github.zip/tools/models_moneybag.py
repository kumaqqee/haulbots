"""Surplus money bag ("tax return") dropped by an extraction point. Origin at the bag centre.
Run: blender -b -P tools/models_moneybag.py"""
import sys, os, math
sys.path.insert(0, os.path.dirname(__file__))
from blib import *
from organic import displace, decimate
import bake as BK

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "models")
reset()
sack = lathe([(0.0, -0.2), (0.12, -0.195), (0.19, -0.14), (0.215, -0.05), (0.2, 0.05), (0.15, 0.12), (0.075, 0.17),
              (0.05, 0.19), (0.06, 0.215), (0.09, 0.25), (0.07, 0.275), (0.0, 0.28)], "L_fabric_b89a62", 28, cap_bottom=True)
displace(sack, 0.012, 0.06, "CLOUDS", 2, 3)
subsurf(sack, 1)
rope = lathe([(0.052, 0.178), (0.06, 0.178), (0.062, 0.2), (0.054, 0.2)], "L_leather_5a3a1e", 20, cap_bottom=False)
tag = box((0.07, 0.006, 0.09), (0.07, -0.06, 0.16), "C_d8c28a", 0.004, rot=(0.2, 0, 0.5))
# "$" emblem: stylised with two bars and an S made of boxes, printed on the front
em = []
for (x, z, w, h) in [(0, 0.06, 0.07, 0.014), (0, 0.0, 0.07, 0.014), (0, -0.06, 0.07, 0.014),
                     (-0.03, 0.03, 0.014, 0.06), (0.03, -0.03, 0.014, 0.06), (0, 0.0, 0.01, 0.17)]:
    em.append(box((w, 0.01, h), (x, -0.212, z), "E_2f8a3a" if False else "C_2e7d32", 0.002))
o = join([sack, rope, tag] + em, "moneybag")
decimate(o, 1400)
o.data.use_auto_smooth = True
o.data.auto_smooth_angle = math.radians(50)
BK.bake("moneybag", [o], 128, ao_dist=0.06)
export(os.path.join(OUT, "moneybag.glb"), [o])
print("EXPORT moneybag", tris())
