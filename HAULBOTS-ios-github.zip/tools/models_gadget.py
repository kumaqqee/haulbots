"""First-person grab gadget (the tool the player always holds).
Forward (emitter) is +Y in Blender (= Godot -Z); origin at the grip top.
M_player / M_player_glow stay separate so the game tints them with the player colour.
Run: blender -b -P tools/models_gadget.py"""
import sys, os, math
sys.path.insert(0, os.path.dirname(__file__))
from blib import *
from mathutils import Matrix
import organic as O
import bake as BK

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "models")
ZC = 0.062  # barrel axis height


def torus(R, r, y, material, segs=28, rsegs=8, z=ZC):
    prof = [(R + math.cos(2 * math.pi * i / rsegs) * r, math.sin(2 * math.pi * i / rsegs) * r) for i in range(rsegs + 1)]
    t = lathe(prof, material, segs, cap_bottom=False, cap_top=False)
    t.rotation_euler = (-math.pi / 2, 0, 0)
    t.location = (0, y, z)
    return t


def along_y(o, y, z=ZC):
    o.rotation_euler = (-math.pi / 2, 0, 0)
    o.location = (0, y, z)
    return o


def gadget():
    reset()
    parts = []
    # main shell: tapered body flaring into the emitter housing
    shell = lathe([(0.0, 0.0), (0.026, 0.0), (0.038, 0.01), (0.045, 0.035), (0.048, 0.12), (0.045, 0.19),
                   (0.047, 0.205), (0.057, 0.225), (0.064, 0.255), (0.064, 0.275), (0.058, 0.286), (0.05, 0.29)],
                  "C_3b3f47", 32, cap_bottom=True)
    parts.append(along_y(shell, -0.13))
    # recessed emitter cone + glowing lens (player colour)
    cone = lathe([(0.05, 0.0), (0.036, -0.018), (0.02, -0.024)], "M_dark_metal", 28, cap_bottom=False)
    parts.append(along_y(cone, 0.16))
    lens = cyl(0.021, 0.004, (0, 0.137, ZC), "M_player_glow", 20, rot=(math.pi / 2, 0, 0))
    parts.append(lens)
    parts.append(torus(0.057, 0.0065, 0.162, "M_chrome"))
    parts.append(torus(0.037, 0.003, 0.147, "M_player_glow", 24, 6))
    # three claws around the emitter, tilted inward
    for k in range(3):
        a = math.pi / 2 + k * 2 * math.pi / 3
        for seg, (ln, r0, tilt, y0) in enumerate([(0.055, 0.056, 0.22, 0.16), (0.03, 0.046, 0.42, 0.212)]):
            c = box((0.012, ln, 0.009), (0, 0, 0), "M_dark_metal", 0.003)
            c.matrix_world = (Matrix.Translation((0, y0, ZC)) @ Matrix.Rotation(a, 4, "Y") @
                              Matrix.Translation((r0, 0, 0)) @ Matrix.Rotation(tilt, 4, "Z") @
                              Matrix.Translation((0, ln / 2, 0)))
            parts.append(c)
        tip = sphere(0.006, (0, 0, 0), "M_chrome", 8, 4)
        tip.matrix_world = Matrix.Translation((0, 0.239, ZC)) @ Matrix.Rotation(a, 4, "Y") @ Matrix.Translation((0.034, 0, 0))
        parts.append(tip)
    # copper coils
    for y in (-0.005, 0.02, 0.045):
        parts.append(torus(0.049, 0.0055, y, "L_metal_b87333", 28, 8))
    # side armour panels with vents
    for sx in (-1, 1):
        parts.append(box((0.008, 0.1, 0.034), (sx * 0.047, 0.1, ZC), "C_23262c", 0.003))
        for k in range(4):
            parts.append(box((0.003, 0.012, 0.022), (sx * 0.0515, 0.066 + k * 0.022, ZC), "M_dark_metal", 0.001))
    # top rail with player-colour strip and a tilted status screen
    parts.append(box((0.03, 0.2, 0.012), (0, 0.02, ZC + 0.048), "C_2a2d33", 0.004))
    parts.append(box((0.018, 0.17, 0.004), (0, 0.025, ZC + 0.055), "M_player", 0.0015))
    scr = box((0.046, 0.05, 0.012), (0, -0.095, ZC + 0.05), "C_1b1d22", 0.004, rot=(-0.4, 0, 0))
    parts.append(scr)
    parts.append(box((0.038, 0.04, 0.002), (0, -0.097, ZC + 0.057), "E_3de0c8", 0.0008, rot=(-0.4, 0, 0)))
    # rear power cell with glowing window
    parts.append(cyl(0.032, 0.05, (0, -0.15, ZC), "M_metal", 20, rot=(math.pi / 2, 0, 0), bevel=0.004))
    parts.append(cyl(0.0335, 0.014, (0, -0.155, ZC), "M_player_glow", 20, rot=(math.pi / 2, 0, 0)))
    parts.append(cyl(0.024, 0.01, (0, -0.178, ZC), "M_dark_metal", 16, rot=(math.pi / 2, 0, 0), bevel=0.002))
    # grip, trigger, guard
    parts.append(box((0.036, 0.05, 0.115), (0, -0.03, -0.035), "M_rubber", 0.013, rot=(0.28, 0, 0)))
    for k in range(3):
        parts.append(box((0.038, 0.008, 0.006), (0, -0.003 + 0.004 * k, -0.02 - k * 0.028), "C_2a2d33", 0.002, rot=(0.28, 0, 0)))
    parts.append(box((0.01, 0.014, 0.03), (0, 0.022, 0.012), "C_c0392b", 0.003, rot=(-0.3, 0, 0)))
    guard = O.tube([(0, 0.0, 0.03, 0.004), (0, 0.045, 0.01, 0.004), (0, 0.04, -0.012, 0.004), (0, 0.01, -0.016, 0.004)], "M_dark_metal")
    parts.append(guard)
    # cable from the grip base to the power cell
    parts.append(O.tube([(0, -0.055, -0.085, 0.006), (0, -0.1, -0.07, 0.006), (0, -0.15, -0.03, 0.006), (0, -0.17, 0.02, 0.006)], "M_rubber"))
    o = join(parts, "gadget")
    BK.bake("gadget", [o], 512, ao_dist=0.03)
    export(os.path.join(OUT, "gadget.glb"), [o])
    print("EXPORT gadget", tris())


gadget()
