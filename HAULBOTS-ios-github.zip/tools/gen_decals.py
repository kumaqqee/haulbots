"""Grunge decals (RGBA, 256 px): water stains, mould, cracks, cobwebs, drips, floor dirt, scuffs.
Run: python3 tools/gen_decals.py [size] [out_dir]"""
import numpy as np
from PIL import Image
import os, sys, math

N = int(sys.argv[1]) if len(sys.argv) > 1 else 256
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(__file__), "..", "assets", "decals")
os.makedirs(OUT, exist_ok=True)
Y, X = np.mgrid[0:N, 0:N].astype(np.float32) / N
R = np.sqrt((X - 0.5) ** 2 + (Y - 0.5) ** 2) * 2


def noise(freq, seed):
    r = np.random.default_rng(seed)
    w = r.standard_normal((N, N))
    f = np.fft.fft2(w)
    k = np.sqrt((np.fft.fftfreq(N)[:, None] * N) ** 2 + (np.fft.fftfreq(N)[None, :] * N) ** 2)
    k[0, 0] = 1
    out = np.real(np.fft.ifft2(f * np.exp(-(k / freq) ** 2) / k))
    out = (out - out.mean()) / (out.std() + 1e-9)
    return np.clip(0.5 + out * 0.18, 0, 1)


def fbm(seed, base=3, octaves=5):
    acc = 0
    amp = 1
    tot = 0
    for i in range(octaves):
        acc = acc + (noise(base * 2 ** i, seed + i * 13) - 0.5) * amp
        tot += amp
        amp *= 0.5
    return 0.5 + acc / tot * 1.6


def ss(a, b, x):
    t = np.clip((x - a) / (b - a + 1e-9), 0, 1)
    return t * t * (3 - 2 * t)


def save(name, rgb, a):
    img = np.dstack([np.clip(rgb, 0, 1), np.clip(a, 0, 1)])
    Image.fromarray((img * 255).astype(np.uint8), "RGBA").save(os.path.join(OUT, name + ".png"))
    print("wrote", name)


def col(h):
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)], np.float32)


def water_stain(seed=1):
    f = fbm(seed, 3)
    shape = R + (f - 0.5) * 0.9
    body = ss(0.8, 0.55, shape)
    ring = ss(0.12, 0.0, np.abs(shape - 0.72)) * 0.9 + ss(0.08, 0.0, np.abs(shape - 0.5)) * 0.4
    rgb = np.ones((N, N, 3)) * col("6a5234")
    rgb = rgb * (0.8 + fbm(seed + 3, 8)[..., None] * 0.4)
    a = np.clip(body * 0.35 + ring * 0.6, 0, 1) * ss(1.0, 0.85, R)
    save("stain_water", rgb, a)


def mould(seed=2):
    f = fbm(seed, 4)
    spots = ss(0.55, 0.75, fbm(seed + 1, 12) * 0.7 + f * 0.5)
    a = spots * ss(1.0, 0.3, R + (f - 0.5) * 0.6)
    rgb = np.ones((N, N, 3)) * col("1e2418") * (0.7 + noise(40, seed)[..., None] * 0.6)
    save("mould", rgb, a * 0.9)


def crack(seed=3):
    rnd = np.random.default_rng(seed)
    a = np.zeros((N, N), np.float32)
    def walk(x, y, ang, steps, w):
        nonlocal a
        for i in range(steps):
            ang += rnd.normal(0, 0.35)
            x += math.cos(ang) * 1.5 / N
            y += math.sin(ang) * 1.5 / N
            d = np.sqrt((X - x) ** 2 + (Y - y) ** 2)
            a = np.maximum(a, ss(w / N, w / N * 0.3, d))
            if rnd.random() < 0.02 and w > 1.0:
                walk(x, y, ang + rnd.choice([-1, 1]) * 0.9, steps // 2, w * 0.6)
            w = max(0.6, w * 0.995)
    for k in range(3):
        walk(0.5, 0.5, k * 2.1 + rnd.random(), int(90 * N / 256), 2.6)
    rgb = np.ones((N, N, 3)) * 0.06
    save("crack", rgb, a * ss(1.0, 0.9, R))


def cobweb(seed=4):
    # corner web: centre at top-left corner, radial strands + sagging rings
    x, y = X, Y
    r = np.sqrt(x * x + y * y) * 1.25
    th = np.arctan2(y, x)
    strands = np.zeros_like(r)
    for i in range(7):
        t = (i + 0.5) / 7 * (math.pi / 2)
        strands = np.maximum(strands, ss(0.006, 0.0, np.abs(np.sin(th - t)) * r))
    rings = np.zeros_like(r)
    for k in range(1, 7):
        rr = k * 0.14
        sag = 0.02 * np.sin((th % (math.pi / 14)) / (math.pi / 14) * math.pi)
        rings = np.maximum(rings, ss(0.004, 0.0, np.abs(r - rr - sag)))
    a = np.clip(strands + rings * 0.8, 0, 1) * ss(1.0, 0.8, r) * (0.6 + noise(30, seed) * 0.6)
    rgb = np.ones((N, N, 3)) * 0.85
    save("cobweb", rgb, a * 0.8)


def drips(seed=5):
    rnd = np.random.default_rng(seed)
    a = np.zeros((N, N), np.float32)
    for i in range(12):
        x0 = rnd.uniform(0.1, 0.9)
        ln = rnd.uniform(0.3, 0.95)
        w = rnd.uniform(0.006, 0.02)
        wob = np.sin(Y * rnd.uniform(8, 20) + rnd.uniform(0, 6)) * 0.01
        line = ss(w, w * 0.2, np.abs(X - x0 - wob)) * ss(ln, ln - 0.1, Y)
        a = np.maximum(a, line * rnd.uniform(0.4, 1.0))
    top = ss(0.25, 0.0, Y) * ss(0.55, 0.3, np.abs(X - 0.5)) * fbm(seed, 6)
    a = np.clip(a + top, 0, 1)
    rgb = np.ones((N, N, 3)) * col("3a2c1c")
    save("drips", rgb, a * 0.7)


def floor_dirt(seed=6):
    f = fbm(seed, 3)
    a = ss(0.9, 0.2, R + (f - 0.5) * 1.1) * (0.4 + fbm(seed + 1, 16) * 0.8)
    rgb = np.ones((N, N, 3)) * col("2e261c") * (0.8 + noise(60, seed)[..., None] * 0.4)
    save("floor_dirt", rgb, np.clip(a, 0, 1) * 0.6)


def scuffs(seed=7):
    rnd = np.random.default_rng(seed)
    a = np.zeros((N, N), np.float32)
    for i in range(25):
        x0, y0 = rnd.uniform(0.1, 0.9, 2)
        ang = rnd.uniform(-0.4, 0.4)
        ln = rnd.uniform(0.05, 0.3)
        dx, dy = math.cos(ang), math.sin(ang)
        t = np.clip((X - x0) * dx + (Y - y0) * dy, 0, ln)
        d = np.sqrt((X - x0 - t * dx) ** 2 + (Y - y0 - t * dy) ** 2)
        a = np.maximum(a, ss(0.006, 0.0, d) * rnd.uniform(0.3, 0.8))
    rgb = np.ones((N, N, 3)) * 0.12
    save("scuffs", rgb, a * ss(1.0, 0.8, R))


for f in (water_stain, mould, crack, cobweb, drips, floor_dirt, scuffs):
    f()
