"""Procedural, tileable textures (albedo + normal) for HAULBOTS.
Run: python3 tools/gen_textures.py  -> writes assets/tex/*.png
"""
import numpy as np
from PIL import Image
import os, math

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "tex")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(1234)
N = 512


def pnoise(n, scale, seed=0, aniso=(1.0, 1.0)):
    """Periodic fractal-ish noise via spectral filtering (tileable)."""
    r = np.random.default_rng(seed)
    w = r.standard_normal((n, n))
    f = np.fft.fft2(w)
    ky = np.fft.fftfreq(n)[:, None] * n / aniso[0]
    kx = np.fft.fftfreq(n)[None, :] * n / aniso[1]
    k = np.sqrt(kx * kx + ky * ky)
    k[0, 0] = 1.0
    filt = np.exp(-(k / scale) ** 2) / (k ** 0.9)
    filt[0, 0] = 0.0
    out = np.real(np.fft.ifft2(f * filt))
    out -= out.min()
    out /= out.max() + 1e-9
    return out


def fbm(n, seed, scales=(4, 12, 40, 110), weights=(0.5, 0.25, 0.15, 0.1), aniso=(1.0, 1.0)):
    acc = np.zeros((n, n))
    for i, (s, wt) in enumerate(zip(scales, weights)):
        acc += pnoise(n, s, seed + i * 17, aniso) * wt
    acc -= acc.min()
    return acc / (acc.max() + 1e-9)


def normal_from_height(h, strength=4.0):
    dx = (np.roll(h, -1, 1) - np.roll(h, 1, 1)) * strength
    dy = (np.roll(h, -1, 0) - np.roll(h, 1, 0)) * strength
    nz = np.ones_like(h)
    l = np.sqrt(dx * dx + dy * dy + nz * nz)
    n = np.stack([-dx / l, dy / l, nz / l], -1)  # OpenGL-style (Godot expects +Y up)
    return ((n * 0.5 + 0.5) * 255).astype(np.uint8)


NO_NORMAL = {"fabric", "carpet", "metal", "marble", "wood_dark", "wall_stripes"}


def save(name, rgb, height=None, strength=4.0):
    if name in NO_NORMAL:
        height = None
    img = np.clip(rgb * 255, 0, 255).astype(np.uint8)
    Image.fromarray(img, "RGB").save(os.path.join(OUT, name + ".png"))
    if height is not None:
        Image.fromarray(normal_from_height(height, strength), "RGB").save(os.path.join(OUT, name + "_n.png"))
    print("wrote", name)


def lerp(a, b, t):
    return a + (b - a) * t


def col(c):
    return np.array(c, dtype=float)[None, None, :]


yy, xx = np.mgrid[0:N, 0:N] / N

# ---------------------------------------------------------------- woods
def wood_grain(seed, base, dark, planks=6, herring=False):
    g = fbm(N, seed, scales=(3, 10, 30, 90), aniso=(1.0, 6.0))
    rings = 0.5 + 0.5 * np.sin((xx * 3 + g * 2.2) * math.pi * 6)
    t = np.clip(g * 0.6 + rings * 0.4, 0, 1)[..., None]
    rgb = lerp(col(dark), col(base), t)
    h = t[..., 0] * 0.3
    if planks:
        pw = 1.0 / planks
        row = np.floor(yy / pw)
        off = (row * 0.37) % 1.0
        seg = np.floor((xx + off) * 2.0)
        tone = (np.sin(row * 12.9898 + seg * 78.233) * 43758.5453) % 1.0
        rgb *= (0.82 + 0.3 * tone)[..., None]
        edge = np.minimum((yy % pw) / pw, 1 - (yy % pw) / pw)
        edge2 = np.minimum(((xx + off) * 2.0) % 1.0, 1 - ((xx + off) * 2.0) % 1.0)
        gap = np.clip(np.minimum(edge * 60, edge2 * 90), 0, 1)
        rgb *= (0.45 + 0.55 * gap)[..., None]
        h = h + gap * 0.6
    return np.clip(rgb, 0, 1), h


rgb, h = wood_grain(1, (0.55, 0.36, 0.2), (0.3, 0.17, 0.08), planks=6)
save("wood_floor", rgb, h, 6)
rgb, h = wood_grain(2, (0.5, 0.32, 0.17), (0.26, 0.14, 0.07), planks=0)
save("wood", rgb, h, 3)
rgb, h = wood_grain(3, (0.28, 0.16, 0.09), (0.12, 0.06, 0.03), planks=0)
save("wood_dark", rgb, h, 3)

# ---------------------------------------------------------------- wallpapers (grayscale-ish, tinted in engine)
def damask():
    rep = 4
    u = (xx * rep) % 1.0 - 0.5
    v = (yy * rep) % 1.0 - 0.5
    u2 = ((xx * rep + 0.5) % 1.0) - 0.5
    v2 = ((yy * rep + 0.5) % 1.0) - 0.5
    def orn(u, v):
        r = np.sqrt(u * u + (v * 0.8) ** 2)
        a = np.arctan2(v, np.abs(u))
        petal = 0.28 + 0.1 * np.cos(a * 5) + 0.05 * np.cos(a * 11)
        return np.clip((petal - r) * 40, 0, 1)
    m = np.maximum(orn(u, v), orn(u2, v2) * 0.6)
    n = fbm(N, 11) * 0.25
    t = np.clip(m * 0.55 + n, 0, 1)
    base = lerp(0.62, 0.95, t)
    rgb = np.repeat(base[..., None], 3, -1)
    return rgb, m * 0.5 + n * 0.3


def stripes():
    rep = 16
    s = (xx * rep) % 1.0
    band = np.where(s < 0.42, 1.0, np.where(s < 0.5, 0.75, 0.88))
    thin = np.exp(-((s - 0.46) ** 2) / 0.0004) * 0.2
    n = fbm(N, 12) * 0.2
    base = np.clip(band * 0.8 + thin + n, 0, 1)
    return np.repeat(base[..., None], 3, -1), band * 0.3 + n


def diamonds():
    rep = 6
    u = (xx * rep) % 1.0 - 0.5
    v = (yy * rep) % 1.0 - 0.5
    d = np.abs(u) + np.abs(v)
    m = np.clip((0.42 - d) * 30, 0, 1) - np.clip((0.3 - d) * 30, 0, 1)
    dot = np.clip((0.06 - np.sqrt(u * u + v * v)) * 80, 0, 1)
    n = fbm(N, 13) * 0.22
    base = np.clip(0.72 + m * 0.2 + dot * 0.25 + n, 0, 1)
    return np.repeat(base[..., None], 3, -1), m * 0.4 + dot * 0.4 + n


def plaster():
    n = fbm(N, 14, scales=(6, 20, 60, 160), weights=(0.35, 0.3, 0.2, 0.15))
    base = 0.78 + n * 0.22
    return np.repeat(base[..., None], 3, -1), n


def panels():
    rep = 4
    u = (xx * rep) % 1.0
    v = (yy * rep * 0.5) % 1.0
    edge = np.minimum(np.minimum(u, 1 - u), np.minimum(v, 1 - v))
    line = np.clip(edge * 70, 0, 1)
    n = fbm(N, 15) * 0.12
    rivet = 0
    base = np.clip(0.82 + n - (1 - line) * 0.35, 0, 1)
    return np.repeat(base[..., None], 3, -1), line * 0.8 + n


for name, fn in [("wall_damask", damask), ("wall_stripes", stripes), ("wall_diamond", diamonds), ("wall_plaster", plaster), ("wall_panels", panels)]:
    rgb, h = fn()
    save(name, rgb, h, 3)

# ---------------------------------------------------------------- floors
def tiles(c1, c2, rep=4, marble=False, seed=20):
    u = xx * rep
    v = yy * rep
    chk = ((np.floor(u) + np.floor(v)) % 2)[..., None]
    rgb = lerp(col(c1), col(c2), chk)
    if marble:
        n = fbm(N, seed, scales=(3, 9, 27, 81))
        vein = np.abs(np.sin((xx * 5 + n * 4) * math.pi * 3))
        vein = np.clip(1 - vein * 8, 0, 1) * 0.35
        rgb = rgb * (0.9 + 0.12 * n[..., None]) - vein[..., None] * 0.5
    else:
        n = fbm(N, seed) * 0.1
        rgb = rgb * (0.94 + n[..., None])
    fu = u % 1.0
    fv = v % 1.0
    grout = np.clip(np.minimum(np.minimum(fu, 1 - fu), np.minimum(fv, 1 - fv)) * 120, 0, 1)
    rgb = rgb * (0.55 + 0.45 * grout[..., None])
    return np.clip(rgb, 0, 1), grout * 0.8


rgb, h = tiles((0.86, 0.85, 0.82), (0.22, 0.21, 0.21), 4, True)
save("floor_marble", rgb, h, 5)
rgb, h = tiles((0.62, 0.66, 0.7), (0.52, 0.56, 0.6), 6, False, 21)
save("floor_lab", rgb, h, 5)
n = fbm(N, 30, scales=(8, 30, 90, 200))
rgb = np.repeat((0.42 + n * 0.25)[..., None], 3, -1) * col((1.0, 0.98, 0.95))
cracks = np.clip(1 - np.abs(pnoise(N, 5, 31) - 0.5) * 60, 0, 1) * 0.2
rgb -= cracks[..., None]
save("concrete", np.clip(rgb, 0, 1), n * 0.5 + cracks, 4)
n = fbm(N, 32, scales=(40, 120, 200, 250), weights=(0.3, 0.3, 0.2, 0.2))
rgb = np.repeat((0.7 + n * 0.3)[..., None], 3, -1)
save("carpet", rgb, n, 2)

# ---------------------------------------------------------------- misc
n = fbm(N, 40, scales=(2, 6, 200, 250), aniso=(1.0, 30.0))
rgb = np.repeat((0.55 + n * 0.35)[..., None], 3, -1)
save("metal", rgb, n * 0.3, 2)
weave = (np.sin(xx * N * math.pi / 2) * np.sin(yy * N * math.pi / 2)) * 0.5 + 0.5
n = fbm(N, 41) * 0.3
rgb = np.repeat((0.7 + weave * 0.15 + n)[..., None], 3, -1)
save("fabric", np.clip(rgb, 0, 1), weave * 0.5 + n, 2)
n = fbm(N, 42, scales=(3, 9, 27, 81))
vein = np.clip(1 - np.abs(np.sin((xx * 3 + yy * 2 + n * 3) * math.pi * 2)) * 10, 0, 1) * 0.3
rgb = np.repeat((0.9 + n * 0.08 - vein)[..., None], 3, -1)
save("marble", np.clip(rgb, 0, 1), n * 0.3 + vein, 2)
# grime overlay (used as detail on walls bottom etc.)
n = fbm(N, 43, scales=(4, 12, 40, 110))
rgb = np.repeat((0.75 + n * 0.25)[..., None], 3, -1)
save("grime", rgb)

# ---------------------------------------------------------------- paintings (256)
M = 256
py, px = np.mgrid[0:M, 0:M] / M
for i in range(8):
    r = np.random.default_rng(100 + i)
    kind = i % 4
    if kind == 0:  # landscape
        sky = lerp(col(r.uniform(0.3, 0.7, 3)), col(r.uniform(0.6, 1, 3)), py[..., None])
        hills = 0.55 + 0.1 * np.sin(px * 6 + r.uniform(0, 6)) + 0.05 * np.sin(px * 17)
        img = np.where((py > hills)[..., None], col(r.uniform(0.1, 0.4, 3)) * (1.2 - py[..., None] * 0.5), sky)
        sun = np.clip((0.08 - np.sqrt((px - r.uniform(0.2, 0.8)) ** 2 + (py - 0.3) ** 2)) * 30, 0, 1)
        img = img + sun[..., None] * col((1, 0.9, 0.6))
    elif kind == 1:  # portrait silhouette
        bg = col(r.uniform(0.15, 0.45, 3))
        head = np.sqrt((px - 0.5) ** 2 + ((py - 0.38) * 0.85) ** 2) < 0.16
        body = ((px - 0.5) ** 2 / 0.12 + (py - 1.0) ** 2 / 0.2) < 1.0
        img = np.where((head | body)[..., None], col(r.uniform(0.05, 0.2, 3)), bg * (1.2 - np.sqrt((px - .5) ** 2 + (py - .4) ** 2)[..., None]))
    elif kind == 2:  # abstract
        img = np.zeros((M, M, 3))
        for k in range(7):
            c = r.uniform(0, 1, 3)
            cx, cy, rr = r.uniform(0, 1), r.uniform(0, 1), r.uniform(0.1, 0.35)
            m = (np.sqrt((px - cx) ** 2 + (py - cy) ** 2) < rr)[..., None]
            img = np.where(m, img * 0.3 + c * 0.7, img)
        img += 0.15
    else:  # still life / sea
        img = lerp(col((0.1, 0.2, 0.35)), col((0.5, 0.65, 0.8)), (1 - py)[..., None])
        waves = np.sin(px * 40 + np.sin(py * 20) * 2) * 0.05 * (py > 0.5)[...]
        img = img + waves[..., None]
        boat = ((np.abs(px - 0.55) < 0.12) & (np.abs(py - 0.55) < 0.03)) | ((np.abs(px - 0.55) < 0.01) & (py > 0.35) & (py < 0.55))
        img = np.where(boat[..., None], col((0.2, 0.1, 0.05)), img)
    crack = pnoise(M, 60, 200 + i) * 0.12
    img = np.clip(img * (0.85 + crack[..., None]) * col((1.0, 0.95, 0.85)), 0, 1)
    Image.fromarray((img * 255).astype(np.uint8), "RGB").save(os.path.join(OUT, f"painting{i}.png"))
print("done")
