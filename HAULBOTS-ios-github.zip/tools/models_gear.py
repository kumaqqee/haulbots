"""Weapons, throwables, drones, trackers, crystal, pocket cart, truck charger.
Held tools: forward (barrel / blade tip) is +Y in Blender (= Godot -Z), origin at the grip centre."""
import sys, os, math
sys.path.insert(0, os.path.dirname(__file__))
from blib import *

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "models")


import bake as BK


def save(name, parts):
    o = join(parts, name)
    BK.bake(name, [o], 256 if name in ("charger", "w_shotgun", "w_sledge", "i_pocketcart") else 128, ao_dist=0.08)
    export(os.path.join(OUT, name + ".glb"), [o])
    print("EXPORT", name, tris())


def bat():
    reset()
    b = lathe([(0.018, 0), (0.024, 0.02), (0.02, 0.05), (0.022, 0.25), (0.03, 0.45), (0.04, 0.62), (0.042, 0.75), (0.035, 0.8), (0.0, 0.81)], "M_wood", 16, cap_bottom=True)
    b.rotation_euler = (-math.pi / 2, 0, 0)
    b.location = (0, -0.25, 0)
    tape = cyl(0.024, 0.16, (0, -0.14, 0), "C_1a1a1a", 12, rot=(math.pi / 2, 0, 0))
    save("w_bat", [b, tape])


def sledge():
    reset()
    handle = cyl(0.022, 0.9, (0, 0.0, 0), "M_wood_dark", 10, rot=(math.pi / 2, 0, 0))
    head = box((0.12, 0.12, 0.3), (0, 0.45, 0), "M_dark_metal", 0.015)
    grip = cyl(0.026, 0.2, (0, -0.35, 0), "C_b01818", 10, rot=(math.pi / 2, 0, 0))
    save("w_sledge", [handle, head, grip])


def pan():
    reset()
    dish = lathe([(0.0, 0.0), (0.13, 0.0), (0.15, 0.045), (0.14, 0.048), (0.12, 0.012), (0.0, 0.012)], "M_dark_metal", 24, cap_bottom=False)
    dish.location = (0, 0.28, -0.02)
    handle = box((0.035, 0.3, 0.025), (0, 0.0, 0), "M_wood_dark", 0.01)
    save("w_pan", [dish, handle])


def pistol():
    reset()
    body = box((0.05, 0.24, 0.07), (0, 0.06, 0.04), "C_2a2d33", 0.01)
    barrel = cyl(0.014, 0.1, (0, 0.2, 0.05), "M_chrome", 10, rot=(math.pi / 2, 0, 0))
    grip = box((0.045, 0.06, 0.12), (0, -0.03, -0.03), "C_14161a", 0.01, rot=(0.25, 0, 0))
    cell = box((0.03, 0.08, 0.02), (0, 0.06, 0.085), "E_ffb030", 0.005)
    save("w_pistol", [body, barrel, grip, cell])


def shotgun():
    reset()
    body = box((0.07, 0.4, 0.09), (0, 0.1, 0.03), "C_2a2d33", 0.01)
    barrel = cyl(0.02, 0.45, (0, 0.45, 0.05), "M_dark_metal", 12, rot=(math.pi / 2, 0, 0))
    pump = cyl(0.03, 0.14, (0, 0.38, 0.0), "M_wood_dark", 12, rot=(math.pi / 2, 0, 0))
    stock = box((0.06, 0.25, 0.1), (0, -0.2, 0.0), "M_wood_dark", 0.02, rot=(-0.15, 0, 0))
    cell = box((0.04, 0.1, 0.02), (0, 0.1, 0.085), "E_ffb030", 0.005)
    save("w_shotgun", [body, barrel, pump, stock, cell])


def tranq():
    reset()
    body = box((0.05, 0.28, 0.07), (0, 0.08, 0.04), "C_2e6a8a", 0.012)
    barrel = cyl(0.018, 0.16, (0, 0.28, 0.05), "C_e0e0e0", 10, rot=(math.pi / 2, 0, 0))
    tank = cyl(0.025, 0.12, (0, 0.05, 0.1), "E_40c8ff", 10, rot=(math.pi / 2, 0, 0))
    grip = box((0.045, 0.06, 0.12), (0, -0.03, -0.03), "C_14161a", 0.01, rot=(0.25, 0, 0))
    save("w_tranq", [body, barrel, tank, grip])


def prod():
    reset()
    shaft = cyl(0.02, 0.6, (0, 0.1, 0), "C_2a2d33", 10, rot=(math.pi / 2, 0, 0))
    tip = [cyl(0.006, 0.08, (x, 0.43, 0), "M_chrome", 6, rot=(math.pi / 2, 0, 0)) for x in (-0.015, 0.015)]
    glow = sphere(0.02, (0, 0.46, 0), "E_7ad8ff", 8, 4)
    grip = cyl(0.026, 0.18, (0, -0.15, 0), "C_f0b418", 10, rot=(math.pi / 2, 0, 0))
    save("w_prod", [shaft, glow, grip] + tip)


def grenades():
    for nm, col in (("g_explosive", "C_3a5a2a"), ("g_stun", "C_2a4a8a"), ("g_shock", "C_8a5a1a")):
        reset()
        b = sphere(0.06, (0, 0, 0), col, 14, 7, (1, 1, 1.15))
        cap = cyl(0.025, 0.035, (0, 0, 0.075), "M_dark_metal", 10)
        lever = box((0.015, 0.02, 0.09), (0.03, 0, 0.05), "M_chrome", rot=(0, 0.3, 0))
        ring = lathe([(0.018, 0.1), (0.024, 0.1), (0.024, 0.106), (0.018, 0.106)], "M_chrome", 12, cap_bottom=False)
        band = lathe([(0.061, -0.01), (0.063, -0.01), (0.063, 0.01), (0.061, 0.01)], "E_ff3020" if nm == "g_explosive" else ("E_40a0ff" if nm == "g_stun" else "E_ffa020"), 16, cap_bottom=False)
        save(nm, [b, cap, lever, ring, band])


def mines():
    for nm, col in (("m_explosive", "E_ff2010"), ("m_stun", "E_40a0ff")):
        reset()
        base = cyl(0.15, 0.05, (0, 0, 0), "C_2a2d33", 20, bevel=0.01)
        top = cyl(0.1, 0.03, (0, 0, 0.035), "M_dark_metal", 20)
        led = sphere(0.022, (0, 0, 0.06), col, 10, 5)
        prongs = [cyl(0.006, 0.05, (math.cos(a) * 0.07, math.sin(a) * 0.07, 0.06), "M_chrome", 6) for a in (0, 2.1, 4.2)]
        save(nm, [base, top, led] + prongs)


def drones():
    for nm, col in (("d_feather", "E_9fffb0"), ("d_shield", "E_ffd060")):
        reset()
        body = sphere(0.08, (0, 0, 0), "C_d0d4d8", 16, 8, (1, 1, 0.6))
        eye = sphere(0.03, (0, 0.07, 0), col, 10, 5)
        arms = []
        for a in (0.785, 2.356, 3.927, 5.498):
            x, y = math.cos(a) * 0.11, math.sin(a) * 0.11
            arms.append(box((0.12, 0.015, 0.012), (x * 0.5, y * 0.5, 0), "C_2a2d33", rot=(0, 0, a)))
            arms.append(cyl(0.045, 0.006, (x, y, 0.02), col, 12))
        ring = lathe([(0.081, -0.005), (0.085, -0.005), (0.085, 0.005), (0.081, 0.005)], col, 16, cap_bottom=False)
        save(nm, [body, eye, ring] + arms)


def trackers():
    for nm, col in (("t_valuable", "E_ffd040"), ("t_extract", "E_40ff80")):
        reset()
        body = box((0.09, 0.05, 0.16), (0, 0, 0), "C_2a2d33", 0.012)
        screen = box((0.07, 0.01, 0.08), (0, 0.026, 0.025), col, 0.004)
        ant = cyl(0.006, 0.08, (0.03, 0, 0.12), "M_chrome", 6)
        tip = sphere(0.012, (0.03, 0, 0.165), col, 6, 3)
        save(nm, [body, screen, ant, tip])


def crystal():
    reset()
    parts = [cyl(0.07, 0.03, (0, 0, -0.12), "M_dark_metal", 12, bevel=0.005)]
    for i, (h, r, x, y) in enumerate([(0.22, 0.04, 0, 0), (0.16, 0.03, 0.04, 0.02), (0.14, 0.028, -0.035, 0.03), (0.12, 0.025, 0.0, -0.04)]):
        c = cyl(r, h, (x, y, -0.1 + h / 2), "E_ffe066", 6, r2=0.0, smooth=False)
        c.rotation_euler = (x * 4, y * 4, 0)
        parts.append(c)
    save("i_crystal", parts)


def pocket_cart():
    reset()
    parts = [box((0.6, 0.4, 0.03), (0, 0, -0.1), "M_metal", 0.005)]
    for x in (-0.3, 0.3):
        parts.append(box((0.02, 0.4, 0.2), (x, 0, 0.0), "M_metal"))
    for y in (-0.2, 0.2):
        parts.append(box((0.6, 0.02, 0.2), (0, y, 0.0), "M_metal"))
    parts.append(cyl(0.012, 0.45, (-0.4, 0, 0.16), "C_e0551a", 8, rot=(math.pi / 2, 0, 0)))
    for x in (-0.22, 0.22):
        for y in (-0.16, 0.16):
            parts.append(cyl(0.04, 0.03, (x, y, -0.13), "M_rubber", 12, rot=(math.pi / 2, 0, 0)))
    save("i_pocketcart", parts)


def charger():
    reset()
    save("charger", [box((0.9, 0.6, 0.5), (0, 0, 0.25), "C_2a2d33", 0.02),
                     box((0.8, 0.5, 0.05), (0, 0, 0.51), "E_ffcc30", 0.01),
                     box((0.3, 0.05, 0.2), (0, 0.3, 0.3), "C_f0b418", 0.01)])


def smoke_puff():
    pass


for f in [bat, sledge, pan, pistol, shotgun, tranq, prod, grenades, mines, drones, trackers, crystal, pocket_cart, charger]:
    f()
