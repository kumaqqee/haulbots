"""HAULBOTS logo in the rusty-steel + chipped orange paint style of the key art.
Run: python3 tools/gen_title.py out.png [width]"""
import sys, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = sys.argv[1] if len(sys.argv) > 1 else "title.png"
W = int(sys.argv[2]) if len(sys.argv) > 2 else 1400
FONT = os.path.join(os.path.dirname(__file__), "..", "assets", "fonts", "RussoOne.ttf")
rng = np.random.default_rng(7)


def noise(h, w, scale, seed):
    r = np.random.default_rng(seed)
    small = r.random((max(2, h // scale), max(2, w // scale)))
    return np.array(Image.fromarray((small * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)).astype(np.float32) / 255.0


def fbm(h, w, seed):
    acc = np.zeros((h, w), np.float32)
    amp, tot = 1.0, 0.0
    for i, sc in enumerate([64, 32, 16, 8, 4, 2]):
        acc += noise(h, w, sc, seed + i) * amp
        tot += amp
        amp *= 0.55
    return acc / tot


H = int(W * 0.24)
font = ImageFont.truetype(FONT, int(H * 0.78))
text = "HAULBOTS"
# glyph mask
mask_img = Image.new("L", (W, H), 0)
d = ImageDraw.Draw(mask_img)
bb = d.textbbox((0, 0), text, font=font)
tw, th = bb[2] - bb[0], bb[3] - bb[1]
ox, oy = (W - tw) // 2 - bb[0], (H - th) // 2 - bb[1]
d.text((ox, oy), text, font=font, fill=255)
m = np.array(mask_img).astype(np.float32) / 255.0

# steel base with brushed streaks
steel = 0.33 + 0.13 * fbm(H, W, 1) + 0.05 * noise(H, W, 1, 9)[:, :]
streak = np.repeat(noise(1, W, 3, 4), H, axis=0) * 0.08
rgb = np.stack([steel + streak] * 3, axis=-1) * np.array([0.93, 0.95, 1.0])

# orange paint band across the middle (chipped edges like the key art)
y = np.linspace(0, 1, H)[:, None].repeat(W, axis=1)
band = ((y > 0.44) & (y < 0.7)).astype(np.float32)
chips = fbm(H, W, 20)
band *= (chips > 0.36).astype(np.float32)
paint = np.array([0.93, 0.44, 0.08]) * (0.8 + 0.3 * fbm(H, W, 21))[..., None]
rgb = rgb * (1 - band[..., None]) + paint * band[..., None]

# rust: brown-orange blotches concentrated on edges and bottom
rust_n = fbm(H, W, 30)
edge = np.array(Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.FIND_EDGES).filter(ImageFilter.GaussianBlur(4))).astype(np.float32) / 255.0
rust_amt = np.clip((rust_n - 0.47) * 3.0 + edge * 1.4 + (y - 0.6) * 0.8, 0, 1)
rust_col = np.array([0.36, 0.17, 0.07]) * (0.6 + 0.6 * fbm(H, W, 31))[..., None]
rgb = rgb * (1 - rust_amt[..., None] * 0.85) + rust_col * rust_amt[..., None] * 0.85
# grime streaks running down
drip = np.clip(np.repeat(noise(1, W, 2, 40), H, axis=0) - 0.55, 0, 1) * np.clip(y * 1.4, 0, 1) * 1.6
rgb *= (1 - drip[..., None] * 0.5)
# scratches
for _ in range(60):
    x0, y0 = rng.integers(0, W), rng.integers(0, H)
    ln = rng.integers(10, 60)
    ang = rng.uniform(-0.5, 0.5)
    xs = (x0 + np.arange(ln) * np.cos(ang)).astype(int)
    ys = (y0 + np.arange(ln) * np.sin(ang)).astype(int)
    ok = (xs >= 0) & (xs < W) & (ys >= 0) & (ys < H)
    rgb[ys[ok], xs[ok]] = rgb[ys[ok], xs[ok]] * 0.75 + 0.18

# bevel: light from top-left using the blurred mask gradient
hm = np.array(Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(3))).astype(np.float32) / 255.0
gy, gx = np.gradient(hm)
shade = np.clip(1.0 + (-gx - gy) * 9.0, 0.45, 1.6)
rgb *= shade[..., None]

rgb = np.clip(rgb, 0, 1)
alpha = m
# dark outline + drop shadow
out_mask = np.array(Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(11))).astype(np.float32) / 255.0
shadow = np.array(Image.fromarray((out_mask * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(10))).astype(np.float32) / 255.0
shadow = np.roll(np.roll(shadow, 8, axis=0), 6, axis=1)
final = np.zeros((H, W, 4), np.float32)
# layer 1: shadow
final[..., 3] = shadow * 0.75
# layer 2: outline (near-black rusty)
ol = np.array([0.06, 0.04, 0.03])
a2 = out_mask
final[..., :3] = final[..., :3] * (1 - a2[..., None]) + ol * a2[..., None]
final[..., 3] = final[..., 3] * (1 - a2) + a2
# layer 3: letters
final[..., :3] = final[..., :3] * (1 - alpha[..., None]) + rgb * alpha[..., None]
final[..., 3] = np.maximum(final[..., 3], alpha)
img = Image.fromarray((np.clip(final, 0, 1) * 255).astype(np.uint8), "RGBA")
img = img.crop(img.getbbox())
img.save(OUT)
print("wrote", OUT, img.size)
