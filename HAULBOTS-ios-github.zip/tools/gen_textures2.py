"""High quality procedural PBR surface textures (tileable): <name>.png (albedo), <name>_n.png (normal),
<name>_r.png (roughness). Run: python3 tools/gen_textures2.py [size] [out_dir]
Base game uses 512, the HD pack 2048. Everything is computed in UV space [0,1) so every size looks the same."""
import numpy as np
from PIL import Image
import os, sys, math

N = int(sys.argv[1]) if len(sys.argv) > 1 else 512
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(__file__), "..", "assets", "tex")
os.makedirs(OUT, exist_ok=True)
Y, X = np.mgrid[0:N, 0:N].astype(np.float32) / N      # v, u in [0,1)
_cache = {}


def noise(freq, seed, aniso=(1.0, 1.0), power=1.0):
    """Tileable band-limited noise, 0..1. freq ~ features per tile."""
    key = (freq, seed, aniso, power)
    if key in _cache:
        return _cache[key]
    r = np.random.default_rng(seed)
    w = r.standard_normal((N, N)).astype(np.float32)
    f = np.fft.fft2(w)
    ky = np.fft.fftfreq(N)[:, None] * N / aniso[0]
    kx = np.fft.fftfreq(N)[None, :] * N / aniso[1]
    k = np.sqrt(kx * kx + ky * ky)
    k[0, 0] = 1.0
    filt = np.exp(-(k / freq) ** 2) / (k ** power)
    filt[0, 0] = 0.0
    out = np.real(np.fft.ifft2(f * filt)).astype(np.float32)
    out = (out - out.mean()) / (out.std() + 1e-9)
    out = 0.5 + out * 0.18
    out = np.clip(out, 0, 1)
    _cache[key] = out
    return out


def fbm(seed, base=4, octaves=5, aniso=(1.0, 1.0), gain=0.5):
    acc = np.zeros((N, N), np.float32)
    amp, tot = 1.0, 0.0
    for i in range(octaves):
        acc += (noise(base * 2 ** i, seed + i * 31, aniso) - 0.5) * amp
        tot += amp
        amp *= gain
    return 0.5 + acc / tot * 1.6


def ss(a, b, x):
    t = np.clip((x - a) / (b - a + 1e-9), 0, 1)
    return t * t * (3 - 2 * t)


def mix(a, b, t):
    if np.ndim(t) == 2 and (np.ndim(a) != 2 or np.ndim(b) != 2) and (np.ndim(a) in (1, 3) or np.ndim(b) in (1, 3)):
        t = t[..., None]
    return a * (1 - t) + b * t


def C(hexs):
    return np.array([int(hexs[i:i + 2], 16) / 255.0 for i in (0, 2, 4)], np.float32)


def normal_map(h, strength):
    s = strength * N / 512.0
    dx = (np.roll(h, -1, 1) - np.roll(h, 1, 1)) * s
    dy = (np.roll(h, -1, 0) - np.roll(h, 1, 0)) * s
    nz = np.ones_like(h)
    l = np.sqrt(dx * dx + dy * dy + nz * nz)
    n = np.stack([-dx / l, dy / l, nz / l], -1)
    return n * 0.5 + 0.5


def cavity(h, r=3):
    """Local height minus blurred height (tileable) -> crevices < 0."""
    k = max(1, int(r * N / 512))
    b = h.copy()
    for ax in (0, 1):
        acc = np.zeros_like(b)
        for d in range(-k, k + 1):
            acc += np.roll(b, d, ax)
        b = acc / (2 * k + 1)
    return h - b


def save(name, alb, h, rough, nstr=3.0, ao=0.6):
    cav = cavity(h, 4)
    shade = np.clip(1.0 + cav * ao * 6.0, 0.55, 1.12)
    alb = np.clip(alb * shade[..., None], 0, 1)
    Image.fromarray((alb * 255).astype(np.uint8), "RGB").save(os.path.join(OUT, name + ".png"))
    Image.fromarray((normal_map(h, nstr) * 255).astype(np.uint8), "RGB").save(os.path.join(OUT, name + "_n.png"))
    Image.fromarray((np.clip(rough, 0, 1) * 255).astype(np.uint8), "L").save(os.path.join(OUT, name + "_r.png"))
    print("wrote", name, N)


def grime(seed, amount=1.0):
    """Large soft stains + fine dirt, 0..1 (1 = dirty)."""
    big = ss(0.55, 0.8, fbm(seed, 2, 5))
    fine = ss(0.5, 0.9, fbm(seed + 7, 16, 3))
    return np.clip(big * 0.7 + fine * 0.3, 0, 1) * amount


# ------------------------------------------------------------------ wood

def grain(u, v, seed, rings=18.0, warp=0.05):
    """Wood grain running along u. v*rings = number of growth bands across. Returns 0..1."""
    w = fbm(seed, 2, 4, aniso=(1.0, 0.1))
    w2 = noise(24, seed + 5, aniso=(1.0, 0.1667))
    phase = v * rings + (w - 0.5) * 2.0 + (w2 - 0.5) * 0.8
    sn = np.sin(phase * math.pi * 2)
    band = 0.5 + 0.5 * sn
    lines = ss(0.9, 1.0, sn) * 0.5
    fibres = noise(220, seed + 3, aniso=(1.0, 0.0417))
    return np.clip(band * 0.5 + fibres * 0.35 + 0.15 - lines * 0.4, 0, 1)


def planks(name, light, dark, rows=6, seed=1, varnish=0.35, herring=False, vertical=False):
    u, v = X, Y
    r = np.floor(v * rows)
    lv = v * rows - r
    rnd = np.random.default_rng(seed)
    offs = rnd.random(rows + 1).astype(np.float32)
    lens = rnd.integers(1, 3, rows + 1)
    # plank index along u with staggered joints (1 or 2 joints per tile per row)
    uu = (u + offs[r.astype(int) % rows]) % 1.0
    seg = np.floor(uu * lens[r.astype(int) % rows])
    lu = uu * lens[r.astype(int) % rows] - seg
    pid = (r * 7 + seg * 13) % 29
    ptone = np.array(rnd.random(32), np.float32)[pid.astype(int)]
    g = grain(uu, v + ptone[..., None][..., 0] * 0.5, seed + 11, rings=rows * (3.0 + ptone * 2.0))
    base = mix(C(dark), C(light), (g * 0.65 + ptone * 0.35))
    base *= (0.85 + ptone[..., None] * 0.25)
    # knots
    kn = ss(0.88, 0.97, noise(9, seed + 5))
    base = mix(base, C(dark) * 0.6, kn * 0.8)
    # gaps + bevels
    dv = np.minimum(lv, 1 - lv) / rows
    du = np.minimum(lu, 1 - lu) / lens[r.astype(int) % rows]
    gap = 1 - ss(0.0, 0.0035, np.minimum(dv, du))
    h = g * 0.25 + (1 - gap) * 0.6 + ptone * 0.05
    h -= gap * 0.6
    base = mix(base, base * 0.45, gap)
    wear = grime(seed + 20, 0.8)
    base = mix(base, base * 0.7 + np.array([0.04, 0.03, 0.02]), wear * 0.5)
    scratches = ss(0.75, 0.95, noise(60, seed + 40, aniso=(1.0, 0.0333)))
    base = mix(base, base * 1.25, scratches * 0.25)
    rough = varnish + wear * 0.3 + (1 - g) * 0.08 + scratches * 0.1 + gap * 0.4
    if vertical:
        base, h, rough = base.transpose(1, 0, 2), h.T, rough.T
    save(name, base, h, rough, 3.5)


def wainscot(name, light, dark, seed=3):
    """Raised wood panels (two panels per tile horizontally, one vertically)."""
    pu = (X * 2) % 1.0
    pv = Y
    d = np.minimum(np.minimum(pu, 1 - pu), np.minimum(pv, 1 - pv))
    frame = d < 0.12
    bevel = ss(0.12, 0.2, d)
    g = grain(X, Y, seed, rings=14)
    gv = grain(Y, X, seed + 9, rings=14)
    wood = np.where(frame[..., None], mix(C(dark), C(light), gv * 0.7), mix(C(dark), C(light), g * 0.8 + 0.1))
    h = np.where(frame, 0.55, 0.3 + bevel * 0.5) + g * 0.05
    groove = ss(0.0, 0.01, np.abs(d - 0.12))
    h -= (1 - groove) * 0.3
    wood = mix(wood, wood * 0.35, (1 - groove))
    wood = mix(wood, wood * 0.75, grime(seed + 4, 0.6) * 0.6)
    rough = 0.4 + (1 - bevel) * 0.1 + grime(seed + 4) * 0.25
    save(name, wood, h, rough, 3.0)


# ------------------------------------------------------------------ wallpapers

def motif_damask(u, v):
    """Symmetric damask ornament in a unit cell centred at 0.5,0.5."""
    x = np.abs(u - 0.5) * 2
    y = (v - 0.5) * 2
    r = np.sqrt(x * x + y * y)
    th = np.arctan2(y, x + 1e-6)
    petals = np.cos(th * 3 + 0.5) * 0.18 + 0.52
    body = ss(0.03, -0.01, r - petals * (1 - 0.4 * np.abs(y)))
    stem = ss(0.07, 0.04, np.abs(x - 0.18 * np.sin(y * 3.2 + 0.4)) + np.abs(y) * 0.1) * ss(0.95, 0.7, np.abs(y))
    curl = ss(0.06, 0.03, np.abs(np.sqrt((x - 0.55) ** 2 + (y + 0.35) ** 2) - 0.22)) * (x > 0.35)
    leaf = ss(0.04, 0.0, np.sqrt((x * 1.6 - 0.9) ** 2 + (y * 0.9 - 0.55) ** 2) - 0.28)
    inner = ss(0.02, -0.02, r - petals * 0.55)
    return np.clip(body - inner * 0.7 + stem + curl + leaf, 0, 1)


def wallpaper_damask(name, ground, ink, seed=5):
    # two offset motif lattices (brick layout)
    m1 = motif_damask((X * 2) % 1.0, (Y * 2) % 1.0)
    m2 = motif_damask((X * 2 + 0.5) % 1.0, (Y * 2 + 0.5) % 1.0)
    m = np.clip(np.maximum(m1, m2 * 0.9), 0, 1)
    sheen = noise(200, seed, aniso=(1.0, 0.1667))
    alb = mix(C(ground) * (0.94 + sheen[..., None] * 0.1), C(ink), m * 0.85)
    seam = ss(0.004, 0.0, np.abs(((X * 2) % 1.0) - 0.0))
    stains = grime(seed + 3, 0.9)
    water = ss(0.6, 0.72, fbm(seed + 8, 2, 5)) * ss(0.55, 0.0, Y) * 0.7
    alb = mix(alb, alb * np.array([0.78, 0.7, 0.55]), np.clip(stains * 0.55 + water, 0, 1))
    alb = mix(alb, alb * 0.6, seam * 0.6)
    h = m * 0.35 + sheen * 0.05 + noise(120, seed + 1) * 0.08
    rough = 0.72 - m * 0.2 + stains * 0.15
    save(name, alb, h, rough, 1.6, ao=0.3)


def wallpaper_stripes(name, a, b, seed=6):
    u = X * 6
    wide = ((np.floor(u) % 2) == 0)
    pin = ss(0.015, 0.0, np.abs((u % 1.0) - 0.5) - 0.02)
    micro = ss(0.3, 0.0, np.abs(((X * 60 + Y * 60) % 1.0) - 0.5) - 0.2) * 0.25
    alb = np.where(wide[..., None], C(a), C(b))
    alb = mix(alb, C(a) * 1.35, pin * 0.8)
    alb = alb * (1 - micro[..., None] * 0.2)
    stains = grime(seed, 0.8)
    alb = mix(alb, alb * np.array([0.75, 0.68, 0.55]), stains * 0.55)
    peel = ss(0.84, 0.9, fbm(seed + 2, 3, 5)) * ss(0.3, 0.0, Y)
    alb = mix(alb, np.array([0.55, 0.5, 0.42]), peel)
    h = wide * 0.05 + pin * 0.1 + micro * 0.2 + peel * 0.3
    rough = 0.75 + stains * 0.1
    save(name, alb, h, rough, 1.4, ao=0.3)


def wallpaper_diamond(name, ground, line, flower, seed=7):
    u = X * 4
    v = Y * 4
    d = np.abs(((u + v) % 1.0) - 0.5)
    e = np.abs(((u - v) % 1.0) - 0.5)
    lines = ss(0.03, 0.01, np.minimum(d, e))
    cx = (u % 1.0) - 0.5
    cy = (v % 1.0) - 0.5
    rr = np.sqrt(cx * cx + cy * cy)
    th = np.arctan2(cy, cx)
    fl = ss(0.02, 0.0, rr - (0.09 + 0.05 * np.cos(th * 5)))
    dot = ss(0.02, 0.0, rr - 0.025)
    alb = mix(C(ground), C(line), lines * 0.9)
    alb = mix(alb, C(flower), fl)
    alb = mix(alb, C(line) * 0.8, dot)
    alb *= (0.95 + noise(150, seed)[..., None] * 0.1)
    stains = grime(seed + 1, 0.8)
    alb = mix(alb, alb * np.array([0.75, 0.68, 0.55]), stains * 0.5)
    h = lines * 0.2 + fl * 0.25 + noise(100, seed + 2) * 0.06
    rough = 0.7 - fl * 0.15 + stains * 0.1
    save(name, alb, h, rough, 1.5, ao=0.3)


def plaster(name, col, seed=8, dirty=1.0):
    n = fbm(seed, 6, 6)
    bumps = noise(90, seed + 1) * 0.5 + noise(30, seed + 2) * 0.5
    cr = fbm(seed + 3, 4, 5)
    crack = ss(0.008, 0.0, np.abs(cr - 0.5)) * ss(0.6, 0.72, fbm(seed + 4, 3, 4)) * 0.8
    patch = ss(0.62, 0.66, fbm(seed + 5, 3, 4))
    alb = C(col) * (0.88 + n[..., None] * 0.2)
    alb = mix(alb, C(col) * 1.08, patch * 0.5)
    g = grime(seed + 6, dirty)
    alb = mix(alb, alb * np.array([0.7, 0.66, 0.6]), g * 0.5)
    alb = mix(alb, alb * 0.35, crack)
    h = bumps * 0.3 + patch * 0.1 - crack * 0.6
    rough = 0.85 + n * 0.1
    save(name, alb, h, rough, 2.2)


def lab_panels(name, col, seed=9):
    pu = (X * 2) % 1.0
    pv = (Y * 2) % 1.0
    d = np.minimum(np.minimum(pu, 1 - pu), np.minimum(pv, 1 - pv))
    seam = ss(0.012, 0.004, d)
    bevel = ss(0.004, 0.03, d)
    screws = np.zeros_like(X)
    for sx in (0.05, 0.95):
        for sy in (0.05, 0.95):
            screws = np.maximum(screws, ss(0.018, 0.01, np.sqrt((pu - sx) ** 2 + (pv - sy) ** 2)))
    n = fbm(seed, 8, 4)
    alb = C(col) * (0.95 + n[..., None] * 0.08)
    pid = (np.floor(X * 2) + np.floor(Y * 2) * 3) % 4
    alb *= (0.95 + pid[..., None] * 0.02)
    alb = mix(alb, alb * 0.3, seam)
    alb = mix(alb, np.array([0.55, 0.56, 0.58]), screws)
    g = grime(seed + 1, 0.6)
    alb = mix(alb, alb * np.array([0.72, 0.72, 0.7]), g * 0.45)
    scuff = ss(0.8, 0.95, noise(40, seed + 3, aniso=(1.0, 0.1))) * ss(0.35, 0.0, Y % 0.5 * 2)
    alb = mix(alb, alb * 0.75, scuff * 0.5)
    h = bevel * 0.4 - seam * 0.5 + screws * 0.2
    rough = 0.35 + g * 0.3 + scuff * 0.2 - screws * 0.1
    save(name, alb, h, rough, 3.0)


# ------------------------------------------------------------------ floors

def tiles(name, c1, c2, rep=4, marble=False, seed=10, grout="3a3836"):
    tu = X * rep
    tv = Y * rep
    iu = np.floor(tu)
    iv = np.floor(tv)
    lu = tu - iu
    lv = tv - iv
    d = np.minimum(np.minimum(lu, 1 - lu), np.minimum(lv, 1 - lv))
    g = ss(0.035, 0.015, d)
    checker = ((iu + iv) % 2 == 0)
    tone = np.random.default_rng(seed).random((rep + 1) * (rep + 1)).astype(np.float32)[(iu * (rep + 1) + iv).astype(int)]
    base = np.where(checker[..., None], C(c1), C(c2)) * (0.93 + tone[..., None] * 0.12)
    if marble:
        vein = fbm(seed + 1, 3, 6)
        v2 = ss(0.02, 0.0, np.abs(vein - 0.5)) + ss(0.05, 0.0, np.abs(fbm(seed + 2, 5, 5) - 0.5)) * 0.4
        base = mix(base, base * 0.55 + np.array([0.05, 0.05, 0.06]), np.clip(v2, 0, 1) * 0.8)
        base *= (0.95 + fbm(seed + 3, 10, 4)[..., None] * 0.1)
    else:
        speck = ss(0.7, 0.9, noise(250, seed + 4))
        base = mix(base, base * 0.6, speck * 0.5)
    base = mix(base, C(grout), g)
    dirt = grime(seed + 5, 0.9)
    base = mix(base, base * np.array([0.72, 0.68, 0.62]), dirt * 0.4)
    chips = ss(0.93, 0.97, noise(30, seed + 6)) * ss(0.06, 0.02, d)
    base = mix(base, C(grout) * 1.2, chips)
    h = (1 - g) * 0.5 + tone * 0.04 - chips * 0.3
    rough = (0.12 if marble else 0.35) + g * 0.6 + dirt * 0.3
    save(name, base, h, rough, 3.0)


def concrete(name, col, seed=11):
    n = fbm(seed, 4, 6)
    pores = ss(0.75, 0.9, noise(300, seed + 1))
    cr = ss(0.01, 0.0, np.abs(fbm(seed + 2, 3, 6) - 0.5)) * ss(0.5, 0.65, fbm(seed + 3, 2, 4))
    stains = ss(0.55, 0.8, fbm(seed + 4, 2, 5))
    oil = ss(0.7, 0.8, fbm(seed + 5, 3, 4))
    alb = C(col) * (0.8 + n[..., None] * 0.35)
    alb = mix(alb, alb * 0.6, pores * 0.4)
    alb = mix(alb, alb * np.array([0.7, 0.68, 0.62]), stains * 0.5)
    alb = mix(alb, np.array([0.06, 0.06, 0.07]), oil * 0.55)
    alb = mix(alb, alb * 0.3, cr)
    joint = ss(0.004, 0.0, np.minimum(np.abs(X - 0.0), np.abs(Y - 0.0)))
    alb = mix(alb, alb * 0.5, joint)
    h = n * 0.3 - pores * 0.15 - cr * 0.5 - joint * 0.4
    rough = 0.9 - oil * 0.5 + stains * 0.05
    save(name, alb, h, rough, 2.5)


def carpet(name, field, border, accent, seed=12):
    fib = noise(400, seed) * 0.6 + noise(150, seed + 1) * 0.4
    u = (X * 2) % 1.0
    v = (Y * 2) % 1.0
    x = u - 0.5
    y = v - 0.5
    r = np.sqrt(x * x + y * y)
    th = np.arctan2(y, x)
    medal = ss(0.02, 0.0, r - (0.26 + 0.05 * np.cos(th * 8)))
    ring = ss(0.015, 0.0, np.abs(r - 0.3))
    star = ss(0.02, 0.0, r - (0.1 + 0.06 * np.abs(np.cos(th * 4))))
    corner = ss(0.02, 0.0, np.sqrt((np.abs(x) - 0.5) ** 2 + (np.abs(y) - 0.5) ** 2) - 0.16)
    alb = mix(C(field), C(border), medal * 0.8)
    alb = mix(alb, C(accent), np.clip(ring + star + corner * 0.7, 0, 1))
    alb *= (0.8 + fib[..., None] * 0.35)
    worn = grime(seed + 2, 0.7)
    alb = mix(alb, alb * 0.75 + 0.05, worn * 0.4)
    h = fib * 0.4 + medal * 0.05
    rough = 0.95 - fib * 0.05
    save(name, alb, h, rough, 2.0, ao=0.4)


def metal(name, col, seed=13):
    brush = noise(300, seed, aniso=(1.0, 0.025))
    blot = fbm(seed + 1, 3, 5)
    alb = C(col) * (0.85 + brush[..., None] * 0.2 + (blot[..., None] - 0.5) * 0.15)
    dents = ss(0.8, 0.95, noise(12, seed + 2))
    h = brush * 0.1 - dents * 0.3
    rough = 0.3 + blot * 0.3 + brush * 0.1
    save(name, alb, h, rough, 1.5)


def fabric(name, col, seed=14):
    w1 = np.sin(X * N * 0.5 * math.pi / (N / 512)) * 0.5 + 0.5
    w2 = np.sin(Y * N * 0.5 * math.pi / (N / 512)) * 0.5 + 0.5
    weave = np.where(((np.floor(X * 128) + np.floor(Y * 128)) % 2) == 0, w1, w2)
    n = fbm(seed, 6, 4)
    alb = C(col) * (0.8 + weave[..., None] * 0.2 + (n[..., None] - 0.5) * 0.2)
    h = weave * 0.3 + n * 0.1
    save(name, alb, h, 0.95 - weave * 0.05, 1.5)


def marble(name, col, seed=15):
    v = fbm(seed, 3, 7)
    vein = ss(0.02, 0.0, np.abs(v - 0.5)) + ss(0.06, 0.0, np.abs(fbm(seed + 1, 6, 5) - 0.5)) * 0.35
    alb = C(col) * (0.94 + fbm(seed + 2, 12, 4)[..., None] * 0.08)
    alb = mix(alb, np.array([0.35, 0.36, 0.38]), np.clip(vein, 0, 1) * 0.7)
    save(name, alb, v * 0.05, 0.15 + vein * 0.1, 0.8)


def ceiling(name, col, seed=16):
    plaster(name, col, seed, dirty=0.6)


if __name__ == "__main__":
    planks("wood_floor", "a0683a", "4a2a14", rows=9, seed=1)
    wainscot("wood", "8a5530", "3e2212", seed=3)
    planks("wood_dark", "5a3620", "22120a", rows=4, seed=4, vertical=True)
    wallpaper_damask("wall_damask", "cfc4b0", "8a7a62", seed=5)
    wallpaper_stripes("wall_stripes", "c8c0ae", "a89e8a", seed=6)
    wallpaper_diamond("wall_diamond", "d8cdb4", "a08a5e", "b86a58", seed=7)
    plaster("wall_plaster", "c9c3b6", seed=8)
    lab_panels("wall_panels", "d8dde2", seed=9)
    tiles("floor_marble", "e8e4dc", "2c2a28", rep=4, marble=True, seed=10, grout="5a5650")
    tiles("floor_lab", "b8c0c8", "9aa4ae", rep=6, marble=False, seed=17, grout="4a5058")
    concrete("concrete", "8e8a84", seed=11)
    carpet("carpet", "7a2a22", "3a1812", "c8a060", seed=12)
    metal("metal", "b0b4ba", seed=13)
    fabric("fabric", "a83232", seed=14)
    marble("marble", "e8e4de", seed=15)
    ceiling("ceiling", "d6d0c4", seed=16)
