"""Monsters, rebuilt with organic shapes (metaballs + skin + displacement) and baked textures.
Blender Z-up, facing +Y (= Godot -Z). Origin at the feet. Animated parts are separate objects whose
origin is the joint pivot (names are what scripts/game/monster.gd looks for).
Run: blender -b --python tools/models_monsters.py -- [names...]"""
import sys, os, math, random
sys.path.insert(0, os.path.dirname(__file__))
from blib import *
from organic import split_limb, cloth, meta, displace, smooth, decimate, assign_by, spikes, snap_objs, snap_verts, ring_radius
import bake as BK

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "models")
SIZE = {}


def part(objs, name, pivot):
    o = join(objs, name)
    set_origin(o, pivot)
    return o


NO_SPLIT = {"tick", "skitter", "eye", "hidden", "mimic", "puff", "bighead", "spewer", "bomber"}


def save(name, parts, tex=512, tris=6000, ao=0.25):
    # knees and elbows: split limbs so the game can bend them
    if name not in NO_SPLIT:
        extra = []
        for o in parts:
            if o.type == "MESH" and o.name in ("leg_l", "leg_r", "arm_l", "arm_r"):
                mat_name = o.material_slots[0].material.name if o.material_slots else "C_808080"
                lo = split_limb(o, 0.5, mat_name, 0.0)
                if lo is not None:
                    extra.append(lo)
    # keep the triangle budget per model sane for mobile
    total = sum(sum(len(p.vertices) - 2 for p in o.data.polygons) for o in parts if o.type == "MESH")
    if total > tris:
        k = tris / total
        for o in parts:
            if o.type == "MESH":
                n = sum(len(p.vertices) - 2 for p in o.data.polygons)
                decimate(o, max(60, int(n * k)))
    BK.bake(name, parts, tex, ao_dist=ao)
    export(os.path.join(OUT, name + ".glb"), parts)
    print("EXPORT", name, tris_count(parts))


def tris_count(parts):
    return sum(sum(len(p.vertices) - 2 for p in o.data.polygons) for o in parts if o.type == "MESH")


def eyeball(pos, r, iris="C_d8b020", look=(0, 1, 0), pupil="C_050505", glow=False, name="eye"):
    """White eyeball + iris + pupil + tiny specular dot, looking along +Y."""
    x, y, z = pos
    ps = [sphere(r, pos, "L_ceramic_efe9dc", 14, 8)]
    ps.append(sphere(r * 0.55, (x, y + r * 0.62, z), ("E_" + iris[2:]) if glow else iris, 12, 6, (1, 0.45, 1)))
    ps.append(sphere(r * 0.28, (x, y + r * 0.86, z), pupil, 10, 5, (1, 0.4, 1)))
    ps.append(sphere(r * 0.1, (x + r * 0.18, y + r * 0.95, z + r * 0.22), "E_ffffff", 6, 3))
    return ps


def teeth_row(cx, y, z, width, n, h, material="L_bone_ece3c8", down=True, r=0.012, curve=0.0):
    out = []
    for i in range(n):
        t = (i / max(1, n - 1)) - 0.5
        x = cx + t * width
        yy = y - curve * (t * t) * 4
        c = cyl(r, h, (x, yy, z - h / 2 if down else z + h / 2), material, 5, r2=0.0, smooth=False)
        if not down:
            c.rotation_euler = (math.pi, 0, 0)
        out.append(c)
    return out


def claw_hand(x, y, z, material, side=1, n=3, length=0.06, r=0.012, claw="L_bone_d8cfb0"):
    out = [sphere(r * 2.6, (x, y, z), material, 10, 6, (1, 0.8, 0.9))]
    for i in range(n):
        a = (i - (n - 1) / 2) * 0.45
        fx = x + math.sin(a) * r * 2 * side
        fy = y + math.cos(a) * r * 1.6
        out.append(skin([(fx, fy, z, r), (fx + math.sin(a) * length * 0.5, fy + length * 0.6, z - length * 0.4, r * 0.8)], material=material, subdiv=1))
        out.append(cyl(r * 0.7, length * 0.5, (fx + math.sin(a) * length * 0.7, fy + length * 0.85, z - length * 0.65), claw, 5, r2=0.0, smooth=False, rot=(-2.2, 0, 0)))
    return out


# ================================================================ tier 1

def gremlin():
    reset()
    S = "L_skin_7f9a55"
    body = meta("body", [
        ("ell", (0, 0.0, 0.3), 0.15, (1.0, 0.95, 1.1)),
        ("ball", (0, 0.03, 0.36), 0.11),
        ("ell", (0, -0.01, 0.22), 0.1, (1.2, 1.0, 0.8)),
        ("ball", (0, 0.0, 0.43), 0.07),
    ], S, 0.018)
    displace(body, 0.006, 0.05)
    belt = lathe([(0.13, 0.19), (0.145, 0.21), (0.14, 0.26), (0.125, 0.27)], "L_leather_5a3a22", 20, cap_bottom=False)
    buckle = box((0.05, 0.02, 0.04), (0, 0.145, 0.235), "M_gold", 0.005)
    body = part([body, belt, buckle], "body", (0, 0, 0.25))
    head = meta("head", [
        ("ell", (0, 0.02, 0.6), 0.14, (1.05, 0.95, 0.92)),
        ("ell", (0, 0.1, 0.645), 0.055, (1.7, 0.7, 0.55)),           # brow ridge
        ("cap", (0, 0.16, 0.585), 0.03, (0.03, 1.0, 1.0), (0, 1.1, math.pi / 2)),  # hooked nose
        ("ball", (-0.065, 0.1, 0.565), 0.045), ("ball", (0.065, 0.1, 0.565), 0.045),  # cheeks
        ("ell", (0, 0.07, 0.52), 0.07, (1.4, 1.0, 0.6)),              # jaw
        {"t": "ell", "co": (0, 0.14, 0.535), "r": 0.045, "s": (1.5, 0.7, 0.45), "neg": True},  # mouth cavity
        {"t": "ball", "co": (-0.05, 0.135, 0.605), "r": 0.03, "neg": True},
        {"t": "ball", "co": (0.05, 0.135, 0.605), "r": 0.03, "neg": True},
    ], S, 0.012)
    displace(head, 0.004, 0.04)
    ears = []
    for s in (1, -1):
        ears.append(meta("ear", [("ell", (0.15 * s, -0.01, 0.64), 0.028, (2.2, 0.35, 1.0), (0, 0.5 * s, 0)),
                                 ("ell", (0.2 * s, -0.02, 0.67), 0.018, (1.8, 0.3, 0.8), (0, 0.6 * s, 0))], S, 0.008))
    eyes = eyeball((-0.048, 0.128, 0.606), 0.026, "C_e8c020", glow=True) + eyeball((0.048, 0.128, 0.606), 0.026, "C_e8c020", glow=True)
    mouth_in = sphere(0.04, (0, 0.13, 0.535), "C_2a0808", 10, 5, (1.4, 0.5, 0.4))
    teeth = teeth_row(0, 0.162, 0.552, 0.07, 5, 0.018, r=0.007, curve=0.01) + teeth_row(0, 0.158, 0.518, 0.05, 4, 0.014, r=0.006, down=False)
    # little mining helmet with a lamp
    helmet = lathe([(0.0, 0.73), (0.08, 0.725), (0.125, 0.69), (0.145, 0.655), (0.165, 0.648), (0.168, 0.64), (0.13, 0.642), (0.12, 0.66), (0.0, 0.662)], "L_plastic_d8a21e", 24)
    helmet.location = (0, 0.01, 0.0)
    lamp = cyl(0.025, 0.03, (0, 0.13, 0.71), "M_dark_metal", 12, rot=(math.pi / 2 - 0.3, 0, 0))
    lens = cyl(0.02, 0.005, (0, 0.146, 0.715), "E_fff0b0", 12, rot=(math.pi / 2 - 0.3, 0, 0))
    head = part([head, mouth_in, helmet, lamp, lens] + ears + eyes + teeth, "head", (0, 0, 0.46))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.12 * s
        a = skin([(x, 0, 0.42, 0.035), (x + 0.04 * s, 0.02, 0.32, 0.028), (x + 0.05 * s, 0.05, 0.22, 0.024)], material=S, subdiv=1)
        arms.append(part([a] + claw_hand(x + 0.05 * s, 0.07, 0.19, S, s, 3, 0.05, 0.011), nm, (x, 0, 0.42)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.065 * s
        l = skin([(x, 0, 0.22, 0.045), (x, 0.01, 0.12, 0.035), (x, 0.0, 0.04, 0.03)], material=S, subdiv=1)
        foot = meta("foot", [("ell", (x, 0.04, 0.025), 0.045, (0.9, 1.6, 0.55)), ("ball", (x, 0.1, 0.025), 0.03)], S, 0.012)
        legs.append(part([l, foot], nm, (x, 0, 0.22)))
    save("gremlin", [body, head] + arms + legs, tex=256, tris=3500)


def bomber():
    reset()
    iron = "L_metal_2a2a30"
    shell = meta("shell", [("ball", (0, 0, 0.3), 0.21), ("ell", (0, 0.04, 0.26), 0.16, (1.1, 1.0, 0.8))], iron, 0.02)
    displace(shell, 0.008, 0.07)
    # glowing cracks = thin emissive strips on the shell
    cracks = []
    rnd = random.Random(3)
    for i in range(7):
        a = rnd.uniform(0, math.tau)
        z = rnd.uniform(0.2, 0.42)
        r = math.sqrt(max(0.001, 0.215 ** 2 - (z - 0.3) ** 2))
        c = box((0.008, 0.07, 0.006), (math.cos(a) * r, math.sin(a) * r, z), "E_ff6a10", 0.0)
        c.rotation_euler = (rnd.uniform(-0.8, 0.8), 0, a + math.pi / 2)
        cracks.append(c)
    snap_objs(cracks, shell, 0.6)
    br = ring_radius(shell, 0.2)
    band = lathe([(br - 0.004, 0.18), (br + 0.006, 0.19), (br + 0.006, 0.215), (br - 0.004, 0.225)], "M_gold", 28, cap_bottom=False)
    rivets = [sphere(0.012, (math.cos(a) * (br + 0.008), math.sin(a) * (br + 0.008), 0.2), "M_gold", 8, 4) for a in [i * math.tau / 12 for i in range(12)]]
    mouth = sphere(0.1, (0, 0.17, 0.26), "E_ff8a20", 14, 7, (1.2, 0.35, 0.45))
    teeth = teeth_row(0, 0.205, 0.3, 0.14, 6, 0.03, material="L_metal_1a1a1e", r=0.014) + teeth_row(0, 0.205, 0.22, 0.12, 5, 0.025, material="L_metal_1a1a1e", r=0.013, down=False)
    eyes = [sphere(0.035, (x, 0.18, 0.38), "E_ffd040", 10, 5, (1, 0.5, 0.7)) for x in (-0.07, 0.07)]
    brows = [box((0.07, 0.02, 0.02), (x, 0.19, 0.42), iron, 0.005, rot=(0, 0.35 * (1 if x > 0 else -1), 0)) for x in (-0.07, 0.07)]
    snap_objs(eyes + brows, shell, -0.2)
    snap_objs([mouth], shell, 0.12)
    top_z = max((shell.matrix_world @ v.co).z for v in shell.data.vertices)
    cap = cyl(0.05, 0.06, (0, 0, top_z + 0.01), "M_dark_metal", 14, bevel=0.005)
    body = part([shell, band, mouth, cap] + cracks + rivets + teeth + eyes + brows, "body", (0, 0, 0.3))
    fuse = part([skin([(0, 0, 0.56, 0.01), (0.02, 0.01, 0.62, 0.009), (0.0, 0.02, 0.67, 0.008)], material="L_fabric_a88a5a", subdiv=1),
                 sphere(0.022, (0, 0.02, 0.69), "E_ffb020", 8, 4), sphere(0.035, (0, 0.02, 0.69), "G_ff8020", 8, 4)], "fuse", (0, 0, 0.56))
    legs = []
    for x in (0.1, -0.1):
        l = skin([(x, 0, 0.24, 0.034), (x, 0.01, 0.15, 0.032), (x, 0.03, 0.06, 0.026)], material=iron, subdiv=1)
        boot = meta("boot", [("ell", (x, 0.05, 0.03), 0.04, (1.0, 1.7, 0.6))], "L_leather_3a2418", 0.012)
        legs.append(part([l, boot], "leg_" + ("r" if x > 0 else "l"), (x, 0, 0.15)))
    save("bomber", [body, fuse] + legs, tex=256, tris=3500)


def eye():
    reset()
    F = "L_skin_7a3040"
    stalk = skin([(0, 0, 0.0, 0.1), (0.02, 0.01, -0.15, 0.06), (-0.01, 0.0, -0.3, 0.05), (0, 0, -0.42, 0.07)], material=F, subdiv=2)
    base = meta("base", [("ell", (0, 0, 0.0), 0.18, (1.3, 1.3, 0.35))] + [("ell", (math.cos(a) * 0.2, math.sin(a) * 0.2, -0.02), 0.06, (1.6, 0.6, 0.5), (0, 0, a)) for a in [i * 1.26 for i in range(5)]], F, 0.02)
    displace(base, 0.01, 0.05)
    tend = []
    rnd = random.Random(5)
    for i in range(6):
        a = i * math.tau / 6 + rnd.uniform(-0.3, 0.3)
        r0 = 0.22
        tend.append(skin([(math.cos(a) * r0, math.sin(a) * r0, -0.02, 0.025), (math.cos(a) * (r0 + 0.12), math.sin(a) * (r0 + 0.12), -0.12, 0.018), (math.cos(a) * (r0 + 0.16), math.sin(a) * (r0 + 0.16), -0.3, 0.006)], material=F, subdiv=1))
    body = part([stalk, base] + tend, "body", (0, 0, 0.0))
    ball = meta("ball", [("ball", (0, 0, -0.58), 0.2)], "L_ceramic_ede4d8", 0.018)
    veins = []
    for i in range(10):
        a = i * math.tau / 10
        pts = []
        for k in range(5):
            th = 1.1 - k * 0.2        # polar angle from +Y (front)
            ph = a + 0.2 * math.sin(k * 1.7 + i)
            d = (math.sin(th) * math.cos(ph), math.cos(th), math.sin(th) * math.sin(ph))
            pts.append((d[0] * 0.203, d[1] * 0.203, -0.58 + d[2] * 0.203, 0.006 - k * 0.001))
        veins.append(snap_verts(skin(pts, material="C_a01820", subdiv=0), ball, 0.001))
    iris = sphere(0.105, (0, 0.125, -0.58), "C_b0181c", 16, 8, (1, 0.5, 1))
    iris_ring = lathe([(0.105, 0.0), (0.108, 0.005), (0.095, 0.01)], "C_5a0808", 18, cap_bottom=False, pos=(0, 0.17, -0.58))
    iris_ring.rotation_euler = (-math.pi / 2, 0, 0)
    pupil = sphere(0.055, (0, 0.185, -0.58), "C_020202", 12, 6, (1, 0.35, 1))
    glint = sphere(0.018, (0.03, 0.205, -0.55), "E_ffffff", 6, 3)
    lid_t = meta("lids", [("ell", (0, 0.02, -0.46), 0.17, (1.2, 1.1, 0.45)), ("ell", (0, 0.02, -0.71), 0.15, (1.2, 1.05, 0.35))], F, 0.018)
    head = part([ball, iris, iris_ring, pupil, glint, lid_t] + veins, "head", (0, 0, -0.45))
    save("eye", [body, head], tex=256, tris=3500)


def tick():
    reset()
    C = "L_skin_5a2432"
    abdomen = meta("abd", [("ell", (0, -0.035, 0.075), 0.07, (1.0, 1.25, 0.75)), ("ell", (0, 0.03, 0.07), 0.045, (1.1, 0.9, 0.7))], C, 0.006)
    displace(abdomen, 0.002, 0.02)
    shield = meta("shield", [("ell", (0, 0.04, 0.085), 0.04, (1.1, 1.0, 0.45))], "L_leather_2a1410", 0.006)
    head = sphere(0.022, (0, 0.085, 0.07), "L_leather_1e0e0a", 10, 5, (1.1, 1.2, 0.8))
    mand = [cyl(0.005, 0.03, (x, 0.11, 0.065), "L_bone_3a2a1a", 5, r2=0.0, rot=(-1.4, 0, 0.3 * (1 if x > 0 else -1))) for x in (-0.01, 0.01)]
    eyes = [sphere(0.006, (x, 0.1, 0.082), "E_ff2a10", 6, 3) for x in (-0.012, 0.012)]
    stripes = [lathe([(0.061, z), (0.063, z + 0.004), (0.061, z + 0.008)], "C_8a3a4a", 16, cap_bottom=False, pos=(0, -0.035, 0)) for z in (0.06, 0.08)]
    body = part([abdomen, shield, head] + mand + eyes, "body", (0, 0, 0.06))
    legs = []
    for i in range(8):
        side = 1 if i < 4 else -1
        y = 0.06 - (i % 4) * 0.035
        legs.append(part([skin([(side * 0.035, y, 0.07, 0.006), (side * 0.065, y + 0.008, 0.09, 0.005), (side * 0.095, y + 0.015, 0.0, 0.0025)], material="L_leather_4a2a22", subdiv=1)], "leg%d" % i, (side * 0.035, y, 0.07)))
    save("tick", [body] + legs, tex=128, tris=2200)


def spewer():
    reset()
    S = "L_slime_6f8a2a"
    blob = meta("blob", [("ell", (0, 0, 0.25), 0.23, (1.12, 1.0, 0.85)), ("ball", (0, -0.05, 0.3), 0.17),
                         ("ell", (0, 0.1, 0.34), 0.12, (1.4, 0.9, 0.6)),
                         {"t": "ell", "co": (0, 0.2, 0.2), "r": 0.14, "s": (1.3, 0.8, 0.45), "neg": True}], S, 0.02)
    displace(blob, 0.02, 0.06)
    warts = []
    rnd = random.Random(8)
    for i in range(18):
        th = rnd.uniform(0, math.tau)
        ph = rnd.uniform(0.3, 1.5)
        d = (math.sin(ph) * math.cos(th) * 1.12, math.sin(ph) * math.sin(th), math.cos(ph) * 0.85)
        warts.append(sphere(rnd.uniform(0.015, 0.03), (d[0] * 0.23, d[1] * 0.23, 0.25 + d[2] * 0.23), "L_slime_9ab040", 10, 5))
    snap_objs(warts, blob, 0.5)
    eyes = eyeball((-0.11, 0.15, 0.4), 0.045, "C_d8e020") + eyeball((0.11, 0.15, 0.4), 0.045, "C_d8e020")
    lids = [sphere(0.05, (x, 0.13, 0.43), S, 10, 5, (1.1, 1.0, 0.6)) for x in (-0.11, 0.11)]
    drool = [skin([(x, 0.2, 0.14, 0.012), (x + 0.01, 0.22, 0.06, 0.008), (x, 0.22, 0.0, 0.004)], material="G_b8e040", subdiv=1) for x in (-0.06, 0.05)]
    body = part([blob] + warts + eyes + lids + drool, "body", (0, 0, 0.2))
    jaw = meta("jaw", [("ell", (0, 0.1, 0.14), 0.15, (1.25, 0.95, 0.45)), {"t": "ell", "co": (0, 0.13, 0.19), "r": 0.12, "s": (1.2, 0.8, 0.35), "neg": True}], S, 0.015)
    tongue = meta("tongue", [("ell", (0, 0.12, 0.16), 0.08, (1.0, 1.3, 0.3))], "L_skin_b03040", 0.012)
    jteeth = teeth_row(0, 0.2, 0.17, 0.2, 7, 0.03, r=0.01, down=False, curve=0.03)
    jaw = part([jaw, tongue] + jteeth, "jaw", (0, 0.05, 0.18))
    legs = []
    for x in (0.14, -0.14):
        l = skin([(x, 0.02, 0.13, 0.05), (x * 1.45, 0.07, 0.05, 0.04), (x * 1.55, 0.14, 0.02, 0.03)], material=S, subdiv=1)
        toes = [sphere(0.02, (x * 1.55 + dx, 0.18, 0.015), S, 6, 3) for dx in (-0.025, 0.0, 0.025)]
        legs.append(part([l] + toes, "leg_" + ("r" if x > 0 else "l"), (x, 0.02, 0.13)))
    save("spewer", [body, jaw] + legs, tex=256, tris=4000)


def rugrat():
    """Giant cracked porcelain doll in a frilly dress."""
    reset()
    P = "L_ceramic_f2e6da"
    dress_c = "L_fabric_6a8ab8"
    dress = lathe([(0.0, 0.18), (0.36, 0.18), (0.34, 0.24), (0.3, 0.4), (0.24, 0.55), (0.2, 0.66), (0.17, 0.72), (0.0, 0.74)], dress_c, 28)
    frill = lathe([(0.37, 0.16), (0.4, 0.19), (0.37, 0.22), (0.35, 0.2)], "L_fabric_f0f0f0", 28, cap_bottom=False)
    collar = lathe([(0.19, 0.7), (0.24, 0.73), (0.18, 0.76)], "L_fabric_f0f0f0", 24, cap_bottom=False)
    buttons = [sphere(0.018, (0, 0.2 + 0.0, 0.5 + i * 0.07), "M_gold", 6, 3) for i in range(3)]
    for b in buttons:
        b.location.y = 0.24 - (b.location.z - 0.5) * 0.25
    body = part([dress, frill, collar] + buttons, "body", (0, 0, 0.35))
    head = meta("head", [("ell", (0, 0.05, 1.0), 0.3, (1.0, 0.95, 1.05)), ("ball", (-0.12, 0.2, 0.92), 0.1), ("ball", (0.12, 0.2, 0.92), 0.1),
                         {"t": "ball", "co": (-0.11, 0.3, 1.02), "r": 0.075, "neg": True}, {"t": "ball", "co": (0.11, 0.3, 1.02), "r": 0.075, "neg": True}], P, 0.02)
    sockets = [sphere(0.06, (x, 0.25, 1.02), "C_050303", 10, 5) for x in (-0.11, 0.11)]
    glints = [sphere(0.012, (x + 0.02, 0.3, 1.04), "E_ffffff", 6, 3) for x in (-0.11, 0.11)]
    cheeks = [sphere(0.05, (x, 0.27, 0.9), "C_e89090", 8, 4, (1, 0.3, 0.8)) for x in (-0.15, 0.15)]
    lips = sphere(0.04, (0, 0.33, 0.84), "C_a01828", 8, 4, (1.4, 0.4, 0.6))
    # painted cracks
    cracks = []
    rnd = random.Random(11)
    for i in range(5):
        x0, z0 = rnd.uniform(-0.15, 0.15), rnd.uniform(0.9, 1.2)
        pts = [(x0, 0.0, z0, 0.004)]
        for k in range(3):
            x0 += rnd.uniform(-0.05, 0.05)
            z0 -= rnd.uniform(0.03, 0.07)
            pts.append((x0, 0.0, z0, 0.003))
        c = skin(pts, material="C_2a2020", subdiv=0)
        for v in c.data.vertices:
            x, _, z = v.co
            yy = math.sqrt(max(0.0, 0.305 ** 2 - x ** 2 - ((z - 1.0) / 1.05) ** 2 * 0.95)) + 0.05
            v.co.y = yy
        cracks.append(c)
    hair = meta("hair", [("ell", (0, -0.02, 1.12), 0.3, (1.08, 1.0, 0.7)), ("ell", (-0.22, -0.02, 0.95), 0.12, (0.8, 0.8, 1.5)), ("ell", (0.22, -0.02, 0.95), 0.12, (0.8, 0.8, 1.5)),
                         {"t": "ell", "co": (0, 0.25, 1.0), "r": 0.24, "s": (1.2, 1.0, 1.0), "neg": True}], "L_fur_c8a050", 0.02)
    bow = [sphere(0.07, (x, -0.02, 1.32), "L_fabric_d83050", 8, 4, (1.4, 0.5, 0.9)) for x in (-0.07, 0.07)]
    head = part([head, hair] + sockets + glints + cheeks + [lips] + cracks + bow, "head", (0, 0.05, 0.72))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.24 * s
        arms.append(part([skin([(x, 0, 0.68, 0.07), (x + 0.05 * s, 0.05, 0.5, 0.06), (x + 0.06 * s, 0.1, 0.36, 0.055)], material=P, subdiv=1),
                          sphere(0.065, (x + 0.06 * s, 0.12, 0.32), P, 10, 6)], nm, (x, 0, 0.68)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.12 * s
        legs.append(part([skin([(x, 0, 0.3, 0.08), (x, 0.02, 0.12, 0.07)], material=P, subdiv=1),
                          meta("shoe", [("ell", (x, 0.05, 0.05), 0.08, (0.9, 1.5, 0.6))], "L_leather_1a1a1e", 0.02)], nm, (x, 0, 0.3)))
    save("rugrat", [body, head] + arms + legs, tex=512, tris=5000)


def skitter():
    """Six-legged feral critter with a bony skull face."""
    reset()
    F = "L_fur_5a4638"
    body = meta("body", [("ell", (0, -0.05, 0.33), 0.2, (0.9, 1.4, 0.8)), ("ell", (0, 0.15, 0.36), 0.13, (1.0, 1.0, 0.9)), ("ell", (0, -0.25, 0.38), 0.13)], F, 0.02)
    displace(body, 0.015, 0.03)
    skull = meta("skull", [("ell", (0, 0.3, 0.4), 0.13, (0.9, 1.25, 0.85)), ("ell", (0, 0.42, 0.35), 0.075, (1.0, 1.2, 0.7)),
                           {"t": "ball", "co": (-0.045, 0.37, 0.41), "r": 0.03, "neg": True}, {"t": "ball", "co": (0.045, 0.37, 0.41), "r": 0.03, "neg": True}], "L_bone_e6dcc0", 0.012)
    eyes = [sphere(0.018, (x, 0.365, 0.41), "E_ff3a10", 6, 3) for x in (-0.045, 0.045)]
    fangs = teeth_row(0, 0.45, 0.32, 0.06, 4, 0.04, r=0.01)
    spines = spikes((0, -0.05, 0.4), 16, 0.16, 0.08, "L_bone_8a7a60", 0.015, seed=4, up_only=True)
    tail = skin([(0, -0.35, 0.38, 0.05), (0, -0.5, 0.45, 0.035), (0, -0.62, 0.55, 0.015)], material=F, subdiv=1)
    body = part([body, skull, tail] + eyes + fangs + spines, "body", (0, 0, 0.3))
    legs = []
    for i in range(6):
        side = 1 if i < 3 else -1
        y = 0.12 - (i % 3) * 0.16
        x = 0.12 * side
        legs.append(part([skin([(x, y, 0.32, 0.035), (x + 0.2 * side, y + 0.02, 0.46, 0.028), (x + 0.36 * side, y + 0.04, 0.12, 0.02), (x + 0.42 * side, y + 0.05, 0.0, 0.012)], material=F, subdiv=1)], "leg%d" % i, (x, y, 0.32)))
    save("skitter", [body] + legs, tex=256, tris=4500)


# ================================================================ tier 2

def puff():
    reset()
    W = "L_fur_f2e8b0"
    fluff = meta("fluff", [("ball", (0, 0, 0.27), 0.22)] + [("ball", (0.22 * math.cos(a) * math.cos(b), 0.22 * math.sin(a) * math.cos(b), 0.27 + 0.2 * math.sin(b)), 0.09)
                                                              for a in [i * 0.9 for i in range(7)] for b in (-0.5, 0.3, 1.0)], W, 0.02)
    displace(fluff, 0.012, 0.03)
    face = meta("face", [("ell", (0, 0.2, 0.28), 0.1, (1.2, 0.5, 0.9))], "L_skin_f0c8a8", 0.012)
    eyes = [sphere(0.04, (x, 0.26, 0.33), "C_111111", 10, 5, (1, 0.6, 1.2)) for x in (-0.07, 0.07)]
    glints = [sphere(0.012, (x + 0.012, 0.29, 0.35), "E_ffffff", 6, 3) for x in (-0.07, 0.07)]
    blush = [sphere(0.025, (x, 0.27, 0.27), "C_f08888", 6, 3, (1, 0.3, 0.7)) for x in (-0.11, 0.11)]
    beak = cyl(0.03, 0.04, (0, 0.29, 0.28), "L_plastic_f09020", 8, r2=0.012, rot=(math.pi / 2, 0, 0))
    feet = [meta("ft", [("ell", (x, 0.05, 0.03), 0.04, (1.0, 1.4, 0.5))], "L_plastic_f09020", 0.012) for x in (-0.08, 0.08)]
    body = part([fluff, face, beak] + eyes + glints + blush + feet, "body", (0, 0, 0.25))
    jaw = meta("jawm", [("ell", (0, 0.12, 0.2), 0.19, (1.05, 1.0, 0.55)), {"t": "ell", "co": (0, 0.15, 0.23), "r": 0.16, "s": (1.0, 0.95, 0.4), "neg": True}], "L_skin_7a1418", 0.015)
    jt = teeth_row(0, 0.27, 0.25, 0.26, 9, 0.05, r=0.012, curve=0.04) + teeth_row(0, 0.26, 0.15, 0.22, 8, 0.04, r=0.011, down=False, curve=0.04)
    jaw = part([jaw] + jt, "jaw", (0, 0, 0.26))
    save("puff", [body, jaw], tex=256, tris=4000)


def howler():
    reset()
    S = "L_skin_9a9088"
    head = meta("head", [("ell", (0, 0.02, 1.68), 0.14, (0.9, 0.95, 1.3)), ("ell", (0, 0.1, 1.55), 0.12, (1.0, 0.8, 1.2)),
                         {"t": "ell", "co": (0, 0.16, 1.52), "r": 0.085, "s": (0.9, 0.8, 1.5), "neg": True},
                         {"t": "ball", "co": (-0.055, 0.13, 1.74), "r": 0.035, "neg": True}, {"t": "ball", "co": (0.055, 0.13, 1.74), "r": 0.035, "neg": True}], S, 0.015)
    displace(head, 0.004, 0.03)
    mouth = part([sphere(0.075, (0, 0.14, 1.52), "C_120404", 10, 5, (0.95, 0.5, 1.5))], "mouth", (0, 0.14, 1.52))
    eyes = [sphere(0.02, (x, 0.12, 1.74), "E_f0f0ff", 6, 3) for x in (-0.055, 0.055)]
    hair = [skin([(x, -0.05, 1.8, 0.012), (x * 1.4, -0.1, 1.55, 0.01), (x * 1.6, -0.08, 1.25, 0.004)], material="L_fur_1a1a1a", subdiv=1) for x in (-0.1, -0.05, 0.0, 0.05, 0.1)]
    head = part([head] + eyes + hair, "head", (0, 0, 1.5))
    robe = cloth([(0.34, 0.02), (0.31, 0.3), (0.25, 0.8), (0.2, 1.2), (0.17, 1.42), (0.1, 1.5), (0.02, 1.53)], "L_fabric_3a3530", 11, 0.035, 48, 3, 0.07)
    inner = cyl(0.3, 0.02, (0, 0, 0.06), "C_050404", 24)
    shoulders = meta("sh", [("ell", (0, 0, 1.43), 0.14, (1.5, 0.9, 0.6))], "L_fabric_3a3530", 0.02)
    collar_bones = [skin([(x, 0.1, 1.46, 0.012), (x * 2.2, 0.08, 1.44, 0.01)], material="L_bone_c8bca0", subdiv=0) for x in (-0.05, 0.05)]
    body = part([robe, inner, shoulders] + collar_bones, "body", (0, 0, 0.8))
    arms = []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.18 * s
        a = skin([(x, 0, 1.42, 0.035), (x + 0.08 * s, 0.05, 1.05, 0.025), (x + 0.1 * s, 0.1, 0.7, 0.022)], material=S, subdiv=1)
        sleeve = cloth([(0.08, 1.02), (0.065, 1.25), (0.05, 1.42)], "L_fabric_3a3530", 5, 0.012, 16, 7 + s, 0.03)
        sleeve.location = (x + 0.06 * s, 0.035, 0)
        arms.append(part([a, sleeve] + claw_hand(x + 0.1 * s, 0.12, 0.66, S, s, 4, 0.1, 0.012), nm, (x, 0, 1.42)))
    save("howler", [body, head, mouth] + arms, tex=512, tris=5000)


def levitator():
    reset()
    robe_c = "L_fabric_3a2a5a"
    robe = cloth([(0.25, 0.2), (0.22, 0.35), (0.17, 0.6), (0.13, 0.8), (0.07, 0.86), (0.01, 0.87)], robe_c, 8, 0.025, 40, 5, 0.03)
    trim = lathe([(0.245, 0.2), (0.25, 0.23), (0.23, 0.26)], "M_gold", 24, cap_bottom=False)
    tails = [skin([(math.cos(a) * 0.18, math.sin(a) * 0.18, 0.22, 0.05), (math.cos(a) * 0.14, math.sin(a) * 0.14, 0.05, 0.03), (math.cos(a) * 0.08, math.sin(a) * 0.08, -0.12, 0.005)], material=robe_c, subdiv=1) for a in [i * math.tau / 5 for i in range(5)]]
    runes = [box((0.04, 0.005, 0.06), (math.cos(a) * 0.19, math.sin(a) * 0.19, 0.45), "E_c080ff", 0.0, rot=(0, 0, a + math.pi / 2)) for a in [i * math.tau / 6 for i in range(6)]]
    body = part([robe, trim] + tails + runes, "body", (0, 0, 0.4))
    hood = meta("hood", [("ell", (0, 0, 1.05), 0.25, (1.0, 1.05, 1.2)), {"t": "ell", "co": (0, 0.14, 1.02), "r": 0.19, "s": (0.9, 1.0, 1.1), "neg": True}], robe_c, 0.018)
    face = sphere(0.17, (0, 0.04, 1.02), "C_08060c", 14, 7, (0.9, 0.8, 1.05))
    eyes = [sphere(0.035, (x, 0.18, 1.04), "E_c080ff", 8, 4, (1.2, 0.5, 0.7)) for x in (-0.06, 0.06)]
    crown = [cyl(0.012, 0.12, (math.cos(a) * 0.12, math.sin(a) * 0.12 - 0.02, 1.32), "M_gold", 5, r2=0.0, smooth=False) for a in [i * math.tau / 7 for i in range(7)]]
    head = part([hood, face] + eyes + crown, "head", (0, 0, 0.85))
    arms = []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.16 * s
        sleeve = lathe([(0.04, 0.0), (0.07, 0.22), (0.09, 0.3)], robe_c, 12, cap_bottom=False)
        sleeve.rotation_euler = (math.pi, 0.5 * s, 0)
        sleeve.location = (x + 0.08 * s, 0.05, 0.78)
        hand = claw_hand(x + 0.2 * s, 0.1, 0.58, "L_skin_8a7aa0", s, 4, 0.07, 0.01)
        orb = sphere(0.05, (x + 0.2 * s, 0.14, 0.52), "E_b070ff", 10, 5)
        arms.append(part([sleeve, orb] + hand, nm, (x, 0, 0.78)))
    save("levitator", [body, head] + arms, tex=512, tris=4500)


def butcher():
    reset()
    S = "L_skin_c89a80"
    torso = meta("torso", [("ell", (0, 0.02, 1.15), 0.3, (1.05, 0.9, 1.0)), ("ell", (0, 0.12, 1.0), 0.28, (1.0, 0.9, 0.9)), ("ell", (0, 0.02, 1.42), 0.24, (1.3, 0.9, 0.7))], S, 0.03)
    displace(torso, 0.01, 0.1)
    apron = lathe([(0.3, 0.72), (0.33, 0.9), (0.33, 1.1), (0.3, 1.3), (0.26, 1.36)], "L_fabric_e0d8c8", 24, cap_bottom=False)
    apron.scale = (1.0, 0.95, 1.0)
    blood = [sphere(rnd, (x, 0.3, z), "C_7a0a0a", 6, 3, (1, 0.25, 1)) for rnd, x, z in ((0.05, 0.05, 1.0), (0.035, -0.1, 0.9), (0.04, 0.12, 1.2), (0.03, -0.02, 0.8))]
    pants = lathe([(0.26, 0.6), (0.28, 0.75), (0.28, 0.8)], "L_fabric_2a2a3a", 20, cap_bottom=False)
    body = part([torso, apron, pants] + blood, "body", (0, 0, 0.9))
    head = meta("head", [("ell", (0, 0.2, 1.64), 0.15, (1.0, 1.0, 1.05)), ("ell", (0, 0.27, 1.56), 0.1, (1.2, 0.8, 0.6))], S, 0.015)
    sack = meta("sack", [("ell", (0, 0.2, 1.68), 0.165, (1.0, 1.0, 1.1)), {"t": "ell", "co": (0, 0.35, 1.55), "r": 0.1, "s": (1.2, 0.8, 0.5), "neg": True}], "L_fabric_a89070", 0.015)
    displace(sack, 0.008, 0.05)
    holes = [sphere(0.03, (x, 0.35, 1.7), "C_050505", 8, 4, (1, 0.4, 1)) for x in (-0.06, 0.06)]
    eyes = [sphere(0.01, (x, 0.365, 1.7), "E_ffe0a0", 6, 3) for x in (-0.06, 0.06)]
    stitch = [box((0.004, 0.005, 0.03), (x * 0.03, 0.36, 1.82), "C_2a1a0a", 0.0) for x in range(-3, 4)]
    rope = lathe([(0.15, 1.53), (0.16, 1.545), (0.15, 1.56)], "L_fabric_6a5030", 16, cap_bottom=False, pos=(0, 0.2, 0))
    cap = cyl(0.13, 0.2, (0, 0.18, 1.88), "L_fabric_f2f0ea", 14, r2=0.16)
    head = part([head, sack, rope, cap] + holes + eyes + stitch, "head", (0, 0.18, 1.5))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.36 * s
        a = [skin([(x, 0, 1.4, 0.1), (x + 0.06 * s, 0.05, 1.1, 0.085), (x + 0.05 * s, 0.12, 0.85, 0.075)], material=S, subdiv=1),
             sphere(0.08, (x + 0.05 * s, 0.14, 0.8), S, 10, 6)]
        if s == 1:
            a += [box((0.04, 0.03, 0.18), (x + 0.05 * s, 0.16, 0.78), "L_wood_3a2010", 0.01),
                  box((0.02, 0.26, 0.2), (x + 0.05 * s, 0.3, 0.66), "L_metal_b8bcc4", 0.004)]
        arms.append(part(a, nm, (x, 0, 1.4)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.15 * s
        legs.append(part([skin([(x, 0, 0.85, 0.12), (x, 0.02, 0.45, 0.1), (x, 0.0, 0.1, 0.085)], material="L_fabric_2a2a3a", subdiv=1),
                          meta("boot", [("ell", (x, 0.06, 0.06), 0.1, (0.9, 1.5, 0.6))], "L_leather_2a1a10", 0.02)], nm, (x, 0, 0.85)))
    save("butcher", [body, head] + arms + legs, tex=512, tris=6000)


def lurker():
    """The Reaper: tall, thin, blind shadow with scythe-like claws."""
    reset()
    S = "L_skin_1c1a22"
    torso = meta("torso", [("ell", (0, 0, 1.55), 0.16, (1.2, 0.8, 1.4)), ("ell", (0.19, 0, 1.76), 0.07, (1.2, 0.9, 0.8)), ("ell", (-0.19, 0, 1.76), 0.07, (1.2, 0.9, 0.8)),
                           ("cap", (0, 0.01, 1.85), 0.045, (0.08, 1, 1), (0, math.pi / 2, 0)), ("ell", (0, -0.02, 1.25), 0.1, (1.1, 0.8, 1.3)), ("ell", (0, 0, 1.05), 0.13, (1.2, 0.8, 0.8))], S, 0.02)
    displace(torso, 0.008, 0.05)
    ribs = [lathe([(0.14 - abs(k - 2) * 0.01, 1.35 + k * 0.07), (0.15 - abs(k - 2) * 0.01, 1.37 + k * 0.07), (0.14 - abs(k - 2) * 0.01, 1.39 + k * 0.07)], "L_bone_5a5248", 16, cap_bottom=False) for k in range(5)]
    spine = [sphere(0.03, (0, -0.13, 1.1 + k * 0.1), "L_bone_4a443a", 6, 3) for k in range(8)]
    snap_objs(spine, torso, 0.4)
    body = part([torso] + spine, "body", (0, 0, 1.0))
    head = meta("head", [("ell", (0, 0.05, 2.08), 0.15, (0.8, 1.1, 1.3)), ("ell", (0, 0.14, 1.98), 0.08, (1.0, 1.0, 0.8)),
                         {"t": "ell", "co": (0, 0.2, 1.97), "r": 0.06, "s": (1.2, 0.8, 0.5), "neg": True}], S, 0.015)
    grin = sphere(0.05, (0, 0.18, 1.97), "C_120000", 8, 4, (1.3, 0.4, 0.45))
    teeth = teeth_row(0, 0.215, 1.99, 0.09, 8, 0.03, r=0.006, curve=0.02) + teeth_row(0, 0.21, 1.945, 0.08, 7, 0.025, r=0.006, down=False, curve=0.02)
    eyes = [sphere(0.022, (x, 0.18, 2.12), "E_ff2a10", 8, 4, (1.3, 0.5, 0.6)) for x in (-0.055, 0.055)]
    horns = [skin([(x, 0.0, 2.2, 0.03), (x * 1.8, -0.1, 2.35, 0.018), (x * 1.6, -0.25, 2.42, 0.004)], material="L_bone_2a2620", subdiv=1) for x in (-0.07, 0.07)]
    head = part([head, grin] + teeth + eyes + horns, "head", (0, 0.02, 1.93))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.24 * s
        a = skin([(x, 0, 1.78, 0.05), (x + 0.05 * s, 0.02, 1.3, 0.035), (x + 0.04 * s, 0.03, 0.85, 0.03), (x, 0.04, 0.66, 0.028)], material=S, subdiv=1)
        claws = []
        for f in range(3):
            fx = x + (f - 1) * 0.03 * s
            claws.append(skin([(fx, 0.05, 0.64, 0.012), (fx, 0.14, 0.52, 0.01), (fx, 0.26, 0.5, 0.004)], material="L_bone_3a3630", subdiv=1))
        arms.append(part([a] + claws, nm, (x, 0, 1.78)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.1 * s
        legs.append(part([skin([(x, 0, 1.0, 0.07), (x, 0.08, 0.55, 0.045), (x, -0.04, 0.14, 0.035), (x, 0.12, 0.02, 0.03)], material=S, subdiv=1)], nm, (x, 0, 1.0)))
    save("lurker", [body, head] + arms + legs, tex=512, tris=5500)


def hidden():
    reset()
    b = meta("body", [("ell", (0, 0, 1.0), 0.3, (1.0, 0.8, 2.0))], "L_skin_808890", 0.05)
    save("hidden", [part([b], "body", (0, 0, 0))], tex=64, tris=400)


def mimic():
    """Treasure chest with a mouthful of teeth and a tongue."""
    reset()
    W = "L_wood_5a3418"
    body_parts = [box((0.66, 0.44, 0.34), (0, 0, 0.19), W, 0.015)]
    for x in (-0.33, 0.33):
        body_parts.append(box((0.03, 0.46, 0.36), (x, 0, 0.19), "L_metal_3a3a40", 0.004))
    for y in (-0.22, 0.22):
        body_parts.append(box((0.68, 0.03, 0.05), (0, y, 0.34), "L_metal_3a3a40", 0.004))
        body_parts.append(box((0.68, 0.03, 0.05), (0, y, 0.04), "L_metal_3a3a40", 0.004))
    body_parts.append(box((0.08, 0.02, 0.1), (0, 0.23, 0.3), "M_gold", 0.006))
    body_parts += [sphere(0.012, (x, 0.232, z), "M_gold", 6, 3) for x in (-0.3, -0.15, 0.15, 0.3) for z in (0.06, 0.32)]
    inner = box((0.6, 0.38, 0.02), (0, 0, 0.355), "C_3a0a0a", 0.0)
    lower_teeth = teeth_row(0, 0.19, 0.36, 0.56, 9, 0.05, r=0.018, down=False) + teeth_row(0, -0.19, 0.36, 0.56, 9, 0.04, r=0.015, down=False)
    tongue = part([skin([(0, 0.0, 0.37, 0.06), (0, 0.15, 0.39, 0.05), (0, 0.32, 0.34, 0.035), (0, 0.4, 0.28, 0.02)], material="L_skin_b3162a", subdiv=1)], "tongue", (0, 0.0, 0.37))
    body = part(body_parts + [inner] + lower_teeth, "body", (0, 0, 0.0))
    lid_parts = [lathe([(0.0, -0.33), (0.22, -0.33), (0.22, 0.33), (0.0, 0.33)], W, 24, cap_bottom=True)]
    lid_parts[0].rotation_euler = (0, math.pi / 2, 0)
    lid_parts[0].scale = (0.55, 1.0, 1.0)
    lid_parts[0].location = (0, 0.0, 0.38)
    for x in (-0.25, 0.0, 0.25):
        band = lathe([(0.225, -0.02), (0.232, -0.02), (0.232, 0.02), (0.225, 0.02)], "L_metal_3a3a40", 24, cap_bottom=False)
        band.rotation_euler = (0, math.pi / 2, 0)
        band.scale = (0.55, 1.0, 1.0)
        band.location = (x, 0.0, 0.38)
        lid_parts.append(band)
    upper_teeth = teeth_row(0, 0.19, 0.4, 0.56, 9, 0.06, r=0.02) + teeth_row(0, -0.19, 0.4, 0.56, 9, 0.05, r=0.016)
    lid = part(lid_parts + upper_teeth, "lid", (0, -0.23, 0.38))
    eyes = []
    for x, nm in ((-0.14, "eye_l"), (0.14, "eye_r")):
        eyes.append(part(eyeball((x, 0.12, 0.45), 0.05, "C_d8c010", glow=True), nm, (x, 0.12, 0.45)))
    save("mimic", [body, lid, tongue] + eyes, tex=512, tris=4500)


# ================================================================ tier 3

def bighead():
    reset()
    S = "L_skin_c8a890"
    head = meta("head", [("ell", (0, 0, 1.55), 0.5, (1.0, 0.95, 1.05)), ("ell", (0, 0.32, 1.72), 0.2, (1.8, 0.6, 0.45)),
                         ("ell", (0, 0.42, 1.5), 0.08, (0.8, 1.0, 1.2)),
                         {"t": "ball", "co": (-0.17, 0.44, 1.62), "r": 0.1, "neg": True}, {"t": "ball", "co": (0.17, 0.44, 1.62), "r": 0.1, "neg": True},
                         ("ell", (-0.5, 0.0, 1.55), 0.1, (0.4, 0.8, 1.2)), ("ell", (0.5, 0.0, 1.55), 0.1, (0.4, 0.8, 1.2))], S, 0.03)
    displace(head, 0.012, 0.15)
    veins = []
    rnd = random.Random(21)
    for i in range(9):
        ph0 = rnd.uniform(0, math.tau)
        pts = []
        for k in range(5):
            th = 0.35 + k * 0.22
            ph = ph0 + rnd.uniform(-0.12, 0.12)
            d = (math.sin(th) * math.cos(ph), math.sin(th) * math.sin(ph) * 0.95 - 0.1, math.cos(th) * 1.05)
            pts.append((d[0] * 0.5, d[1] * 0.5, 1.55 + d[2] * 0.5, 0.012))
        veins.append(snap_verts(skin(pts, material="C_7a4a5a", subdiv=0), head, 0.001))
    eyes = eyeball((-0.17, 0.42, 1.62), 0.075, "C_101010") + eyeball((0.17, 0.42, 1.62), 0.075, "C_101010")
    stitch = [box((0.012, 0.01, 0.07), (x, 0.47, 1.38), "C_2a1a1a", 0.0) for x in [i * 0.05 - 0.2 for i in range(9)]]
    snap_objs(stitch, head, 0.3)
    head = part([head] + veins + eyes + stitch, "head", (0, 0, 1.5))
    jaw = meta("jaw", [("ell", (0, 0.25, 1.22), 0.3, (1.1, 0.8, 0.45)), {"t": "ell", "co": (0, 0.3, 1.28), "r": 0.24, "s": (1.0, 0.8, 0.3), "neg": True}], S, 0.025)
    jin = sphere(0.24, (0, 0.28, 1.25), "C_4a0c0c", 12, 6, (1.0, 0.7, 0.2))
    jt = teeth_row(0, 0.45, 1.3, 0.44, 10, 0.08, r=0.022, down=False, curve=0.08)
    jaw = part([jaw, jin] + jt, "jaw", (0, 0.1, 1.3))
    wisps = [skin([(x, -0.1, 1.05, 0.06), (x * 1.2, -0.15, 0.7, 0.04), (x * 0.8, -0.1, 0.35, 0.01)], material="L_skin_7a5a58", subdiv=1) for x in (-0.12, 0.0, 0.12)]
    body = part(wisps, "body", (0, 0, 1.0))
    save("bighead", [head, jaw, body], tex=512, tris=5000)


def projector():
    """Lanky suited thing with an old film projector for a head."""
    reset()
    suit = "L_fabric_2a2a38"
    torso = meta("torso", [("ell", (0, 0, 1.6), 0.2, (1.3, 0.8, 1.2)), ("ell", (0, 0, 1.3), 0.15, (1.2, 0.8, 1.2))], suit, 0.02)
    shirt = box((0.14, 0.02, 0.35), (0, 0.16, 1.6), "L_fabric_e8e4dc", 0.01)
    tie = box((0.05, 0.02, 0.28), (0, 0.175, 1.58), "L_fabric_b01820", 0.005)
    bow = box((0.5, 0.3, 0.1), (0, 0, 1.88), "L_fabric_c02020", 0.03)
    buttons = [sphere(0.014, (0.06, 0.17, 1.4 + i * 0.1), "M_gold", 6, 3) for i in range(3)]
    body = part([torso, shirt, tie, bow] + buttons, "body", (0, 0, 1.2))
    case = box((0.44, 0.34, 0.3), (0, 0, 2.2), "L_metal_2a2c30", 0.03)
    reels = [cyl(0.13, 0.03, (0, y, 2.52), "L_metal_1a1a1e", 20, rot=(0, math.pi / 2, 0), bevel=0.005) for y in (-0.12, 0.14)]
    spokes = [box((0.035, 0.24, 0.02), (0, y, 2.52), "M_chrome", 0.0, rot=(a, 0, 0)) for y in (-0.12, 0.14) for a in (0, 1.05, 2.1)]
    lens = cyl(0.1, 0.16, (0, 0.24, 2.2), "M_dark_metal", 18, rot=(math.pi / 2, 0, 0), bevel=0.01)
    glass = cyl(0.085, 0.01, (0, 0.325, 2.2), "E_fff4c0", 18, rot=(math.pi / 2, 0, 0))
    vents = [box((0.3, 0.01, 0.02), (0, -0.175, 2.1 + i * 0.05), "C_0a0a0a", 0.0) for i in range(4)]
    neck = cyl(0.05, 0.12, (0, 0, 2.02), "M_dark_metal", 8)
    head = part([case, lens, glass, neck] + reels + spokes + vents, "head", (0, 0, 2.05))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.28 * s
        arms.append(part([skin([(x, 0, 1.78, 0.06), (x + 0.04 * s, 0.03, 1.3, 0.05), (x + 0.03 * s, 0.06, 0.95, 0.045)], material=suit, subdiv=1),
                          sphere(0.055, (x + 0.03 * s, 0.07, 0.9), "L_fabric_f0f0f0", 10, 5)], nm, (x, 0, 1.78)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.12 * s
        legs.append(part([skin([(x, 0, 1.2, 0.08), (x, 0.02, 0.6, 0.06), (x, 0.0, 0.08, 0.055)], material=suit, subdiv=1),
                          meta("shoe", [("ell", (x, 0.08, 0.04), 0.07, (0.8, 1.9, 0.55))], "L_leather_101010", 0.02)], nm, (x, 0, 1.2)))
    save("projector", [body, head] + arms + legs, tex=512, tris=5500)


def hunter():
    reset()
    coat = "L_leather_3a3226"
    body = meta("coat", [("ell", (0, 0, 1.45), 0.25, (1.1, 0.85, 1.1)), ("ell", (0, 0, 1.1), 0.24, (1.1, 0.85, 1.0))], coat, 0.025)
    skirt = lathe([(0.34, 0.3), (0.3, 0.6), (0.26, 0.95), (0.22, 1.1)], coat, 24, cap_bottom=False)
    displace(skirt, 0.02, 0.1)
    belt = lathe([(0.25, 1.0), (0.26, 1.03), (0.26, 1.07), (0.25, 1.1)], "L_leather_1a120a", 24, cap_bottom=False)
    shells = [cyl(0.014, 0.05, (math.cos(a) * 0.265, math.sin(a) * 0.265, 1.05), "C_b02010", 6) for a in [0.2 + i * 0.28 for i in range(8)]]
    collar = lathe([(0.2, 1.62), (0.26, 1.7), (0.18, 1.78)], coat, 20, cap_bottom=False)
    body = part([body, skirt, belt, collar] + shells, "body", (0, 0, 1.1))
    face = meta("face", [("ell", (0, 0.06, 1.98), 0.14, (0.9, 1.0, 1.15))], "L_skin_8a7060", 0.015)
    band = lathe([(0.135, 1.97), (0.14, 1.99), (0.14, 2.05), (0.135, 2.07)], "L_fabric_d8d0c0", 20, cap_bottom=False, pos=(0, 0.06, 0))
    hood = meta("hood", [("ell", (0, 0.0, 2.02), 0.2, (1.0, 1.0, 1.15)), ("ell", (0, -0.1, 2.2), 0.1, (0.8, 1.0, 1.2)), {"t": "ell", "co": (0, 0.14, 1.98), "r": 0.15, "s": (0.95, 1.0, 1.1), "neg": True}], "L_fabric_2a261e", 0.02)
    beard = meta("beard", [("ell", (0, 0.13, 1.88), 0.08, (1.1, 0.6, 1.0))], "L_fur_4a3a2a", 0.012)
    head = part([face, band, hood, beard], "head", (0, 0, 1.85))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.3 * s
        arms.append(part([skin([(x, 0, 1.72, 0.08), (x + 0.04 * s, 0.05, 1.45, 0.065), (x + 0.03 * s, 0.1, 1.22, 0.06)], material=coat, subdiv=1),
                          sphere(0.055, (x + 0.03 * s, 0.13, 1.18), "L_leather_1a120a", 10, 5)], nm, (x, 0, 1.72)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.13 * s
        legs.append(part([skin([(x, 0, 1.1, 0.09), (x, 0.02, 0.55, 0.07), (x, 0.0, 0.1, 0.065)], material="L_fabric_3a3a30", subdiv=1),
                          meta("boot", [("ell", (x, 0.06, 0.07), 0.09, (0.9, 1.5, 0.8))], "L_leather_1a120a", 0.02)], nm, (x, 0, 1.1)))
    gun = [cyl(0.028, 0.9, (0.25, 0.45, 1.3), "L_metal_303236", 10, rot=(math.pi / 2, 0, 0)), cyl(0.028, 0.9, (0.31, 0.45, 1.3), "L_metal_303236", 10, rot=(math.pi / 2, 0, 0)),
           box((0.1, 0.35, 0.1), (0.28, -0.05, 1.28), "L_wood_4a2a14", 0.02), box((0.08, 0.2, 0.06), (0.28, 0.2, 1.27), "L_wood_4a2a14", 0.01)]
    g = join(gun, "gun")
    parent(g, arms[0])
    save("hunter", [body, head] + arms + legs + [g], tex=512, tris=6000)


def brute():
    """Armoured stone-plated ogre with huge fists."""
    reset()
    S = "L_skin_6a4a3a"
    torso = meta("torso", [("ell", (0, 0.05, 1.5), 0.5, (1.2, 0.9, 1.0)), ("ell", (0, 0.15, 1.95), 0.45, (1.35, 0.9, 0.6)), ("ell", (0, 0.1, 1.1), 0.35, (1.1, 0.9, 0.8)),
                           ("ell", (0, 0.3, 1.35), 0.25, (1.0, 0.6, 0.7))], S, 0.04)
    displace(torso, 0.025, 0.2)
    plates = []
    rnd = random.Random(31)
    for i in range(9):
        a = rnd.uniform(-1.2, 1.2) + (math.pi if i % 3 == 0 else 0)
        z = rnd.uniform(1.3, 2.05)
        r = 0.55
        p = box((0.28, 0.08, 0.24), (math.sin(a) * r, -math.cos(a) * r * 0.8 + 0.1, z), "L_stone_6a6560", 0.03, rot=(rnd.uniform(-0.2, 0.2), 0, -a))
        plates.append(p)
    belt = lathe([(0.42, 0.95), (0.44, 1.0), (0.44, 1.08), (0.42, 1.12)], "L_leather_2a1a10", 24, cap_bottom=False)
    chain = [lathe([(0.03, -0.01), (0.04, 0.0), (0.03, 0.01)], "L_rust_6a5a50", 8, cap_bottom=False, pos=(math.cos(a) * 0.5, math.sin(a) * 0.5 * 0.8, 1.75 + math.sin(a * 2) * 0.05)) for a in [i * 0.35 for i in range(18)]]
    body = part([torso, belt] + plates + chain, "body", (0, 0, 1.0))
    head = meta("head", [("ell", (0, 0.4, 2.25), 0.2, (1.1, 1.0, 0.9)), ("ell", (0, 0.52, 2.3), 0.08, (2.0, 0.6, 0.5)), ("ell", (0, 0.5, 2.12), 0.14, (1.3, 0.9, 0.6))], S, 0.02)
    tusks = [skin([(x, 0.58, 2.12, 0.025), (x * 1.3, 0.64, 2.24, 0.012), (x * 1.2, 0.62, 2.3, 0.003)], material="L_bone_e8dcc0", subdiv=1) for x in (-0.08, 0.08)]
    eyes = [sphere(0.03, (x, 0.58, 2.27), "E_ff7a00", 8, 4, (1.2, 0.5, 0.6)) for x in (-0.08, 0.08)]
    helm = meta("helm", [("ell", (0, 0.38, 2.36), 0.22, (1.15, 1.05, 0.7))], "L_rust_5a4a40", 0.02)
    head = part([head, helm] + tusks + eyes, "head", (0, 0.3, 2.2))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.75 * s
        arm = skin([(x, 0.05, 1.9, 0.2), (x + 0.12 * s, 0.1, 1.45, 0.17), (x + 0.12 * s, 0.2, 1.05, 0.15)], material=S, subdiv=1)
        pad = meta("pad", [("ell", (x, 0.05, 2.0), 0.25, (1.1, 1.0, 0.7))], "L_stone_6a6560", 0.03)
        fist = meta("fist", [("ell", (x + 0.12 * s, 0.25, 0.85), 0.24, (1.0, 1.0, 1.1)), ("ball", (x + 0.12 * s, 0.4, 0.95), 0.12)], S, 0.025)
        knuckles = [sphere(0.07, (x + 0.12 * s + dx, 0.45, 0.82), "L_stone_7a7570", 8, 4) for dx in (-0.1, 0.0, 0.1)]
        arms.append(part([arm, pad, fist] + knuckles, nm, (x, 0.05, 1.9)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.3 * s
        legs.append(part([skin([(x, 0, 1.0, 0.22), (x, 0.05, 0.5, 0.19), (x, 0.0, 0.12, 0.17)], material=S, subdiv=1),
                          meta("foot", [("ell", (x, 0.12, 0.08), 0.18, (1.0, 1.4, 0.55))], "L_stone_5a5550", 0.03)], nm, (x, 0, 1.0)))
    save("brute", [body, head] + arms + legs, tex=512, tris=6500, ao=0.4)


def watcher():
    """Faceless jointed shop mannequin."""
    reset()
    P = "L_plastic_d8d0c4"
    torso = meta("torso", [("ell", (0, 0, 1.52), 0.17, (1.3, 0.8, 1.3)), ("ell", (0, 0, 1.2), 0.12, (1.2, 0.8, 1.0)), ("ell", (0, 0, 1.0), 0.14, (1.3, 0.85, 0.7))], P, 0.02)
    neck = cyl(0.035, 0.12, (0, 0, 1.8), "L_wood_7a5a3a", 10)
    stand_ring = lathe([(0.04, 1.73), (0.05, 1.75), (0.04, 1.77)], "M_chrome", 12, cap_bottom=False)
    joints = [sphere(0.055, (x, 0, 1.72), "L_wood_7a5a3a", 10, 5) for x in (-0.24, 0.24)] + [sphere(0.07, (x, 0, 0.98), "L_wood_7a5a3a", 10, 5) for x in (-0.11, 0.11)]
    seam = lathe([(0.155, 1.34), (0.16, 1.35), (0.155, 1.36)], "C_8a8278", 20, cap_bottom=False)
    body = part([torso, neck, stand_ring, seam] + joints, "body", (0, 0, 1.0))
    head = meta("head", [("ell", (0, 0, 1.97), 0.13, (0.85, 0.95, 1.25)), ("ell", (0, 0.1, 1.95), 0.035, (0.6, 1.0, 1.4))], P, 0.012)
    crack = skin([(0.03, 0.115, 2.08, 0.004), (0.0, 0.12, 2.0, 0.003), (0.04, 0.115, 1.92, 0.003)], material="C_1a1410", subdiv=0)
    head = part([head, crack], "head", (0, 0, 1.84))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.24 * s
        up = skin([(x, 0, 1.72, 0.045), (x + 0.02 * s, 0.01, 1.45, 0.04)], material=P, subdiv=1)
        elbow = sphere(0.045, (x + 0.02 * s, 0.01, 1.42), "L_wood_7a5a3a", 8, 4)
        lo = skin([(x + 0.02 * s, 0.01, 1.4, 0.038), (x + 0.02 * s, 0.03, 1.15, 0.032)], material=P, subdiv=1)
        hand = meta("hand", [("ell", (x + 0.02 * s, 0.04, 1.08), 0.045, (0.6, 0.9, 1.4))], P, 0.01)
        arms.append(part([up, elbow, lo, hand], nm, (x, 0, 1.72)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.11 * s
        up = skin([(x, 0, 0.98, 0.065), (x, 0.01, 0.55, 0.05)], material=P, subdiv=1)
        knee = sphere(0.055, (x, 0.01, 0.52), "L_wood_7a5a3a", 8, 4)
        lo = skin([(x, 0.01, 0.5, 0.048), (x, 0.0, 0.08, 0.04)], material=P, subdiv=1)
        foot = meta("foot", [("ell", (x, 0.06, 0.04), 0.06, (0.7, 1.6, 0.5))], P, 0.012)
        legs.append(part([up, knee, lo, foot], nm, (x, 0, 0.98)))
    save("watcher", [body, head] + arms + legs, tex=512, tris=4500)


ALL = [gremlin, bomber, eye, tick, spewer, rugrat, skitter, puff, howler, levitator, butcher, lurker, hidden, mimic, bighead, projector, hunter, brute, watcher]
ONLY = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
for f in ALL:
    if not ONLY or f.__name__ in ONLY:
        f()
