"""Detailed shop gear (v1.5): replaces the blocky versions from models_gear.py (same names,
same sizes so the collision shapes in item_defs.gear_shapes still fit).
Held tools: forward (barrel / blade tip) is +Y in Blender (= Godot -Z), origin at the grip centre.
Run: blender -b -P tools/models_gear2.py [-- name1,name2]"""
import sys, os, math
sys.path.insert(0, os.path.dirname(__file__))
from blib import *
from mathutils import Matrix
import organic as O
import bake as BK

OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "models")
HX = math.pi / 2


def save(name, parts, size=256):
    o = join(parts, name)
    BK.bake(name, [o], size, ao_dist=0.03)
    export(os.path.join(OUT, name + ".glb"), [o])
    print("EXPORT", name, tris())


def ring(R, r, pos, material, axis="Y", segs=20, rsegs=6):
    prof = [(R + math.cos(2 * math.pi * i / rsegs) * r, math.sin(2 * math.pi * i / rsegs) * r) for i in range(rsegs + 1)]
    t = lathe(prof, material, segs, cap_bottom=False, cap_top=False)
    if axis == "Y":
        t.rotation_euler = (-HX, 0, 0)
    elif axis == "X":
        t.rotation_euler = (0, HX, 0)
    t.location = pos
    return t


def lathe_y(profile, material, pos, segs=20, **kw):
    o = lathe(profile, material, segs, **kw)
    o.rotation_euler = (-HX, 0, 0)
    o.location = pos
    return o


def guard(y0, y1, z_top, z_bot, material="M_dark_metal", r=0.0035):
    return O.tube([(0, y0, z_top, r), (0, y1, z_top - 0.012, r), (0, y1 - 0.005, z_bot, r), (0, y0 - 0.01, z_bot - 0.004, r)], material)


# ---------------------------------------------------------------- guns
def pistol():
    reset()
    p = []
    p.append(box((0.034, 0.2, 0.036), (0, 0.07, 0.05), "C_2c2f36", 0.006))                 # slide
    for k in range(6):                                                                       # serrations
        p.append(box((0.036, 0.0035, 0.022), (0, -0.018 + k * 0.007, 0.052), "C_181a1e", 0.0008))
    p.append(box((0.03, 0.17, 0.028), (0, 0.06, 0.02), "C_1b1d22", 0.005))                  # frame
    p.append(box((0.031, 0.05, 0.008), (0, 0.13, 0.006), "C_1b1d22", 0.003))                # rail
    p.append(cyl(0.0095, 0.03, (0, 0.178, 0.05), "M_chrome", 14, rot=(HX, 0, 0)))            # barrel
    p.append(cyl(0.0055, 0.004, (0, 0.194, 0.05), "C_050505", 10, rot=(HX, 0, 0)))
    p.append(box((0.026, 0.085, 0.01), (0, 0.075, 0.072), "M_dark_metal", 0.003))           # cell cradle
    p.append(box((0.018, 0.07, 0.012), (0, 0.075, 0.078), "E_ffb030", 0.004))               # energy cell
    p.append(box((0.006, 0.01, 0.01), (0, 0.16, 0.074), "M_dark_metal", 0.002))             # sights
    for x in (-0.007, 0.007):
        p.append(box((0.004, 0.008, 0.01), (x, -0.02, 0.074), "M_dark_metal", 0.0015))
    p.append(box((0.028, 0.046, 0.102), (0, -0.03, -0.028), "M_rubber", 0.009, rot=(0.28, 0, 0)))   # grip
    for k in range(4):
        p.append(box((0.03, 0.03, 0.004), (0, -0.034 + k * 0.004, -0.0 - k * 0.018), "C_2c2f36", 0.0015, rot=(0.28, 0, 0)))
    p.append(guard(0.045, 0.06, 0.008, -0.015))
    p.append(box((0.006, 0.008, 0.02), (0, 0.03, -0.004), "M_chrome", 0.002, rot=(-0.3, 0, 0)))
    for sx in (-1, 1):
        p.append(box((0.001, 0.09, 0.004), (sx * 0.0175, 0.08, 0.04), "E_ffb030"))          # side glow line
    save("w_pistol", p)


def shotgun():
    reset()
    p = []
    p.append(box((0.056, 0.22, 0.072), (0, 0.08, 0.03), "C_2c2f36", 0.008))                  # receiver
    p.append(box((0.058, 0.08, 0.02), (0, 0.08, 0.01), "C_1b1d22", 0.004))                   # ejection port / trim
    p.append(cyl(0.017, 0.46, (0, 0.42, 0.052), "M_dark_metal", 16, rot=(HX, 0, 0)))          # barrel
    p.append(cyl(0.0125, 0.005, (0, 0.652, 0.052), "C_050505", 12, rot=(HX, 0, 0)))
    p.append(cyl(0.014, 0.34, (0, 0.36, 0.018), "M_dark_metal", 14, rot=(HX, 0, 0)))          # mag tube
    p.append(cyl(0.016, 0.02, (0, 0.53, 0.018), "M_chrome", 14, rot=(HX, 0, 0)))
    for k in range(5):                                                                        # heat shield
        p.append(box((0.03, 0.03, 0.008), (0, 0.24 + k * 0.05, 0.071), "C_22252b", 0.003))
    p.append(sphere(0.005, (0, 0.64, 0.072), "M_chrome", 8, 4))
    p.append(lathe_y([(0.022, 0), (0.026, 0.01), (0.026, 0.13), (0.022, 0.14)], "M_wood_dark", (0, 0.3, 0.02), 18))   # pump
    for k in range(5):
        p.append(ring(0.0262, 0.0022, (0, 0.322 + k * 0.022, 0.02), "C_140d08", segs=18, rsegs=4))
    p.append(box((0.046, 0.26, 0.068), (0, -0.19, 0.0), "M_wood_dark", 0.014, rot=(-0.12, 0, 0)))   # stock
    p.append(box((0.048, 0.022, 0.092), (0, -0.315, -0.012), "M_rubber", 0.008, rot=(-0.12, 0, 0)))
    p.append(box((0.036, 0.05, 0.09), (0, -0.035, -0.035), "M_wood_dark", 0.01, rot=(0.35, 0, 0)))  # grip
    p.append(guard(0.02, 0.04, -0.006, -0.03))
    p.append(box((0.006, 0.008, 0.022), (0, 0.012, -0.016), "M_chrome", 0.002, rot=(-0.3, 0, 0)))
    for sx in (-1, 1):
        p.append(box((0.004, 0.1, 0.02), (sx * 0.029, 0.09, 0.036), "M_dark_metal", 0.002))
        p.append(box((0.002, 0.085, 0.008), (sx * 0.0315, 0.09, 0.036), "E_ffb030"))
    p.append(ring(0.006, 0.0018, (0.026, -0.1, -0.01), "M_chrome", "X", 10, 4))              # sling loop
    save("w_shotgun", p, 256)


def tranq():
    reset()
    p = []
    p.append(box((0.05, 0.2, 0.06), (0, 0.06, 0.04), "C_2e6a8a", 0.01))                      # body
    p.append(box((0.052, 0.12, 0.02), (0, 0.05, 0.015), "C_e8e8e8", 0.006))
    p.append(cyl(0.013, 0.14, (0, 0.24, 0.05), "C_dcdcdc", 14, rot=(HX, 0, 0)))               # barrel
    p.append(cyl(0.017, 0.03, (0, 0.3, 0.05), "M_dark_metal", 14, rot=(HX, 0, 0), bevel=0.003))
    p.append(cyl(0.007, 0.004, (0, 0.317, 0.05), "C_050505", 10, rot=(HX, 0, 0)))
    p.append(cyl(0.024, 0.1, (0, 0.05, 0.098), "E_40c8ff", 14, rot=(HX, 0, 0)))               # glowing tank
    for y in (0.0, 0.1):
        p.append(cyl(0.027, 0.012, (0, y, 0.098), "M_chrome", 14, rot=(HX, 0, 0), bevel=0.002))
    for a in (0.8, 2.35, 3.9, 5.5):
        p.append(box((0.004, 0.1, 0.004), (math.cos(a) * 0.026, 0.05, 0.098 + math.sin(a) * 0.026), "M_chrome"))
    p.append(O.tube([(0, 0.105, 0.098, 0.004), (0, 0.13, 0.085, 0.004), (0, 0.15, 0.07, 0.004)], "M_rubber"))
    p.append(box((0.03, 0.046, 0.1), (0, -0.03, -0.025), "M_rubber", 0.009, rot=(0.28, 0, 0)))
    p.append(guard(0.04, 0.058, 0.008, -0.016))
    p.append(box((0.006, 0.008, 0.02), (0, 0.028, -0.003), "C_e8e8e8", 0.002, rot=(-0.3, 0, 0)))
    save("w_tranq", p)


def prod():
    reset()
    p = []
    p.append(lathe_y([(0.022, 0), (0.028, 0.01), (0.027, 0.2), (0.032, 0.21), (0.032, 0.225), (0.02, 0.235)], "M_rubber", (0, -0.25, 0), 18))  # grip
    for k in range(6):
        p.append(ring(0.0275, 0.0025, (0, -0.22 + k * 0.03, 0), "C_f0b418", segs=18, rsegs=4))
    p.append(cyl(0.017, 0.4, (0, 0.18, 0), "C_2a2d33", 14, rot=(HX, 0, 0)))                    # shaft
    p.append(ring(0.019, 0.004, (0, 0.0, 0), "M_chrome", segs=16))
    for k in range(4):
        p.append(ring(0.019, 0.0035, (0, 0.3 + k * 0.012, 0), "L_metal_b87333", segs=16, rsegs=6))
    p.append(cyl(0.022, 0.03, (0, 0.39, 0), "M_dark_metal", 14, rot=(HX, 0, 0), bevel=0.004))
    for x in (-0.012, 0.012):
        p.append(cyl(0.004, 0.06, (x, 0.43, 0), "M_chrome", 8, rot=(HX, 0, 0)))
        p.append(sphere(0.006, (x, 0.46, 0), "M_chrome", 8, 4))
    p.append(sphere(0.011, (0, 0.445, 0), "E_7ad8ff", 10, 5))
    p.append(box((0.012, 0.05, 0.006), (0, 0.1, 0.018), "E_7ad8ff", 0.002))
    save("w_prod", p)


# ---------------------------------------------------------------- melee
def bat():
    reset()
    b = lathe([(0.0, 0), (0.026, 0.0), (0.03, 0.008), (0.022, 0.02), (0.019, 0.05), (0.02, 0.25), (0.028, 0.42),
               (0.038, 0.6), (0.042, 0.74), (0.04, 0.79), (0.03, 0.81), (0.0, 0.812)], "M_wood", 24, cap_bottom=True)
    b.rotation_euler = (-HX, 0, 0)
    b.location = (0, -0.25, 0)
    p = [b, cyl(0.0215, 0.17, (0, -0.135, 0), "M_rubber", 16, rot=(HX, 0, 0))]
    for k in range(7):
        p.append(ring(0.0215, 0.0016, (0, -0.21 + k * 0.024, 0), "C_2a2a2a", segs=16, rsegs=4))
    for k in range(5):   # nails for some attitude
        a = k * 1.3
        n = cyl(0.003, 0.05, (0, 0, 0), "M_metal", 6)
        n.matrix_world = Matrix.Translation((0, 0.42 + k * 0.03, 0)) @ Matrix.Rotation(a, 4, "Y") @ Matrix.Translation((0.04, 0, 0)) @ Matrix.Rotation(HX, 4, "Y")
        p.append(n)
    save("w_bat", p)


def sledge():
    reset()
    p = [lathe_y([(0.018, 0), (0.021, 0.02), (0.019, 0.3), (0.017, 0.86), (0.02, 0.88)], "M_wood_dark", (0, -0.43, 0), 14)]
    p.append(cyl(0.025, 0.2, (0, -0.33, 0), "C_b01818", 14, rot=(HX, 0, 0)))
    for k in range(5):
        p.append(ring(0.025, 0.0022, (0, -0.42 + k * 0.045, 0), "C_5a0808", segs=14, rsegs=4))
    head = cyl(0.062, 0.29, (0, 0.45, 0), "M_dark_metal", 8, rot=(0, HX, 0), bevel=0.012, smooth=False)
    p.append(head)
    for x in (-0.15, 0.15):
        p.append(cyl(0.056, 0.012, (x, 0.45, 0), "M_metal", 8, rot=(0, HX, 0), bevel=0.003, smooth=False))
    p.append(box((0.07, 0.07, 0.105), (0, 0.45, 0), "M_metal", 0.01))
    p.append(cyl(0.026, 0.03, (0, 0.395, 0), "M_metal", 12, rot=(HX, 0, 0), bevel=0.004))
    save("w_sledge", p, 256)


def pan():
    reset()
    dish = lathe([(0.0, 0.0), (0.125, 0.0), (0.145, 0.012), (0.152, 0.046), (0.146, 0.049), (0.138, 0.016), (0.12, 0.009), (0.0, 0.009)],
                 "M_dark_metal", 32, cap_bottom=False)
    dish.location = (0, 0.28, -0.02)
    p = [dish]
    p.append(box((0.028, 0.06, 0.012), (0, 0.13, 0.012), "M_metal", 0.004))
    for x in (-0.008, 0.008):
        p.append(sphere(0.004, (x, 0.145, 0.019), "M_chrome", 6, 3))
    p.append(lathe_y([(0.012, 0), (0.016, 0.01), (0.018, 0.2), (0.02, 0.24), (0.014, 0.26)], "M_wood_dark", (0, -0.13, 0.008), 14))
    p.append(ring(0.008, 0.002, (0, -0.12, 0.008), "M_chrome", "X", 12, 4))
    save("w_pan", p)


# ---------------------------------------------------------------- throwables / mines
def grenades():
    for nm, col, glow in (("g_explosive", "C_3a5a2a", "E_ff3020"), ("g_stun", "C_2a4a8a", "E_40a0ff"), ("g_shock", "C_8a5a1a", "E_ffa020")):
        reset()
        p = [lathe([(0.0, -0.068), (0.03, -0.066), (0.05, -0.052), (0.06, -0.025), (0.062, 0.0), (0.058, 0.03), (0.046, 0.055), (0.03, 0.066), (0.0, 0.068)], col, 24)]
        for z in (-0.04, -0.018, 0.018, 0.04):   # pineapple grooves
            p.append(ring(0.059 if abs(z) < 0.03 else 0.052, 0.0022, (0, 0, z), "C_1d2a14" if nm == "g_explosive" else "C_111111", "Z", 24, 4))
        p.append(ring(0.0625, 0.004, (0, 0, 0.0), glow, "Z", 24, 4))
        p.append(cyl(0.024, 0.028, (0, 0, 0.078), "M_dark_metal", 14, bevel=0.003))
        p.append(cyl(0.016, 0.014, (0, 0, 0.097), "M_metal", 12, bevel=0.002))
        lever = box((0.016, 0.006, 0.1), (0.028, 0, 0.055), "M_chrome", 0.002, rot=(0, 0.35, 0))
        p.append(lever)
        p.append(ring(0.016, 0.0022, (0.0, 0.028, 0.088), "M_chrome", "Y", 14, 4))
        p.append(sphere(0.006, (0, 0, 0.106), glow, 8, 4))
        save(nm, p, 128)


def mines():
    for nm, glow in (("m_explosive", "E_ff2010"), ("m_stun", "E_40a0ff")):
        reset()
        p = [lathe([(0.0, -0.025), (0.14, -0.025), (0.15, -0.015), (0.15, 0.012), (0.138, 0.024), (0.1, 0.028), (0.0, 0.028)], "C_2a2d33", 32)]
        for k in range(12):   # hazard stripes on the rim
            a = k * math.pi / 6
            c = "C_f0b418" if k % 2 == 0 else "C_151515"
            s = box((0.006, 0.076, 0.022), (math.cos(a) * 0.149, math.sin(a) * 0.149, -0.002), c, 0.002, rot=(0, 0, a))
            p.append(s)
        p.append(lathe([(0.0, 0.028), (0.09, 0.028), (0.085, 0.045), (0.05, 0.058), (0.0, 0.06)], "M_dark_metal", 28))
        p.append(ring(0.092, 0.004, (0, 0, 0.03), glow, "Z", 28, 4))
        p.append(sphere(0.02, (0, 0, 0.062), glow, 12, 6))
        for a in (0.3, 2.4, 4.5):
            x, y = math.cos(a) * 0.065, math.sin(a) * 0.065
            p.append(cyl(0.005, 0.05, (x, y, 0.07), "M_chrome", 6))
            p.append(sphere(0.007, (x, y, 0.096), "M_chrome", 6, 3))
        for k in range(6):
            a = k * math.pi / 3 + 0.5
            p.append(box((0.03, 0.006, 0.004), (math.cos(a) * 0.12, math.sin(a) * 0.12, 0.026), "C_151515", 0.001, rot=(0, 0, a)))
        save(nm, p, 128)


# ---------------------------------------------------------------- drones / trackers
def drones():
    for nm, glow in (("d_feather", "E_9fffb0"), ("d_shield", "E_ffd060")):
        reset()
        p = [lathe([(0.0, -0.035), (0.05, -0.034), (0.075, -0.02), (0.082, 0.0), (0.075, 0.018), (0.05, 0.032), (0.0, 0.036)], "C_d4d8dc", 28)]
        p.append(ring(0.083, 0.004, (0, 0, 0.0), glow, "Z", 28, 4))
        p.append(lathe([(0.0, 0.03), (0.03, 0.032), (0.028, 0.045), (0.0, 0.05)], "C_2a2d33", 16))
        p.append(sphere(0.022, (0, 0.066, -0.004), "C_1b1d22", 12, 6))
        p.append(sphere(0.014, (0, 0.08, -0.004), glow, 10, 5))
        for a in (0.785, 2.356, 3.927, 5.498):
            x, y = math.cos(a) * 0.115, math.sin(a) * 0.115
            p.append(box((0.085, 0.016, 0.012), (x * 0.62, y * 0.62, 0.004), "C_2a2d33", 0.004, rot=(0, 0, a)))
            p.append(cyl(0.014, 0.024, (x, y, 0.01), "M_dark_metal", 12, bevel=0.002))
            p.append(cyl(0.004, 0.012, (x, y, 0.027), "M_chrome", 8))
            for b in (0.0, math.pi):
                bl = box((0.05, 0.012, 0.0025), (0, 0, 0), "C_1b1d22", 0.001)
                bl.matrix_world = Matrix.Translation((x, y, 0.033)) @ Matrix.Rotation(a + b + 0.6, 4, "Z") @ Matrix.Translation((0.026, 0, 0)) @ Matrix.Rotation(0.2, 4, "X")
                p.append(bl)
            p.append(ring(0.052, 0.002, (x, y, 0.033), "C_2a2d33", "Z", 20, 4))
            p.append(cyl(0.004, 0.035, (x, y, -0.02), "C_2a2d33", 6))
        save(nm, p, 256)


def trackers():
    for nm, glow in (("t_valuable", "E_ffd040"), ("t_extract", "E_40ff80")):
        reset()
        p = [box((0.086, 0.05, 0.16), (0, 0, 0), "C_2a2d33", 0.014)]
        for sx in (-1, 1):
            p.append(box((0.01, 0.052, 0.11), (sx * 0.043, 0, -0.02), "M_rubber", 0.004))
        p.append(box((0.07, 0.006, 0.085), (0, 0.026, 0.028), "C_111316", 0.004))
        p.append(box((0.06, 0.004, 0.072), (0, 0.029, 0.028), glow, 0.002))
        for k, x in enumerate((-0.022, 0.0, 0.022)):
            p.append(cyl(0.008, 0.006, (x, 0.027, -0.04), "C_c0392b" if k == 1 else "C_3a3d44", 12, rot=(HX, 0, 0), bevel=0.001))
        p.append(box((0.05, 0.004, 0.01), (0, 0.026, -0.062), "C_151515", 0.001))
        p.append(cyl(0.011, 0.02, (0.028, 0, 0.088), "M_dark_metal", 10, bevel=0.002))
        p.append(cyl(0.005, 0.045, (0.028, 0, 0.12), "M_chrome", 8))
        p.append(cyl(0.0035, 0.04, (0.028, 0, 0.16), "M_chrome", 6))
        p.append(sphere(0.01, (0.028, 0, 0.183), glow, 8, 4))
        p.append(ring(0.012, 0.002, (-0.03, 0, 0.083), "M_chrome", "Y", 10, 4))
        save(nm, p, 128)


def pocket_cart():
    reset()
    p = []
    p.append(box((0.6, 0.4, 0.02), (0, 0, -0.1), "M_metal", 0.004))
    for x in (-0.28, -0.14, 0.0, 0.14, 0.28):
        p.append(box((0.012, 0.4, 0.01), (x, 0, -0.087), "M_dark_metal", 0.002))
    for x in (-0.3, 0.3):
        p.append(box((0.02, 0.4, 0.2), (x, 0, 0.0), "M_metal", 0.004))
    for y in (-0.2, 0.2):
        p.append(box((0.6, 0.02, 0.2), (0, y, 0.0), "M_metal", 0.004))
    for x in (-0.3, 0.3):              # top rim tubes
        p.append(cyl(0.012, 0.42, (x, 0, 0.1), "M_chrome", 10, rot=(HX, 0, 0)))
    for y in (-0.2, 0.2):
        p.append(cyl(0.012, 0.62, (0, y, 0.1), "M_chrome", 10, rot=(0, HX, 0)))
    p.append(O.tube([(-0.3, -0.15, 0.1, 0.012), (-0.42, -0.15, 0.16, 0.012), (-0.42, 0.15, 0.16, 0.012), (-0.3, 0.15, 0.1, 0.012)], "C_e0551a"))
    p.append(box((0.3, 0.3, 0.003), (0, 0.0, 0.0), "E_ffb030", 0.001)) if False else None
    p.append(box((0.2, 0.004, 0.05), (0, -0.211, 0.02), "C_f0b418", 0.002))
    p.append(box((0.03, 0.2, 0.11), (-0.43, 0, 0.2), "C_1b1d22", 0.006, rot=(0, 0.5, 0)))        # value screen
    p.append(box((0.004, 0.17, 0.085), (-0.447, 0, 0.206), "E_0c2a18", 0.001, rot=(0, 0.5, 0)))
    for x in (-0.22, 0.22):
        for y in (-0.16, 0.16):
            p.append(cyl(0.04, 0.03, (x, y, -0.135), "M_rubber", 16, rot=(0, HX, 0), bevel=0.006))
            p.append(cyl(0.02, 0.034, (x, y, -0.135), "M_chrome", 10, rot=(0, HX, 0)))
            p.append(box((0.04, 0.03, 0.03), (x, y, -0.105), "M_dark_metal", 0.004))
    save("i_pocketcart", [q for q in p if q is not None], 256)


ALL = {"w_pistol": pistol, "w_shotgun": shotgun, "w_tranq": tranq, "w_prod": prod, "w_bat": bat,
       "w_sledge": sledge, "w_pan": pan, "grenades": grenades, "mines": mines, "drones": drones,
       "trackers": trackers, "i_pocketcart": pocket_cart}
sel = sys.argv[sys.argv.index("--") + 1].split(",") if "--" in sys.argv else list(ALL)
for k in sel:
    ALL[k]()
