extends Node
## Four-player network playthrough (host + 3 clients on localhost), levels 1..N with shops between.
## Host (HB_ROLE=0) drives every phase; clients (HB_ROLE=1..3) act on commands sent by RPC and
## report their own view of the game back, so desyncs show up as failed checks.
## Run: tools/mp4.sh  (starts the four processes and collects the logs)

const ItemDefs = preload("res://scripts/game/item_defs.gd")
const MonsterScript = preload("res://scripts/game/monster.gd")

var main: Node
var role := 0
var errors := []
var reports := {}
var target_level := 6
var _log_t0 := 0


func _ready() -> void:
	role = int(OS.get_environment("HB_ROLE")) if OS.get_environment("HB_ROLE") != "" else 0
	target_level = int(OS.get_environment("HB_LEVELS")) if OS.get_environment("HB_LEVELS") != "" else 6
	_log_t0 = Time.get_ticks_msec()
	Settings.player_name = ["Host", "Alpha", "Bravo", "Charlie"][role]
	Settings.player_uid = "test-uid-%d" % role    # the four test processes share one settings file
	Settings.robot_color = [0, 5, 9, 12][role]
	Settings.chat_voice = false
	Settings.voice_mode = 2
	Settings.mic_open = false
	Settings.achievements = {}
	Settings.ach_progress = {}
	Settings.crown_name = ""    # a crown from an earlier arena would replace a hat
	# each robot wears something different: the host checks everyone sees it
	Settings.cos_hat = ["", "tophat", "cap", ""][role]
	Settings.cos_acc = ["", "", "shades", "bowtie"][role]
	Settings.cos_finish = ["", "", "", "gold"][role]
	Net.delete_save()
	if role == 0:
		_host_main()
	else:
		_client_main()


# ------------------------------------------------------------------ helpers

func W():
	return main.world


func _wait(t: float) -> void:
	await get_tree().create_timer(t).timeout


func note(s: String) -> void:
	print("[MP%d %6.1f] %s" % [role, (Time.get_ticks_msec() - _log_t0) / 1000.0, s])


func check(cond: bool, msg: String) -> bool:
	if cond:
		note("OK   " + msg)
	else:
		note("FAIL " + msg)
		errors.append(msg)
	return cond


func _wait_until(cond: Callable, timeout: float) -> bool:
	var t := 0.0
	while t < timeout:
		if cond.call():
			return true
		await _wait(0.2)
		t += 0.2
	return cond.call()


func me() -> int:
	return multiplayer.get_unique_id()


func clients() -> Array:
	var out := []
	for id in Net.players:
		if id != 1:
			out.append(id)
	out.sort()
	return out


func snap() -> Dictionary:
	var w = W()
	var d := {"level": Net.level, "money": Net.money, "energy": Net.energy, "owned": Net.owned.size(),
		"screen": main.screen_name, "rejoin_wait": Net.rejoin_wait, "id": me(), "up": Net.upgrades.get(me(), {}).duplicate()}
	if w == null:
		d["world"] = false
		return d
	d["world"] = true
	d["shop"] = w.shop_mode
	d["arena"] = w.arena_mode
	d["started"] = w.started
	d["items"] = w.items.size()
	var live := 0
	for m in w.monsters.values():
		if m.state != MonsterScript.DEAD:
			live += 1
	d["monsters"] = live
	d["players"] = w.players.size()
	d["hp"] = Net.hp.duplicate()
	d["extr_done"] = w.extr.map(func(e): return e["done"])
	d["active"] = w.active_extr
	d["all_done"] = w.all_done
	d["inv"] = Net.inv_of(me()).duplicate(true)
	d["up"] = Net.upgrades.get(me(), {}).duplicate()
	var lp = w.local_player
	if lp:
		d["dead"] = lp.dead
		d["pos"] = lp.global_position
	var types := {}
	for it in w.items.values():
		types[it.type] = int(types.get(it.type, 0)) + 1
	d["types"] = types
	return d


@rpc("authority", "call_remote", "reliable")
func cmd(name: String, args: Array) -> void:
	var res: Dictionary = await _client_cmd(name, args)
	res["snap"] = snap()
	rpc_id(1, "report", name, res)


@rpc("any_peer", "call_remote", "reliable")
func report(name: String, res: Dictionary) -> void:
	reports["%d:%s" % [multiplayer.get_remote_sender_id(), name]] = res


func ask(pid: int, name: String, args := [], timeout := 25.0) -> Dictionary:
	var k := "%d:%s" % [pid, name]
	reports.erase(k)
	rpc_id(pid, "cmd", name, args)
	var ok := await _wait_until(func(): return reports.has(k), timeout)
	if not ok:
		check(false, "client %d answered '%s'" % [pid, name])
		return {}
	return reports[k]


func ask_all(name: String, args := [], timeout := 25.0) -> Dictionary:
	var out := {}
	for pid in clients():
		reports.erase("%d:%s" % [pid, name])
		rpc_id(pid, "cmd", name, args)
	await _wait_until(func():
		for pid in clients():
			if not reports.has("%d:%s" % [pid, name]):
				return false
		return true, timeout)
	for pid in clients():
		var k := "%d:%s" % [pid, name]
		if reports.has(k):
			out[pid] = reports[k]
		else:
			check(false, "client %d answered '%s'" % [pid, name])
			out[pid] = {}
	return out


# ------------------------------------------------------------------ client side

var relay_url := OS.get_environment("HB_RELAY")
const ROOM_FILE := "/tmp/hb_room.txt"


func _client_main() -> void:
	await _wait(1.0 + role * 0.7)
	if relay_url != "":
		# internet play through the relay: read the room code the host published
		Settings.relay_url = relay_url
		var code := ""
		for i in 120:
			if FileAccess.file_exists(ROOM_FILE):
				code = FileAccess.get_file_as_string(ROOM_FILE).strip_edges()
				if code != "":
					break
			await _wait(0.5)
		check(code != "", "got the room code from the host (%s)" % code)
		Net.join_online(code.to_lower() if role == 2 else code)    # codes are case-insensitive
	else:
		Net.join_game("127.0.0.1")
	var ok := await _wait_until(func(): return Net.players.has(me()), 30.0)
	check(ok, "joined the host")
	# stay alive until the host says we're done (or a long timeout)
	var t := 0.0
	while t < 3600.0 and not _done:
		await _wait(1.0)
		t += 1.0
	_finish()


var _done := false


func _client_cmd(name: String, args: Array) -> Dictionary:
	var w = W()
	var lp = w.local_player if w else null
	match name:
		"snap":
			return {}
		"done":
			_done = true
			return {}
		"chat":
			w.send_chat(str(args[0]))
			await _wait(0.5)
			return {"bubbles": w._bubbles.keys(), "feed": w.hud.chat_feed.get_child_count() if w.hud and w.hud.chat_feed else -1}
		"expr":
			lp.set_expr_bit(int(args[0]))
			await _wait(0.4)
			return {"expr": lp.expr}
		"spectate":
			# a broken robot: cycle the watched teammate, switch the camera, drop a mark
			var r := {"dead": lp.dead}
			var t0 = lp.spectate_target()
			r["t0"] = t0.peer_id if t0 else -1
			lp.spectate_step(1)
			await _wait(0.2)
			var t1 = lp.spectate_target()
			r["t1"] = t1.peer_id if t1 else -1
			lp.spectate_toggle_mode()
			await _wait(0.6)
			r["mode"] = lp.spectate_mode
			r["cam_to_target"] = lp.cam.global_position.distance_to(t1.global_position) if t1 else -1.0
			r["hud_name"] = w.hud.spec_name.text if w.hud and w.hud.spec_name else ""
			r["bar"] = w.hud.spec_bar.visible if w.hud and w.hud.spec_bar else false
			lp.spectate_toggle_mode()
			await _wait(0.6)
			r["cam_to_target0"] = lp.cam.global_position.distance_to(t1.global_position) if t1 else -1.0
			# look down at the floor next to the teammate and mark it
			lp.cam.look_at(t1.global_position if t1 else lp.global_position, Vector3.UP)
			r["pinged"] = lp.spectate_ping()
			return r
		"drop":
			# lose the connection like a phone losing its signal (no goodbye)
			get_tree().create_timer(0.3).timeout.connect(func(): multiplayer.multiplayer_peer.close())
			return {}
		"moveto":
			var dst: Vector3 = args[0]
			if lp.global_position.distance_to(dst) < 6.5:
				# hop via a point far above so the host snaps the puppet instead of sweeping it through the haul
				lp.global_position = dst + Vector3(0, 7.0, 0)
				lp.velocity = Vector3.ZERO
				await _wait(0.25)
			lp.global_position = dst
			lp.velocity = Vector3.ZERO
			if args.size() > 1:
				lp.yaw = float(args[1])
			await _wait(0.6)
			return {"pos": lp.global_position}
		"look":
			# aim at a world point: set yaw/pitch
			var to: Vector3 = args[0] - lp.eye_pos()
			lp.yaw = atan2(-to.x, -to.z)
			lp.pitch = atan2(to.y, Vector2(to.x, to.z).length())
			await _wait(0.2)
			return {}
		"grab_lift":
			var id: int = args[0]
			var it = w.items.get(id)
			if it == null:
				return {"err": "no item"}
			var y0: float = it.global_position.y
			var peak := y0
			for i in 90:
				var tgt: Vector3 = it.net_pos + Vector3(0, 1.0, 0) if i > 3 else it.global_position
				tgt.y = y0 + 1.2
				w.rpc_id(1, "rpc_grab_update", id, tgt, Vector3.ZERO)
				await get_tree().physics_frame
				if w.items.has(id):
					peak = maxf(peak, w.items[id].global_position.y)
			w.rpc_id(1, "rpc_grab_release", id, Vector3.ZERO)
			await _wait(0.5)
			return {"y0": y0, "peak": peak}
		"carry":
			# drag an item to a destination with the beam, walking along (like a player would)
			var id: int = args[0]
			var dest: Vector3 = args[1]
			var it = w.items.get(id)
			if it == null:
				return {"err": "no item"}
			# follow the level's door-to-door route, like a player walking the item over
			var route: Array = w.gen.path_points(it.global_position, dest)
			var t := 0.0
			# the beam point walks at a player's pace (4 m/s) and never runs more than 1.2 m ahead
			var carrot := Vector3(it.global_position.x, dest.y + 0.9, it.global_position.z)
			var best_d := 9999.0
			var stuck_t := 0.0
			var detours := 0
			var tmax: float = float(args[3]) if args.size() > 3 else 60.0
			while t < tmax and not route.is_empty():
				if not w.items.has(id):
					break
				var ip: Vector3 = w.items[id].global_position
				var wp: Vector3 = route[0]
				var flat := Vector3(wp.x - ip.x, 0, wp.z - ip.z)
				if flat.length() < (0.35 if route.size() == 1 else 0.6):
					route.pop_front()
					best_d = 9999.0
					stuck_t = 0.0
					continue
				# caught on a corner: step back to the middle of the room/corridor first, like a player would
				if flat.length() < best_d - 0.2:
					best_d = flat.length()
					stuck_t = 0.0
				else:
					stuck_t += 1.0 / 60.0
				if stuck_t > 1.5 and detours < 6:
					var cc: Vector3 = w.gen.cell_center(w.gen.cell_at(ip))
					var fn := flat.normalized()
					var sidev := Vector3(-fn.z, 0, fn.x) * (1.2 if detours % 2 == 0 else -1.2)
					if detours == 0 and Vector2(cc.x - ip.x, cc.z - ip.z).length() > 0.7 and Vector2(cc.x - wp.x, cc.z - wp.z).length() > 0.5:
						route.push_front(Vector3(cc.x, dest.y, cc.z))
					else:
						route.push_front(Vector3(ip.x, dest.y, ip.z) - fn * 0.7 + sidev * (1 + detours / 2))
					detours += 1
					best_d = 9999.0
					stuck_t = 0.0
					continue
				var to_wp := Vector3(wp.x - carrot.x, 0, wp.z - carrot.z)
				carrot += to_wp.normalized() * minf(4.0 / 60.0, to_wp.length())
				var lead := Vector3(carrot.x - ip.x, 0, carrot.z - ip.z)
				if lead.length() > 1.2:
					lead = lead.normalized() * 1.2
					carrot = Vector3(ip.x + lead.x, carrot.y, ip.z + lead.z)
				var tgt := carrot
				var back := lead.normalized() if lead.length() > 0.05 else flat.normalized()
				lp.global_position = Vector3(tgt.x, lp.global_position.y, tgt.z) - back * 1.5
				w.rpc_id(1, "rpc_grab_update", id, tgt, Vector3.ZERO)
				await get_tree().physics_frame
				t += 1.0 / 60.0
			var left := route.size()
			var wp_left: Vector3 = route[0] if not route.is_empty() else Vector3.ZERO
			var full: Array = w.gen.path_points(Vector3(args[2].x, args[2].y, args[2].z) if args.size() > 2 else dest, dest)
			w.rpc_id(1, "rpc_grab_release", id, Vector3.ZERO)
			await _wait(1.0)
			return {"pos": w.items[id].global_position if w.items.has(id) else Vector3.ZERO, "t": t, "left": left, "wp": wp_left, "route": str(full)}
		"hold":
			# keep an item in the beam in front of us for a while
			var id: int = args[0]
			var dur: float = args[1]
			var t := 0.0
			while t < dur and w.items.has(id):
				w.rpc_id(1, "rpc_grab_update", id, lp.eye_pos() + lp.look_dir() * 1.3, Vector3.ZERO)
				await get_tree().physics_frame
				t += 1.0 / 60.0
			return {}
		"release":
			w.rpc_id(1, "rpc_grab_release", int(args[0]), args[1] if args.size() > 1 else Vector3.ZERO)
			await _wait(0.3)
			return {}
		"use":
			var id: int = args[0]
			var dir: Vector3 = args[1] if args.size() > 1 else lp.look_dir()
			w.gear.rpc_id(1, "rpc_use", id, lp.eye_pos(), dir)
			await _wait(0.5)
			return {}
		"use_item":
			w.rpc_id(1, "rpc_use_item", int(args[0]))
			await _wait(0.6)
			return {}
		"store":
			w.gear.rpc_id(1, "rpc_store", int(args[0]), int(args[1]))
			await _wait(0.6)
			return {}
		"take":
			w.gear.rpc_id(1, "rpc_take", int(args[0]))
			await _wait(0.8)
			return {"grabbed": lp.grabbed_id}
		"interact":
			w.rpc_id(1, "rpc_interact", str(args[0]), int(args[1]))
			await _wait(0.4)
			return {}
		"press":
			# look at a console/button like a player and press "use" (real ray, real range)
			var to2: Vector3 = args[0] - lp.eye_pos()
			lp.yaw = atan2(-to2.x, -to2.z)
			lp.pitch = atan2(to2.y, Vector2(to2.x, to2.z).length())
			await _wait(0.3)
			var seen: String = str(lp.look_interact.get_meta("interact")) if lp.look_interact else ""
			var ph: Dictionary = lp._ray(3.2, 1 | 4)
			var pc = ph.get("collider")
			var press: String = str(pc.get_meta("interact")) if pc and pc.has_meta("interact") else ""
			lp._interact()
			await _wait(0.4)
			return {"seen": seen, "press": press, "hit": str(pc) + " " + str(ph.get("position", "")), "eye": lp.eye_pos()}
		"ping":
			w.rpc("rpc_ping", lp.global_position + lp.look_dir() * 3.0)
			await _wait(0.3)
			return {}
		"tumble":
			lp.stamina = 40.0
			lp._toggle_tumble()
			await _wait(0.6)
			var on: bool = lp.tumbling
			lp._toggle_tumble()
			await _wait(0.3)
			return {"was": on, "now": lp.tumbling}
		"crouch":
			lp._set_crouch(true)
			await _wait(0.5)
			var c: bool = lp.crouching
			lp._set_crouch(false)
			return {"crouched": c}
		"tumble_set":
			lp.stamina = 40.0
			if lp.tumbling != bool(args[0]):
				lp._toggle_tumble()
			await _wait(0.4)
			return {"tumbling": lp.tumbling}
		"lift_player":
			# hold a (tumbling) teammate up in the beam, then throw them forward
			var tid: int = args[0]
			var dur: float = args[1]
			var tp0 = w.players.get(tid)
			var y0: float = tp0.global_position.y if tp0 else 0.0
			var ymax := y0
			var t := 0.0
			while t < dur:
				var tp = w.players.get(tid)
				if tp == null:
					break
				ymax = maxf(ymax, tp.global_position.y)
				w.rpc_id(1, "rpc_grab_update", -tid, lp.global_position + Vector3(0, 2.0, 0) + lp.look_dir() * 1.6, Vector3.ZERO)
				await get_tree().physics_frame
				t += 1.0 / 60.0
			var before: Vector3 = w.players[tid].global_position if w.players.has(tid) else Vector3.ZERO
			w.rpc_id(1, "rpc_grab_release", -tid, lp.look_dir())
			await _wait(0.8)
			var after: Vector3 = w.players[tid].global_position if w.players.has(tid) else Vector3.ZERO
			return {"rise": ymax - y0, "thrown": Vector2(after.x - before.x, after.z - before.z).length()}
		"grab_player":
			var tid: int = args[0]
			var dur: float = args[1]
			var t := 0.0
			while t < dur:
				var tp = w.players.get(tid)
				if tp == null:
					break
				w.rpc_id(1, "rpc_grab_update", -tid, tp.global_position + Vector3(0, 1.0, 0), Vector3.ZERO)
				await get_tree().physics_frame
				t += 1.0 / 60.0
			w.rpc_id(1, "rpc_grab_release", -tid, Vector3.ZERO)
			await _wait(0.3)
			return {}
		"grab_mon":
			var mid: int = args[0]
			var dur: float = args[1]
			var t := 0.0
			while t < dur:
				var mm = w.monsters.get(mid)
				if mm == null or not is_instance_valid(mm):
					break
				w.rpc_id(1, "rpc_grab_update", mid, lp.eye_pos() + lp.look_dir() * 1.6 + Vector3(0, 0.8, 0), Vector3.ZERO)
				await get_tree().physics_frame
				t += 1.0 / 60.0
			w.rpc_id(1, "rpc_grab_release", mid, Vector3.ZERO)
			await _wait(0.3)
			return {}
		"throw_player":
			var tid: int = args[0]
			var tp = w.players.get(tid)
			if tp == null:
				return {"err": "no player"}
			var top := 0.0
			for i in 40:
				w.rpc_id(1, "rpc_grab_update", -tid, tp.global_position + Vector3(0, 1.6, 0), Vector3.ZERO)
				await get_tree().physics_frame
				top = maxf(top, tp.global_position.y)
			w.rpc_id(1, "rpc_grab_release", -tid, Vector3(0, 0.3, -1.0))
			await _wait(0.3)
			return {"top": top}
			await _wait(0.3)
			return {}
		"leave":
			_done = true
			Net.leave()
			return {}
		"color":
			Net.request_color(int(args[0]))
			await _wait(0.6)
			return {"color": int(Net.players.get(me(), {}).get("color", -1))}
		"voice":
			# ~1 s of "speech" fed in real-time-sized chunks (the mic capture path)
			var mr := AudioServer.get_mix_rate()
			var o0: int = w.voice.packets_out if w.voice else 0
			for c in 25:
				var buf := PackedVector2Array()
				for i in int(mr * 0.04):
					var k := c * int(mr * 0.04) + i
					var v := (sin(TAU * 240.0 * k / mr) * 0.35 + sin(TAU * 900.0 * k / mr) * 0.12) * (0.6 + 0.4 * sin(k * 0.0009))
					buf.append(Vector2(v, v))
				if w.voice:
					w.voice.feed(buf)
				await get_tree().process_frame
				await _wait(0.03)
			await _wait(0.3)
			return {"out": (w.voice.packets_out - o0) if w.voice else -1, "sending": w.voice.sending if w.voice else false}
		"cos":
			var out := {}
			for pid in w.players:
				var pl = w.players[pid]
				out[str(Net.players.get(pid, {}).get("name", "?"))] = [pl.model_head != null and pl.model_head.has_node("CosHat"),
					pl.model != null and pl.model.find_child("CosAcc", true, false) != null]
			return {"cos": out}
		"ach":
			return {"prog": Settings.ach_progress.duplicate(), "got": Settings.achievements.keys()}
		"voice_stat":
			var pin := {}
			var vpos := {}
			if w.voice:
				for pid in w.voice.packets_in:
					pin[str(pid)] = w.voice.packets_in[pid]
				for pid in w.voice._voices:
					var ap = w.voice._voices[pid]["ap"]
					if is_instance_valid(ap):
						vpos[str(pid)] = ap.global_position
			return {"in": pin, "vpos": vpos}
		"hud":
			# exercise HUD code paths on the client: map, chat panel, pause menu, settings panel
			var h = w.hud
			h._toggle_map()
			await _wait(0.2)
			h._toggle_map()
			h._toggle_chat()
			await _wait(0.2)
			h._toggle_chat()
			h.expr_bar.visible = true
			await _wait(0.1)
			h.expr_bar.visible = false
			h._toggle_pause()
			await _wait(0.2)
			h._open_settings()
			await _wait(0.3)
			h._close_settings()
			h._toggle_pause()
			await _wait(0.2)
			return {"paused": h.is_paused()}
	return {"err": "unknown cmd " + name}


# ------------------------------------------------------------------ host side

func _host_main() -> void:
	if relay_url != "":
		Settings.relay_url = relay_url
		if FileAccess.file_exists(ROOM_FILE):
			DirAccess.remove_absolute(ROOM_FILE)
		check(Net.host_online(false), "online host started (relay %s)" % relay_url)
		var got := await _wait_until(func(): return Net.relay_code != "", 20.0)
		check(got and Net.relay_code.length() == 5, "relay gave a room code (%s)" % Net.relay_code)
		var f := FileAccess.open(ROOM_FILE, FileAccess.WRITE)
		f.store_string(Net.relay_code)
		f.close()
	else:
		check(Net.host_game(), "host started")
	var ok := await _wait_until(func(): return Net.players.size() >= 4, 60.0)
	check(ok, "3 clients joined (players=%d)" % Net.players.size())
	await _wait(1.0)
	# lobby: colours and names
	for pid in clients():
		var p: Dictionary = Net.players[pid]
		note("lobby player %d %s colour %d" % [pid, p["name"], p["color"]])
	var want := {"Alpha": 5, "Bravo": 9, "Charlie": 12}
	for pid in clients():
		var p2: Dictionary = Net.players[pid]
		check(int(p2["color"]) == int(want.get(str(p2["name"]), -1)), "client %s keeps its chosen colour %d in the lobby" % [p2["name"], int(p2["color"])])
	var rc := await ask(clients()[1], "color", [3])
	await _wait(0.5)
	check(int(Net.players[clients()[1]]["color"]) == 3, "colour change in the lobby reaches the host (%s)" % str(rc.get("color")))
	Net.set_difficulty(1)
	Net.start_run()
	var only := OS.get_environment("HB_ONLY")
	if only != "":
		ok = await _wait_until(func(): return W() != null and not W().shop_mode and W().started, 40.0)
		_freeze_monsters(true)
		await _wait(1.0)
		match only:
			"beam":
				await _beam_physics(1)
			"drones":
				await _drone_quick()
			"carry":
				for k in 5:
					await _client_carry_test(k + 1)
			"pad":
				await _death_and_pad_revive(2)
			"fight":
				for k in 3:
					await _combat_basic(k + 1)
			"mpsave":
				await _mp_save_test()
			"rejoin":
				await _rejoin_test(1)
				await _finish_level_to_shop(1)
				await _rejoin_check_after(1)
			"melee":
				await _melee_quick()
			"voice":
				await _cos_check()
				await _voice_check(1, clients()[2])
				await _voice_check(1, clients()[0])
				await _death_and_pad_revive(2)
			"gear":
				var wg = W()
				var lst := OS.get_environment("HB_GEAR")
				if lst == "":
					lst = "w_pistol,d_feather,t_valuable,d_shield,w_shotgun,i_pocketcart,w_duck,d_recharge,d_zerog,w_tranq"
				var k := 0
				for t in lst.split(","):
					var gid: int = wg.spawn_item(t, 0, wg.truck_pos + Vector3((k % 3 - 1) * 0.5, 0.4 + (k / 3) * 0.3, 0), Quaternion.IDENTITY, 0)
					if wg.items.has(gid):
						wg.items[gid].uid = 900 + k
					k += 1
				await _wait(0.5)
				for rep in 2:
					await _gear_tests(4)
			"console":
				var wc = W()
				var ec: Dictionary = wc.extr[0]
				var cpos: Vector3 = ec["console"]
				var cax := Vector3(cpos.x - ec["pos"].x, 0, cpos.z - ec["pos"].z)
				var perp := Vector3(-cax.z, 0, cax.x).normalized()
				note("  pad %s console %s" % [ec["pos"], cpos])
				for rep in 3:
					var dst: Vector3 = cpos + perp * 0.9 + Vector3(0, 0.1, 0)
					var mv := await ask(clients()[rep], "moveto", [dst])
					note("  client %d asked %s -> %s" % [rep, dst, str(mv.get("pos"))])
					for k in 6:
						var sn := await ask(clients()[rep], "snap")
						note("    t%d client pos %s host puppet %s" % [k, str(sn.get("snap", {}).get("pos")), wc.players[clients()[rep]].global_position])
						await _wait(0.2)
					await ask(clients()[rep], "moveto", [wc.gen.spawn_points[1]])
			"press":
				var wq = W()
				for i in clients().size():
					await ask(clients()[i], "moveto", [wq.gen.spawn_points[(i + 1) % 4]])
				wq.local_player.global_position = wq.gen.spawn_points[0]
				await _wait(1.0)
				for i in clients().size():
					var tq := await ask(clients()[i], "press", [wq.gen.truck_button + Vector3(0, 0.95, 0)])
					note("  press from spawn %d: %s / button %s" % [i + 1, str(tq), str(wq.gen.truck_button)])
		await ask_all("done", [], 10.0)
		_finish()
		return
	for lvl in range(1, target_level + 1):
		ok = await _wait_until(func(): return W() != null and not W().shop_mode and W().started and Net.level == lvl, 40.0)
		if not check(ok, "level %d started" % lvl):
			break
		if lvl == 1:
			await _cos_check()
		await _play_level(lvl)
		if errors.size() > 60:
			break
		ok = await _wait_until(func(): return W() != null and W().shop_mode and W().started, 40.0)
		if not check(ok, "shop after level %d" % lvl):
			break
		await _play_shop(lvl)
	# the next level loads after the last shop: the leave and the arena run in a real level
	ok = await _wait_until(func(): return W() != null and not W().shop_mode and W().started and Net.level == target_level + 1, 40.0)
	if check(ok, "level %d loaded after the last shop" % (target_level + 1)):
		_freeze_monsters(true)
		await _wait(1.5)
		await _cmp_with_clients("L%d start" % (target_level + 1))
		await _disconnect_test()
		await _final_arena()
	await _ach_check()
	await ask_all("done", [], 10.0)
	_finish()


func _freeze_monsters(on: bool) -> void:
	for m in W().monsters.values():
		if on:
			m.dormant = maxf(m.dormant, 9999.0)
		else:
			m.dormant = 0.0


func _cmp_with_clients(tag: String) -> void:
	var w = W()
	var s := await ask_all("snap")
	var hs := snap()
	for pid in s:
		var cs: Dictionary = s[pid].get("snap", {})
		if cs.is_empty():
			continue
		check(cs["level"] == hs["level"] and cs["money"] == hs["money"], "%s: client %d level/money in sync (%s/%s vs %s/%s)" % [tag, pid, cs["level"], cs["money"], hs["level"], hs["money"]])
		check(cs.get("players", 0) == hs["players"], "%s: client %d sees %d players" % [tag, pid, cs.get("players", 0)])
		check(absi(int(cs.get("items", 0)) - int(hs["items"])) <= 1, "%s: client %d items %d vs host %d" % [tag, pid, cs.get("items", 0), hs["items"]])
		if hs.has("extr_done"):
			check(str(cs.get("extr_done")) == str(hs["extr_done"]), "%s: client %d extraction state %s vs %s" % [tag, pid, cs.get("extr_done"), hs["extr_done"]])
		var hh: Dictionary = hs["hp"]
		var ch: Dictionary = cs.get("hp", {})
		for k in hh:
			if absf(float(ch.get(k, -1.0)) - float(hh[k])) > 0.6:
				check(false, "%s: client %d sees hp[%d]=%.1f, host %.1f" % [tag, pid, k, float(ch.get(k, -1.0)), float(hh[k])])


func _valuables() -> Array:
	var out := []
	for it in W().items.values():
		if it.value > 0 and not ItemDefs.is_gear(it.type) and it.type != "head" and it.held == 0:
			out.append(it)
	out.sort_custom(func(a, b): return a.value > b.value)
	return out


## Put enough value on the active pad (teleported: this is the test harness, the real carry is tested separately).
func _fill_pad(idx: int, overshoot := 1.0) -> int:
	var w = W()
	var e: Dictionary = w.extr[idx]
	var goal := int(e["goal"] * overshoot)
	var sum := int(e["value"])
	var n := 0
	var slots := [Vector2(0, 0), Vector2(0.75, 0), Vector2(-0.75, 0), Vector2(0, 0.75), Vector2(0, -0.75),
		Vector2(0.75, 0.75), Vector2(-0.75, -0.75), Vector2(0.75, -0.75), Vector2(-0.75, 0.75)]
	for it in _valuables():
		if sum >= goal:
			break
		if w._in_zone(it.global_position, e["pos"], 1.55):
			continue
		if it.mass > 15.0 and n > 0:
			continue      # tall heavy pieces only in the middle, or they topple off the pad
		var sl: Vector2 = slots[n % slots.size()]
		it.teleport(e["pos"] + Vector3(sl.x, 0.45 + (n / slots.size()) * 0.5, sl.y))
		it.linear_velocity = Vector3.ZERO
		it.angular_velocity = Vector3.ZERO
		sum += it.value
		n += 1
	if sum < goal:
		# not enough loose valuables left (some broke): top up so the run can continue
		var need := goal - sum + 100
		w.spawn_item("trophy", need, e["pos"] + Vector3(0, 0.8, 0), Quaternion.IDENTITY, 0)
		note("  topped up pad %d with $%d" % [idx, need])
	return n


func _play_level(lvl: int) -> void:
	var w = W()
	var cl := clients()
	note("===== LEVEL %d (%s) cells=%d halls=%d insets=%d points=%d quota=%d items=%d monsters=%d moon=%d" % [lvl, ["warehouse", "offices", "lab"][w.gen.location], w.gen.order.size(),
		w.gen.rooms.filter(func(r): return r.size() >= 2).size(), w.gen.inset.size(), w.extr.size(), w.quota_total, w.items.size(), w.monsters.size(), w.moon_phase(lvl)])
	_freeze_monsters(true)
	await _wait(1.0)
	await _cmp_with_clients("L%d start" % lvl)
	check(w.players.size() == 4, "L%d: host sees 4 robots" % lvl)
	# owned items from the shop wait in the van
	if lvl > 1:
		var own := 0
		for it in w.items.values():
			if it.uid > 0:
				own += 1
		var in_inv := Net.inv_uids().size()
		check(own + in_inv >= Net.owned.size() - 0, "L%d: bought items in the van (%d spawned + %d in slots, %d owned)" % [lvl, own, in_inv, Net.owned.size()])
		await _use_owned(lvl)
	# chat + expressions + ping + HUD on every client
	var cr := await ask(cl[lvl % 3], "chat", ["Уровень %d, погнали!" % lvl])
	await _wait(0.6)
	check(w._bubbles.has(cl[lvl % 3]), "L%d: chat bubble of client %d on host" % [lvl, cl[lvl % 3]])
	var er := await ask(cl[(lvl + 1) % 3], "expr", [lvl % 6])
	await _wait(0.6)
	var ep = w.players[cl[(lvl + 1) % 3]]
	check(ep.expr == int(er.get("expr", -1)), "L%d: expression replicated (%d vs %s)" % [lvl, ep.expr, str(er.get("expr"))])
	await ask(cl[(lvl + 2) % 3], "ping")
	if lvl == 1:
		var hr := await ask_all("hud")
		for pid in hr:
			check(hr[pid].get("paused", true) == false, "L1: HUD menus open/close on client %d" % pid)
		var tr := await ask(cl[0], "tumble")
		check(tr.get("was", false) and not tr.get("now", true), "L1: client tumble on/off")
		var crr := await ask(cl[1], "crouch")
		check(crr.get("crouched", false), "L1: client crouch")
		await _voice_check(lvl, cl[2])
	# a client carries a real item with the beam and lifts another
	await _client_carry_test(lvl)
	_repair_all("L%d after the carry" % lvl)
	# combat / damage / revive scenarios by level
	match lvl:
		1:
			await _combat_basic(lvl)
		2:
			await _death_and_pad_revive(lvl)
		3:
			await _hp_transfer(lvl)
			await _tumble_lift(lvl)
			await _combat_basic(lvl)
		4:
			await _combat_basic(lvl)
			await _beam_physics(lvl)
		5:
			await _combat_basic(lvl)
			await _charger_test(lvl)
	_repair_all("L%d after the fights" % lvl)
	# extraction points in order
	for idx in w.extr.size():
		if w.extr[idx]["done"]:
			continue
		await _extract(lvl, idx)
		if lvl == 3 and idx == w.extr.size() - 1:
			pass
	check(w.all_done, "L%d: all points done" % lvl)
	var carts := 0
	for it in w.items.values():
		if it.type == "cart":
			carts += 1
	check(carts == 0, "L%d: carts gone after the last point (%d)" % [lvl, carts])
	await _cmp_with_clients("L%d after points" % lvl)
	# van: everyone in (one robot left behind on level 4 to test the explosion), head revive on level 3
	if lvl == 3:
		await _truck_head_revive(lvl)
	await _depart(lvl)


func _client_carry_test(lvl: int) -> void:
	var w = W()
	var cl := clients()
	var carrier: int = cl[(lvl + 1) % 3]
	var vals := _valuables().filter(func(it): return it.mass <= 4.0 and not w.is_protected(it) and it.value >= it.base_value * 0.8 and it.type != "moneybag")
	if vals.is_empty():
		return
	# prefer a piece outside the big halls: the harness walks the route blindly and the rows of
	# furniture islands in a hall need real steering (a player does that, this script can't)
	var plain := vals.filter(func(x):
		var c: Vector2i = w.gen.cell_at(x.global_position)
		return not w.gen.room_of.has(c) or w.gen.rooms[w.gen.room_of[c]].size() < 2)
	if not plain.is_empty():
		vals = plain
	var it = vals[vals.size() - 1]
	var iid: int = it.item_id
	var ityp: String = it.type
	var e: Dictionary = w.extr[w.active_extr]
	var start: Vector3 = it.global_position
	await ask(carrier, "moveto", [start + Vector3(0, 0.1, 1.6)])
	var v0: int = it.value if is_instance_valid(it) else 0
	var r := await ask(carrier, "carry", [iid, e["pos"], start, 55.0], 70.0)
	if int(r.get("left", 0)) > 0:
		note("  carry stuck: %d waypoints left, next %s, item at %s, route %s" % [int(r.get("left", 0)), str(r.get("wp")), str(r.get("pos")), str(r.get("route"))])
		if w.items.has(iid):
			var ip: Vector3 = w.items[iid].global_position
			var wp: Vector3 = r.get("wp", ip)
			var sp: PhysicsDirectSpaceState3D = w.get_world_3d().direct_space_state
			for hy in [0.15, 0.5, 1.0]:
				var rq := PhysicsRayQueryParameters3D.create(Vector3(ip.x, hy, ip.z), Vector3(wp.x, hy, wp.z), 1 | 2 | 4 | 8)
				rq.exclude = [w.items[iid].get_rid()]
				var rh := sp.intersect_ray(rq)
				note("    ray y=%.2f -> %s %s" % [hy, str(rh.get("position", "none")), str(rh.get("collider", ""))])
			var shq := PhysicsShapeQueryParameters3D.new()
			var sph := SphereShape3D.new()
			sph.radius = 0.7
			shq.shape = sph
			shq.transform = Transform3D(Basis(), ip)
			shq.collision_mask = 1 | 2 | 4 | 8
			shq.exclude = [w.items[iid].get_rid()]
			for hh in sp.intersect_shape(shq, 12):
				var co = hh["collider"]
				note("    near: %s %s" % [str(co), str(co.global_position) if co is Node3D else ""])
			var gc: Vector2i = w.gen.cell_at(ip)
			note("    cell %s inset %s room %s theme %s" % [gc, str(w.gen.inset.get(gc, "-")), str(w.gen.room_of.get(gc, "-")), str(w.gen.cells.get(gc, "-"))])
	await _wait(0.8)
	var alive: bool = w.items.has(iid) and is_instance_valid(w.items[iid])
	var in_zone: bool = alive and w.item_in_zone(w.items[iid])
	if not in_zone and alive:
		var d0 := Vector2(start.x - e["pos"].x, start.z - e["pos"].z).length()
		var d1 := Vector2(w.items[iid].global_position.x - e["pos"].x, w.items[iid].global_position.z - e["pos"].z).length()
		note("  carry ended %.1f m from the pad (started %.1f m away)" % [d1, d0])
		in_zone = d1 < 2.5
	note("  carry: client %d moved %s from %s to %s in %.1fs, value %d -> %d" % [carrier, ityp, start, r.get("pos"), float(r.get("t", 0)), v0, w.items[iid].value if alive else -1])
	check(in_zone, "L%d: client %d carried a %s onto the pad with the beam" % [lvl, carrier, ityp])
	var sp0: PhysicsDirectSpaceState3D = w.get_world_3d().direct_space_state
	var lift := _valuables().filter(func(x):
		if x.mass > 3.0 or w.item_in_zone(x) or x.global_position.y > 0.6:
			return false
		# nothing above it (a piece under a table can't be lifted up)
		var rq := PhysicsRayQueryParameters3D.create(x.global_position + Vector3(0, 0.3, 0), x.global_position + Vector3(0, 1.8, 0), 1)
		return sp0.intersect_ray(rq).is_empty())
	if lift.size() > 0:
		var li = lift[0]
		await ask(cl[lvl % 3], "moveto", [li.global_position + Vector3(0, 0.1, 1.8)])
		var lr := await ask(cl[lvl % 3], "grab_lift", [li.item_id])
		check(float(lr.get("peak", 0)) > float(lr.get("y0", 0)) + 0.3, "L%d: client sees its own lift replicated (%.2f -> %.2f)" % [lvl, float(lr.get("y0", 0)), float(lr.get("peak", 0))])


func _extract(lvl: int, idx: int) -> void:
	var w = W()
	var cl := clients()
	var last: bool = idx == w.extr.size() - 1
	var bags0 := 0
	for it in w.items.values():
		if it.type == "moneybag":
			bags0 += 1
	var e: Dictionary = w.extr[idx]
	var presser: int = cl[idx % 3]
	for k in cl.size():
		if not w.players[presser].dead:
			break
		presser = cl[(idx + k + 1) % 3]
	# walk up to the button first (a robot teleported across the pad would shove the haul off it)
	var cpos: Vector3 = e.get("console", e["pos"] + Vector3(2.15, 0, 0))
	var cax := Vector3(cpos.x - e["pos"].x, 0, cpos.z - e["pos"].z)
	var perp := Vector3(-cax.z, 0, cax.x).normalized()
	var spot: Vector3 = cpos + perp * 0.9
	for ci in cl.size():
		var c: int = cl[ci]
		var cp: Vector3 = w.players[c].global_position
		if c != presser and not w.players[c].dead and (w._in_zone(cp, e["pos"], 2.4) or Vector2(cp.x - spot.x, cp.z - spot.z).length() < 1.5):
			await ask(c, "moveto", [cpos - perp * (1.4 + ci * 0.8) + Vector3(0, 0.1, 0)])    # off the pad, beyond the console
	if w._in_zone(w.local_player.global_position, e["pos"], 2.0):
		w.local_player.global_position = w.gen.spawn_points[0]
	await _wait(0.4)
	var mv := await ask(presser, "moveto", [cpos + perp * 0.9 + Vector3(0, 0.1, 0)])
	var mvp: Vector3 = mv.get("pos", Vector3.ZERO)
	if w._in_zone(mvp, e["pos"], 1.6) or mvp.distance_to(cpos + perp * 0.9) > 0.3:
		note("    presser %d ended at %s (asked %s)" % [presser, mvp, cpos + perp * 0.9])
		var sp: PhysicsDirectSpaceState3D = w.get_world_3d().direct_space_state
		var shq := PhysicsShapeQueryParameters3D.new()
		var sph := SphereShape3D.new()
		sph.radius = 0.8
		shq.shape = sph
		shq.transform = Transform3D(Basis(), cpos + perp * 0.9 + Vector3(0, 0.6, 0))
		shq.collision_mask = 1 | 2 | 4 | 8
		for hh in sp.intersect_shape(shq, 16):
			var co = hh["collider"]
			note("      near: %s %s %s" % [str(co), str(co.global_position) if co is Node3D else "", str(co.get("type")) if co.is_in_group("item") else ""])
	await _wait(0.5)
	var n := _fill_pad(idx, 1.35 if not last else 1.2)
	await _wait(1.5)
	check(e["value"] >= e["goal"], "L%d P%d: pad value %d >= goal %d (%d items)" % [lvl, idx + 1, e["value"], e["goal"], n])
	var pr := await ask(presser, "press", [cpos + Vector3(0, 1.12, 0)])
	var hp_pos: Vector3 = w.players[presser].global_position
	check(not w._in_zone(hp_pos, e["pos"], 1.6), "L%d P%d: presser %d stands off the pad (%s, client eye %s)" % [lvl, idx + 1, presser, hp_pos, str(pr.get("eye", ""))])
	check(str(pr.get("press", "")) == "extract", "L%d P%d: client %d aims at the console and presses it (%s, hit %s from %s)" % [lvl, idx + 1, presser, str(pr.get("seen", "")), str(pr.get("hit", "")), str(pr.get("eye", ""))])
	if str(pr.get("press", "")) != "extract":
		await ask(presser, "interact", ["extract", idx])
	var ok := await _wait_until(func(): return w.extr[idx]["done"], 12.0)
	check(ok, "L%d P%d: extraction by client %d finished" % [lvl, idx + 1, presser])
	if not ok:
		# keep the run going: refill and press again (the failure above is already counted)
		note("    retrying P%d: pad value %d / %d" % [idx + 1, e["value"], e["goal"]])
		_fill_pad(idx, 1.3)
		await _wait(1.5)
		await ask(presser, "interact", ["extract", idx])
		await _wait_until(func(): return w.extr[idx]["done"], 12.0)
	await _wait(1.0)
	var bags := 0
	for it in w.items.values():
		if it.type == "moneybag":
			bags += 1
	if not last:
		check(bags >= 1, "L%d P%d: surplus bag spawned (%d)" % [lvl, idx + 1, bags])
		check(w.active_extr == idx + 1, "L%d: next point active (%d)" % [lvl, w.active_extr])
	else:
		check(bags <= bags0, "L%d: no new surplus bag at the last point (%d -> %d)" % [lvl, bags0, bags])
	await _cmp_with_clients("L%d P%d" % [lvl, idx + 1])


var _head_watch := -1


func _process(_d: float) -> void:
	if role == 0 and _head_watch > 0 and W() and W().items.has(_head_watch):
		var h = W().items[_head_watch]
		if Engine.get_process_frames() % 20 == 0:
			note("    head %s type=%s value=%d extra=%d extracting=%s t=%.2f zone=%s" % [h.global_position, h.type, h.value, h.extra, W().extracting, W().extract_t, W().item_in_zone(h)])


func _bags_left_from_before() -> bool:
	return false


func _depart(lvl: int) -> void:
	var w = W()
	var cl := clients()
	var behind: int = cl[0] if lvl == 4 else -1
	for i in cl.size():
		var pid: int = cl[i]
		if pid == behind or w.players[pid].dead:
			continue
		await ask(pid, "moveto", [w.gen.spawn_points[(i + 1) % 4]])
	w.local_player.global_position = w.gen.spawn_points[0]
	w.local_player.velocity = Vector3.ZERO
	if behind > 0:
		var ep: Vector3 = w.gen.cell_center(w.gen.order[1])
		await ask(behind, "moveto", [ep + Vector3(0, 0.2, 0)])
	await _wait(1.0)
	for pid in w.players:
		if pid != behind and not w.players[pid].dead:
			check(w.in_truck(w.players[pid].global_position), "L%d: robot %d is inside the van" % [lvl, pid])
	var money0 := Net.money
	var vpress: int = cl[mini(1, cl.size() - 1)]
	var order: Array = cl.slice(1) + cl.slice(0, 1)
	for c in order:
		if c != behind and w.players.has(c) and not w.players[c].dead:
			vpress = c
			break
	var tp := await ask(vpress, "press", [w.gen.truck_button + Vector3(0, 0.95, 0)])
	check(str(tp.get("press", "")) == "truck", "L%d: client aims at the van button and presses it (%s, hit %s from %s)" % [lvl, str(tp.get("seen", "")), str(tp.get("hit", "")), str(tp.get("eye", ""))])
	if str(tp.get("press", "")) != "truck":
		await ask(vpress, "interact", ["truck", 0])
	var ok := await _wait_until(func(): return w.leaving, 3.0)
	check(ok, "L%d: van countdown started" % lvl)
	var wid: int = w.get_instance_id()
	var shopped := await _wait_until(func(): return W() != null and (W().get_instance_id() != wid or W().shop_mode), 25.0)
	check(shopped, "L%d: van left, shop loaded" % lvl)
	check(Net.money > money0, "L%d: haul paid out ($%d -> $%d)" % [lvl, money0, Net.money])
	if behind > 0:
		await _wait(3.0)
		check(float(Net.hp.get(behind, 0.0)) > 0.0, "L%d: robot left behind is back in the shop with HP %.0f" % [lvl, float(Net.hp.get(behind, 0.0))])


## Cosmetics: everyone sees everyone's hat / accessory.
func _cos_check() -> void:
	var want := {"Host": [false, false], "Alpha": [true, false], "Bravo": [true, true], "Charlie": [false, true]}
	var views := await ask_all("cos")
	var hv := {}
	for pid in W().players:
		var pl = W().players[pid]
		hv[str(Net.players.get(pid, {}).get("name", "?"))] = [pl.model_head != null and pl.model_head.has_node("CosHat"),
			pl.model != null and pl.model.find_child("CosAcc", true, false) != null]
	views[1] = {"cos": hv}
	for vid in views:
		var seen: Dictionary = views[vid].get("cos", {})
		for nm in want:
			check(seen.get(nm, []) == want[nm], "cosmetics: %s sees %s wearing %s (%s)" % [str(Net.players.get(vid, {}).get("name", vid)), nm, str(want[nm]), str(seen.get(nm))])


## Achievements counted on every robot during the run.
func _ach_check() -> void:
	var res := await ask_all("ach")
	res[1] = {"prog": Settings.ach_progress, "got": Settings.achievements.keys()}
	for pid in res:
		var pr: Dictionary = res[pid].get("prog", {})
		var got: Array = res[pid].get("got", [])
		note("  achievements %s: %s  unlocked %s" % [str(Net.players.get(pid, {}).get("name", pid)), str(pr), str(got)])
		check(int(pr.get("extract", 0)) >= target_level and int(pr.get("level", 0)) >= target_level and int(pr.get("earn", 0)) > 0, "achievements: robot %d counted extractions / levels / money" % pid)
		check("first_haul" in got and "squad" in got, "achievements: robot %d unlocked First haul and Full van" % pid)
		if relay_url != "":
			check("online" in got, "achievements: robot %d unlocked Net hauler over the internet" % pid)
		else:
			check(not ("online" in got), "achievements: no Net hauler for a Wi-Fi game (robot %d)" % pid)


## A client talks: everyone near hears it (host included), the voice comes from its robot.
func _voice_check(lvl: int, spk: int, dead := false) -> void:
	var w = W()
	var before := int(w.voice.packets_in.get(spk, 0))
	var others0 := await ask_all("voice_stat")
	var vr := await ask(spk, "voice")
	await _wait(0.4)
	var got := int(w.voice.packets_in.get(spk, 0)) - before
	check(int(vr.get("out", 0)) >= 15, "L%d: %s robot %d sends voice (%d packets)" % [lvl, "broken" if dead else "", spk, int(vr.get("out", 0))])
	check(got >= int(vr.get("out", 0)) - 3 and got > 0, "L%d: the host hears it (%d packets)" % [lvl, got])
	var st := await ask_all("voice_stat")
	for pid in st:
		if pid == spk:
			continue
		var n0 := int(others0.get(pid, {}).get("in", {}).get(str(spk), 0))
		var n1 := int(st[pid].get("in", {}).get(str(spk), 0))
		check(n1 - n0 > 0, "L%d: client %d hears robot %d (%d packets)" % [lvl, pid, spk, n1 - n0])
	# the 3D voice sits at the robot's head, or at the severed head when broken
	if w.voice._voices.has(spk):
		var ap = w.voice._voices[spk]["ap"]
		var want: Vector3 = w.chat_pos(spk) if dead else w.players[spk].global_position + Vector3(0, 1.55, 0)
		check(ap.global_position.distance_to(want) < 0.8, "L%d: voice plays from %s (%.2f m off)" % [lvl, "its head on the floor" if dead else "the robot", ap.global_position.distance_to(want)])
	else:
		check(false, "L%d: host has a voice player for robot %d" % [lvl, spk])


func _death_and_pad_revive(lvl: int) -> void:
	var w = W()
	var victim: int = clients()[1]
	w.server_damage_player(victim, 9999.0, Vector3.ZERO)
	await _wait(1.0)
	var head = null
	for it in w.items.values():
		if it.type == "head" and it.extra == victim:
			head = it
	check(w.players[victim].dead, "L%d: robot %d destroyed" % [lvl, victim])
	check(head != null, "L%d: its head dropped" % lvl)
	var vr := await ask(victim, "snap")
	check(vr.get("snap", {}).get("dead", false), "L%d: client %d knows it is dead (spectating)" % [lvl, victim])
	var p0 := int(w.ping_count.get(victim, 0))
	var sr := await ask(victim, "spectate")
	note("  spectate: %s" % str(sr))
	check(int(sr.get("t0", -1)) > 0 and int(sr.get("t1", -1)) > 0 and int(sr.get("t0", -1)) != int(sr.get("t1", -1)), "L%d: the broken robot switches between teammates (%s -> %s)" % [lvl, sr.get("t0"), sr.get("t1")])
	check(bool(sr.get("bar", false)) and str(sr.get("hud_name", "")).contains("HP"), "L%d: spectator buttons and '%s'" % [lvl, str(sr.get("hud_name", ""))])
	check(float(sr.get("cam_to_target", 99)) < 6.0 and float(sr.get("cam_to_target0", 99)) < 4.0, "L%d: orbit and over-the-shoulder cameras follow the teammate (%.1f / %.1f m)" % [lvl, float(sr.get("cam_to_target", 99)), float(sr.get("cam_to_target0", 99))])
	await _wait(0.6)
	check(bool(sr.get("pinged", false)) and int(w.ping_count.get(victim, 0)) > p0, "L%d: a broken robot can drop a mark for the team" % lvl)
	await _voice_check(lvl, victim, true)
	if head:
		var e: Dictionary = w.extr[w.active_extr]
		head.teleport(e["pos"] + Vector3(0.0, 0.5, 0.85))
		head.linear_velocity = Vector3.ZERO
		head.angular_velocity = Vector3.ZERO
	# the extraction of the active point revives it (checked after _extract)
	var hid: int = head.item_id if head else -1
	await _wait(1.0)
	if head and w.items.has(hid):
		note("  head at %s pad %s in zone %s" % [head.global_position, w.extr[w.active_extr]["pos"], w._in_zone(head.global_position, w.extr[w.active_extr]["pos"], 1.55)])
	var dbg_idx: int = w.active_extr
	_head_watch = hid
	await _extract(lvl, dbg_idx)
	_head_watch = -1
	note("  after extraction: head exists %s, victim dead %s" % [w.items.has(hid), w.players[victim].dead])
	await _wait(1.0)
	check(not w.players[victim].dead, "L%d: head on the pad revived robot %d" % [lvl, victim])
	check(absf(float(Net.hp.get(victim, 0.0)) - 1.0) < 0.1, "L%d: revived with 1 HP (%.1f)" % [lvl, float(Net.hp.get(victim, 0.0))])
	var vs := await ask(victim, "snap")
	check(not vs.get("snap", {}).get("dead", true), "L%d: client %d is alive again on its own screen" % [lvl, victim])


func _truck_head_revive(lvl: int) -> void:
	var w = W()
	var victim: int = clients()[2]
	await ask(victim, "moveto", [w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.2, 0)])
	w.server_damage_player(victim, 9999.0, Vector3.ZERO)
	await _wait(1.0)
	var head = null
	for it in w.items.values():
		if it.type == "head" and it.extra == victim:
			head = it
	if not check(head != null, "L%d: head of robot %d dropped" % [lvl, victim]):
		return
	check(w.players[victim].dead, "L%d: robot %d stays down until its head reaches the van" % [lvl, victim])
	head.teleport(w.truck_pos + Vector3(0, 0.6, 0))
	head.linear_velocity = Vector3.ZERO
	var ok := await _wait_until(func(): return not w.players[victim].dead, 6.0)
	check(ok, "L%d: head in the van after the last point revives robot %d" % [lvl, victim])
	check(float(Net.hp.get(victim, 0.0)) >= 24.0, "L%d: van revive gives 25 HP (%.1f)" % [lvl, float(Net.hp.get(victim, 0.0))])


func _hp_transfer(lvl: int) -> void:
	var w = W()
	var a: int = clients()[0]
	var b: int = clients()[1]
	Net.hp[b] = 30.0
	w.rpc("rpc_player_hp", b, 30.0, false, Vector3.ZERO)
	var ap: Vector3 = w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.1, 0)
	await ask(a, "moveto", [ap])
	await ask(b, "moveto", [ap + Vector3(0, 0, -2.0)])
	var ha := float(Net.hp.get(a, 0.0))
	await ask(a, "grab_player", [b, 2.5], 20.0)
	await _wait(0.5)
	var hb := float(Net.hp.get(b, 0.0))
	check(hb > 34.0 and float(Net.hp.get(a, 0.0)) < ha, "L%d: beam on a teammate transfers HP (%d: %.0f->%.0f, %d: 30->%.0f)" % [lvl, a, ha, float(Net.hp.get(a, 0.0)), b, hb])


## A teammate in tumble form is lifted by the beam, carried and thrown.
func _tumble_lift(lvl: int) -> void:
	var w = W()
	var a: int = clients()[0]
	var b: int = clients()[1]
	var ap: Vector3 = w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.1, 0)
	await ask(a, "moveto", [ap])
	await ask(b, "moveto", [ap + Vector3(0, 0, -1.6)])
	var tr := await ask(b, "tumble_set", [true])
	check(bool(tr.get("tumbling", false)), "L%d: robot %d curls into tumble form" % [lvl, b])
	await _wait(0.3)
	var r := await ask(a, "lift_player", [b, 2.0], 20.0)
	check(float(r.get("rise", 0.0)) > 0.8, "L%d: tumbling teammate lifted by the beam (rise %.2f m)" % [lvl, float(r.get("rise", 0.0))])
	check(float(r.get("thrown", 0.0)) > 1.0, "L%d: tumbling teammate thrown (%.2f m)" % [lvl, float(r.get("thrown", 0.0))])
	await ask(b, "tumble_set", [false])


## A monster wakes up next to a robot and fights; the crew fights back with whatever gear it has.
func _combat_basic(lvl: int) -> void:
	var w = W()
	var cl := clients()
	var fighter: int = cl[lvl % 3]
	var m = null
	if OS.get_environment("HB_FIGHTMON") != "":
		m = w.monsters[w.spawn_monster(OS.get_environment("HB_FIGHTMON"), w.gen.cell_center(w.gen.order[1]))]
	for pref in ["brute", "butcher", "howler", "rugrat", "skitter", "lurker", "bighead", "watcher", "projector"]:
		for mm in w.monsters.values():
			if m == null and mm.state != MonsterScript.DEAD and mm.mtype == pref:
				m = mm
	if m == null:
		note("  no melee monster on this level")
		return
	var arena: Vector3 = w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.1, 0)
	await ask(fighter, "moveto", [arena + Vector3(0, 0, 2.0), 0.0])
	_wake(m, arena + Vector3(0, 0.1, -1.2))
	# face it, like a player would (the watcher only charges once someone looks straight at it);
	# the others look at the floor so it goes for the fighter, not for someone staring from the van
	w.local_player.pitch = -1.35
	for c in cl:
		if c != fighter:
			await ask(c, "look", [w.players[c].global_position + Vector3(0.3, -6.0, 0)])
	await ask(fighter, "look", [m.global_position + Vector3(0, minf(float(m.cfg["height"]) * 0.6, 1.3), 0)])
	var hp0 := float(Net.hp.get(fighter, 100.0))
	var hps0 := {}
	for pid in Net.players:
		hps0[pid] = float(Net.hp.get(pid, 100.0))
	var ok := false
	var who := -1
	for i in 50:
		await _wait(0.5)
		if i == 4 or i == 20:
			await ask(fighter, "chat", ["Эй, чудище! Я тут!"])    # noise: monsters hear chatter
		if i % 6 == 0 and not _mdead(m):
			var fp: Vector3 = w.players[fighter].global_position
			var tp2 = w.players.get(m.target_pid)
			note("    %s state=%d target=%d dist=%.1f dormant=%.0f lurk=%s stun=%.1f sus=%s pos=%s tpos=%s stall=%.1f best=%.1f path=%s" % [m.mtype, m.state, m.target_pid, m.global_position.distance_to(fp), m.dormant, m.lurking, m.stun_t, str(m.sus), m.global_position, tp2.global_position if tp2 else Vector3.ZERO, m.chase_stall, m.chase_best, str(m.path.slice(0, 3))])
		for pid in Net.players:
			if w.players.has(pid) and (float(Net.hp.get(pid, 100.0)) < float(hps0[pid]) or w.players[pid].dead):
				ok = true
				who = pid
		if ok:
			break
	note("  monster %s vs client %d: hp %.0f -> %.0f (hurt robot %d)" % [m.mtype, fighter, hp0, float(Net.hp.get(fighter, 100.0)), who])
	check(ok, "L%d: a %s hurts a robot (%d)" % [lvl, m.mtype, who])
	# fight back: throw a heavy valuable at it (works without gear), then gear if the crew has any
	var mhp: float = m.hp
	var rock = null
	for it in w.items.values():
		if it.value > 0 and it.mass >= 2.0 and it.mass <= 8.0 and not ItemDefs.is_gear(it.type) and it.type != "head" \
				and (rock == null or it.fragility < rock.fragility):
			rock = it    # the sturdiest one: a vase shatters on the first throw
	if rock and not _mdead(m):
		var rtype: String = rock.type
		var hurt := false
		for attempt in 3:
			if not is_instance_valid(rock) or _mdead(m):
				break
			m.stun_t = 3.0
			await _wait(0.3)
			var aim: Vector3 = m.global_position + Vector3(0, minf(float(m.cfg["height"]) * 0.5, 1.0), 0)
			# throw from the fighter's side: that side is open floor, the other may be a wall
			var fp2: Vector3 = w.players[fighter].global_position
			var side := Vector3(fp2.x - aim.x, 0, fp2.z - aim.z)
			side = side.normalized() if side.length() > 0.3 else Vector3(0, 0, 1)
			side = side.rotated(Vector3.UP, [0.9, -0.9, 0.0][attempt])
			# never throw from inside a robot standing next to the monster (it would catch the throw)
			var from: Vector3 = aim + side * (float(m.cfg.get("radius", 0.5)) + 1.1) + Vector3(0, 0.3, 0)
			for k in 8:
				var busy := false
				for pl in w.players.values():
					if not pl.dead and Vector2(pl.global_position.x - from.x, pl.global_position.z - from.z).length() < 1.0:
						busy = true
				if not busy:
					break
				side = side.rotated(Vector3.UP, PI / 4.0)
				from = aim + side * (float(m.cfg.get("radius", 0.5)) + 1.1) + Vector3(0, 0.3, 0)
			rock.teleport(from)
			rock.hit_cd = 0.0
			rock.linear_velocity = (aim - rock.global_position).normalized() * 9.0
			await _wait(1.2)
			if _mdead(m) or m.hp < mhp:
				hurt = true
				break
		check(hurt, "L%d: a flung %s hurts the %s (%.0f -> %.0f)" % [lvl, rtype, _mname(m), mhp, _mhp(m)])
	# put it back to sleep far away so the rest of the level is calm
	if not _mdead(m):
		m.dormant = 9999.0
		m.global_position = _park_spot()
	for vp in w.players.keys():
		if w.players[vp].dead:
			if vp != fighter:
				note("  robot %d was broken as a bystander of the fight: repaired for the rest of the test" % vp)
			for hi in w.items.values():
				if hi.type == "head" and hi.extra == vp:
					w.remove_item(hi.item_id, 0)
			w._revive(vp)
	# heal the fighter for the rest of the test
	Net.hp[fighter] = maxf(float(Net.hp.get(fighter, 0.0)), 60.0)
	w.rpc("rpc_player_hp", fighter, float(Net.hp[fighter]), false, Vector3.ZERO)


## Items bought in the shop: upgrades, meds and crystals get used; gear gets tried on a monster.
func _use_owned(lvl: int) -> void:
	var w = W()
	var cl := clients()
	var owned := []
	for it in w.items.values():
		if it.uid > 0:
			owned.append(it)
	note("  owned in van: %s" % str(owned.map(func(x): return x.type)))
	var user: int = cl[lvl % 3]
	await ask(user, "moveto", [w.gen.spawn_points[1]])
	for it0 in owned:
		var oid: int = it0.item_id
		if not w.items.has(oid):
			continue
		var it = w.items[oid]
		var t: String = it.type
		if t.begins_with("up_") or t.begins_with("med_") or t == "i_crystal":
			var k := t.substr(3)
			var before := Net.up(user, k) if t.begins_with("up_") else 0
			var e0 := Net.energy
			if t.begins_with("med_"):
				Net.hp[user] = 20.0
				w.rpc("rpc_player_hp", user, 20.0, false, Vector3.ZERO)
				await _wait(0.3)
			var h0 := float(Net.hp.get(user, 0.0))
			var r0 := Net.grab_range(user)
			var st0 := Net.max_stamina(user)
			await ask(user, "use_item", [it.item_id])
			await _wait(0.4)
			if t.begins_with("up_"):
				check(Net.up(user, k) == before + 1, "L%d: upgrade %s applied to %d (%d -> %d)" % [lvl, k, user, before, Net.up(user, k)])
				match k:
					"range":
						check(Net.grab_range(user) > r0, "L%d: beam range %.1f -> %.1f" % [lvl, r0, Net.grab_range(user)])
					"stamina":
						check(Net.max_stamina(user) > st0, "L%d: max stamina %.0f -> %.0f" % [lvl, st0, Net.max_stamina(user)])
				var s := await ask(user, "snap")
				check(int(s.get("snap", {}).get("up", {}).get(k, -1)) == Net.up(user, k), "L%d: client %d sees its %s upgrade" % [lvl, user, k])
			elif t == "i_crystal":
				check(Net.energy > e0, "L%d: crystal adds energy (%.1f -> %.1f)" % [lvl, e0, Net.energy])
			elif t.begins_with("med_"):
				check(float(Net.hp.get(user, 0.0)) > h0, "L%d: %s heals robot %d (%.0f -> %.0f)" % [lvl, t, user, h0, float(Net.hp.get(user, 0.0))])
			if w.items.has(oid):
				var lft = w.items[oid]
				note("    %s still here: owned=%s at %s, user at %s (d=%.2f, range %.2f)" % [t, lft.owned, lft.global_position, w.players[user].global_position, lft.global_position.distance_to(w.players[user].global_position), Net.grab_range(user) + 2.0])
			check(not w.items.has(oid), "L%d: used %s is gone" % [lvl, t])
	await _gear_tests(lvl)


func _mdead(m) -> bool:
	return m == null or not is_instance_valid(m) or m.state == MonsterScript.DEAD


func _mhp(m) -> float:
	return 0.0 if m == null or not is_instance_valid(m) else float(m.hp)


func _mname(m) -> String:
	return "?" if m == null or not is_instance_valid(m) else str(m.mtype)


## Bring a monster into the house (it idles "outside" at level start) and put it at p.
func _wake(m, p: Vector3) -> void:
	if m.lurking:
		m._appear()
	m.dormant = 0.0
	m.global_position = p
	m.path = []


## Every melee weapon against a brute, repeated (quick scenario HB_ONLY=melee).
func _melee_quick() -> void:
	var w = W()
	var gunner: int = clients()[0]
	var base: Vector3 = w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.1, 0)
	for rep in 3:
		for t in ["w_bat", "w_pan", "w_sledge", "w_prod"]:
			var mid: int = w.spawn_monster("brute", base + Vector3(0, 0.1, -1.5))
			await _wait(0.3)
			var m = w.monsters[mid]
			m.dormant = 9999.0
			m.lurking = false
			var gid := _spawn_near(t, base + Vector3(0.3, 1.2, 1.7))
			await ask(gunner, "moveto", [base + Vector3(0, 0, 2.5), 0.0])
			await _wait(0.3)
			var it = w.items[gid]
			var mhp: float = m.hp
			it.teleport(m.global_position + Vector3(0, 1.0, 1.0))
			var mv := await ask(gunner, "moveto", [m.global_position + Vector3(0, 0, 1.3), 0.0])
			var hpp: Vector3 = w.players[gunner].global_position
			await ask(gunner, "use", [gid, Vector3(0, 0, -1)])
			await _wait(0.4)
			var ok: bool = _mdead(m) or m.hp < mhp
			if not ok:
				note("    %s miss: brute at %s state=%d, gunner host %s client %s, item %s bat=%.2f d=%.2f" % [t, m.global_position, m.state, hpp, str(mv.get("pos")), it.global_position if is_instance_valid(it) else Vector3.ZERO, it.battery if is_instance_valid(it) else -1.0, hpp.distance_to(it.global_position) if is_instance_valid(it) else -1.0])
			check(ok, "melee %d: %s hits the brute (%.0f -> %.0f)" % [rep, t, mhp, _mhp(m)])
			w.remove_item(gid, 0)
			m.queue_free()
			w.monsters.erase(mid)
			await _wait(0.3)


## Monsters woken by a bump (a carried item hitting one wakes it, like in the real game) may break
## robots: repair them, put the monsters back to sleep so the scripted part stays deterministic.
func _repair_all(tag: String) -> void:
	var w = W()
	for vp in w.players.keys():
		if w.players[vp].dead:
			note("  %s: robot %d was broken (monster woke up) - repaired for the rest of the test" % [tag, vp])
			for hi in w.items.values():
				if hi.type == "head" and hi.extra == vp:
					w.remove_item(hi.item_id, 0)
			w._revive(vp)
	for m in w.monsters.values():
		if not _mdead(m) and (m.dormant <= 0.0 or m.state == MonsterScript.CHASE or m.state == MonsterScript.ATTACK):
			m.dormant = 9999.0
			m.state = MonsterScript.WANDER
			m.target_pid = -1
			m.global_position = _park_spot()


var _rj_uid := "test-uid-3"
var _rj_new := -1


## A client loses its connection mid-level and comes back on its own: same upgrades, health and
## slots; it waits for the next level / shop, then plays on.
func _rejoin_test(lvl: int) -> void:
	var w = W()
	var cid := -1
	for pid in Net.players:
		if str(Net.players[pid].get("uid", "")) == _rj_uid:
			cid = pid
	if not check(cid > 0, "L%d: the rejoin test player is here" % lvl):
		return
	Net.upgrades[cid]["speed"] = 3
	Net.upgrades[cid]["strength"] = 2
	Net.hp[cid] = 77.0
	Net.inv[cid] = [{"u": 999, "t": "w_pan", "b": 0.5}, null, null]
	Net.send_run()
	await _wait(0.5)
	await ask(cid, "drop")
	var gone := await _wait_until(func(): return Net.away.has(_rj_uid), 15.0)
	check(gone and not Net.players.has(cid) and not w.players.has(cid), "L%d: dropped player removed, kept for rejoin (%s)" % [lvl, str(Net.away.keys())])
	var back := await _wait_until(func():
		for pid in Net.pending:
			if str(Net.pending[pid].get("uid", "")) == _rj_uid:
				return true
		return false, 60.0)
	check(back, "L%d: the player reconnected on its own and is waiting to re-enter" % lvl)
	for pid in Net.pending:
		if str(Net.pending[pid].get("uid", "")) == _rj_uid:
			_rj_new = pid
	if _rj_new < 0:
		return
	check(_rj_new != cid, "L%d: it came back as a new connection (%d -> %d)" % [lvl, cid, _rj_new])
	check(int(Net.upgrades[_rj_new].get("speed", 0)) == 3 and int(Net.upgrades[_rj_new].get("strength", 0)) == 2, "L%d: upgrades kept (%s)" % [lvl, str(Net.upgrades[_rj_new])])
	check(absf(float(Net.hp.get(_rj_new, 0.0)) - 77.0) < 0.1, "L%d: health kept (%.0f)" % [lvl, float(Net.hp.get(_rj_new, 0.0))])
	var slot = Net.inv_of(_rj_new)[0]
	check(slot is Dictionary and str(slot.get("t", "")) == "w_pan", "L%d: slot item kept (%s)" % [lvl, str(slot)])
	var sn := await ask(_rj_new, "snap")
	var cs: Dictionary = sn.get("snap", {})
	check(bool(cs.get("rejoin_wait", false)) and str(cs.get("screen", "")) == "rejoin_wait", "L%d: the returning player sees 'you're back, wait for the next level' (%s)" % [lvl, str(cs.get("screen", ""))])
	check(int(cs.get("up", {}).get("speed", 0)) == 3, "L%d: ... and its own upgrades on its screen" % lvl)


## Co-op run save: the host saves after a level; later, from the lobby, "continue" restores the
## money, bought gear and every robot's upgrades by player id.
func _mp_save_test() -> void:
	var by_uid := {}
	for pid in Net.players:
		by_uid[str(Net.players[pid].get("uid", ""))] = pid
	var a: int = by_uid.get("test-uid-1", -1)
	var b: int = by_uid.get("test-uid-2", -1)
	Net.upgrades[a]["speed"] = 4
	Net.upgrades[b]["range"] = 2
	Net.hp[b] = 60.0
	Net.inv[a] = [null, {"u": 777, "t": "w_bat", "b": 0.8}, null]
	Net.delete_mp_save()
	await _finish_level_to_shop(1)
	var d := Net.mp_save_info()
	check(int(d.get("level", 0)) == 2, "co-op run saved after level 1 (level %s)" % str(d.get("level")))
	var sp: Dictionary = d.get("players", {})
	check(sp.has("test-uid-1") and sp.has("test-uid-2") and sp.has("test-uid-3") and sp.has(Settings.player_uid), "every robot is in the save (%s)" % str(sp.keys()))
	var money_saved := int(d.get("money", -1))
	check(money_saved == Net.money and money_saved > 0, "money saved ($%d)" % money_saved)
	# back to the lobby: the run resets
	Net.back_to_lobby()
	var lob := await _wait_until(func(): return main.screen_name == "lobby", 10.0)
	check(lob, "host back in the lobby")
	await _wait(1.0)
	var ls := await ask_all("snap")
	for pid in ls:
		check(str(ls[pid].get("snap", {}).get("screen", "")) == "lobby", "client %d back in the lobby" % pid)
	check(Net.money == 0 and int(Net.upgrades.get(a, {}).get("speed", -1)) == 0, "the run was reset in the lobby")
	# continue the saved run
	Net.continue_mp()
	var shop := await _wait_until(func(): return W() != null and W().shop_mode and W().started, 30.0)
	check(shop and Net.level == 2, "continue -> shop before level %d" % Net.level)
	await _wait(1.0)
	check(Net.money == money_saved, "money restored ($%d)" % Net.money)
	check(int(Net.upgrades[a].get("speed", 0)) == 4, "Alpha's speed upgrade restored")
	var hp_saved := float(sp.get("test-uid-2", {}).get("hp", -1.0))
	check(int(Net.upgrades[b].get("range", 0)) == 2 and absf(float(Net.hp[b]) - hp_saved) < 0.1, "Bravo's range and health restored (%.0f, saved %.0f)" % [float(Net.hp[b]), hp_saved])
	var slot = Net.inv_of(a)[1]
	check(slot is Dictionary and str(slot.get("t", "")) == "w_bat", "Alpha's slot restored (%s)" % str(slot))
	var sa := await ask(a, "snap")
	check(int(sa.get("snap", {}).get("up", {}).get("speed", 0)) == 4, "Alpha sees its own restored upgrade")
	await _cmp_with_clients("after continue")


## Close every point and leave in the van (used by short scenarios).
func _finish_level_to_shop(lvl: int) -> void:
	var w = W()
	for idx in w.extr.size():
		if not w.extr[idx]["done"]:
			await _extract(lvl, idx)
	await _depart(lvl)
	await _wait_until(func(): return W() != null and W().shop_mode and W().started, 40.0)
	await _wait(1.5)


func _rejoin_check_after(lvl: int) -> void:
	var w = W()
	if not check(w != null and w.shop_mode, "L%d: shop loaded after the rejoin" % lvl):
		return
	check(Net.players.has(_rj_new) and Net.pending.is_empty(), "L%d: the returning player is in the crew again" % lvl)
	check(w.players.has(_rj_new), "L%d: ... with its robot in the shop" % lvl)
	var sn := await ask(_rj_new, "snap")
	var cs: Dictionary = sn.get("snap", {})
	check(bool(cs.get("world", false)) and bool(cs.get("shop", false)) and int(cs.get("players", 0)) == Net.players.size(), "L%d: its screen shows the shop with %d robots (%s)" % [lvl, Net.players.size(), str(cs.get("players"))])
	check(not bool(cs.get("rejoin_wait", true)), "L%d: no longer waiting" % lvl)
	await _cmp_with_clients("after rejoin")


## Where a monster is parked after a test: a room that is neither a pad nor the van, nor the test room.
func _park_spot() -> Vector3:
	var w = W()
	var best: Vector2i = w.gen.monster_cells[0]
	var bd := -1.0
	for c in w.gen.order:
		if c in w.gen.extraction_cells or c == w.gen.spawn_cell or c == w.gen.order[1]:
			continue
		var d := 99999.0
		for c2 in w.gen.extraction_cells + [w.gen.spawn_cell, w.gen.order[1]]:
			d = minf(d, Vector2(c - c2).length())
		if d > bd:
			bd = d
			best = c
	return w.gen.cell_center(best) + Vector3(0, 0.2, 0)


var _cleanup := []


## Every drone on its own target (spawned, not bought) — quick scenario HB_ONLY=drones.
func _drone_quick() -> void:
	var w = W()
	var gunner: int = clients()[0]
	var base: Vector3 = w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.1, 0)
	await ask(gunner, "moveto", [base + Vector3(0, 0, 2.5), 0.0])
	for t in ["d_feather", "d_shield", "d_zerog", "d_recharge", "d_feather"]:
		var tgt_id := _spawn_near("w_pistol" if t == "d_recharge" else "trophy", base + Vector3(0.8, 0.4, 1.0))
		var did := _spawn_near(t, base + Vector3(0.6, 0.6, 1.4))
		await _wait(0.5)
		if t == "d_recharge":
			w.items[tgt_id].battery = 0.2
		var eye: Vector3 = w.players[gunner].global_position + Vector3(0, 1.38, 0)
		await ask(gunner, "use", [did, (w.items[tgt_id].global_position - eye).normalized()])
		await _wait(2.0)
		var tg = w.items.get(tgt_id)
		var ok := false
		match t:
			"d_feather": ok = tg != null and tg.mass_scale < 0.5
			"d_shield": ok = tg != null and tg.indestructible
			"d_zerog": ok = tg != null and tg.gravity_scale == 0.0
			"d_recharge": ok = tg != null and tg.battery > 0.3
		check(ok, "drone %s works on its target" % t)
		w.remove_item(tgt_id, 0)
		await _wait(0.5)
		check(w.items.has(did) and not w.items[did].freeze, "drone %s drops off when its target is gone" % t)
		w.remove_item(did, 0)
		await _wait(0.3)


func _spawn_near(t: String, p: Vector3) -> int:
	return W().spawn_item(t, 0, p, Quaternion.IDENTITY, 0)


## Every weapon and gadget, used by a client over the network.
func _gear_tests(lvl: int) -> void:
	var w = W()
	var cl := clients()
	var gunner: int = cl[(lvl + 2) % 3]
	var base: Vector3 = w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.1, 0)
	var gear := []
	for it in w.items.values():
		if ItemDefs.is_gear(it.type) and it.uid > 0 and w.items.has(it.item_id):
			gear.append(it.item_id)
	for gid0 in gear:
		var gid: int = gid0
		if not w.items.has(gid) or not is_instance_valid(w.items[gid]):
			continue
		var it = w.items[gid]
		var t: String = it.type
		var cat: String = ItemDefs.DEFS[t].get("cat", "")
		# fresh target monster in front of the gunner
		var m = null
		for mm in w.monsters.values():
			if m == null and mm.state != MonsterScript.DEAD and not mm.mtype in ["eye", "mimic", "hidden"] and float(mm.cfg["height"]) >= 1.0:
				m = mm
		if m == null:
			for mm in w.monsters.values():
				if m == null and mm.state != MonsterScript.DEAD and not mm.mtype in ["eye", "mimic"]:
					m = mm
		await ask(gunner, "moveto", [base + Vector3(0, 0, 2.5), 0.0])
		it.teleport(base + Vector3(0.3, 1.2, 1.7))
		it.linear_velocity = Vector3.ZERO
		if m:
			_wake(m, base + Vector3(0, 0.1, -1.5))
			m.dormant = 9999.0
			m.stun_t = 0.0
		await _wait(0.4)
		var mhp: float = m.hp if m else 0.0
		var aim_h: float = float(m.cfg["height"]) * 0.5 if m else 0.8
		var dir: Vector3 = ((m.global_position + Vector3(0, aim_h, 0)) if m else base) - (w.players[gunner].global_position + Vector3(0, 1.38, 0))
		match cat:
			"gun":
				await ask(gunner, "use", [gid, dir.normalized()])
				await _wait(0.4)
				if m:
					if t == "w_tranq":
						check(_mdead(m) or m.stun_t > 0.0, "L%d: tranquilizer stuns the %s (client %d)" % [lvl, _mname(m), gunner])
					else:
						check(_mdead(m) or m.hp < mhp, "L%d: %s hits the %s (%.0f -> %.0f)" % [lvl, t, _mname(m), mhp, _mhp(m)])
				check(not w.items.has(gid) or w.items[gid].battery < 1.0, "L%d: %s used battery" % [lvl, t])
			"melee":
				it.teleport(m.global_position + Vector3(0, 1.0, 1.0) if m else base)
				await ask(gunner, "moveto", [(m.global_position if m else base) + Vector3(0, 0, 1.3), 0.0])
				var gp0: Vector3 = w.players[gunner].global_position
				var bat0: float = it.battery
				await ask(gunner, "use", [gid, Vector3(0, 0, -1)])
				await _wait(0.4)
				if m:
					if not (_mdead(m) or m.hp < mhp):
						note("    %s miss: %s at %s state=%d lurk=%s, gunner %s (dead %s), item %s battery %.2f, cd %.2f now %.2f" % [t, _mname(m), m.global_position, m.state, m.lurking, gp0, w.players[gunner].dead, it.global_position if is_instance_valid(it) else Vector3.ZERO, bat0, float(w.gear.cooldown.get(gid, 0.0)), w.game_time])
					check(_mdead(m) or m.hp < mhp, "L%d: %s swing hits the %s (%.0f -> %.0f)" % [lvl, t, _mname(m), mhp, _mhp(m)])
			"throw":
				await ask(gunner, "use", [gid])
				await _wait(0.3)
				if w.items.has(gid) and m:
					it.teleport(m.global_position + Vector3(0.4, 0.4, 0))
				await ask(gunner, "moveto", [base + Vector3(0, 0, 7.0), 0.0])
				await _wait(3.5)
				check(not w.items.has(gid), "L%d: %s went off" % [lvl, t])
				if m and t != "g_stun":
					check(_mdead(m) or m.hp < mhp, "L%d: %s hurts the %s (%.0f -> %.0f)" % [lvl, t, _mname(m), mhp, _mhp(m)])
				elif m:
					check(_mdead(m) or m.stun_t > 0.0, "L%d: stun grenade stuns the %s" % [lvl, m.mtype])
			"mine":
				await ask(gunner, "use", [gid])
				await ask(gunner, "moveto", [base + Vector3(0, 0, 7.0), 0.0])
				await _wait(2.0)
				if m and w.items.has(gid):
					it.teleport(m.global_position + Vector3(0, 0.3, 0))
					await _wait(1.0)
				check(not w.items.has(gid), "L%d: %s triggered by the %s" % [lvl, t, _mname(m)])
			"drone":
				var tgt_id := -1
				if t == "d_recharge":
					tgt_id = _spawn_near("w_pistol", base + Vector3(0.8, 0.4, 1.0))
					await _wait(0.3)
					w.items[tgt_id].battery = 0.2
				else:
					tgt_id = _spawn_near("trophy", base + Vector3(0.8, 0.4, 1.0))
				await _wait(0.4)
				it.teleport(base + Vector3(0.6, 0.6, 1.4))
				await _wait(0.3)
				await ask(gunner, "use", [gid, (w.items[tgt_id].global_position - (w.players[gunner].global_position + Vector3(0, 1.38, 0))).normalized()])
				await _wait(2.0)
				var tg = w.items.get(tgt_id)
				_cleanup.append(tgt_id)
				var on2 = w.items.get(int(w.gear.drones.get(gid, -1)))
				if on2 != tg:
					note("    %s latched onto %s (target %s at %s), drone battery %.2f, drone at %s" % [t, (str(on2.type) + " " + str(on2.global_position)) if on2 else "nothing", str(tg.type) if tg else "gone", tg.global_position if tg else Vector3.ZERO, it.battery if is_instance_valid(it) else -1.0, it.global_position if is_instance_valid(it) else Vector3.ZERO])
				match t:
					"d_feather":
						check(tg != null and tg.mass_scale < 0.5, "L%d: feather drone makes the target light" % lvl)
					"d_shield":
						check(tg != null and tg.indestructible, "L%d: shield drone makes the target unbreakable" % lvl)
					"d_zerog":
						check(tg != null and tg.gravity_scale == 0.0, "L%d: zero-g drone floats the target" % lvl)
					"d_recharge":
						if tg == null or tg.battery <= 0.3:
							var on = w.items.get(int(w.gear.drones.get(gid, -1)))
							note("    recharge drone latched onto %s" % (str(on.type) + " " + str(on.global_position) if on else "nothing"))
						check(tg != null and tg.battery > 0.3, "L%d: recharge drone charges the pistol (%.2f)" % [lvl, tg.battery if tg else -1.0])
			"tracker":
				await ask(gunner, "hold", [gid, 2.0])
				await ask(gunner, "release", [gid])
				check(w.items.has(gid) and w.items[gid].battery < 1.0, "L%d: %s drains while held" % [lvl, t])
			"duck":
				if m:
					it.teleport(m.global_position + Vector3(1.2, 1.8, 1.2))
					it.linear_velocity = Vector3(-2, -6, -2)
					await _wait(2.0)
					check((w.items.has(gid) and int(w.items[gid].get_meta("duck_hops", 0)) > 0) or _mdead(m) or m.hp < mhp, "L%d: rubber duck bounces at the %s" % [lvl, _mname(m)])
			"cart":
				await ask(gunner, "hold", [gid, 1.5])
				await ask(gunner, "release", [gid])
				check(w.items.has(gid), "L%d: pocket cart grabbed" % lvl)
				# a valuable dropped into the pocket cart counts on its tag
				await _wait(1.0)
				var pc = w.items.get(gid)
				if pc:
					pc.rotation = Vector3.ZERO
					pc.teleport(base + Vector3(0.0, 0.3, 1.6))
					await _wait(1.0)
					var gob: int = w.spawn_item("trophy", 1000, pc.global_position + pc.global_basis.y * 0.35, Quaternion.IDENTITY, 0)
					_cleanup.append(gob)
					await _wait(1.5)
					check(int(pc.cart_total) > 0, "L%d: pocket cart counts what lies in it ($%d)" % [lvl, int(pc.cart_total)])
		if m and not _mdead(m):
			m.dormant = 9999.0
			m.global_position = _park_spot()
		for cid in _cleanup:
			if w.items.has(cid):
				w.remove_item(cid, 0)
		_cleanup.clear()
		await _wait(0.3)
	# inventory: store a gun in a slot and take it back out
	for it in w.items.values():
		if it.type in ["w_pistol", "w_shotgun", "w_bat", "w_pan", "w_tranq", "w_prod", "w_sledge"] and it.uid > 0:
			var b0: float = it.battery
			var itype: String = it.type
			var inv_user: int = cl[0]
			await ask(inv_user, "moveto", [it.global_position + Vector3(0, 0.1, 1.2)])
			await ask(inv_user, "store", [it.item_id, 0])
			await _wait(0.5)
			var inv: Array = Net.inv_of(inv_user)
			check(inv[0] != null and inv[0]["t"] == itype if inv[0] != null else false, "L%d: %s stored in slot 1 of client %d" % [lvl, itype, inv_user])
			var sr := await ask(inv_user, "snap")
			var cinv: Array = sr.get("snap", {}).get("inv", [null, null, null])
			check(cinv.size() == 3 and cinv[0] != null, "L%d: client %d sees the item in its slot" % [lvl, inv_user])
			var tr := await ask(inv_user, "take", [0])
			await _wait(0.5)
			var back := false
			for it2 in w.items.values():
				if it2.type == itype and absf(it2.battery - b0) < 0.02:
					back = true
			check(back, "L%d: taken back out with the same charge" % lvl)
			check(int(tr.get("grabbed", -1)) > 0, "L%d: taken item lands in the beam" % lvl)
			await ask(inv_user, "release", [int(tr.get("grabbed", -1))])
			break


## Drained gear on the van charger gets its battery back (costs energy crystals).
func _charger_test(lvl: int) -> void:
	var w = W()
	var gun = null
	for it in w.items.values():
		if ItemDefs.DEFS[it.type].get("cat", "") in ["gun", "melee", "drone", "tracker"]:
			gun = it
			break
	if gun == null or w.gear.charger_pos == Vector3.ZERO:
		note("  charger test skipped (no gear)")
		return
	gun.battery = 0.2
	if Net.energy < 1.0:
		Net.energy = 2.0
	var e0 := Net.energy
	gun.teleport(w.gear.charger_pos + Vector3(0, 0.6, 0))
	await _wait(3.0)
	check(gun.battery > 0.4 and Net.energy < e0, "L%d: charger recharges %s (0.20 -> %.2f, energy %.1f -> %.1f)" % [lvl, gun.type, gun.battery, e0, Net.energy])


## Beam on monsters and robots: lift a light monster, throw a teammate.
func _beam_physics(lvl: int) -> void:
	var w = W()
	var cl := clients()
	var base: Vector3 = w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.1, 0)
	var light = null
	var force := OS.get_environment("HB_BEAMMON")
	if force != "":
		light = w.monsters[w.spawn_monster(force, base + Vector3(0, 0.1, -1.5))]
	for mm in w.monsters.values():
		if light == null and mm.state != MonsterScript.DEAD and float(mm.cfg["weight"]) > 0.0 and float(mm.cfg["weight"]) <= 10.0:
			light = mm
	if light == null:
		var mid: int = w.spawn_monster("gremlin", base + Vector3(0, 0.1, -1.5))
		light = w.monsters[mid]
	_wake(light, base + Vector3(0, 0.1, -1.5))
	light.stun_t = 6.0
	await ask(cl[0], "moveto", [base + Vector3(0, 0, 1.2), 0.0])
	await ask(cl[0], "look", [light.global_position + Vector3(0, 0.4, 0)])
	var y0: float = light.global_position.y
	reports.erase("%d:grab_mon" % cl[0])
	rpc_id(cl[0], "cmd", "grab_mon", [light.mid, 2.0])
	var peak := y0
	var held := false
	for i in 12:
		await _wait(0.2)
		if _mdead(light):
			break
		peak = maxf(peak, light.global_position.y)
		held = held or light.state == MonsterScript.HELD
	await _wait_until(func(): return reports.has("%d:grab_mon" % cl[0]), 10.0)
	if peak <= y0 + 0.3:
		note("    lift failed: %s state=%d stun=%.1f dormant=%.0f lurk=%s pos=%s, grabs=%s, lifter %s dead=%s" % [_mname(light), light.state, light.stun_t, light.dormant, light.lurking, light.global_position, str(w.grabs), w.players[cl[0]].global_position, w.players[cl[0]].dead])
	check(peak > y0 + 0.3, "L%d: beam lifts a %s (held=%s, %.2f -> %.2f)" % [lvl, _mname(light), held, y0, peak])
	if not _mdead(light):
		light.dormant = 9999.0
		light.global_position = _park_spot()
	# throw a teammate across the room
	await ask(cl[1], "moveto", [base + Vector3(0, 0, -0.6), 0.0])
	await ask(cl[2], "moveto", [base + Vector3(0, 0, 1.4), 0.0])
	var p0: Vector3 = w.players[cl[1]].global_position
	var s0 := await ask(cl[1], "snap")
	var tr := await ask(cl[2], "throw_player", [cl[1]])
	note("  throw: victim rose to y=%.2f while held" % float(tr.get("top", -1)))
	await _wait(1.0)
	var s1 := await ask(cl[1], "snap")
	note("  throw: victim host-view %s -> %s, own view %s -> %s, dead=%s grabs=%s" % [p0, w.players[cl[1]].global_position, s0.get("snap", {}).get("pos"), s1.get("snap", {}).get("pos"), w.players[cl[1]].dead, str(w.grabs)])
	var moved: float = w.players[cl[1]].global_position.distance_to(p0)
	check(moved > 1.0, "L%d: beam throws a teammate (%.1f m)" % [lvl, moved])


func _play_shop(lvl: int) -> void:
	var w = W()
	var cl := clients()
	await _wait(1.5)
	note("===== SHOP after level %d: money $%d, stock %d" % [lvl, Net.money, w.items.values().filter(func(i): return i.is_shop()).size()])
	await _cmp_with_clients("shop %d" % lvl)
	for pid in Net.players:
		check(float(Net.hp.get(pid, 0.0)) > 0.0, "shop %d: robot %d has HP %.0f" % [lvl, pid, float(Net.hp.get(pid, 0.0))])
	var wish: Array = [["w_pistol", "g_explosive", "med_s", "up_hp", "d_feather", "t_valuable"],
		["w_shotgun", "m_explosive", "d_shield", "i_crystal", "up_speed", "w_bat"],
		["d_recharge", "d_zerog", "w_duck", "w_tranq", "up_wings", "i_pocketcart"],
		["w_prod", "g_stun", "g_shock", "m_stun", "t_extract", "up_strength"],
		["w_sledge", "w_pan", "med_l", "up_range", "g_explosive", "up_jump"],
		["up_stamina", "up_crouch", "up_tumble", "med_m", "g_shock", "w_duck"]][(lvl - 1) % 6]
	# make sure the wanted goods are on the shelves (spawn missing ones — test harness)
	var picked := []
	for t in wish:
		var found = null
		for it in w.items.values():
			if it.type == t and it.is_shop() and not it.owned and not (it in picked):
				found = it
				break
		if found == null:
			var id: int = w.spawn_item(t, w.shop_price(t), w.gen.checkout_pos + Vector3(3.0, 0.5, 0), Quaternion.IDENTITY, 0)
			await _wait(0.2)
			found = w.items.get(id)
		if found:
			picked.append(found)
	# test top-up so every shop can buy its list (coverage of all goods over the run)
	Net.money += 60000
	Net.send_run()
	await _wait(0.5)
	# carry the first one with a client, teleport the rest onto the pad (limited by money)
	var budget: int = w.spendable()
	var total := 0
	var n := 0
	for it in picked:
		if total + it.value > budget:
			continue
		total += it.value
		if n == 0:
			await ask(cl[0], "moveto", [it.global_position + Vector3(0, 0.1, 1.5)])
			var sr := await ask(cl[0], "carry", [it.item_id, w.gen.checkout_pos, it.global_position, 30.0], 45.0)
			if is_instance_valid(it) and not w._in_zone(it.global_position, w.gen.checkout_pos, 1.25):
				note("  shop carry ended at %s (%d waypoints left, next %s)" % [it.global_position, int(sr.get("left", 0)), str(sr.get("wp", ""))])
				it.teleport(w.gen.checkout_pos + Vector3(0, 0.5, 0))
				it.linear_velocity = Vector3.ZERO
		else:
			it.teleport(w.gen.checkout_pos + Vector3((n % 3 - 1) * 0.5, 0.5, (n / 3 - 0.5) * 0.5))
			it.linear_velocity = Vector3.ZERO
		n += 1
	await _wait(1.5)
	# anything else that slid onto the pad and breaks the budget goes back to the shelf
	for it in w.items.values():
		if w.basket <= budget:
			break
		if it.is_shop() and not it.owned and not (it in picked) and w._in_zone(it.global_position, w.gen.checkout_pos, 1.25):
			it.teleport(w.gen.checkout_pos + Vector3(3.0, 0.5, 1.0))
			await _wait(0.4)
	check(w.basket > 0 and w.basket <= budget, "shop %d: basket shows $%d for %d goods (cash $%d)" % [lvl, w.basket, n, budget])
	var owned0 := Net.owned.size()
	var money0 := Net.money
	await ask(cl[2], "interact", ["buy", 0])
	var ok := await _wait_until(func(): return Net.money < money0, 6.0)
	check(ok, "shop %d: checkout by client %d took $%d ($%d -> $%d)" % [lvl, cl[2], money0 - Net.money, money0, Net.money])
	check(Net.owned.size() > owned0, "shop %d: bought goods are owned (%d -> %d)" % [lvl, owned0, Net.owned.size()])
	await _cmp_with_clients("shop %d after buy" % lvl)
	# everyone into the van, a client presses the button
	for i in cl.size():
		await ask(cl[i], "moveto", [w.gen.spawn_points[(i + 1) % 4]])
	w.local_player.global_position = w.gen.spawn_points[0]
	await _wait(1.0)
	var tp := await ask(cl[0], "press", [w.gen.truck_button + Vector3(0, 0.95, 0)])
	check(str(tp.get("press", "")) == "truck", "shop %d: client presses the van button (%s, hit %s)" % [lvl, str(tp.get("seen", "")), str(tp.get("hit", ""))])
	if str(tp.get("press", "")) != "truck":
		await ask(cl[0], "interact", ["truck", 0])


func _disconnect_test() -> void:
	var w = W()
	if w == null:
		return
	var leaver: int = clients()[0]
	var nm := str(Net.players.get(leaver, {}).get("name", "?"))
	rpc_id(leaver, "cmd", "leave", [])
	var ok := await _wait_until(func(): return not Net.players.has(leaver), 10.0)
	check(ok, "client %s left mid-game, host dropped it" % nm)
	await _wait(1.0)
	check(W() != null and not W().players.has(leaver), "left robot removed from the world")
	var rest := await ask_all("snap")
	for pid in rest:
		check(int(rest[pid].get("snap", {}).get("players", 0)) == Net.players.size(), "client %d sees %d robots after the leave" % [pid, Net.players.size()])


func _final_arena() -> void:
	var w = W()
	if w == null or w.shop_mode:
		return
	note("===== ARENA: whole crew broken")
	for pid in Net.players.keys():
		w.server_damage_player(pid, 99999.0, Vector3.ZERO)
		await _wait(0.2)
	var wid: int = w.get_instance_id()
	var ok := await _wait_until(func(): return W() != null and W().get_instance_id() != wid and W().arena_mode, 20.0)
	check(ok, "all robots broken online -> disposal arena")
	if not ok:
		return
	var a = W()
	await _wait(3.0)
	await _cmp_with_clients("arena")
	# knock everyone but one client out of the arena
	var keep: int = clients()[clients().size() - 1]
	for pid in Net.players.keys():
		if pid != keep:
			a.server_damage_player(pid, 99999.0, Vector3.ZERO)
			await _wait(0.4)
	var won := await _wait_until(func(): return Settings.crown_name == str(Net.players.get(keep, {}).get("name", "?")), 15.0)
	check(won, "arena: last robot standing (%s) is the King of Losers (crown=%s)" % [str(Net.players.get(keep, {}).get("name", "?")), Settings.crown_name])
	await _wait(6.0)


func _finish() -> void:
	var rp = multiplayer.multiplayer_peer
	if rp and rp.get_script() == preload("res://scripts/autoload/relay_peer.gd"):
		var mins := float(Time.get_ticks_msec() - _log_t0) / 60000.0
		note("relay traffic: in %.1f MB, out %.1f MB in %.1f min (%.2f MB/min), dropped %d" % [rp.bytes_in / 1e6, rp.bytes_out / 1e6, mins, (rp.bytes_in + rp.bytes_out) / 1e6 / maxf(mins, 0.01), rp.dropped])
	note("errors: %d" % errors.size())
	for e in errors:
		note("  - " + e)
	print("[MP%d] %s" % [role, "ALL PASSED" if errors.is_empty() else "FAILURES %d" % errors.size()])
	await _wait(1.0)
	get_tree().quit(0 if errors.is_empty() else 1)
