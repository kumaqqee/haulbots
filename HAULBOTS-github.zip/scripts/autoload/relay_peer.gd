extends MultiplayerPeerExtension
## Internet play through the HAULBOTS relay server (server/relay.js): one WebSocket per player,
## the host creates a room with a short code, friends join with it. To the game this looks like
## the ENet star (host = peer 1, everyone else talks to the host; the multiplayer layer relays
## player-to-player messages through the host), so all the game code works unchanged.
##
## Frame: [int32 LE peer][u8 channel][u8 mode][payload], see server/relay.js.

signal hosted(code: String)
signal rooms_listed(rooms: Array)

const OUT_BUF := 4 * 1024 * 1024
const DROP_UNRELIABLE_AT := 192 * 1024    # slow link: skip position updates rather than lag behind

var ws := WebSocketPeer.new()
var url := ""
var role := ""            # "host" / "client" / "list"
var code := ""
var fail_reason := ""
var player_name := ""
var game_id := ""
var public_room := false
var tls_unsafe := false   # tests only: accept a self-signed certificate

var _status := MultiplayerPeer.CONNECTION_DISCONNECTED
var _id := 0
var _target := 0
var _mode := MultiplayerPeer.TRANSFER_MODE_RELIABLE
var _channel := 0
var _refuse := false
var _queue: Array = []          # [peer, channel, mode, PackedByteArray]
var _peers := {}
var _sent_hello := false
var bytes_in := 0
var bytes_out := 0
var dropped := 0


## Normalise what a player pastes: https://x.onrender.com -> wss://x.onrender.com
static func normalize_url(u: String) -> String:
	u = u.strip_edges()
	if u == "":
		return ""
	if u.begins_with("https://"):
		u = "wss://" + u.substr(8)
	elif u.begins_with("http://"):
		u = "ws://" + u.substr(7)
	elif not (u.begins_with("wss://") or u.begins_with("ws://")):
		u = "wss://" + u
	return u.trim_suffix("/")


func _setup(u: String) -> Error:
	url = normalize_url(u)
	ws = WebSocketPeer.new()
	ws.outbound_buffer_size = OUT_BUF
	ws.inbound_buffer_size = OUT_BUF
	ws.max_queued_packets = 8192
	_queue.clear()
	_peers.clear()
	_sent_hello = false
	fail_reason = ""
	var err := ws.connect_to_url(url, TLSOptions.client_unsafe() if tls_unsafe else null)
	if err != OK:
		fail_reason = "relay_unreachable"
		_status = MultiplayerPeer.CONNECTION_DISCONNECTED
		return err
	_status = MultiplayerPeer.CONNECTION_CONNECTING
	return OK


func host(u: String, pname: String, gid: String, pub: bool) -> Error:
	role = "host"
	_id = 1
	player_name = pname
	game_id = gid
	public_room = pub
	return _setup(u)


var rejoin := false


func join(u: String, room: String, pname: String, gid: String, rj := false) -> Error:
	role = "client"
	rejoin = rj
	_id = 0
	code = room.strip_edges().to_upper()
	player_name = pname
	game_id = gid
	return _setup(u)


## A plain connection that only asks for the list of open rooms.
func list_rooms(u: String, gid: String) -> Error:
	role = "list"
	game_id = gid
	return _setup(u)


func send_control(d: Dictionary) -> void:
	if ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
		ws.send_text(JSON.stringify(d))


# ------------------------------------------------------------------ MultiplayerPeer

func _poll() -> void:
	if _status == MultiplayerPeer.CONNECTION_DISCONNECTED:
		return
	ws.poll()
	var st := ws.get_ready_state()
	if st == WebSocketPeer.STATE_OPEN:
		if not _sent_hello:
			_sent_hello = true
			match role:
				"host":
					send_control({"op": "host", "v": game_id, "n": player_name, "pub": public_room})
				"client":
					send_control({"op": "join", "code": code, "v": game_id, "n": player_name, "rj": rejoin})
				"list":
					send_control({"op": "list", "v": game_id})
		while ws.get_available_packet_count() > 0:
			var pkt := ws.get_packet()
			if ws.was_string_packet():
				_on_control(pkt.get_string_from_utf8())
			elif pkt.size() >= 6:
				bytes_in += pkt.size()
				var from := pkt.decode_s32(0)
				_queue.append([from, pkt[4], pkt[5], pkt.slice(6)])
	elif st == WebSocketPeer.STATE_CLOSED:
		if fail_reason == "":
			var r := ws.get_close_reason()
			fail_reason = r if r != "" else ("relay_lost" if _status == MultiplayerPeer.CONNECTION_CONNECTED else "relay_unreachable")
		_drop_all()


func _on_control(txt: String) -> void:
	var d = JSON.parse_string(txt)
	if not (d is Dictionary):
		return
	match str(d.get("op", "")):
		"hosted":
			code = str(d.get("code", ""))
			_status = MultiplayerPeer.CONNECTION_CONNECTED
			hosted.emit(code)
		"joined":
			_id = int(d.get("id", 0))
			_status = MultiplayerPeer.CONNECTION_CONNECTED
			_peers[1] = true
			peer_connected.emit(1)
		"peer":
			var pid := int(d.get("id", 0))
			if pid > 1 and not _peers.has(pid):
				if _refuse:
					send_control({"op": "kick", "id": pid})
					return
				_peers[pid] = true
				peer_connected.emit(pid)
		"left":
			var lid := int(d.get("id", 0))
			if _peers.has(lid):
				_peers.erase(lid)
				peer_disconnected.emit(lid)
		"rooms":
			var rl = d.get("rooms", [])
			rooms_listed.emit(rl if rl is Array else [])
			ws.close()
		"error":
			fail_reason = str(d.get("e", "relay_error"))


func _drop_all() -> void:
	var was := _status
	_status = MultiplayerPeer.CONNECTION_DISCONNECTED
	if was == MultiplayerPeer.CONNECTION_CONNECTED and role == "host":
		for pid in _peers.keys():
			peer_disconnected.emit(pid)
	_peers.clear()


func _get_available_packet_count() -> int:
	return _queue.size()


func _get_packet_script() -> PackedByteArray:
	if _queue.is_empty():
		return PackedByteArray()
	return _queue.pop_front()[3]


func _get_packet_peer() -> int:
	return int(_queue[0][0]) if not _queue.is_empty() else 0


func _get_packet_channel() -> int:
	return int(_queue[0][1]) if not _queue.is_empty() else 0


func _get_packet_mode() -> MultiplayerPeer.TransferMode:
	return int(_queue[0][2]) as MultiplayerPeer.TransferMode if not _queue.is_empty() else MultiplayerPeer.TRANSFER_MODE_RELIABLE


func _put_packet_script(buf: PackedByteArray) -> Error:
	if _status != MultiplayerPeer.CONNECTION_CONNECTED or ws.get_ready_state() != WebSocketPeer.STATE_OPEN:
		return ERR_UNCONFIGURED
	if _mode != MultiplayerPeer.TRANSFER_MODE_RELIABLE and ws.get_current_outbound_buffered_amount() > DROP_UNRELIABLE_AT:
		dropped += 1
		return OK    # the link is behind: a newer position update will follow anyway
	var frame := PackedByteArray()
	frame.resize(6)
	frame.encode_s32(0, _target if role == "host" else 1)
	frame[4] = _channel & 0xff
	frame[5] = int(_mode)
	frame.append_array(buf)
	bytes_out += frame.size()
	return ws.send(frame, WebSocketPeer.WRITE_MODE_BINARY)


func _get_max_packet_size() -> int:
	return 1 << 20


func _set_target_peer(p: int) -> void:
	_target = p


func _set_transfer_mode(m: MultiplayerPeer.TransferMode) -> void:
	_mode = m


func _get_transfer_mode() -> MultiplayerPeer.TransferMode:
	return _mode


func _set_transfer_channel(c: int) -> void:
	_channel = c


func _get_transfer_channel() -> int:
	return _channel


func _is_server() -> bool:
	return role == "host"


func _get_unique_id() -> int:
	return _id


func _get_connection_status() -> MultiplayerPeer.ConnectionStatus:
	return _status


func _close() -> void:
	if ws.get_ready_state() == WebSocketPeer.STATE_OPEN or ws.get_ready_state() == WebSocketPeer.STATE_CONNECTING:
		ws.close(1000, "bye")
	_queue.clear()
	_peers.clear()
	_status = MultiplayerPeer.CONNECTION_DISCONNECTED


func _disconnect_peer(p: int, _force: bool) -> void:
	if role == "host" and _peers.has(p):
		send_control({"op": "kick", "id": p})
		_peers.erase(p)
		peer_disconnected.emit(p)


func _set_refuse_new_connections(on: bool) -> void:
	_refuse = on


func _is_refusing_new_connections() -> bool:
	return _refuse


func _is_server_relay_supported() -> bool:
	return true
