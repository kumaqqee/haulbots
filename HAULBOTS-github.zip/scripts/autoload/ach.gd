extends Node
## Achievements: progress counters kept in the settings file, unlocks, the cosmetic each one gives,
## and a toast that pops up wherever the player is (menu, level, shop).
## Team events arrive from the host (World.rpc_ach); personal ones are counted locally.

signal unlocked(id: String)

const UI = preload("res://scripts/ui/ui.gd")
const Icons = preload("res://scripts/ui/icons.gd")

## id, counter, goal, reward [slot, item]
const LIST := [
	["first_haul", "extract", 1, ["hat", "cap"]],
	["hunter", "kill", 1, ["acc", "shades"]],
	["online", "online", 1, ["hat", "beanie"]],
	["medic", "revive", 1, ["acc", "heart"]],
	["pitcher", "throw_kill", 1, ["acc", "antenna"]],
	["flawless", "flawless", 1, ["acc", "scarf"]],
	["lvl5", "level", 5, ["hat", "tophat"]],
	["shopper", "buy", 10, ["hat", "chef"]],
	["big_haul", "big_haul", 1, ["acc", "monocle"]],
	["squad", "squad", 1, ["fin", "neon"]],
	["hauler", "extract", 25, ["acc", "bowtie"]],
	["rich", "earn", 100000, ["fin", "chrome"]],
	["pilot", "glide", 30, ["hat", "propeller"]],
	["king", "arena_win", 1, ["hat", "party"]],
	["exterminator", "kill", 25, ["hat", "viking"]],
	["scrap", "die", 10, ["fin", "rust"]],
	["lvl10", "level", 10, ["hat", "halo"]],
	["tycoon", "earn", 1000000, ["fin", "gold"]],
]
const MAX_KINDS := ["level", "online", "squad"]    # "best so far" instead of a running total
const BIG_HAUL := 20000

var hurt_this_level := false
var _acc := {}          # fractional counters (glide seconds)
var _dirty := false
var _save_t := 0.0
var _layer: CanvasLayer
var _queue := []
var _showing := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS


func _process(delta: float) -> void:
	if _dirty:
		_save_t -= delta
		if _save_t <= 0.0:
			flush()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		flush()


func flush() -> void:
	if _dirty:
		_dirty = false
		Settings.save_cfg()


func progress(kind: String) -> int:
	return int(Settings.ach_progress.get(kind, 0))


func is_unlocked(id: String) -> bool:
	return Settings.achievements.has(id)


func count_unlocked() -> int:
	var n := 0
	for a in LIST:
		if Settings.achievements.has(a[0]):
			n += 1
	return n


## Is this cosmetic unlocked? ("" = nothing, always available)
func owned(slot: String, item: String) -> bool:
	if item == "":
		return true
	if item in preload("res://scripts/game/cosmetics.gd").SUPPORTER_ITEMS:
		return Store.supporter()
	for a in LIST:
		if a[3][0] == slot and a[3][1] == item:
			return Settings.achievements.has(a[0])
	return false


## The achievement that gives this cosmetic.
func source_of(slot: String, item: String) -> Array:
	for a in LIST:
		if a[3][0] == slot and a[3][1] == item:
			return a
	return []


## Adds to a counter (or raises a "best" value) and unlocks whatever it completes.
func event(kind: String, n := 1) -> void:
	if n <= 0:
		return
	var old := progress(kind)
	var v := maxi(old, n) if kind in MAX_KINDS else old + n
	if v == old:
		return
	Settings.ach_progress[kind] = v
	_dirty = true
	_save_t = 5.0
	if kind == "clear" and not hurt_this_level:
		event("flawless", 1)
	for a in LIST:
		if a[1] == kind and v >= int(a[2]) and not Settings.achievements.has(a[0]):
			_unlock(a)


## Time-based counters (seconds of gliding).
func add_time(kind: String, dt: float) -> void:
	var t: float = float(_acc.get(kind, 0.0)) + dt
	if t >= 1.0:
		event(kind, int(t))
		t -= floorf(t)
	_acc[kind] = t


func level_started(level: int, shop: bool, arena: bool) -> void:
	hurt_this_level = false
	if not shop and not arena and level > 0:
		event("level", level)
	if Net.online and not Net.solo:
		if Net.relay:
			event("online", 1)
		if Net.players.size() >= 4:
			event("squad", 1)


func _unlock(a: Array) -> void:
	Settings.achievements[a[0]] = int(Time.get_unix_time_from_system())
	_dirty = false
	Settings.save_cfg()
	if OS.is_debug_build():
		print("[ACH] unlocked ", a[0])
	unlocked.emit(a[0])
	_queue.append(a)
	if not _showing:
		_show_next()


# ------------------------------------------------------------------ toast

func _show_next() -> void:
	if _queue.is_empty():
		_showing = false
		return
	_showing = true
	var a: Array = _queue.pop_front()
	if _layer == null:
		_layer = CanvasLayer.new()
		_layer.layer = 95
		add_child(_layer)
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", UI.sb(Color(0.05, 0.045, 0.035, 0.94), Color(1.0, 0.8, 0.35, 0.9), 2, 16, Vector4(16, 10, 22, 10)))
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	pc.add_child(hb)
	var ic := Control.new()
	ic.custom_minimum_size = Vector2(56, 56)
	ic.draw.connect(func():
		ic.draw_circle(Vector2(28, 28), 27, Color(1.0, 0.75, 0.25, 0.22))
		Icons.draw(ic, "trophy", Vector2(28, 28), 40.0, Color(1.0, 0.82, 0.35)))
	hb.add_child(ic)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	hb.add_child(vb)
	var l1 := UI.label(Settings.t("ach_unlocked").to_upper(), 15, Color(1.0, 0.78, 0.35), HORIZONTAL_ALIGNMENT_LEFT)
	l1.autowrap_mode = TextServer.AUTOWRAP_OFF
	vb.add_child(l1)
	var l2 := UI.label(Settings.t("ach_" + a[0]), 25, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	l2.autowrap_mode = TextServer.AUTOWRAP_OFF
	vb.add_child(l2)
	var l3 := UI.label(Settings.t("ach_reward") % Settings.t("cos_" + a[3][1]), 16, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT)
	l3.autowrap_mode = TextServer.AUTOWRAP_OFF
	vb.add_child(l3)
	_layer.add_child(pc)
	pc.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	pc.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pc.reset_size()
	pc.position = Vector2((pc.get_viewport_rect().size.x - pc.size.x) / 2.0, -pc.size.y - 10)
	Sfx.play("extract", null, -6.0, 1.4)
	var tw := pc.create_tween()
	tw.tween_property(pc, "position:y", 86.0, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(3.2 if _queue.size() < 2 else 1.6)
	tw.tween_property(pc, "modulate:a", 0.0, 0.4)
	tw.tween_callback(func():
		pc.queue_free()
		_show_next())
