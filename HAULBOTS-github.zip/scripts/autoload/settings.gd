extends Node
## Global settings, input map and translations.

const PATH := "user://settings.cfg"
const VERSION := "3.0.0"

var sensitivity := 1.0
var volume := 0.8
var lang := "en"
var player_name := ""
var quality := 2
var invert_y := false
var fov := 75.0
var last_ip := "192.168.1."
## internet play: address of the relay server (server/relay.js, e.g. on Render)
const DEFAULT_RELAY := "https://haulbots-relay.onrender.com"
## region servers (like the reference game): [id, address, first letter of its room codes]
const RELAY_REGIONS := [
	["asia", "https://haulbots-relay.onrender.com", "A"],
	["eu", "https://haulbots-relay-eu.onrender.com", "E"],
	["us", "https://haulbots-relay-us.onrender.com", "U"],
]
var relay_url := DEFAULT_RELAY
var relay_region := ""        # asia / eu / us, or "custom" (own server address)
var last_room := ""
var room_public := false
## stable id of this player (install): the host recognises you when you come back after a drop
## and restores your robot from a saved co-op run
var player_uid := ""
var last_session := {}
## cosmetics: unlocked achievements, equipped hat / accessory / finish, progress counters
var achievements := {}
var ach_progress := {}
var cos_hat := ""
var cos_acc := ""
var cos_finish := ""
var force_touch := false
var difficulty := 1
var voice := false
var best_level := 0
var best_earned := 0
var tutorial_done := false
var vibration := true
var btn_scale := 1.0
var btn_alpha := 0.75
var show_detect := true
var show_fps := false
var music_vol := 0.7
var film_fx := true
var fps_cap := 60
var crown_name := ""
var brightness := 1.0
var adaptive_res := true
var auto_q_done := false
var robot_color := -1     # -1 = automatic (first free colour)
var chat_voice := true    # speak chat messages with the system text-to-speech voice
var cam_bob := true       # head bob, landing dip, sprint FOV
var fog_level := 1        # 0 off, 1 light (default), 2 dense
var beam_haze := false    # fake volumetric cone in the flashlight beam (read as a milky veil)
var battery_saver := false  # 30 FPS, low graphics preset, smaller 3D resolution
var pad_active := false     # a gamepad is in use: hide the on-screen buttons
var btn_layout := {}        # on-screen buttons moved / resized by the player: {name: [x, y, scale]}
var iap_owned := {}         # one-time purchases (re-checked with Google Play at start)
var tips_total := 0         # "support the developer" purchases
var voice_mode := 2         # 0 off, 1 push-to-talk, 2 open mic (voice activated)
var mic_open := false       # open mic unmuted (remembered)
var mic_sens := 0.5         # voice activation sensitivity
var voice_vol := 1.0        # other robots' voices
var voice_filter := true    # robot radio sound

signal changed

const STR := {
	"ru": {
		"basket": "КОРЗИНА",
		"cash": "КАССА",
		"shop_welcome": "Мастерская: несите товары на платформу и жмите кнопку — покупки будут ждать в фургоне на следующем уровне. Потом — все в фургон.",
		"msg_basket_empty": "В зоне покупки пусто",
		"msg_no_money": "Не хватает денег в кассе",
		"msg_bought": "Куплено на $%s!",
		"msg_used": "%s применил: %s",
		"obj_shop": "Мастерская · Касса $%s",
		"press_buy": "ИСП. — оплатить товары в зоне",
		"press_use_item": "ИСП. — применить",
		"owned_tag": "КУПЛЕНО",
		"item_med_s": "Аптечка малая",
		"item_med_m": "Аптечка",
		"item_med_l": "Аптечка большая",
		"btn_crouch": "ПРИСЕД",
		"btn_map": "КАРТА",
		"btn_mic": "МИК",
		"btn_ping": "МЕТКА",
		"item_chest": "Сундук",
		"item_trophy": "Кубок",
		"item_camera": "Фотоаппарат",
		"item_gem": "Самоцвет",
		"item_goldbar": "Слиток",
		"item_cube": "Кубик-головоломка",
		"item_duck_gold": "Золотая уточка",
		"item_figurine": "Статуэтка",
		"item_cash": "Пачка денег",
		"item_laptop": "Ноутбук",
		"item_teddy": "Плюшевый мишка",
		"item_toolbox": "Ящик с инструментами",
		"item_flasks": "Штатив с колбами",
		"item_tv": "Телевизор",
		"item_microwave": "Микроволновка",
		"item_computer": "Компьютер",
		"item_safe": "Сейф",
		"item_aquarium": "Аквариум",
		"item_crown": "Корона",
		"item_microscope": "Микроскоп",
		"item_powercell": "Энергоячейка",
		"item_server": "Сервер",
		"tut_move": "Левый джойстик — ходьба, свайп справа — обзор.",
		"tut_grab": "Наведите прицел на ценность и нажмите ЛУЧ.",
		"tut_carry": "Несите её к зелёной точке сдачи — путь показывает стрелка вверху. ▲▼ меняют дистанцию.",
		"tut_button": "Соберите квоту в зоне и нажмите ИСП. у тумбы с кнопкой.",
		"tut_hide": "Слышите шаги? ПРИСЕД делает вас тише — а под столом или кроватью монстр вас почти не увидит. МЕТКА отмечает место для друзей.",
		"difficulty": "Сложность",
		"diff_0": "Лёгкая",
		"diff_1": "Нормальная",
		"diff_2": "Хардкор",
		"record": "Рекорд: уровень %d · $%s",
		"loc_0": "Склад",
		"loc_1": "Офисы",
		"loc_2": "Лаборатория",
		"msg_location": "Локация: %s",
		"vibration": "Вибрация",
		"new_record": "НОВЫЙ РЕКОРД!",
		"mic_hint": "MIC — голосовой чат с напарниками рядом",
		"tagline": "Тащи. Не разбей. Выживи.",
		"name": "Имя",
		"continue": "Продолжить (уровень %d)",
		"new_game": "Новая игра (соло)",
		"host": "Создать игру по Wi‑Fi",
		"join": "Подключиться по Wi‑Fi",
		"settings": "Настройки",
		"how_to_play": "Как играть",
		"quit": "Выход",
		"back": "Назад",
		"close": "Закрыть",
		"searching": "Поиск игр в вашей сети Wi‑Fi...",
		"no_games": "Игры пока не найдены. Убедитесь, что вы в одной сети Wi‑Fi, или введите IP хоста вручную.",
		"ip_hint": "IP хоста, например 192.168.1.5",
		"connect": "Подключиться",
		"connecting": "Подключение...",
		"cancel": "Отмена",
		"conn_failed": "Не удалось подключиться",
		"host_left": "Хост завершил игру",
		"kicked_full": "Лобби заполнено",
		"kicked_in_game": "Игра уже идёт — дождитесь конца забега",
		"kicked_version": "У хоста другая версия игры",
		"host_failed": "Не удалось создать сервер (порт занят?)",
		"lobby": "Лобби",
		"your_ip": "Друзья подключаются к IP: %s",
		"players_n": "Игроки (%d/4)",
		"start": "Начать забег",
		"waiting_host": "Ожидание хоста...",
		"leave": "Выйти",
		"shop": "Мастерская",
		"level_done": "Уровень %d пройден! Сдано: $%s (квота $%s)",
		"team_money": "Касса команды: $%s",
		"next_level": "Следующий уровень ▶",
		"buy": "Купить",
		"maxed": "МАКС",
		"lvl_short": "ур. %d",
		"up_hp": "Бронекорпус",
		"up_hp_d": "+20 к максимальному здоровью",
		"up_stamina": "Батарея",
		"up_stamina_d": "+10 к выносливости",
		"up_strength": "Сервоприводы",
		"up_strength_d": "Луч держит более тяжёлые вещи",
		"up_range": "Фокусировщик",
		"up_range_d": "+1 м к дальности луча",
		"up_speed": "Моторы",
		"up_speed_d": "+8% к скорости движения",
		"heal": "Ремкомплект",
		"heal_d": "Восстановить 50% здоровья",
		"hp_now": "Здоровье: %d / %d",
		"next_quota": "Следующий уровень: %d",
		"game_over": "ИГРА ОКОНЧЕНА",
		"go_levels": "Пройдено уровней: %d",
		"go_earned": "Всего заработано: $%s",
		"to_menu": "В меню",
		"to_lobby": "В лобби",
		"sensitivity": "Чувствительность",
		"volume": "Громкость",
		"quality": "Графика",
		"q_low": "Низкая",
		"q_med": "Средняя",
		"q_high": "Высокая",
		"fov": "Поле зрения",
		"invert_y": "Инверсия по вертикали",
		"language": "Язык",
		"pause": "Пауза",
		"resume": "Продолжить",
		"leave_game": "Выйти в меню",
		"hud_level": "Уровень %d",
		"hud_cash": "Касса $%s",
		"level_haul": "Сдано за уровень: $%s",
		"obj_extract": "Точка %d/%d: $%s / $%s",
		"obj_ready": "Квота точки набрана — нажмите кнопку!",
		"obj_truck": "Все точки сданы — все в фургон!",
		"obj_extracting": "Отправка ценностей...",
		"obj_wait": "Подготовка...",
		"press_extract": "ИСП. — отправить ценности",
		"press_truck": "ИСП. — уехать с уровня",
		"btn_grab": "ЛУЧ",
		"btn_drop": "ОТПУСТ.",
		"btn_jump": "ПРЫЖОК",
		"btn_use": "ИСП.",
		"btn_throw": "БРОСОК",
		"btn_run": "БЕГ",
		"msg_level": "Уровень %d. Найдите ценности и донесите их до точки сдачи!",
		"msg_tip1": "Берите вещи лучом. Удары снижают их стоимость!",
		"msg_need_more": "Не хватает ценностей до квоты этой точки",
		"msg_extract_fail": "Отправка сорвана — ценности убрали из зоны",
		"msg_next_point": "Точка закрыта! Активирована следующая",
		"msg_all_done": "Квота выполнена! Возвращайтесь в фургон",
		"msg_quota_first": "Сначала закройте все точки сдачи",
		"msg_everyone_truck": "Все живые роботы должны быть в фургоне",
		"msg_player_down": "%s уничтожен! Отнесите его голову в фургон",
		"msg_revived": "%s отремонтирован!",
		"msg_monsters_awake": "В доме что-то проснулось...",
		"msg_player_left": "%s отключился — может вернуться",
		"dead_title": "ВЫ УНИЧТОЖЕНЫ",
		"dead_hint": "Голову можно отнести на активную точку или в фургон — вы вернётесь. Ставьте МЕТКИ и говорите: вас слышат из головы.",
		"extr_done": "СДАНО",
		"extr_idle": "НЕАКТИВНА",
		"extr_press": "НАЖМИ КНОПКУ",
		"extr_sending": "ОТПРАВКА %d",
		"truck_label": "ФУРГОН",
		"truck_ready": "ВСЕ СЮДА → КНОПКА",
		"truck_wait": "СНАЧАЛА КВОТА",
		"item_moneybag": "Мешок с излишком",
		"loading": "ЗАГРУЗКА",
		"tip_0": "Совет: хватайте тележку за ручку — так она едет перед вами.",
		"tip_1": "Совет: на платформе сдачи и в тележке вещи не бьются.",
		"tip_2": "Совет: присядьте под стол или кровать — монстры заметят вас только вплотную.",
		"tip_3": "Совет: держите товарища лучом, чтобы передать ему здоровье.",
		"tip_4": "Совет: перебор на точке сдачи вернётся мешком для следующей точки.",
		"tip_5": "Совет: фонарик помогает видеть, но и выдаёт вас.",
		"tip_6": "Совет: купленное в магазине ждёт в фургоне на следующем уровне.",
		"tip_7": "Совет: кнопка с глазами меняет эмоции вашего робота.",
		"tip_8": "Совет: тяжёлую вещь поднимают вдвоём — лучи складываются.",
		"tip_9": "Совет: после последней точки у вас 10 секунд, чтобы забраться в фургон.",
		"arena_title": "Арена утилизации",
		"msg_arena_out": "%s выбывает!",
		"arena_sub": "Выживет только один",
		"arena_obj": "Арена: осталось роботов — %d",
		"arena_win": "Король неудачников",
		"arena_draw": "Никто не выжил",
		"msg_arena_next": "Все сломаны... Налоговик отправляет вас на арену!",
		"expr_angry": "Злость",
		"expr_sad": "Грусть",
		"expr_sus": "Подозрение",
		"expr_closed": "Глаза закрыты",
		"expr_crazy": "Безумие",
		"expr_happy": "Радость",
		"expr_hint": "Эмоции робота видят напарники. Можно включать несколько сразу.",
		"broken_tag": "РАЗБИТО  −$%s",
		"sum_title": "Уровень %d пройден",
		"sum_haul": "Сдано",
		"sum_quota": "Квота",
		"sum_broken": "Разбито вещей",
		"sum_kills": "Монстров убито",
		"sum_deaths": "Поломок роботов",
		"sum_cash": "В кассе",
		"sum_tap": "нажмите, чтобы закрыть",
		"moon_1": "Растущая луна",
		"moon_2": "Полулуние",
		"moon_3": "Полнолуние",
		"moon_4": "Суперлуние",
		"msg_truck_leaving": "Фургон уезжает через 10 секунд! Кто не внутри — взорвётся!",
		"truck_leave": "УЕЗЖАЕМ\n%d",
		"msg_bought_truck": "Куплено на $%s — покупки будут ждать в фургоне на следующем уровне",
		"msg_surplus_last": "Излишек $%s вернулся мешком — отнесите его в фургон, он зачтётся при отъезде!",
		"msg_surplus": "Излишек $%s вернулся мешком — отнесите его к следующей точке!",
		"item_vase": "Ваза",
		"item_painting": "Картина",
		"item_radio": "Радиоприёмник",
		"item_statue": "Статуя",
		"item_orb": "Ядро монстра",
		"item_head": "Голова робота",
		"item_cart": "Тележка",
		"tab_game": "Игра",
		"tab_controls": "Управление",
		"tab_video": "Графика",
		"tab_audio": "Звук",
		"btn_scale": "Размер кнопок",
		"btn_alpha": "Прозрачность кнопок",
		"show_detect": "Индикатор обнаружения",
		"show_fps": "Показывать FPS",
		"film_fx": "Эффект камеры (зерно, виньетка)",
		"fps_cap": "Частота кадров",
		"brightness": "Яркость",
		"cart_strong": "Хват за ручку: тележка едет перед вами",
		"cart_weak": "Слабый хват — возьмитесь за ручку",
		"cart_hint": "Возьмите лучом за ручку, чтобы катить",
		"adaptive_res": "Адаптивное разрешение",
		"adaptive_hint": "Если кадров не хватает, игра чуть снижает внутреннее разрешение вместо рывков, а когда запас есть — возвращает полное.",
		"hd_pack": "HD-пакет текстур",
		"hd_on": "HD включён (%s)",
		"hd_off": "Не установлен — базовое качество",
		"hd_install": "Установить из «Загрузок»",
		"hd_remove": "Удалить HD",
		"hd_restart": "Перезапустить игру",
		"hd_hint": "Скачайте файлы HAULBOTS-HD-3.0-*.pck в папку «Загрузки» (Download) телефона и нажмите «Установить». Игра попросит доступ к файлам — он нужен только чтобы скопировать пакет.",
		"hd_need_perm": "Разрешите доступ ко всем файлам для HAULBOTS и вернитесь в игру…",
		"hd_not_found": "Файлы HAULBOTS-HD-3.0-*.pck не найдены в «Загрузках»",
		"hd_bad": "Файл повреждён или это не пакет HAULBOTS",
		"hd_done": "Установлено частей: %d. Перезапустите игру",
		"hd_removed": "HD удалён. Перезапустите игру",
		"hd_pending": "Нужен перезапуск, чтобы применить",
		"hd_hint_ios": "Скопируйте файлы HAULBOTS-HD-3.0-*.pck через приложение «Файлы» в папку «На iPhone → HAULBOTS» и нажмите «Установить».",
		"hd_install_ios": "Установить из «Файлов»",
		"hd_not_found_ios": "Файлы HAULBOTS-HD-3.0-*.pck не найдены в «Файлы → На iPhone → HAULBOTS»",
		"hd_restart_ios": "Закрыть игру",
		"hd_done_ios": "Установлено частей: %d. Закройте игру и откройте снова",
		"hd_removed_ios": "HD удалён. Закройте игру и откройте снова",
		"hd_pending_ios": "Закройте игру и откройте снова, чтобы применить",
		"music_vol": "Музыка",
		"reset_tutorial": "Пройти обучение заново",
		"tutorial_reset_done": "Обучение будет показано на 1-м уровне",
		"detect_hint": "Глаз над прицелом показывает, что монстр вас замечает",
		"hud_hp": "Здоровье",
		"hud_stamina": "Энергия",
		"hidden_tag": "СПРЯТАН",
		"btn_slot": "Слот",
		"energy": "Энергия",
		"msg_pay_first": "Сначала оплатите товар в зоне покупки",
		"msg_drone_no_target": "Дрону не к чему прикрепиться",
		"msg_crystal": "Кристалл вставлен: +3 заряда станции",
		"msg_cant_store": "Это нельзя положить в слот",
		"msg_no_energy": "Станции нужна энергия — купите кристалл",
		"msg_truck_heal": "Фургон подлатал %s: +%s здоровья",
		"btn_tumble": "КУВЫРОК",
		"item_w_bat": "Бита",
		"item_w_sledge": "Кувалда",
		"item_w_pan": "Сковорода",
		"item_w_prod": "Электрошокер",
		"item_w_pistol": "Пистолет",
		"item_w_shotgun": "Дробовик",
		"item_w_tranq": "Транквилизатор",
		"item_g_explosive": "Граната",
		"item_g_stun": "Оглушающая граната",
		"item_g_shock": "Шоковая граната",
		"item_m_explosive": "Мина",
		"item_m_stun": "Оглушающая мина",
		"item_d_feather": "Дрон-перо",
		"item_d_shield": "Дрон-щит",
		"item_d_recharge": "Дрон-зарядник",
		"item_d_zerog": "Дрон невесомости",
		"item_w_duck": "Резиновая утка",
		"gd_d_feather": "Цепляется к ценности — она становится почти невесомой",
		"gd_d_shield": "Цепляется к ценности — её нельзя разбить",
		"gd_d_recharge": "Наведите на разряженное оружие или гаджет — дрон зарядит его",
		"gd_d_zerog": "Цепляется к ценности — она парит без гравитации",
		"gd_w_duck": "Бросьте в монстра: утка скачет к нему и бьёт, но пищит на весь дом",
		"up_wings": "Крылья",
		"up_wings_d": "В кувырке в воздухе держите ПРЫЖОК — планирование",
		"msg_drone_no_target_gear": "Рядом нет разряженного снаряжения",
		"msg_drone_empty": "Дрон разряжен — зарядите его в фургоне",
		"chat_hint": "Напишите — робот скажет вслух",
		"chat_send": "СКАЗАТЬ",
		"chat_q0": "Сюда!",
		"chat_q1": "Помогите!",
		"chat_q2": "Монстр!",
		"chat_q3": "Бежим!",
		"chat_q4": "Нашёл дорогую вещь",
		"chat_q5": "Несу к точке",
		"chat_q6": "Осторожно, хрупкое!",
		"chat_q7": "Ха-ха-ха",
		"cam_bob": "Покачивание камеры",
		"chat_voice": "Озвучка чата",
		"chat_voice_hint": "Роботы произносят сообщения чата голосом телефона. Монстры тоже слышат.",
		"robot_paint": "Цвет",
		"menu_continue": "Продолжить",
		"menu_new": "Новая игра",
		"menu_host": "Создать игру",
		"menu_join": "Подключиться",
		"menu_continue_sub": "Уровень %d — продолжить забег",
		"menu_new_sub": "Один робот, квоты, монстры",
		"menu_host_sub": "Друзья в той же сети Wi‑Fi подключатся к вам",
		"menu_join_sub": "Найти игру друга в сети",
		"update_title": "Вышла версия %s",
		"update_hint": "Установите поверх старой — сохранения останутся",
		"update_btn": "Скачать",
		"rc_title": "Связь потеряна",
		"rc_trying": "Возвращаемся в игру… попытка %d (ещё %d с)",
		"rc_failed": "Не удалось вернуться в игру",
		"rejoin_title": "Вы снова в команде!",
		"rejoin_sub": "Войдёте в игру, как только начнётся следующий уровень или магазин (сейчас уровень %d). Улучшения, здоровье и слоты сохранены.",
		"menu_rejoin": "Вернуться в игру",
		"menu_rejoin_sub_room": "Комната %s — забег ещё идёт",
		"menu_rejoin_sub_lan": "Игра по Wi‑Fi — забег ещё идёт",
		"msg_player_back": "%s вернулся — войдёт со следующим уровнем",
		"host_left_lan": "Хост не отвечает",
		"lobby_continue": "Продолжить забег (ур. %d)",
		"lobby_continue_hint": "Сохранённый забег: деньги, покупки и улучшения каждого робота",
		"spec_prev": "Назад",
		"spec_next": "Дальше",
		"spec_view": "Вид",
		"spec_watching": "Наблюдаете: %s · HP %d",
		"spec_nobody": "Живых напарников нет",
		"support": "Поддержать",
		"sup_title": "Поддержать игру",
		"sup_sub": "HAULBOTS делает один человек. Покупки — только внешний вид и удобство, игра полностью бесплатна.",
		"sup_pack": "Набор спонсора",
		"sup_pack_d": "Шляпа ковбоя, шлем астронавта, наушники, покраски «Карбон» и «Лава», золотая звезда у имени — напарники всё это видят. Плюс награды без рекламы.",
		"sup_noads": "Без рекламы",
		"sup_noads_d": "Продолжение забега и бонус в магазине — сразу, без видео.",
		"sup_noads_in_pack": "Уже входит в набор спонсора.",
		"sup_tips": "На кофе разработчику",
		"sup_tips_d": "Просто спасибо — любая сумма, сколько угодно раз. Даёт золотую звезду у имени.",
		"sup_tips_thanks": "Спасибо! Вы поддержали игру %d раз(а) ♥",
		"sup_owned": "Куплено",
		"sup_restore": "Восстановить покупки",
		"sup_privacy": "Конфиденциальность",
		"sup_note": "Оплата через Google Play. Покупки привязаны к аккаунту Google и вернутся после переустановки (кнопка «Восстановить покупки»).",
		"iap_unavailable": "Покупки работают в версии из Google Play.",
		"iap_not_loaded": "Google Play ещё загружает товары — попробуйте через пару секунд.",
		"iap_failed": "Покупка не прошла (%s).",
		"iap_pending": "Оплата ожидает подтверждения — покупка появится, когда она пройдёт.",
		"iap_thanks": "Спасибо за поддержку! Всё уже в «Коллекции».",
		"iap_thanks_tip": "Спасибо огромное! ♥",
		"iap_owned_already": "Уже куплено.",
		"iap_restoring": "Проверяю покупки в Google Play…",
		"iap_restored": "Покупки восстановлены.",
		"ad_not_ready": "Видео ещё загружается — попробуйте через несколько секунд.",
		"go_continue": "Продолжить забег",
		"go_continue_ad": "▶  Продолжить забег (видео)",
		"go_continue_hint": "Вернётесь в магазин перед уровнем %d со всеми деньгами и улучшениями. Один раз за забег.",
		"bonus_free": "бонус спонсора",
		"bonus_ad": "за короткое видео",
		"bonus_loading": "видео загружается…",
		"coll_supporter": "Это из «Набора спонсора» — открываю «Поддержать».",
		"cos_cowboy": "Ковбой",
		"cos_astro": "Астронавт",
		"cos_headphones": "Наушники",
		"cos_carbon": "Карбон",
		"cos_lava": "Лава",
		"voice_chat": "Голосовой чат",
		"vm_0": "Выключен",
		"vm_1": "Рация (удерживать)",
		"vm_2": "Открытый микрофон",
		"voice_hint": "Напарников слышно только рядом, как в жизни. Сломанный робот говорит из своей головы. Монстры тоже слышат болтовню! Рация — держите кнопку микрофона (на ПК V); открытый микрофон включается кнопкой и передаёт, когда вы говорите.",
		"voice_vol": "Громкость голосов",
		"voice_filter": "Голос робота (рация)",
		"mic_sens": "Чувствительность микрофона",
		"mic_test": "Проверить микрофон",
		"mic_on": "Микрофон включён",
		"mic_off": "Микрофон выключен",
		"ptt_short": "держать",
		"collection": "Коллекция",
		"coll_title": "Коллекция",
		"coll_count": "Достижения: %d / %d",
		"coll_wardrobe": "Образ робота",
		"coll_achievements": "Достижения",
		"coll_hint": "Выберите шляпу, аксессуар и покраску — напарники увидят их в игре.",
		"coll_slot_hat": "Шляпа",
		"coll_slot_acc": "Аксессуар",
		"coll_slot_fin": "Покраска",
		"coll_locked": "Закрыто. Откроется за достижение «%s»: %s",
		"cos_none": "Нет",
		"cos_cap": "Кепка",
		"cos_tophat": "Цилиндр",
		"cos_beanie": "Шапка",
		"cos_party": "Колпак",
		"cos_chef": "Колпак шефа",
		"cos_viking": "Шлем викинга",
		"cos_propeller": "Пропеллер",
		"cos_halo": "Нимб",
		"cos_bowtie": "Бабочка",
		"cos_shades": "Тёмные очки",
		"cos_scarf": "Шарф",
		"cos_antenna": "Антенна",
		"cos_monocle": "Монокль",
		"cos_heart": "Сердечко",
		"cos_chrome": "Хром",
		"cos_gold": "Золото",
		"cos_rust": "Ржавчина",
		"cos_neon": "Неон",
		"ach_unlocked": "Достижение получено",
		"ach_reward": "Награда: %s — наденьте в «Коллекции»",
		"ach_done": "Получено",
		"sec_short": "с",
		"ach_first_haul": "Первая сдача",
		"ach_first_haul_d": "Закройте точку сдачи",
		"ach_hunter": "Охотник",
		"ach_hunter_d": "Команда убивает монстра",
		"ach_online": "Сетевой грузчик",
		"ach_online_d": "Сыграйте уровень по интернету",
		"ach_medic": "Медбот",
		"ach_medic_d": "Команда оживляет напарника",
		"ach_pitcher": "Меткий бросок",
		"ach_pitcher_d": "Добейте монстра брошенным предметом",
		"ach_flawless": "Ни царапины",
		"ach_flawless_d": "Уедьте с уровня, не получив урона",
		"ach_lvl5": "Бывалый",
		"ach_lvl5_d": "Дойдите до 5 уровня",
		"ach_shopper": "Шопоголик",
		"ach_shopper_d": "Купите 10 товаров в магазине",
		"ach_big_haul": "Крупный улов",
		"ach_big_haul_d": "Сдайте за раз на $20K и больше",
		"ach_squad": "Полный фургон",
		"ach_squad_d": "Сыграйте вчетвером",
		"ach_hauler": "Грузчик года",
		"ach_hauler_d": "Закройте 25 точек сдачи",
		"ach_rich": "Богач",
		"ach_rich_d": "Заработайте $100K за всё время",
		"ach_pilot": "Пилот",
		"ach_pilot_d": "Пропланируйте на крыльях 30 секунд",
		"ach_king": "Король неудачников",
		"ach_king_d": "Победите на арене утилизации",
		"ach_exterminator": "Истребитель",
		"ach_exterminator_d": "Команда убивает 25 монстров",
		"ach_scrap": "Металлолом",
		"ach_scrap_d": "Сломайтесь 10 раз",
		"ach_lvl10": "Легенда",
		"ach_lvl10_d": "Дойдите до 10 уровня",
		"ach_tycoon": "Магнат",
		"ach_tycoon_d": "Заработайте $1M за всё время",
		"layout_open": "Настроить расположение кнопок",
		"layout_open_hint": "Перетащите кнопки и джойстик куда удобно и поменяйте размер каждой кнопки отдельно.",
		"layout_title": "Расположение кнопок",
		"layout_hint": "Перетаскивайте кнопки и джойстик. Выберите кнопку и меняйте размер −/+",
		"layout_pick": "Сначала коснитесь кнопки, которую хотите изменить",
		"layout_sel": "%s · размер %d%%",
		"layout_sel_joy": "Джойстик — место, где он появляется",
		"layout_btn_pull": "Луч ближе",
		"layout_btn_push": "Луч дальше",
		"layout_reset": "Сбросить",
		"layout_cancel": "Отмена",
		"layout_done": "Готово",
		"layout_preview": "предпросмотр",
		"pad_title": "Геймпад",
		"pad_on": "Подключён: %s",
		"pad_off": "Не подключён",
		"pad_map": "Подключите Bluetooth-геймпад — кнопки на экране скроются сами. Левый стик — ходьба, правый — обзор, RT — луч, LT — бросок, A — прыжок, B — присесть, X — использовать, Y — кувырок, LB — бег, RB — метка, крестовина ▲▼ — дистанция луча, ◀▶ и L3 — слоты, R3 — микрофон, Back — карта, Start — пауза.",
		"battery_saver": "Экономия батареи",
		"battery_hint": "30 кадров/с, облегчённая графика и чуть меньшее разрешение 3D — телефон греется меньше, заряда хватает надольше.",
		"menu_online": "Игра по интернету",
		"menu_online_sub": "С друзьями где угодно — комната с кодом",
		"menu_lan": "Игра по Wi‑Fi",
		"menu_lan_sub": "Друзья рядом, в той же сети Wi‑Fi",
		"lan_create": "Создать игру по Wi‑Fi",
		"online_title": "Игра по интернету",
		"online_create": "Создать комнату",
		"online_create_sub": "Вы — хост: игра идёт на вашем телефоне, друзья входят по коду",
		"online_public": "Открытая комната — видна всем в списке ниже",
		"online_join": "Войти по коду",
		"online_code_hint": "Код, например K7QXM",
		"online_region": "Регион сервера",
		"online_region_sub": "Выберите ближайший. Войти по коду можно в комнату любого региона — первая буква кода говорит, где она.",
		"online_ping": "Пинг",
		"region_asia": "Азия",
		"region_eu": "Европа",
		"region_us": "США",
		"ms": "%d мс",
		"online_rooms": "Открытые комнаты",
		"online_no_rooms": "Открытых комнат нет — создайте свою или войдите по коду",
		"online_rooms_loading": "Загружаем список…",
		"online_server": "Сервер",
		"online_server_none": "не указан",
		"online_server_edit": "Изменить",
		"online_server_hint": "Сервер HAULBOTS уже встроен в игру. Менять адрес нужно, только если у вас свой сервер (у всех игроков он должен совпадать). Очистите поле и сохраните, чтобы вернуть встроенный.",
		"online_server_save": "Сохранить и проверить",
		"online_server_ok": "Сервер на связи ✓",
		"online_waking": "Соединяемся с сервером…",
		"online_waking_long": "Сервер просыпается (бесплатный сервер спит, когда им не пользуются) — до минуты…",
		"online_creating": "Создаём комнату…",
		"online_joining": "Входим в комнату %s…",
		"room_code": "Код комнаты",
		"room_code_hint": "Друзья: «Игра по интернету» → «Войти по коду»",
		"err_relay_no_url": "Сначала укажите адрес сервера (внизу экрана)",
		"err_relay_unreachable": "Сервер не отвечает — проверьте адрес и интернет",
		"err_relay_lost": "Связь с сервером потеряна",
		"err_no_room": "Комнаты с таким кодом нет",
		"err_full": "В комнате уже 4 игрока",
		"err_version": "У хоста другая версия игры — обновитесь до одной версии",
		"err_in_game": "Забег уже идёт — дождитесь конца",
		"err_server_full": "Сервер переполнен, попробуйте позже",
		"err_kicked": "Хост отключил вас",
		"err_idle": "Комната закрыта: слишком долго без игры",
		"relay_lost": "Связь с сервером потеряна",
		"kicked": "Хост отключил вас",
		"idle": "Комната закрыта: слишком долго без игры",
		"menu_new2": "Новое в 3.0",
		"menu_new2_text": "• Новый мир: заброшенный склад, офисы и лаборатория\n• Новый робот с одним глазом, 19 новых монстров, 25 ценностей\n• Подними друга в кувырке лучом • серверы Азия/Европа/США",
		"lobby_sub": "Все в фургон! Когда соберётесь — хост начинает забег.",
		"lobby_ip_hint": "Друзья: «Игра по Wi‑Fi» → эта игра в списке или этот адрес",
		"copied": "Скопировано",
		"you": "ВЫ",
		"start_n": "Начать забег (%d/4)",
		"host_games": "Игры в сети",
		"players_short": "%d/4 игроков",
		"manual_ip": "Или введите IP хоста:",
		"join_btn": "Войти",
		"fog_level": "Туман",
		"fog_0": "Выкл",
		"fog_1": "Лёгкий",
		"fog_2": "Густой",
		"beam_haze": "Дымка в луче фонаря",
		"fog_hint": "Лёгкий туман только затемняет даль. Дымка в луче фонаря — светлая завеса перед камерой.",
		"item_t_valuable": "Искатель ценностей",
		"item_t_extract": "Искатель точки сдачи",
		"item_i_crystal": "Энергокристалл",
		"item_i_pocketcart": "Карманная тележка",
		"mon_gremlin": "Гремлин",
		"mon_bomber": "Бомбочка",
		"mon_eye": "Око",
		"mon_tick": "Клещ",
		"mon_spewer": "Рыгун",
		"mon_rugrat": "Хулиган",
		"mon_skitter": "Зверёк",
		"mon_puff": "Пушок",
		"mon_howler": "Ревун",
		"mon_levitator": "Левитатор",
		"mon_butcher": "Мясник",
		"mon_lurker": "Жнец",
		"mon_hidden": "Невидимка",
		"mon_mimic": "Мимик",
		"mon_bighead": "Башка",
		"mon_projector": "Прожектор",
		"mon_hunter": "Слепой охотник",
		"mon_brute": "Громила",
		"mon_watcher": "Манекен",
		"up_jump": "Пружины",
		"up_jump_d": "+1 дополнительный прыжок в воздухе",
		"up_tumble": "Катапульта",
		"up_tumble_d": "Кувырок-рывок летит дальше и бьёт сильнее",
		"up_crouch": "Режим покоя",
		"up_crouch_d": "Сидя или в кувырке выносливость восстанавливается быстрее",
		"battery": "Заряд",
		"slot_empty": "пусто",
		"to_charge": "Положите в фургон на станцию для зарядки",
		"trk_dist": "%d м",
		"too_heavy": "Слишком тяжело!",
		"help_title": "Как играть",
		"help_text": "[b]Цель[/b]\nВы — робот-грузчик. На каждом уровне найдите в заброшенном комплексе ценности и отнесите их в активную [color=#6f6]точку сдачи[/color]. Когда сумма в зоне достигнет квоты — нажмите кнопку на тумбе. Закройте все точки и вернитесь в [color=#fc3]фургон[/color].\n\n[b]Ценности хрупкие[/b]\nКаждый удар об стену или пол снижает стоимость. Разбитая вещь исчезает. Стекло и электроника — самые хрупкие.\n\n[b]Луч-захват[/b]\nНаведите прицел и нажмите ЛУЧ. Кнопки ▲▼ меняют дистанцию, БРОСОК — швыряет предмет. Тяжёлые вещи требуют улучшений или помощи друзей: лучи складываются!\n\n[b]Монстры[/b]\nВ комплексе живут твари. Они слышат грохот и видят вас. Бегите, прячьтесь — или швырните в них что-нибудь тяжёлое. Из убитого монстра выпадает дорогое ядро.\n\n[b]Хитрые твари[/b]\nНе каждый сундук — сундук. А манекен крадётся за вами — и если посмотреть ему прямо в лицо, он бросится в погоню.\n\n[b]Скрытность[/b]\nПРИСЕД уменьшает дальность, с которой вас замечают монстры. МЕТКА показывает друзьям точку.\n\n[b]Локации[/b]\nСклад, офисы и лаборатория сменяют друг друга, а квоты и число монстров растут. Комнаты бывают огромными цехами со стеллажами, узкими коридорами и тесными подсобками; где-то перегорела лампа — нужен фонарик.\n\n[b]Магазин[/b]\nМежду уровнями вы попадаете в магазин: кладите товары лучом на платформу кассы и жмите кнопку — их «сдадут» как ценности, и они будут ждать в фургоне в начале следующего уровня (деньги округляются вниз до $1K). Улучшения и аптечки применяйте там кнопкой ИСП. Купленное снаряжение возвращается в фургон каждый уровень, даже если сломалось; гранаты, мины, улучшения и аптечки исчезают после использования.\n\n[b]Фургон[/b]\nПосле последней точки нажмите кнопку фургона: он уедет через 10 секунд, кто снаружи — взорвётся. Фургон лечит (+50 на первых уровнях). Голова товарища на платформе сдачи оживляет его с 1 HP, в фургоне после последней точки — с 25 HP. Держите товарища лучом — он получает 10 HP/с из вашего здоровья. Каждые 5 уровней меняется фаза луны: монстры крепче, а их ядра дороже.\n\n[b]Оружие и слоты[/b]\nУ каждого робота 3 слота (кнопки 1/2/3): держа предмет лучом, нажмите номер слота — он спрячется; нажмите снова — достанете. Оружие и дроны тратят заряд батареи — заряжайте их на станции в фургоне (на неё тратятся энергокристаллы). Гранаты взрываются через 3 секунды после активации, мины взводятся за 1,5 с.\n\n[b]Прятки[/b]\nМонстр замечает стоящего робота примерно за секунду, присевшего — за две. Присядьте и заползите под стол, кровать или лабораторный стол: там вас увидят, только если подойдут вплотную. Присед на бегу — подкат. Потеряв вас, монстр обыскивает последнее место и может уйти. Глаз над прицелом показывает, что вас замечают.\n\n[b]Кувырок[/b]\nQ (КУВЫРОК) — сжаться в шар. На бегу кувырок превращается в рывок, который сбивает монстров. Монстров полегче можно поднять лучом и швырнуть. Товарища в кувырке тоже можно схватить лучом и унести (или забросить) в безопасное место.\n\n[b]Здоровье[/b]\nПосле каждой сданной точки фургон чинит всех на 25. Аптечки продаются в магазине.\n\n[b]Кооп[/b]\nДо 4 игроков: по Wi‑Fi рядом или по интернету из любой точки — «Игра по интернету», хост создаёт комнату и сообщает друзьям код из 5 символов. Если робот уничтожен, напарники могут отнести его голову в фургон, чтобы починить его.\n\n[b]Тележка и точки сдачи[/b]\nХватайте тележку лучом за ручку — так она едет перед вами (сильный хват); экран на ручке показывает сумму внутри. Когда квота точки набрана, жмите красную кнопку: сверху опустится труба и заберёт всё с платформы — сойдите с неё! Излишек вернётся мешком: несите его к следующей точке, а после последней — в фургон. На платформе и в тележке вещи не бьются.\n\n[b]Тела[/b]\nВещи и других роботов можно толкать, просто упираясь в них. Брошенные предметы бьют тех, в кого попали.\n\n[b]Эмоции и арена[/b]\nКнопка с глазом (вверху справа, на ПК клавиши 5–0) меняет взгляд робота: злость, грусть, подозрение, закрытый глаз, безумие, радость — можно сочетать. По сети, если сломалась вся команда, все попадают на арену утилизации: хватайте оружие, сталкивайте других в яму, края платформы обрушиваются. Последний выживший — Король неудачников и носит корону.\n\n[b]Чат и голос робота[/b]\nКнопка с облачком (вверху справа, на ПК — T) открывает чат: напишите фразу или выберите готовую — робот произнесёт её вслух, над головой появится облачко. Сломанный робот тоже может говорить из своей головы. Осторожно: монстры слышат болтовню. Цвет робота выбирается в главном меню.\n\n[b]Новое снаряжение[/b]\nДрон-зарядник заряжает оружие и гаджеты, дрон невесомости заставляет ценность парить, резиновая утка скачет к монстрам и бьёт их (но громко пищит). Улучшение «Крылья»: в кувырке в воздухе держите ПРЫЖОК — робот планирует.\n\n[b]HD-пакет[/b]\nПо желанию — более чёткие текстуры и полные модели: положите файлы HAULBOTS-HD-3.0-*.pck в папку «Загрузки» (Download), затем Настройки → Графика → «Установить из «Загрузок»» и перезапустите игру.\n\n[b]Голосовой чат[/b]\nПо сети напарников слышно только рядом, а сломанный робот говорит из своей головы. Режим — в Настройках → Звук: рация (держите кнопку микрофона, на ПК V) или открытый микрофон (кнопка включает, передача идёт, когда вы говорите). Монстры слышат болтовню!\n\n[b]Возврат в игру[/b]\nЕсли связь оборвалась, игра сама переподключится к той же комнате, а в меню появится «Вернуться в игру». Вы войдёте со следующим уровнем или магазином — улучшения и здоровье сохранятся. Хост может продолжить сохранённый сетевой забег из лобби.\n\n[b]Коллекция[/b]\nЗа достижения даются шляпы, аксессуары и покраски — надевайте их в «Коллекции» в главном меню, напарники увидят их в игре.\n\n[b]Геймпад и кнопки[/b]\nBluetooth-геймпад подключается сам, кнопки на экране при этом прячутся. Расположение и размер экранных кнопок меняются в Настройках → Управление. «Экономия батареи» (Настройки → Графика) держит 30 кадров/с.\n\n[b]Управление на ПК[/b]\nWASD — ходьба, Shift — бег, Пробел — прыжок, ЛКМ — луч, ПКМ — бросок, колесо — дистанция, E — использовать, Esc — пауза, C — присесть, Q — кувырок, G — метка, 1/2/3 — слоты инвентаря, M — карта, V — микрофон, T — чат. Геймпад: левый стик — ходьба, правый — обзор, RT — луч, LT — бросок, A — прыжок, B — присесть, X — использовать, Y — кувырок, LB — бег, RB — метка.",
	},
	"en": {
		"basket": "BASKET",
		"cash": "CASH",
		"shop_welcome": "Workshop: carry goods onto the pad and press the button — your purchases will wait in the van next level. Then everyone to the van.",
		"msg_basket_empty": "The checkout zone is empty",
		"msg_no_money": "Not enough team cash",
		"msg_bought": "Bought for $%s!",
		"msg_used": "%s used: %s",
		"obj_shop": "Workshop · Cash $%s",
		"press_buy": "USE — pay for goods in the zone",
		"press_use_item": "USE — apply",
		"owned_tag": "OWNED",
		"item_med_s": "Small medkit",
		"item_med_m": "Medkit",
		"item_med_l": "Large medkit",
		"btn_crouch": "CROUCH",
		"btn_map": "MAP",
		"btn_mic": "MIC",
		"btn_ping": "PING",
		"item_chest": "Chest",
		"item_trophy": "Trophy",
		"item_camera": "Camera",
		"item_gem": "Gem",
		"item_goldbar": "Gold bar",
		"item_cube": "Puzzle cube",
		"item_duck_gold": "Golden duck",
		"item_figurine": "Figurine",
		"item_cash": "Cash stack",
		"item_laptop": "Laptop",
		"item_teddy": "Teddy bear",
		"item_toolbox": "Toolbox",
		"item_flasks": "Flask rack",
		"item_tv": "TV",
		"item_microwave": "Microwave",
		"item_computer": "Computer",
		"item_safe": "Safe",
		"item_aquarium": "Aquarium",
		"item_crown": "Crown",
		"item_microscope": "Microscope",
		"item_powercell": "Power cell",
		"item_server": "Server",
		"tut_move": "Left stick to walk, swipe on the right to look.",
		"tut_grab": "Aim at a valuable and press GRAB.",
		"tut_carry": "Carry it to the green extraction point — follow the arrow at the top. ▲▼ change distance.",
		"tut_button": "Fill the quota in the zone and press USE at the button pedestal.",
		"tut_hide": "Hear footsteps? CROUCH makes you quieter — under a table or bed monsters can barely see you. PING marks a spot for friends.",
		"difficulty": "Difficulty",
		"diff_0": "Easy",
		"diff_1": "Normal",
		"diff_2": "Hardcore",
		"record": "Best: level %d · $%s",
		"loc_0": "Warehouse",
		"loc_1": "Offices",
		"loc_2": "Laboratory",
		"msg_location": "Location: %s",
		"vibration": "Vibration",
		"new_record": "NEW RECORD!",
		"mic_hint": "MIC — voice chat with nearby teammates",
		"tagline": "Haul it. Don't break it. Survive.",
		"name": "Name",
		"continue": "Continue (level %d)",
		"new_game": "New game (solo)",
		"host": "Host Wi‑Fi game",
		"join": "Join Wi‑Fi game",
		"settings": "Settings",
		"how_to_play": "How to play",
		"quit": "Quit",
		"back": "Back",
		"close": "Close",
		"searching": "Searching for games on your Wi‑Fi...",
		"no_games": "No games found yet. Make sure you're on the same Wi‑Fi, or type the host IP.",
		"ip_hint": "Host IP, e.g. 192.168.1.5",
		"connect": "Connect",
		"connecting": "Connecting...",
		"cancel": "Cancel",
		"conn_failed": "Connection failed",
		"host_left": "Host ended the session",
		"kicked_full": "Lobby is full",
		"kicked_in_game": "Game in progress — wait for the run to end",
		"kicked_version": "Host has a different game version",
		"host_failed": "Could not start server (port busy?)",
		"lobby": "Lobby",
		"your_ip": "Friends connect to IP: %s",
		"players_n": "Players (%d/4)",
		"start": "Start run",
		"waiting_host": "Waiting for host...",
		"leave": "Leave",
		"shop": "Workshop",
		"level_done": "Level %d cleared! Hauled: $%s (quota $%s)",
		"team_money": "Team cash: $%s",
		"next_level": "Next level ▶",
		"buy": "Buy",
		"maxed": "MAX",
		"lvl_short": "lv %d",
		"up_hp": "Armor plating",
		"up_hp_d": "+20 max health",
		"up_stamina": "Battery",
		"up_stamina_d": "+10 stamina",
		"up_strength": "Servos",
		"up_strength_d": "Beam can hold heavier things",
		"up_range": "Beam focus",
		"up_range_d": "+1 m beam range",
		"up_speed": "Motors",
		"up_speed_d": "+8% movement speed",
		"heal": "Repair kit",
		"heal_d": "Restore 50% health",
		"hp_now": "Health: %d / %d",
		"next_quota": "Next level: %d",
		"game_over": "GAME OVER",
		"go_levels": "Levels cleared: %d",
		"go_earned": "Total earned: $%s",
		"to_menu": "Main menu",
		"to_lobby": "Back to lobby",
		"sensitivity": "Sensitivity",
		"volume": "Volume",
		"quality": "Graphics",
		"q_low": "Low",
		"q_med": "Medium",
		"q_high": "High",
		"fov": "Field of view",
		"invert_y": "Invert Y",
		"language": "Language",
		"pause": "Paused",
		"resume": "Resume",
		"leave_game": "Quit to menu",
		"hud_level": "Level %d",
		"hud_cash": "Cash $%s",
		"level_haul": "Hauled this level: $%s",
		"obj_extract": "Point %d/%d: $%s / $%s",
		"obj_ready": "Quota reached — press the button!",
		"obj_truck": "All points done — everyone to the van!",
		"obj_extracting": "Extracting valuables...",
		"obj_wait": "Getting ready...",
		"press_extract": "USE — extract valuables",
		"press_truck": "USE — leave the level",
		"btn_grab": "GRAB",
		"btn_drop": "DROP",
		"btn_jump": "JUMP",
		"btn_use": "USE",
		"btn_throw": "THROW",
		"btn_run": "RUN",
		"msg_level": "Level %d. Find valuables and bring them to the extraction point!",
		"msg_tip1": "Grab things with your beam. Hits lower their value!",
		"msg_need_more": "Not enough value for this point's quota",
		"msg_extract_fail": "Extraction aborted — valuables left the zone",
		"msg_next_point": "Point closed! Next one activated",
		"msg_all_done": "Quota complete! Head back to the van",
		"msg_quota_first": "Close all extraction points first",
		"msg_everyone_truck": "All living bots must be inside the van",
		"msg_player_down": "%s was destroyed! Carry their head to the van",
		"msg_revived": "%s has been repaired!",
		"msg_monsters_awake": "Something woke up in the house...",
		"msg_player_left": "%s disconnected — may come back",
		"dead_title": "YOU WERE DESTROYED",
		"dead_hint": "Your head on the active point or in the van brings you back. Drop MARKS and talk: they hear you from your head.",
		"extr_done": "DONE",
		"extr_idle": "INACTIVE",
		"extr_press": "PRESS BUTTON",
		"extr_sending": "SENDING %d",
		"truck_label": "VAN",
		"truck_ready": "ALL IN → BUTTON",
		"truck_wait": "QUOTA FIRST",
		"item_moneybag": "Surplus bag",
		"loading": "LOADING",
		"tip_0": "Tip: grab the cart by its handle and it rolls in front of you.",
		"tip_1": "Tip: items on an extraction pad or in a cart don't break.",
		"tip_2": "Tip: crouch under a table or bed — monsters only spot you point-blank.",
		"tip_3": "Tip: hold a teammate in your beam to give them health.",
		"tip_4": "Tip: overshoot at a point comes back as a bag for the next one.",
		"tip_5": "Tip: your flashlight helps you see, but gives you away.",
		"tip_6": "Tip: what you buy in the shop waits in the van next level.",
		"tip_7": "Tip: the eyes button changes your robot's expression.",
		"tip_8": "Tip: two beams lift heavy things together.",
		"tip_9": "Tip: after the last point you have 10 seconds to get into the van.",
		"arena_title": "Disposal arena",
		"msg_arena_out": "%s is out!",
		"arena_sub": "Only one survives",
		"arena_obj": "Arena: robots left — %d",
		"arena_win": "King of Losers",
		"arena_draw": "Nobody survived",
		"msg_arena_next": "Everyone is broken... the Taxman sends you to the arena!",
		"expr_angry": "Angry",
		"expr_sad": "Sad",
		"expr_sus": "Suspicious",
		"expr_closed": "Eyes closed",
		"expr_crazy": "Crazy",
		"expr_happy": "Happy",
		"expr_hint": "Teammates see your robot's face. Combine several at once.",
		"broken_tag": "BROKEN  −$%s",
		"sum_title": "Level %d complete",
		"sum_haul": "Extracted",
		"sum_quota": "Quota",
		"sum_broken": "Items broken",
		"sum_kills": "Monsters killed",
		"sum_deaths": "Robots broken",
		"sum_cash": "Cash",
		"sum_tap": "tap to close",
		"moon_1": "Waxing moon",
		"moon_2": "Half moon",
		"moon_3": "Full moon",
		"moon_4": "Super moon",
		"msg_truck_leaving": "The van leaves in 10 seconds! Anyone outside will explode!",
		"truck_leave": "LEAVING\n%d",
		"msg_bought_truck": "Bought for $%s — your purchases will wait in the van next level",
		"msg_surplus_last": "Surplus $%s came back as a bag — carry it into the van, it pays out when you leave!",
		"msg_surplus": "Surplus $%s came back as a bag — carry it to the next point!",
		"item_vase": "Vase",
		"item_painting": "Painting",
		"item_radio": "Radio",
		"item_statue": "Statue",
		"item_orb": "Monster core",
		"item_head": "Robot head",
		"item_cart": "Cart",
		"tab_game": "Game",
		"tab_controls": "Controls",
		"tab_video": "Graphics",
		"tab_audio": "Audio",
		"btn_scale": "Button size",
		"btn_alpha": "Button opacity",
		"show_detect": "Detection indicator",
		"show_fps": "Show FPS",
		"film_fx": "Camera effect (grain, vignette)",
		"fps_cap": "Frame rate",
		"brightness": "Brightness",
		"cart_strong": "Handle grip: the cart rolls in front of you",
		"cart_weak": "Weak grip — grab the handle",
		"cart_hint": "Grab the handle with the beam to push",
		"adaptive_res": "Adaptive resolution",
		"adaptive_hint": "When frames drop the game lowers internal resolution slightly instead of stuttering, and returns to full when there is headroom.",
		"hd_pack": "HD texture pack",
		"hd_on": "HD enabled (%s)",
		"hd_off": "Not installed — base quality",
		"hd_install": "Install from Downloads",
		"hd_remove": "Remove HD",
		"hd_restart": "Restart game",
		"hd_hint": "Download the HAULBOTS-HD-3.0-*.pck files into your phone's Download folder and tap Install. The game will ask for file access — it is only used to copy the pack.",
		"hd_need_perm": "Allow all-files access for HAULBOTS, then return to the game…",
		"hd_not_found": "No HAULBOTS-HD-3.0-*.pck files found in Downloads",
		"hd_bad": "File is damaged or not a HAULBOTS pack",
		"hd_done": "Installed parts: %d. Restart the game",
		"hd_removed": "HD removed. Restart the game",
		"hd_pending": "Restart required to apply",
		"hd_hint_ios": "Copy the HAULBOTS-HD-3.0-*.pck files with the Files app into \"On My iPhone > HAULBOTS\" and tap Install.",
		"hd_install_ios": "Install from Files",
		"hd_not_found_ios": "No HAULBOTS-HD-3.0-*.pck files in Files > On My iPhone > HAULBOTS",
		"hd_restart_ios": "Close game",
		"hd_done_ios": "Installed parts: %d. Close the game and open it again",
		"hd_removed_ios": "HD removed. Close the game and open it again",
		"hd_pending_ios": "Close the game and open it again to apply",
		"music_vol": "Music",
		"reset_tutorial": "Replay tutorial",
		"tutorial_reset_done": "The tutorial will show on level 1",
		"detect_hint": "The eye above the crosshair shows a monster noticing you",
		"hud_hp": "Health",
		"hud_stamina": "Energy",
		"hidden_tag": "HIDDEN",
		"btn_slot": "Slot",
		"energy": "Energy",
		"msg_pay_first": "Pay for it in the purchase zone first",
		"msg_drone_no_target": "Nothing for the drone to attach to",
		"msg_crystal": "Crystal inserted: +3 charger charges",
		"msg_cant_store": "This can't go into a slot",
		"msg_no_energy": "The charger needs energy — buy a crystal",
		"msg_truck_heal": "The van patched up %s: +%s health",
		"btn_tumble": "TUMBLE",
		"item_w_bat": "Baseball bat",
		"item_w_sledge": "Sledgehammer",
		"item_w_pan": "Frying pan",
		"item_w_prod": "Shock prod",
		"item_w_pistol": "Pistol",
		"item_w_shotgun": "Shotgun",
		"item_w_tranq": "Tranquilizer gun",
		"item_g_explosive": "Grenade",
		"item_g_stun": "Stun grenade",
		"item_g_shock": "Shock grenade",
		"item_m_explosive": "Mine",
		"item_m_stun": "Stun mine",
		"item_d_feather": "Feather drone",
		"item_d_shield": "Shield drone",
		"item_d_recharge": "Recharge drone",
		"item_d_zerog": "Zero-gravity drone",
		"item_w_duck": "Rubber duck",
		"gd_d_feather": "Latches onto a valuable and makes it almost weightless",
		"gd_d_shield": "Latches onto a valuable so it can't break",
		"gd_d_recharge": "Aim at a drained weapon or gadget and the drone recharges it",
		"gd_d_zerog": "Latches onto a valuable and it floats without gravity",
		"gd_w_duck": "Throw it at a monster: it bounces toward it and hits, but squeaks loudly",
		"up_wings": "Wings",
		"up_wings_d": "Hold JUMP while tumbling in the air to glide",
		"msg_drone_no_target_gear": "No drained gear nearby",
		"msg_drone_empty": "The drone is out of charge — recharge it in the van",
		"chat_hint": "Type — your robot says it aloud",
		"chat_send": "SAY",
		"chat_q0": "Over here!",
		"chat_q1": "Help!",
		"chat_q2": "Monster!",
		"chat_q3": "Run!",
		"chat_q4": "Found something pricey",
		"chat_q5": "Taking it to the point",
		"chat_q6": "Careful, fragile!",
		"chat_q7": "Ha ha ha",
		"cam_bob": "Camera bob",
		"chat_voice": "Chat voice",
		"chat_voice_hint": "Robots speak chat lines with your phone's voice. Monsters hear it too.",
		"robot_paint": "Paint",
		"menu_continue": "Continue",
		"menu_new": "New game",
		"menu_host": "Host a game",
		"menu_join": "Join a game",
		"menu_continue_sub": "Level %d — continue the run",
		"menu_new_sub": "One robot, quotas, monsters",
		"menu_host_sub": "Friends on the same Wi‑Fi join you",
		"menu_join_sub": "Find a friend's game on the network",
		"update_title": "Version %s is out",
		"update_hint": "Install it over this one — your progress stays",
		"update_btn": "Download",
		"rc_title": "Connection lost",
		"rc_trying": "Getting back into the game… try %d (%d s left)",
		"rc_failed": "Couldn't get back into the game",
		"rejoin_title": "You're back in the crew!",
		"rejoin_sub": "You'll enter the game as soon as the next level or the shop starts (now level %d). Upgrades, health and slots are kept.",
		"menu_rejoin": "Back to the game",
		"menu_rejoin_sub_room": "Room %s — the run is still on",
		"menu_rejoin_sub_lan": "Wi‑Fi game — the run is still on",
		"msg_player_back": "%s is back — joins with the next level",
		"host_left_lan": "The host doesn't answer",
		"lobby_continue": "Continue run (lvl %d)",
		"lobby_continue_hint": "Saved run: money, gear and every robot's upgrades",
		"spec_prev": "Prev",
		"spec_next": "Next",
		"spec_view": "View",
		"spec_watching": "Watching: %s · HP %d",
		"spec_nobody": "No teammates alive",
		"support": "Support",
		"sup_title": "Support the game",
		"sup_sub": "HAULBOTS is made by one person. Purchases are only looks and convenience — the game is completely free.",
		"sup_pack": "Supporter pack",
		"sup_pack_d": "Cowboy hat, astronaut helmet, headphones, Carbon and Lava finishes and a gold star by your name — teammates see it all. Plus rewards without ads.",
		"sup_noads": "No ads",
		"sup_noads_d": "Continue a run and take the shop bonus instantly, no videos.",
		"sup_noads_in_pack": "Already part of the supporter pack.",
		"sup_tips": "Buy the developer a coffee",
		"sup_tips_d": "Just a thank-you — any amount, as often as you like. Gives a gold star by your name.",
		"sup_tips_thanks": "Thank you! You supported the game %d time(s) ♥",
		"sup_owned": "Owned",
		"sup_restore": "Restore purchases",
		"sup_privacy": "Privacy",
		"sup_note": "Paid through Google Play. Purchases belong to your Google account and come back after a reinstall (Restore purchases).",
		"iap_unavailable": "Purchases work in the Google Play version.",
		"iap_not_loaded": "Google Play is still loading the items — try again in a moment.",
		"iap_failed": "The purchase didn't go through (%s).",
		"iap_pending": "Payment pending — the item arrives once it clears.",
		"iap_thanks": "Thanks for the support! It's in your Collection.",
		"iap_thanks_tip": "Thank you so much! ♥",
		"iap_owned_already": "Already owned.",
		"iap_restoring": "Checking your purchases with Google Play…",
		"iap_restored": "Purchases restored.",
		"ad_not_ready": "The video is still loading — try again in a few seconds.",
		"go_continue": "Continue the run",
		"go_continue_ad": "▶  Continue the run (video)",
		"go_continue_hint": "Back to the shop before level %d with all your money and upgrades. Once per run.",
		"bonus_free": "supporter bonus",
		"bonus_ad": "for a short video",
		"bonus_loading": "video loading…",
		"coll_supporter": "This is from the Supporter pack — opening Support.",
		"cos_cowboy": "Cowboy",
		"cos_astro": "Astronaut",
		"cos_headphones": "Headphones",
		"cos_carbon": "Carbon",
		"cos_lava": "Lava",
		"voice_chat": "Voice chat",
		"vm_0": "Off",
		"vm_1": "Push to talk",
		"vm_2": "Open mic",
		"voice_hint": "You only hear teammates nearby, like in real life. A broken robot talks from its head. Monsters hear the chatter too! Push to talk: hold the mic button (V on PC); open mic is switched on with the button and sends while you speak.",
		"voice_vol": "Voice volume",
		"voice_filter": "Robot voice (radio)",
		"mic_sens": "Mic sensitivity",
		"mic_test": "Test microphone",
		"mic_on": "Microphone on",
		"mic_off": "Microphone off",
		"ptt_short": "hold",
		"collection": "Collection",
		"coll_title": "Collection",
		"coll_count": "Achievements: %d / %d",
		"coll_wardrobe": "Robot look",
		"coll_achievements": "Achievements",
		"coll_hint": "Pick a hat, an accessory and a finish — teammates see them in the game.",
		"coll_slot_hat": "Hat",
		"coll_slot_acc": "Accessory",
		"coll_slot_fin": "Finish",
		"coll_locked": "Locked. Unlocked by the achievement \"%s\": %s",
		"cos_none": "None",
		"cos_cap": "Cap",
		"cos_tophat": "Top hat",
		"cos_beanie": "Beanie",
		"cos_party": "Party hat",
		"cos_chef": "Chef's hat",
		"cos_viking": "Viking helmet",
		"cos_propeller": "Propeller",
		"cos_halo": "Halo",
		"cos_bowtie": "Bow tie",
		"cos_shades": "Shades",
		"cos_scarf": "Scarf",
		"cos_antenna": "Antenna",
		"cos_monocle": "Monocle",
		"cos_heart": "Heart",
		"cos_chrome": "Chrome",
		"cos_gold": "Gold",
		"cos_rust": "Rust",
		"cos_neon": "Neon",
		"ach_unlocked": "Achievement unlocked",
		"ach_reward": "Reward: %s — wear it in the Collection",
		"ach_done": "Unlocked",
		"sec_short": "s",
		"ach_first_haul": "First haul",
		"ach_first_haul_d": "Close an extraction point",
		"ach_hunter": "Hunter",
		"ach_hunter_d": "Your crew kills a monster",
		"ach_online": "Net hauler",
		"ach_online_d": "Play a level online",
		"ach_medic": "Medibot",
		"ach_medic_d": "Your crew revives a teammate",
		"ach_pitcher": "Sharp throw",
		"ach_pitcher_d": "Finish a monster off with a thrown item",
		"ach_flawless": "Not a scratch",
		"ach_flawless_d": "Leave a level without taking damage",
		"ach_lvl5": "Seasoned",
		"ach_lvl5_d": "Reach level 5",
		"ach_shopper": "Shopaholic",
		"ach_shopper_d": "Buy 10 things in the shop",
		"ach_big_haul": "Big catch",
		"ach_big_haul_d": "Extract $20K or more at once",
		"ach_squad": "Full van",
		"ach_squad_d": "Play with four robots",
		"ach_hauler": "Hauler of the year",
		"ach_hauler_d": "Close 25 extraction points",
		"ach_rich": "Rich",
		"ach_rich_d": "Earn $100K in total",
		"ach_pilot": "Pilot",
		"ach_pilot_d": "Glide on wings for 30 seconds",
		"ach_king": "King of Losers",
		"ach_king_d": "Win the disposal arena",
		"ach_exterminator": "Exterminator",
		"ach_exterminator_d": "Your crew kills 25 monsters",
		"ach_scrap": "Scrap metal",
		"ach_scrap_d": "Get broken 10 times",
		"ach_lvl10": "Legend",
		"ach_lvl10_d": "Reach level 10",
		"ach_tycoon": "Tycoon",
		"ach_tycoon_d": "Earn $1M in total",
		"layout_open": "Customize button layout",
		"layout_open_hint": "Drag the buttons and the joystick wherever you like and resize each button separately.",
		"layout_title": "Button layout",
		"layout_hint": "Drag buttons and the joystick. Pick a button and resize it with −/+",
		"layout_pick": "Tap the button you want to change first",
		"layout_sel": "%s · size %d%%",
		"layout_sel_joy": "Joystick — where it appears",
		"layout_btn_pull": "Beam closer",
		"layout_btn_push": "Beam farther",
		"layout_reset": "Reset",
		"layout_cancel": "Cancel",
		"layout_done": "Done",
		"layout_preview": "preview",
		"pad_title": "Gamepad",
		"pad_on": "Connected: %s",
		"pad_off": "Not connected",
		"pad_map": "Connect a Bluetooth gamepad and the on-screen buttons hide by themselves. Left stick move, right stick look, RT beam, LT throw, A jump, B crouch, X use, Y tumble, LB sprint, RB ping, D-pad ▲▼ beam distance, ◀▶ and L3 slots, R3 microphone, Back map, Start pause.",
		"battery_saver": "Battery saver",
		"battery_hint": "30 FPS, lighter graphics and a slightly lower 3D resolution — the phone runs cooler and the battery lasts longer.",
		"menu_online": "Play online",
		"menu_online_sub": "With friends anywhere — a room with a code",
		"menu_lan": "Play on Wi‑Fi",
		"menu_lan_sub": "Friends nearby on the same Wi‑Fi",
		"lan_create": "Host a Wi‑Fi game",
		"online_title": "Play online",
		"online_create": "Create a room",
		"online_create_sub": "You host: the game runs on your phone, friends join with the code",
		"online_public": "Public room — listed for everyone below",
		"online_join": "Join with a code",
		"online_code_hint": "Code, e.g. K7QXM",
		"online_region": "Server region",
		"online_region_sub": "Pick the closest one. A code joins a room in any region — its first letter tells where the room is.",
		"online_ping": "Ping",
		"region_asia": "Asia",
		"region_eu": "Europe",
		"region_us": "USA",
		"ms": "%d ms",
		"online_rooms": "Public rooms",
		"online_no_rooms": "No public rooms — create one or join with a code",
		"online_rooms_loading": "Loading the list…",
		"online_server": "Server",
		"online_server_none": "not set",
		"online_server_edit": "Change",
		"online_server_hint": "The HAULBOTS server is built in. Change the address only if you run your own server (every player needs the same one). Clear the field and save to go back to the built-in one.",
		"online_server_save": "Save and check",
		"online_server_ok": "Server is online ✓",
		"online_waking": "Connecting to the server…",
		"online_waking_long": "The server is waking up (a free server sleeps when unused) — up to a minute…",
		"online_creating": "Creating the room…",
		"online_joining": "Joining room %s…",
		"room_code": "Room code",
		"room_code_hint": "Friends: \"Play online\" → \"Join with a code\"",
		"err_relay_no_url": "Set the server address first (bottom of the screen)",
		"err_relay_unreachable": "The server doesn't answer — check the address and your internet",
		"err_relay_lost": "Lost connection to the server",
		"err_no_room": "No room with that code",
		"err_full": "The room already has 4 players",
		"err_version": "The host has a different game version — update to the same one",
		"err_in_game": "A run is in progress — wait for it to end",
		"err_server_full": "The server is full, try later",
		"err_kicked": "The host removed you",
		"err_idle": "Room closed: idle for too long",
		"relay_lost": "Lost connection to the server",
		"kicked": "The host removed you",
		"idle": "Room closed: idle for too long",
		"menu_new2": "New in 3.0",
		"menu_new2_text": "• A new world: abandoned warehouse, offices and lab\n• A new one-eyed robot, 19 redrawn monsters, 25 valuables\n• Beam up a tumbling friend • Asia/Europe/USA servers",
		"lobby_sub": "Everyone in the van! The host starts the run.",
		"lobby_ip_hint": "Friends: \"Play on Wi‑Fi\" → pick this game or type this address",
		"copied": "Copied",
		"you": "YOU",
		"start_n": "Start the run (%d/4)",
		"host_games": "Games on the network",
		"players_short": "%d/4 players",
		"manual_ip": "Or type the host IP:",
		"join_btn": "Join",
		"fog_level": "Fog",
		"fog_0": "Off",
		"fog_1": "Light",
		"fog_2": "Dense",
		"beam_haze": "Haze in the flashlight beam",
		"fog_hint": "Light fog only darkens the distance. Beam haze is a pale veil in front of the camera.",
		"item_t_valuable": "Valuable tracker",
		"item_t_extract": "Extraction tracker",
		"item_i_crystal": "Energy crystal",
		"item_i_pocketcart": "Pocket cart",
		"mon_gremlin": "Gremlin",
		"mon_bomber": "Bomblet",
		"mon_eye": "The Eye",
		"mon_tick": "Tick",
		"mon_spewer": "Spewer",
		"mon_rugrat": "Rugrat",
		"mon_skitter": "Critter",
		"mon_puff": "Puff",
		"mon_howler": "Howler",
		"mon_levitator": "Levitator",
		"mon_butcher": "Butcher",
		"mon_lurker": "Reaper",
		"mon_hidden": "The Unseen",
		"mon_mimic": "Mimic",
		"mon_bighead": "Bighead",
		"mon_projector": "Projector",
		"mon_hunter": "Blind hunter",
		"mon_brute": "Brute",
		"mon_watcher": "Mannequin",
		"up_jump": "Springs",
		"up_jump_d": "+1 extra mid-air jump",
		"up_tumble": "Catapult",
		"up_tumble_d": "Tumble launch flies farther and hits harder",
		"up_crouch": "Rest mode",
		"up_crouch_d": "Stamina regenerates faster while crouched or tumbling",
		"battery": "Charge",
		"slot_empty": "empty",
		"to_charge": "Put it on the van charger to recharge",
		"trk_dist": "%d m",
		"too_heavy": "Too heavy!",
		"help_title": "How to play",
		"help_text": "[b]Goal[/b]\nYou are a salvage robot. On each level find valuables in the abandoned complex and bring them to the active [color=#6f6]extraction point[/color]. When the value in the zone reaches the quota, press the button on the pedestal. Close every point, then return to the [color=#fc3]van[/color].\n\n[b]Valuables are fragile[/b]\nEvery hit against a wall or floor lowers the value. Broken items disappear. Glass and electronics are the most fragile.\n\n[b]Grab beam[/b]\nAim and press GRAB. ▲▼ change the distance, THROW flings the item. Heavy things need upgrades or friends: beams add up!\n\n[b]Monsters[/b]\nCreatures live in the complex. They hear noise and see you. Run, hide — or throw something heavy at them. A killed monster drops a valuable core.\n\n[b]Tricky creatures[/b]\nNot every chest is a chest. And the mannequin creeps after you — look it straight in the face and it will hunt you down.\n\n[b]Stealth[/b]\nCROUCH reduces how far monsters can spot you. PING shows friends a spot.\n\n[b]Locations[/b]\nWarehouse, offices and laboratory rotate while quotas and monster counts grow. Rooms range from huge racked halls to narrow hallways and cramped storerooms; here and there a lamp is burnt out — use the flashlight.\n\n[b]Shop[/b]\nBetween levels you visit the shop: carry goods onto the checkout pad and press the button — they are extracted like valuables and wait in the van at the start of the next level (cash is rounded down to $1K). Use upgrades and health packs there with USE. Gear you bought comes back in the van every level, even if it broke; grenades, mines, upgrades and health packs are gone once used.\n\n[b]Van[/b]\nAfter the last point press the van button: it leaves in 10 s and anyone outside explodes. The van heals you (+50 HP early on). A teammate's head on an extraction pad revives them with 1 HP, in the van after the last point with 25 HP. Hold a teammate in the beam to give them 10 HP/s of your health. Every 5 levels the moon phase changes: monsters get tougher and their cores more valuable.\n\n[b]Weapons & slots[/b]\nEvery bot has 3 slots (keys 1/2/3): while holding an item press a slot number to pocket it, press again to take it out. Weapons and drones use battery charge — recharge them at the charger in the van (it consumes energy crystals). Grenades go off 3 s after activation, mines arm in 1.5 s.\n\n[b]Hiding[/b]\nA monster needs about a second to notice a standing bot and two seconds for a crouching one. Crouch and crawl under a table, bed or lab bench: there you are only spotted from point-blank range. Crouch while sprinting to slide. After losing you a monster searches the last spot and may wander off. The eye above the crosshair shows that you are being noticed.\n\n[b]Tumble[/b]\nQ (TUMBLE) curls you into a ball. While sprinting it becomes a launch that knocks monsters over. Lighter monsters can be lifted with the beam and thrown. A tumbling teammate can be grabbed with the beam too and carried (or tossed) to safety.\n\n[b]Health[/b]\nThe van repairs everyone by 25 after every extraction. Medkits are sold in the shop.\n\n[b]Co-op[/b]\nUp to 4 players: on the same Wi‑Fi or over the internet from anywhere — \"Play online\", the host creates a room and gives friends the 5-character code. If a bot is destroyed, teammates can carry its head to the van to repair it.\n\n[b]Cart & extraction[/b]\nGrab the cart by its handle to push it (strong grip); the screen on the handle shows what is inside. Press the red button at a point when its goal is met: the tube drops and takes everything on the pad — step off! Overshoot comes back as a surplus bag: carry it to the next point, or into the van after the last one. Items on a pad or in a cart do not break.\n\n[b]Bodies[/b]\nYou can shove items and other robots by walking into them. Flung objects hurt whoever they hit.\n\n[b]Expressions & arena[/b]\nThe eye button (top right, keys 5-0 on PC) changes your robot's look: angry, sad, suspicious, eye closed, crazy, happy — combine them. Online, if the whole crew is broken, everyone lands in the disposal arena: grab weapons, knock others into the pit, the rim falls away ring by ring. The last robot standing is the King of Losers and wears a crown.\n\n[b]Chat & robot voice[/b]\nThe speech-bubble button (top right, T on PC) opens chat: type a line or pick a quick phrase and your robot says it out loud with a bubble over its head. A broken robot can still talk from its head. Careful: monsters hear the chatter. Pick your robot's paint in the main menu.\n\n[b]New gear[/b]\nThe recharge drone charges weapons and gadgets, the zero-gravity drone makes a valuable float, the rubber duck bounces toward monsters and hits them (but squeaks loudly). Wings upgrade: hold JUMP while tumbling in the air to glide.\n\n[b]HD pack[/b]\nOptional sharper textures and full-detail models: put the HAULBOTS-HD-3.0-*.pck files into the phone's Download folder, then Settings → Graphics → Install from Downloads, and restart.\n\n[b]Voice chat[/b]\nOnline you only hear teammates nearby, and a broken robot talks from its head. Pick the mode in Settings → Audio: push to talk (hold the mic button, V on PC) or open mic (the button switches it on, it sends while you speak). Monsters hear the chatter!\n\n[b]Rejoining[/b]\nIf the connection drops the game reconnects to the same room by itself, and the menu shows \"Back to the game\". You come back with the next level or shop, upgrades and health kept. The host can continue a saved co-op run from the lobby.\n\n[b]Collection[/b]\nAchievements give hats, accessories and finishes — wear them via Collection in the main menu, teammates see them in the game.\n\n[b]Gamepad & buttons[/b]\nA Bluetooth gamepad works right away and hides the on-screen buttons. Move and resize the on-screen buttons in Settings → Controls. Battery saver (Settings → Graphics) holds 30 FPS.\n\n[b]PC controls[/b]\nWASD move, Shift sprint, Space jump, LMB beam, RMB throw, wheel distance, E use, Esc pause, C crouch, Q tumble, G ping, 1/2/3 inventory slots, M map, V microphone, T chat. Gamepad: left stick move, right stick look, RT beam, LT throw, A jump, B crouch, X use, Y tumble, LB sprint, RB ping.",
	},
}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var loc := OS.get_locale_language()
	lang = "ru" if loc in ["ru", "uk", "be", "kk", "uz", "ky"] else "en"
	randomize()
	player_name = "Bot-%d" % (randi() % 900 + 100)
	_setup_input()
	load_cfg()
	if relay_region == "":
		relay_region = guess_region()
		relay_url = region_url(relay_region)
	if player_uid == "":
		player_uid = "%08x%08x" % [randi(), randi()]
		save_cfg()
	if not auto_q_done:
		# first launch (or first run of 1.5.1): pick a quality that suits this phone; never raise a manual choice
		quality = mini(quality, detect_quality())
		auto_q_done = true
		save_cfg()
	apply()


## Rough device class from GPU, memory and renderer: 0 low, 1 medium, 2 high.
func detect_quality() -> int:
	if OS.get_name() == "iOS":
		var ram_i := float(OS.get_memory_info().get("physical", 0)) / 1073741824.0
		return 1 if (ram_i > 0.0 and ram_i < 3.5) else 2
	if OS.get_name() != "Android":
		return 2
	var drv := RenderingServer.get_current_rendering_driver_name()
	var ram := float(OS.get_memory_info().get("physical", 0)) / 1073741824.0
	var gpu := RenderingServer.get_video_adapter_name().to_lower()
	var cores := OS.get_processor_count()
	if drv.begins_with("opengl") or (ram > 0.0 and ram < 3.5) or cores <= 4:
		return 0
	for w in ["mali-t", "mali-g31", "mali-g51", "mali-g52", "mali-g57", "mali-g68", "powervr", "ge8", "adreno (tm) 5", "adreno (tm) 4"]:
		if gpu.contains(w):
			return 0 if ram < 5.0 else 1
	var m := RegEx.create_from_string("adreno \\(tm\\) 6([0-3])\\d").search(gpu)
	if m != null or (ram > 0.0 and ram < 6.0):
		return 1
	return 2


func has_t(key: String) -> bool:
	return STR.get(lang, STR["en"]).has(key) or STR["en"].has(key)


func t(key: String) -> String:
	var d: Dictionary = STR.get(lang, STR["en"])
	if OS.get_name() == "iOS" and d.has(key + "_ios"):
		return d[key + "_ios"]
	if d.has(key):
		return d[key]
	return STR["en"].get(key, key)


## REPO-style short money: 950 -> "950", 4230 -> "4.2K", 12400 -> "12.4K", 1250000 -> "1.25M"
func money_k(v: int) -> String:
	var a := absi(v)
	var sgn := "-" if v < 0 else ""
	if a < 1000:
		return sgn + str(a)
	if a < 1000000:
		var k := a / 1000.0
		return sgn + ("%.1fK" % k if k < 100.0 else "%dK" % int(k))
	return sgn + "%.2fM" % (a / 1000000.0)


func money(v: int) -> String:
	var s := str(absi(v))
	var out := ""
	var n := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		n += 1
		if n % 3 == 0 and i > 0:
			out = "," + out
	return ("-" if v < 0 else "") + out


func is_touch() -> bool:
	return force_touch or DisplayServer.is_touchscreen_available()


func _setup_input() -> void:
	_add_keys("move_forward", [KEY_W, KEY_UP])
	_add_keys("move_back", [KEY_S, KEY_DOWN])
	_add_keys("move_left", [KEY_A, KEY_LEFT])
	_add_keys("move_right", [KEY_D, KEY_RIGHT])
	_add_keys("jump", [KEY_SPACE])
	_add_keys("sprint", [KEY_SHIFT])
	_add_keys("use", [KEY_E, KEY_F])
	_add_keys("pause", [KEY_ESCAPE])
	_add_keys("crouch", [KEY_C, KEY_CTRL])
	_add_keys("ping", [KEY_G])
	_add_keys("tumble", [KEY_Q])
	_add_keys("slot1", [KEY_1])
	_add_keys("slot2", [KEY_2])
	_add_keys("slot3", [KEY_3])
	for i in 6:
		_add_keys("expr%d" % i, [[KEY_5, KEY_6, KEY_7, KEY_8, KEY_9, KEY_0][i]])
	_add_keys("map", [KEY_M, KEY_TAB])
	_add_keys("talk", [KEY_V])
	_add_keys("chat", [KEY_T, KEY_SLASH])
	_add_mouse("grab", MOUSE_BUTTON_LEFT)
	_add_mouse("throw", MOUSE_BUTTON_RIGHT)
	_setup_pad()


func _add_keys(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var e := InputEventKey.new()
		e.physical_keycode = k
		InputMap.action_add_event(action, e)


func _add_mouse(action: String, button: int) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var e := InputEventMouseButton.new()
	e.button_index = button
	InputMap.action_add_event(action, e)


## Graphics preset actually used (battery saver forces the lightest one).
func eff_quality() -> int:
	return 0 if battery_saver else quality


func eff_fps_cap() -> int:
	return mini(fps_cap, 30) if battery_saver else fps_cap


func _add_joy_button(action: String, button: int) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var e := InputEventJoypadButton.new()
	e.button_index = button
	InputMap.action_add_event(action, e)


func _add_joy_axis(action: String, axis: int, dir: float) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action, 0.25)
	var e := InputEventJoypadMotion.new()
	e.axis = axis
	e.axis_value = dir
	InputMap.action_add_event(action, e)


## Bluetooth gamepad (Xbox-style layout).
func _setup_pad() -> void:
	_add_joy_axis("move_left", JOY_AXIS_LEFT_X, -1.0)
	_add_joy_axis("move_right", JOY_AXIS_LEFT_X, 1.0)
	_add_joy_axis("move_forward", JOY_AXIS_LEFT_Y, -1.0)
	_add_joy_axis("move_back", JOY_AXIS_LEFT_Y, 1.0)
	_add_joy_axis("look_left", JOY_AXIS_RIGHT_X, -1.0)
	_add_joy_axis("look_right", JOY_AXIS_RIGHT_X, 1.0)
	_add_joy_axis("look_up", JOY_AXIS_RIGHT_Y, -1.0)
	_add_joy_axis("look_down", JOY_AXIS_RIGHT_Y, 1.0)
	_add_joy_axis("pad_grab", JOY_AXIS_TRIGGER_RIGHT, 1.0)
	_add_joy_axis("pad_throw", JOY_AXIS_TRIGGER_LEFT, 1.0)
	_add_joy_button("jump", JOY_BUTTON_A)
	_add_joy_button("crouch", JOY_BUTTON_B)
	_add_joy_button("use", JOY_BUTTON_X)
	_add_joy_button("tumble", JOY_BUTTON_Y)
	_add_joy_button("sprint", JOY_BUTTON_LEFT_SHOULDER)
	_add_joy_button("ping", JOY_BUTTON_RIGHT_SHOULDER)
	_add_joy_button("beam_pull", JOY_BUTTON_DPAD_UP)
	_add_joy_button("beam_push", JOY_BUTTON_DPAD_DOWN)
	_add_joy_button("slot1", JOY_BUTTON_DPAD_LEFT)
	_add_joy_button("slot2", JOY_BUTTON_DPAD_RIGHT)
	_add_joy_button("slot3", JOY_BUTTON_LEFT_STICK)
	_add_joy_button("talk", JOY_BUTTON_RIGHT_STICK)
	_add_joy_button("map", JOY_BUTTON_BACK)
	_add_joy_button("pause", JOY_BUTTON_START)


func _input(e: InputEvent) -> void:
	# switch the on-screen controls off while a gamepad is played, back on at the next touch
	if e is InputEventJoypadButton and e.pressed or e is InputEventJoypadMotion and absf(e.axis_value) > 0.5:
		if not pad_active:
			pad_active = true
			changed.emit()
	elif e is InputEventScreenTouch and e.pressed and pad_active:
		pad_active = false
		changed.emit()


## What this robot wears (sent to the host with the name and paint).
func cosmetics() -> Dictionary:
	var sup := 0
	var st := get_node_or_null("/root/Store")
	if st and st.badge():
		sup = 1
	return {"hat": cos_hat, "acc": cos_acc, "fin": cos_finish, "sup": sup}


func load_cfg() -> void:
	var cf := ConfigFile.new()
	if cf.load(PATH) != OK:
		return
	sensitivity = cf.get_value("s", "sensitivity", sensitivity)
	volume = cf.get_value("s", "volume", volume)
	lang = cf.get_value("s", "lang", lang)
	player_name = cf.get_value("s", "name", player_name)
	quality = cf.get_value("s", "quality", quality)
	invert_y = cf.get_value("s", "invert_y", invert_y)
	fov = cf.get_value("s", "fov", fov)
	last_ip = cf.get_value("s", "last_ip", last_ip)
	relay_url = cf.get_value("s", "relay_url", relay_url)
	if relay_url == "":
		relay_url = DEFAULT_RELAY
	relay_region = cf.get_value("s", "relay_region", relay_region)
	if relay_region == "":
		relay_region = guess_region() if region_url(_region_of_url(relay_url)) != "" else "custom"
		if relay_region != "custom":
			relay_url = region_url(relay_region)
	last_room = cf.get_value("s", "last_room", last_room)
	room_public = cf.get_value("s", "room_public", room_public)
	player_uid = cf.get_value("s", "player_uid", player_uid)
	last_session = cf.get_value("s", "last_session", last_session)
	achievements = cf.get_value("s", "achievements", achievements)
	ach_progress = cf.get_value("s", "ach_progress", ach_progress)
	battery_saver = cf.get_value("s", "battery_saver", battery_saver)
	btn_layout = cf.get_value("s", "btn_layout", btn_layout)
	cos_hat = cf.get_value("s", "cos_hat", cos_hat)
	cos_acc = cf.get_value("s", "cos_acc", cos_acc)
	cos_finish = cf.get_value("s", "cos_finish", cos_finish)
	voice_mode = cf.get_value("s", "voice_mode", voice_mode)
	iap_owned = cf.get_value("s", "iap_owned", iap_owned)
	tips_total = cf.get_value("s", "tips_total", tips_total)
	mic_open = cf.get_value("s", "mic_open", mic_open)
	mic_sens = cf.get_value("s", "mic_sens", mic_sens)
	voice_vol = cf.get_value("s", "voice_vol", voice_vol)
	voice_filter = cf.get_value("s", "voice_filter", voice_filter)
	difficulty = cf.get_value("s", "difficulty", difficulty)
	voice = cf.get_value("s", "voice", voice)
	best_level = cf.get_value("s", "best_level", best_level)
	best_earned = cf.get_value("s", "best_earned", best_earned)
	tutorial_done = cf.get_value("s", "tutorial_done", tutorial_done)
	vibration = cf.get_value("s", "vibration", vibration)
	btn_scale = cf.get_value("s", "btn_scale", btn_scale)
	btn_alpha = cf.get_value("s", "btn_alpha", btn_alpha)
	show_detect = cf.get_value("s", "show_detect", show_detect)
	show_fps = cf.get_value("s", "show_fps", show_fps)
	music_vol = cf.get_value("s", "music_vol", music_vol)
	film_fx = cf.get_value("s", "film_fx", film_fx)
	fps_cap = cf.get_value("s", "fps_cap", fps_cap)
	crown_name = cf.get_value("s", "crown", crown_name)
	brightness = cf.get_value("s", "brightness", brightness)
	adaptive_res = cf.get_value("s", "adaptive_res", adaptive_res)
	auto_q_done = cf.get_value("s", "auto_q_151", auto_q_done)
	robot_color = cf.get_value("s", "robot_color", robot_color)
	chat_voice = cf.get_value("s", "chat_voice", chat_voice)
	cam_bob = cf.get_value("s", "cam_bob", cam_bob)
	fog_level = cf.get_value("s", "fog_level", fog_level)
	beam_haze = cf.get_value("s", "beam_haze", beam_haze)


func save_cfg() -> void:
	var cf := ConfigFile.new()
	cf.set_value("s", "sensitivity", sensitivity)
	cf.set_value("s", "volume", volume)
	cf.set_value("s", "lang", lang)
	cf.set_value("s", "name", player_name)
	cf.set_value("s", "quality", quality)
	cf.set_value("s", "invert_y", invert_y)
	cf.set_value("s", "fov", fov)
	cf.set_value("s", "last_ip", last_ip)
	cf.set_value("s", "relay_url", relay_url)
	cf.set_value("s", "relay_region", relay_region)
	cf.set_value("s", "last_room", last_room)
	cf.set_value("s", "room_public", room_public)
	cf.set_value("s", "player_uid", player_uid)
	cf.set_value("s", "last_session", last_session)
	cf.set_value("s", "achievements", achievements)
	cf.set_value("s", "ach_progress", ach_progress)
	cf.set_value("s", "battery_saver", battery_saver)
	cf.set_value("s", "btn_layout", btn_layout)
	cf.set_value("s", "cos_hat", cos_hat)
	cf.set_value("s", "cos_acc", cos_acc)
	cf.set_value("s", "cos_finish", cos_finish)
	cf.set_value("s", "voice_mode", voice_mode)
	cf.set_value("s", "iap_owned", iap_owned)
	cf.set_value("s", "tips_total", tips_total)
	cf.set_value("s", "mic_open", mic_open)
	cf.set_value("s", "mic_sens", mic_sens)
	cf.set_value("s", "voice_vol", voice_vol)
	cf.set_value("s", "voice_filter", voice_filter)
	cf.set_value("s", "difficulty", difficulty)
	cf.set_value("s", "voice", voice)
	cf.set_value("s", "best_level", best_level)
	cf.set_value("s", "best_earned", best_earned)
	cf.set_value("s", "tutorial_done", tutorial_done)
	cf.set_value("s", "vibration", vibration)
	cf.set_value("s", "btn_scale", btn_scale)
	cf.set_value("s", "btn_alpha", btn_alpha)
	cf.set_value("s", "show_detect", show_detect)
	cf.set_value("s", "show_fps", show_fps)
	cf.set_value("s", "music_vol", music_vol)
	cf.set_value("s", "film_fx", film_fx)
	cf.set_value("s", "fps_cap", fps_cap)
	cf.set_value("s", "crown", crown_name)
	cf.set_value("s", "brightness", brightness)
	cf.set_value("s", "adaptive_res", adaptive_res)
	cf.set_value("s", "auto_q_151", auto_q_done)
	cf.set_value("s", "robot_color", robot_color)
	cf.set_value("s", "chat_voice", chat_voice)
	cf.set_value("s", "cam_bob", cam_bob)
	cf.set_value("s", "fog_level", fog_level)
	cf.set_value("s", "beam_haze", beam_haze)
	cf.save(PATH)


func apply() -> void:
	# capping the frame rate keeps 90/120 Hz phones cool: no thermal throttling mid-run
	Engine.max_fps = eff_fps_cap()
	AudioServer.set_bus_volume_db(0, linear_to_db(max(volume, 0.0001)))
	var sx := get_node_or_null("/root/Sfx")
	if sx:
		sx.set_music_volume(music_vol)
	changed.emit()


# ------------------------------------------------------------------ relay regions

static func region_url(id: String) -> String:
	for r in RELAY_REGIONS:
		if r[0] == id:
			return r[1]
	return ""


static func _region_of_url(u: String) -> String:
	var n := u.strip_edges().trim_suffix("/")
	for r in RELAY_REGIONS:
		if n == r[1] or n == str(r[1]).replace("https://", "wss://"):
			return r[0]
	return ""


## Region of a room code (its first letter), "" for codes of an older server.
static func region_of_code(code: String) -> String:
	if code.length() != 5:
		return ""
	for r in RELAY_REGIONS:
		if code.begins_with(r[2]):
			return r[0]
	return ""


## First guess from the phone's time zone, so nobody wakes three servers to measure pings.
static func guess_region() -> String:
	var off := int(Time.get_time_zone_from_system().get("bias", 0))    # minutes from UTC
	if off >= 4 * 60:
		return "asia"
	if off <= -2 * 60:
		return "us"
	return "eu"


func set_region(id: String) -> void:
	relay_region = id
	if id != "custom":
		relay_url = region_url(id)
	save_cfg()
