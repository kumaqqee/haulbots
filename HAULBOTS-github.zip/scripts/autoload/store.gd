extends Node
## In-app purchases (Google Play Billing) and rewarded ads (AdMob) behind one small API.
## Without the native plugins (PC, a sideloaded APK, the iPhone build) purchases report
## "unavailable" and rewarded offers stay hidden; the tests run a simulated store (HB_STORE_SIM=1).
## Purchases are remembered locally and re-checked with Google Play at every start.

signal changed                    # prices, ownership or ad readiness changed
signal purchased(pid: String)     # a purchase just went through (not a restore)
signal note(text: String)         # short status for the player (pending, failed, not ready)

const Cfg = preload("res://scripts/monetization_config.gd")
const BILLING_SCRIPT := "res://addons/GodotGooglePlayBilling/BillingClient.gd"
const ADS_SCRIPT := "res://scripts/store/ads_admob.gd"
const OK := 0
const USER_CANCELED := 1
const ITEM_ALREADY_OWNED := 7
const PURCHASED := 1
const PENDING := 2

var billing = null        # BillingClient (Android build with the plugin)
var ads = null            # AdMob backend (build with the AdMob plugin)
var sim := false          # simulated store (tests)
var sim_ads := true       # simulated store: an ad is ready
var billing_ready := false
var products := {}        # pid -> {"title": String, "price": String}
var _consuming := {}      # purchase token -> tip product id
var _retry_t := -1.0
var _retries := 0


func _ready() -> void:
	sim = OS.get_environment("HB_STORE_SIM") != ""
	if sim:
		billing_ready = true
		return
	if OS.get_name() == "Android" and Engine.has_singleton("GodotGooglePlayBilling") and ResourceLoader.exists(BILLING_SCRIPT):
		billing = load(BILLING_SCRIPT).new()
		billing.name = "Billing"
		add_child(billing)
		billing.connected.connect(_on_connected)
		billing.disconnected.connect(_on_disconnected)
		billing.connect_error.connect(_on_connect_error)
		billing.query_product_details_response.connect(_on_product_details)
		billing.query_purchases_response.connect(_on_purchases)
		billing.on_purchase_updated.connect(_on_purchase_updated)
		billing.consume_purchase_response.connect(_on_consumed)
		billing.acknowledge_purchase_response.connect(func(_r): pass)
		billing.start_connection()
	if OS.get_name() in ["Android", "iOS"] and Engine.has_singleton("PoingGodotAdMob") and ResourceLoader.exists(ADS_SCRIPT):
		ads = load(ADS_SCRIPT).new()
		ads.name = "Ads"
		add_child(ads)
		ads.ready_changed.connect(func(): changed.emit())


func _process(delta: float) -> void:
	if _retry_t > 0.0:
		_retry_t -= delta
		if _retry_t <= 0.0 and billing and not billing_ready:
			billing.start_connection()


# ------------------------------------------------------------------ state for the game

func all_products() -> Array:
	return Cfg.NON_CONSUMABLE + Cfg.TIPS


func purchases_available() -> bool:
	return billing_ready


func has(pid: String) -> bool:
	return bool(Settings.iap_owned.get(pid, false))


func supporter() -> bool:
	return has(Cfg.SUPPORTER)


## Rewards without ad videos (the "remove ads" purchase or the supporter pack).
func no_ads() -> bool:
	return has(Cfg.REMOVE_ADS) or has(Cfg.SUPPORTER)


func tips() -> int:
	return int(Settings.tips_total)


## Gold star next to the name for anyone who supported the game.
func badge() -> bool:
	return supporter() or tips() > 0


func price(pid: String) -> String:
	var p: Dictionary = products.get(pid, {})
	return str(p.get("price", Cfg.FALLBACK_PRICE.get(pid, "")))


## Can a rewarded offer be shown in this build at all?
func rewards_supported() -> bool:
	return no_ads() or sim or ads != null


func reward_ready() -> bool:
	if no_ads():
		return true
	if sim:
		return sim_ads
	return ads != null and ads.is_ready()


# ------------------------------------------------------------------ buying

func buy(pid: String) -> void:
	if not pid in all_products():
		return
	if pid in Cfg.NON_CONSUMABLE and has(pid):
		note.emit(Settings.t("iap_owned_already"))
		return
	if sim:
		_grant(pid, true)
		return
	if not billing_ready:
		note.emit(Settings.t("iap_unavailable"))
		return
	if not products.has(pid):
		note.emit(Settings.t("iap_not_loaded"))
		billing.query_product_details(PackedStringArray(all_products()), 0)
		return
	var r = billing.purchase(pid)
	if r is Dictionary and int(r.get("response_code", OK)) != OK:
		note.emit(Settings.t("iap_failed") % str(r.get("debug_message", r.get("response_code"))))


func restore() -> void:
	if sim:
		note.emit(Settings.t("iap_restored"))
		return
	if billing_ready:
		billing.query_purchases(0)
		note.emit(Settings.t("iap_restoring"))
	else:
		note.emit(Settings.t("iap_unavailable"))


func _grant(pid: String, fresh: bool) -> void:
	if pid in Cfg.TIPS:
		Settings.tips_total = int(Settings.tips_total) + 1
	else:
		if has(pid) and not fresh:
			return
		Settings.iap_owned[pid] = true
	Settings.save_cfg()
	if fresh:
		purchased.emit(pid)
		note.emit(Settings.t("iap_thanks_tip") if pid in Cfg.TIPS else Settings.t("iap_thanks"))
	changed.emit()


# ------------------------------------------------------------------ rewarded ads

## Show a rewarded ad (or, with "no ads", grant right away). `on_reward` runs once, on the main
## thread, only if the reward was earned; `on_fail` when there was nothing to show.
func show_rewarded(placement: String, on_reward: Callable, on_fail := Callable()) -> void:
	if no_ads():
		on_reward.call_deferred()
		return
	if sim:
		if sim_ads:
			get_tree().create_timer(0.3, true).timeout.connect(on_reward)
		else:
			_ad_fail(on_fail)
		return
	if ads and ads.is_ready():
		ads.show(placement, on_reward, func(): _ad_fail(on_fail))
		return
	_ad_fail(on_fail)


func _ad_fail(on_fail: Callable) -> void:
	note.emit(Settings.t("ad_not_ready"))
	if on_fail.is_valid():
		on_fail.call_deferred()


func privacy_options_required() -> bool:
	return ads != null and ads.privacy_options_required()


func show_privacy_options() -> void:
	if ads:
		ads.show_privacy_options()


# ------------------------------------------------------------------ Google Play Billing

func _on_connected() -> void:
	billing_ready = true
	_retries = 0
	billing.query_product_details(PackedStringArray(all_products()), 0)
	billing.query_purchases(0)
	changed.emit()


func _on_disconnected() -> void:
	billing_ready = false
	_retry_t = 10.0
	changed.emit()


func _on_connect_error(_code: int, _msg: String) -> void:
	billing_ready = false
	_retries += 1
	_retry_t = minf(120.0, 10.0 * _retries)
	changed.emit()


func _on_product_details(r: Dictionary) -> void:
	if int(r.get("response_code", -1)) != OK:
		return
	for d in r.get("product_details", []):
		if not (d is Dictionary):
			continue
		var pid := str(d.get("product_id", ""))
		if pid == "" or not d.has("title"):
			continue    # a product id Play doesn't know (not created / not active yet)
		var pr := ""
		var offers = d.get("one_time_purchase_offer_details_list", [])
		if offers is Array and offers.size() > 0 and offers[0] is Dictionary:
			pr = str(offers[0].get("formatted_price", ""))
		products[pid] = {"title": str(d.get("name", d.get("title", pid))), "price": pr if pr != "" else price(pid)}
	changed.emit()


## Owned purchases from Google Play: the truth for one-time products (restores after a reinstall,
## drops refunded ones), and tips that were paid but never consumed.
func _on_purchases(r: Dictionary) -> void:
	if int(r.get("response_code", -1)) != OK:
		return
	var owned := {}
	for p in r.get("purchases", []):
		if not (p is Dictionary) or int(p.get("purchase_state", 0)) != PURCHASED:
			continue
		for pid in p.get("product_ids", []):
			owned[str(pid)] = true
		_handle_purchase(p, false)
	for pid in Cfg.NON_CONSUMABLE:
		if has(pid) and not owned.has(pid):
			Settings.iap_owned.erase(pid)    # refunded or revoked
	Settings.save_cfg()
	changed.emit()


func _on_purchase_updated(r: Dictionary) -> void:
	var code := int(r.get("response_code", -1))
	if code == USER_CANCELED:
		return
	if code == ITEM_ALREADY_OWNED:
		billing.query_purchases(0)
		return
	if code != OK:
		note.emit(Settings.t("iap_failed") % str(r.get("debug_message", code)))
		return
	for p in r.get("purchases", []):
		if p is Dictionary:
			if int(p.get("purchase_state", 0)) == PENDING:
				note.emit(Settings.t("iap_pending"))
			elif int(p.get("purchase_state", 0)) == PURCHASED:
				_handle_purchase(p, true)


func _handle_purchase(p: Dictionary, fresh: bool) -> void:
	var token := str(p.get("purchase_token", ""))
	for pid_v in p.get("product_ids", []):
		var pid := str(pid_v)
		if pid in Cfg.TIPS:
			if token != "" and not _consuming.has(token):
				_consuming[token] = pid
				billing.consume_purchase(token)    # the tip counts once Play confirms the consume
		elif pid in Cfg.NON_CONSUMABLE:
			_grant(pid, fresh and not has(pid))
			if not bool(p.get("is_acknowledged", false)) and token != "":
				billing.acknowledge_purchase(token)    # unacknowledged purchases get refunded after 3 days


func _on_consumed(r: Dictionary) -> void:
	var token := str(r.get("token", ""))
	var pid := str(_consuming.get(token, ""))
	_consuming.erase(token)
	if int(r.get("response_code", -1)) == OK and pid != "":
		_grant(pid, true)
