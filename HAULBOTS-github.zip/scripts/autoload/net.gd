extends Node
## Networking (ENet LAN co-op, internet play through the relay server), lobby, LAN discovery
## and run state. Solo play uses the same code path with an OfflineMultiplayerPeer.

const RelayPeer = preload("res://scripts/autoload/relay_peer.gd")

const PORT := 7777
const DISC_PORT := 7778
const MAX_PLAYERS := 4
const GAME_ID := "haulbots-2.2"
const SAVE_PATH := "user://save.json"
const MP_SAVE_PATH := "user://save_mp.json"
## reasons a client may simply come back after a drop (host still running)
const REJOINABLE := ["relay_lost", "host_left_lan"]
## Robot paint (the first four are the old automatic colours).
const COLORS := [Color(1.0, 0.55, 0.1), Color(0.2, 0.75, 1.0), Color(0.45, 1.0, 0.3), Color(1.0, 0.35, 0.65),
	Color(0.92, 0.2, 0.18), Color(1.0, 0.86, 0.2), Color(0.1, 0.8, 0.72), Color(0.6, 0.35, 1.0),
	Color(0.92, 0.92, 0.9), Color(0.32, 0.34, 0.38), Color(0.55, 0.36, 0.2), Color(0.62, 1.0, 0.75),
	Color(0.2, 0.32, 0.85), Color(1.0, 0.3, 0.9), Color(0.5, 0.58, 0.22), Color(1.0, 0.68, 0.55)]
const UPGRADE_KEYS := ["hp", "stamina", "strength", "range", "speed", "jump", "tumble", "crouch", "wings"]
const UPGRADE_PRICE := {"hp": 8000, "stamina": 6000, "strength": 10000, "range": 6000, "speed": 9000, "heal": 4000}
const MAX_UPGRADE := 10

signal players_changed
signal connected_ok
signal connect_failed
signal session_ended(reason: String)
signal hosts_changed
signal run_changed
signal room_ready(code: String)
signal update_available(info: Dictionary)
signal rejoin_waiting(level: int)

var players := {}
var online := false
var solo := true
var in_game := false
var difficulty := 1

# run state (host is authoritative, replicated to clients)
var level := 1
var money := 0
var total_earned := 0
var upgrades := {}
var hp := {}
var last_stats := {}
var inv := {}
var energy := 1.0
var truck_items := []
## Everything the crew ever bought and has not used up yet: [{"u": uid, "t": type, "b": battery}].
## Like the reference game, bought items appear in the van at the start of every level
## (durable gear even if it broke); consumables leave the list once used.
var owned := []
var next_uid := 1
var bought := {}
var run_continued := false    # solo: this run already used "continue after game over"
var shop_bonus_level := 0     # solo: the shop visit that already took its rewarded cash bonus
var continue_snapshot := ""   # solo: the last save, kept after a game over for "continue"

var found_hosts := {}
var _bc: PacketPeerUDP = null
var _listen: PacketPeerUDP = null
var _bc_t := 0.0
var _kick_reason := ""
## internet play (relay): room code of this session, last error to show
var relay := false
var last_mode := ""      # "lan" / "relay": where to go back after a failed connection
var relay_code := ""
var last_error := ""
var _relay_open_sent := -1
var _keepalive_t := 0.0
var _keepalive: HTTPRequest = null
## rejoin after a drop: the host keeps who dropped out mid-run (uid -> their old entry) and who
## came back (peer -> entry; they enter the game at the next level or shop)
var away := {}
var pending := {}
## client: back in the team, waiting for the next level; how to get back after a drop
var rejoin_wait := false
var reconnecting := false
var pending_ids := []      # clients: who is waiting to re-enter (skip them for position updates)
var session := {}
## newer release announced by the server (/version): {version, url, page, notes}
var update_info := {}
var _update_req: HTTPRequest = null
var _update_checked := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_conn_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)


func _main() -> Node:
	return get_tree().root.get_node_or_null("Main")


func _world() -> Node:
	var m := _main()
	return m.get_node_or_null("World") if m else null


func my_id() -> int:
	return multiplayer.get_unique_id()


func is_host() -> bool:
	return multiplayer.is_server()


func sender() -> int:
	var s := multiplayer.get_remote_sender_id()
	return s if s != 0 else multiplayer.get_unique_id()


# ------------------------------------------------------------------ stats

func up(id: int, k: String) -> int:
	return int(upgrades.get(id, {}).get(k, 0))


func max_hp(id: int) -> float:
	return 100.0 + 20.0 * up(id, "hp")


func max_stamina(id: int) -> float:
	return 40.0 + 10.0 * up(id, "stamina")


func extra_jumps(id: int) -> int:
	return up(id, "jump")


func tumble_power(id: int) -> float:
	return 1.0 + 0.25 * up(id, "tumble")


## Tumble wings: seconds of gliding per air time.
func wing_time(id: int) -> float:
	var w := up(id, "wings")
	return 0.0 if w <= 0 else 1.2 + 0.6 * w


func player_color(id: int) -> Color:
	return COLORS[int(players.get(id, {}).get("color", 0)) % COLORS.size()]


func my_color_index() -> int:
	return Settings.robot_color if Settings.robot_color >= 0 else 0


func crouch_regen(id: int) -> float:
	return 1.0 + 0.6 * up(id, "crouch")


func inv_of(id: int) -> Array:
	var a = inv.get(id, null)
	if not (a is Array) or a.size() != 3:
		a = [null, null, null]
		inv[id] = a
	return a


func strength(id: int) -> float:
	return 190.0 + 85.0 * up(id, "strength")


func grab_range(id: int) -> float:
	return 4.0 + 1.0 * up(id, "range")


func speed_mult(id: int) -> float:
	return 1.0 + 0.08 * up(id, "speed")


func price(id: int, k: String) -> int:
	var base: float = UPGRADE_PRICE[k]
	var own := 0 if k == "heal" else up(id, k)
	var v := base * (1.0 + 0.12 * (level - 1)) * (1.0 + 0.3 * own)
	return int(round(v / 100.0)) * 100


func _init_player_run(id: int) -> void:
	upgrades[id] = {"hp": 0, "stamina": 0, "strength": 0, "range": 0, "speed": 0, "jump": 0, "tumble": 0, "crouch": 0, "wings": 0}
	hp[id] = max_hp(id)
	inv[id] = [null, null, null]


func _new_run() -> void:
	level = 1
	money = 0
	total_earned = 0
	energy = 1.0
	inv = {}
	truck_items = []
	owned = []
	next_uid = 1
	bought = {}
	upgrades = {}
	hp = {}
	last_stats = {}
	run_continued = false
	shop_bonus_level = 0
	for id in players:
		_init_player_run(id)


# ------------------------------------------------------------------ solo

func start_solo(cont: bool) -> void:
	leave()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	solo = true
	online = false
	players = {1: {"name": Settings.player_name, "color": my_color_index(), "uid": Settings.player_uid, "cos": Settings.cosmetics()}}
	if cont and has_save():
		_load_save()
		last_stats = {}
		run_changed.emit()
		begin_shop({})
	else:
		delete_save()
		_new_run()
		difficulty = Settings.difficulty
		begin_level()


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func save_level() -> int:
	if not has_save():
		return 1
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return 1
	var d = JSON.parse_string(f.get_as_text())
	return int(d.get("level", 1)) if d is Dictionary else 1


func save_run() -> void:
	if not solo:
		save_mp_run()
		return
	var d := {"diff": difficulty, "level": level, "money": money, "earned": total_earned, "up": upgrades.get(1, {}), "hp": hp.get(1, 100.0), "inv": inv_of(1), "energy": energy, "truck": truck_items, "owned": owned, "uid": next_uid, "bought": bought, "cont": run_continued, "sbl": shop_bonus_level}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))


func _load_save() -> void:
	_new_run()
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	if not (d is Dictionary):
		return
	level = int(d.get("level", 1))
	difficulty = int(d.get("diff", 1))
	money = int(d.get("money", 0))
	total_earned = int(d.get("earned", 0))
	var u = d.get("up", {})
	for k in UPGRADE_KEYS:
		upgrades[1][k] = int(u.get(k, 0)) if u is Dictionary else 0
	hp[1] = clampf(float(d.get("hp", 100.0)), 1.0, max_hp(1))
	var si = d.get("inv", [null, null, null])
	if si is Array and si.size() == 3:
		inv[1] = si
	energy = float(d.get("energy", 1.0))
	var ti = d.get("truck", [])
	truck_items = ti if ti is Array else []
	var ow = d.get("owned", [])
	owned = ow if ow is Array else []
	next_uid = int(d.get("uid", 1))
	var bo = d.get("bought", {})
	bought = bo if bo is Dictionary else {}
	run_continued = bool(d.get("cont", false))
	shop_bonus_level = int(d.get("sbl", 0))
	for e in owned:
		next_uid = maxi(next_uid, int(e.get("u", 0)) + 1)


# ------------------------------------------------------------------ network run save (host)

## The host keeps the co-op run too: money, level, bought gear, and every robot's upgrades,
## health and slots by player id — continue later from the lobby with the same crew.
func save_mp_run() -> void:
	if solo or not online or not is_host() or players.size() < 1:
		return
	var pl := {}
	var old = _read_json(MP_SAVE_PATH)
	if old is Dictionary and old.get("players") is Dictionary:
		pl = old["players"]
	var entries := {}
	for id in players:
		entries[id] = players[id]
	for id in pending:
		entries[id] = pending[id]
	for uid in away:
		entries[int(away[uid]["pid"])] = away[uid]["entry"]
	for id in entries:
		var e: Dictionary = entries[id]
		var uid := str(e.get("uid", ""))
		if uid == "":
			continue
		pl[uid] = {"name": str(e.get("name", "?")), "color": int(e.get("color", 0)), "up": upgrades.get(id, {}), "hp": float(hp.get(id, 100.0)), "inv": inv_of(id)}
	var d := {"diff": difficulty, "level": level, "money": money, "earned": total_earned, "energy": energy, "truck": truck_items,
		"owned": owned, "uid": next_uid, "bought": bought, "players": pl, "t": Time.get_unix_time_from_system()}
	var f := FileAccess.open(MP_SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))


static func _read_json(path: String):
	if not FileAccess.file_exists(path):
		return null
	var f := FileAccess.open(path, FileAccess.READ)
	return JSON.parse_string(f.get_as_text()) if f else null


func has_mp_save() -> bool:
	var d = _read_json(MP_SAVE_PATH)
	return d is Dictionary and int(d.get("level", 0)) >= 2


func mp_save_info() -> Dictionary:
	var d = _read_json(MP_SAVE_PATH)
	return d if d is Dictionary else {}


func delete_mp_save() -> void:
	if FileAccess.file_exists(MP_SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(MP_SAVE_PATH))


## Lobby: pick up the saved co-op run (robots are matched by player id, newcomers start fresh).
func continue_mp() -> void:
	if not is_host() or in_game:
		return
	var d := mp_save_info()
	if d.is_empty():
		return
	_new_run()
	level = maxi(1, int(d.get("level", 1)))
	difficulty = int(d.get("diff", Settings.difficulty))
	money = int(d.get("money", 0))
	total_earned = int(d.get("earned", 0))
	energy = float(d.get("energy", 1.0))
	var ti = d.get("truck", [])
	truck_items = ti if ti is Array else []
	var ow = d.get("owned", [])
	owned = ow if ow is Array else []
	next_uid = int(d.get("uid", 1))
	for e in owned:
		next_uid = maxi(next_uid, int(e.get("u", 0)) + 1)
	var bo = d.get("bought", {})
	bought = bo if bo is Dictionary else {}
	var sp = d.get("players", {})
	for id in players:
		var uid := str(players[id].get("uid", ""))
		if not (sp is Dictionary) or not sp.has(uid):
			continue
		var e: Dictionary = sp[uid]
		var u = e.get("up", {})
		for k in UPGRADE_KEYS:
			upgrades[id][k] = int(u.get(k, 0)) if u is Dictionary else 0
		hp[id] = clampf(float(e.get("hp", 100.0)), 1.0, max_hp(id))
		var si = e.get("inv", [null, null, null])
		inv[id] = si if si is Array and si.size() == 3 else [null, null, null]
	last_stats = {}
	send_run()
	begin_shop({})


func delete_save() -> void:
	if has_save():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))


# ------------------------------------------------------------------ online

func host_game() -> bool:
	leave()
	last_mode = "lan"
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_PLAYERS - 1)
	if err != OK:
		return false
	multiplayer.multiplayer_peer = peer
	online = true
	solo = false
	in_game = false
	players = {1: {"name": Settings.player_name, "color": my_color_index(), "uid": Settings.player_uid, "cos": Settings.cosmetics()}}
	_new_run()
	_start_broadcast()
	players_changed.emit()
	return true


func join_game(ip: String) -> void:
	leave()
	last_mode = "lan"
	if ip.strip_edges().is_valid_ip_address():
		Settings.last_ip = ip.strip_edges()
	_kick_reason = ""
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip.strip_edges(), PORT)
	if err != OK:
		connect_failed.emit()
		return
	multiplayer.multiplayer_peer = peer
	online = true
	solo = false


func leave() -> void:
	_stop_broadcast()
	stop_listen()
	var p := multiplayer.multiplayer_peer
	if p and not (p is OfflineMultiplayerPeer):
		p.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	online = false
	in_game = false
	players = {}
	relay = false
	relay_code = ""
	_relay_open_sent = -1
	away.clear()
	pending.clear()
	pending_ids = []
	rejoin_wait = false


# ------------------------------------------------------------------ internet (relay)

func relay_url(code := "") -> String:
	var u: String = Settings.relay_url
	# a room code starts with its region's letter: join on that region's server whatever is selected
	var rg := Settings.region_of_code(code.strip_edges().to_upper()) if code != "" else ""
	if rg != "" and Settings.relay_region != "custom":
		u = Settings.region_url(rg)
	return RelayPeer.normalize_url(u)


## http(s) address of the relay (for the wake-up / keep-alive request).
func relay_http_url(code := "") -> String:
	var u := relay_url(code)
	if u.begins_with("wss://"):
		return "https://" + u.substr(6)
	if u.begins_with("ws://"):
		return "http://" + u.substr(5)
	return u


## Ask the server once per launch whether a newer version is out (this also wakes it up).
func check_update() -> void:
	if _update_checked or relay_url() == "" or OS.get_environment("HB_ROLE") != "":
		return
	_update_checked = true
	_update_req = HTTPRequest.new()
	_update_req.timeout = 70.0
	add_child(_update_req)
	_update_req.request_completed.connect(func(result: int, code: int, _h, body: PackedByteArray):
		_update_req.queue_free()
		_update_req = null
		if result != HTTPRequest.RESULT_SUCCESS or code != 200:
			return
		var d = JSON.parse_string(body.get_string_from_utf8())
		if d is Dictionary and newer_version(str(d.get("version", "")), Settings.VERSION):
			update_info = d
			update_available.emit(d))
	if _update_req.request(relay_http_url() + "/version") != OK:
		_update_req.queue_free()
		_update_req = null


## "2.10.1" > "2.9.3"
static func newer_version(a: String, b: String) -> bool:
	a = a.strip_edges().trim_prefix("v").trim_prefix("V")
	b = b.strip_edges().trim_prefix("v").trim_prefix("V")
	if a == "":
		return false
	var pa := a.split(".")
	var pb := b.split(".")
	for i in maxi(pa.size(), pb.size()):
		var x := int(pa[i]) if i < pa.size() else 0
		var y := int(pb[i]) if i < pb.size() else 0
		if x != y:
			return x > y
	return false


## Where the update button leads: the APK itself on Android, the release page elsewhere.
func update_link() -> String:
	if OS.has_feature("play"):
		return "https://play.google.com/store/apps/details?id=com.jiokim.haulbots"    # Play updates itself
	var u := str(update_info.get("url", ""))
	if OS.get_name() != "Android" and str(update_info.get("page", "")) != "":
		u = str(update_info.get("page", ""))
	return u


func host_online(pub: bool) -> bool:
	leave()
	last_mode = "relay"
	last_error = ""
	if relay_url() == "":
		last_error = "relay_no_url"
		return false
	var peer := RelayPeer.new()
	peer.tls_unsafe = OS.get_environment("HB_TLS_UNSAFE") != ""
	if peer.host(relay_url(), Settings.player_name, GAME_ID, pub) != OK:
		last_error = peer.fail_reason
		return false
	peer.hosted.connect(_on_room_hosted)
	multiplayer.multiplayer_peer = peer
	online = true
	solo = false
	in_game = false
	relay = true
	players = {1: {"name": Settings.player_name, "color": my_color_index(), "uid": Settings.player_uid, "cos": Settings.cosmetics()}}
	_new_run()
	players_changed.emit()
	return true


func join_online(room: String, rejoin := false) -> void:
	leave()
	last_mode = "relay"
	_kick_reason = ""
	last_error = ""
	if relay_url() == "":
		last_error = "relay_no_url"
		connect_failed.emit()
		return
	var peer := RelayPeer.new()
	peer.tls_unsafe = OS.get_environment("HB_TLS_UNSAFE") != ""
	if peer.join(relay_url(room), room, Settings.player_name, GAME_ID, rejoin) != OK:
		last_error = peer.fail_reason
		connect_failed.emit()
		return
	multiplayer.multiplayer_peer = peer
	online = true
	solo = false
	relay = true
	relay_code = room.strip_edges().to_upper()


func _on_room_hosted(c: String) -> void:
	relay_code = c
	room_ready.emit(c)


func _relay_peer():
	var p := multiplayer.multiplayer_peer
	return p if p is RelayPeer else null


## Keep the host's room listed as open only while it is in the lobby; ping the server over
## HTTP now and then (a free Render server falls asleep after 15 minutes without requests).
func _relay_tick(delta: float) -> void:
	var rp = _relay_peer()
	if rp == null:
		return
	if is_host() and rp.code != "":
		var open := 0 if in_game else 1
		if open != _relay_open_sent:
			_relay_open_sent = open
			rp.send_control({"op": "info", "open": open == 1})
	_keepalive_t -= delta
	if _keepalive_t <= 0.0:
		_keepalive_t = 480.0
		if _keepalive == null:
			_keepalive = HTTPRequest.new()
			_keepalive.timeout = 60.0
			add_child(_keepalive)
		_keepalive.cancel_request()
		_keepalive.request(relay_http_url(relay_code) + "/health")


func _on_connected() -> void:
	rpc_id(1, "_register", Settings.player_name, GAME_ID, Settings.robot_color, Settings.player_uid, Settings.cosmetics())
	_remember_session()
	connected_ok.emit()


## Remember how to get back into this session (also across an app restart, for 20 minutes).
func _remember_session() -> void:
	session = {"mode": last_mode, "code": relay_code, "ip": Settings.last_ip, "t": Time.get_unix_time_from_system()}
	Settings.last_session = session
	Settings.save_cfg()


## A session we can try to get back into (dropped out, or the app was closed mid-run).
func recent_session() -> Dictionary:
	var sn: Dictionary = Settings.last_session
	if sn.is_empty() or Time.get_unix_time_from_system() - float(sn.get("t", 0.0)) > 20 * 60:
		return {}
	if str(sn.get("mode", "")) == "relay" and str(sn.get("code", "")) == "":
		return {}
	return sn


func forget_session() -> void:
	Settings.last_session = {}
	Settings.save_cfg()


## One attempt to get back into the last session (the host recognises us by our player id).
func rejoin_session() -> void:
	var sn := recent_session()
	if sn.is_empty():
		connect_failed.emit()
		return
	if str(sn.get("mode", "")) == "relay":
		join_online(str(sn.get("code", "")), true)
	else:
		join_game(str(sn.get("ip", "")))


func _on_conn_failed() -> void:
	var rp = _relay_peer()
	if rp and rp.fail_reason != "":
		last_error = rp.fail_reason
	leave()
	connect_failed.emit()


func _on_server_disconnected() -> void:
	var r := _kick_reason if _kick_reason != "" else "host_left"
	var rp = _relay_peer()
	if _kick_reason == "" and rp:
		r = rp.fail_reason if rp.fail_reason in ["host_left", "kicked", "relay_lost", "idle"] else "relay_lost"
		if is_host():
			r = "relay_lost"
	elif _kick_reason == "" and not is_host() and (in_game or rejoin_wait):
		r = "host_left_lan"    # on Wi-Fi a lost connection and a host that quit look the same: try to come back
	if _kick_reason != "" or r == "host_left":
		forget_session()
	leave()
	session_ended.emit(r)


func _on_peer_connected(_id: int) -> void:
	pass


func _on_peer_disconnected(id: int) -> void:
	if not is_host():
		return
	if pending.has(id):
		var pe: Dictionary = pending[id]
		pending.erase(id)
		_share_pending()
		if in_game and str(pe.get("uid", "")) != "":
			away[str(pe["uid"])] = {"pid": id, "entry": pe}
		return
	if players.has(id):
		var e: Dictionary = players[id]
		var pname: String = e["name"]
		players.erase(id)
		# mid-run: keep their upgrades, health and slots, they may come back (dropped connection)
		if in_game and str(e.get("uid", "")) != "":
			away[str(e["uid"])] = {"pid": id, "entry": e}
		var w := _world()
		if w:
			w.server_peer_left(id, pname)
		_sync_all()


@rpc("any_peer", "reliable")
func _register(pname: String, gid: String, want_color := -1, uid := "", cos := {}) -> void:
	if not is_host():
		return
	var id := multiplayer.get_remote_sender_id()
	var reason := ""
	if gid != GAME_ID:
		reason = "kicked_version"
	elif in_game and uid != "" and away.has(uid):
		_accept_rejoin(id, pname, uid, cos)
		return
	elif in_game:
		reason = "kicked_in_game"
	elif players.size() + pending.size() >= MAX_PLAYERS:
		reason = "kicked_full"
	if reason != "":
		rpc_id(id, "_kicked", reason)
		get_tree().create_timer(0.5).timeout.connect(_kick_peer.bind(id))
		return
	var used := []
	for p in players.values():
		used.append(p["color"])
	var c := 0
	if want_color >= 0 and want_color < COLORS.size():
		c = want_color          # a chosen paint is kept even if someone else has it (like the reference game)
	else:
		while c in used:
			c += 1
	players[id] = {"name": pname.substr(0, 16), "color": c, "uid": uid, "cos": cos if cos is Dictionary else {}}
	_init_player_run(id)
	_sync_all()


## A player who dropped out mid-run is back: same upgrades, health and slots; they wait until
## the next level or shop loads (the running level can't be rebuilt on their phone).
func _accept_rejoin(id: int, pname: String, uid: String, cos) -> void:
	var a: Dictionary = away[uid]
	away.erase(uid)
	var old: int = int(a["pid"])
	for d in [upgrades, hp, inv]:
		if d.has(old):
			d[id] = d[old]
			d.erase(old)
	if not upgrades.has(id):
		_init_player_run(id)
	var e: Dictionary = (a["entry"] as Dictionary).duplicate()
	e["name"] = pname.substr(0, 16)
	e["uid"] = uid
	if cos is Dictionary:
		e["cos"] = cos
	pending[id] = e
	_share_pending()
	rpc("_sync_players", players)
	send_run()
	rpc_id(id, "_rejoin_wait", level)
	var w := _world()
	if w:
		w.rpc_message("msg_player_back", [e["name"]])


## The one waiting peer to leave out of 20 Hz position broadcasts (0 = send to everyone).
func state_exclude() -> int:
	var ids: Array = pending.keys() if is_host() else pending_ids
	return int(ids[0]) if ids.size() == 1 else 0


func _share_pending() -> void:
	if is_host() and online:
		rpc("_set_pending", pending.keys())


@rpc("authority", "reliable")
func _set_pending(ids: Array) -> void:
	pending_ids = ids


@rpc("authority", "reliable")
func _rejoin_wait(lvl: int) -> void:
	rejoin_wait = true
	rejoin_waiting.emit(lvl)


## Players who came back mid-run enter the game with the next level / shop / arena / lobby.
func _merge_pending() -> void:
	if pending.is_empty():
		return
	for id in pending:
		players[id] = pending[id]
		if not upgrades.has(id):
			_init_player_run(id)
	pending.clear()
	_share_pending()
	rpc("_sync_players", players)
	players_changed.emit()


## Repaint your robot (menu or lobby); the host keeps the authoritative copy.
func request_color(c: int) -> void:
	Settings.robot_color = c
	Settings.save_cfg()
	var me := multiplayer.get_unique_id()
	if not online or is_host():
		if players.has(me):
			players[me]["color"] = c
		if online:
			_sync_all()
		else:
			players_changed.emit()
	else:
		rpc_id(1, "_set_color", c)


@rpc("any_peer", "reliable")
func _set_color(c: int) -> void:
	if not is_host() or in_game:
		return
	var id := multiplayer.get_remote_sender_id()
	if players.has(id) and c >= 0 and c < COLORS.size():
		players[id]["color"] = c
		_sync_all()


func set_difficulty(d: int) -> void:
	Settings.difficulty = d
	Settings.save_cfg()
	difficulty = d
	if online and is_host():
		send_run()


func _kick_peer(id: int) -> void:
	var p := multiplayer.multiplayer_peer
	if p is ENetMultiplayerPeer or p is RelayPeer:
		p.disconnect_peer(id)


func _sync_all() -> void:
	rpc("_sync_players", players)
	players_changed.emit()
	send_run()


@rpc("authority", "reliable")
func _sync_players(p: Dictionary) -> void:
	players = p
	players_changed.emit()


@rpc("authority", "reliable")
func _kicked(reason: String) -> void:
	_kick_reason = reason


# ------------------------------------------------------------------ run flow

func send_run() -> void:
	if not is_host():
		return
	if online:
		rpc("_recv_run", level, money, total_earned, upgrades, hp, inv, energy)
	run_changed.emit()


@rpc("authority", "reliable")
func _recv_run(l: int, m: int, te: int, u: Dictionary, h: Dictionary, iv: Dictionary, en: float) -> void:
	inv = iv
	energy = en
	level = l
	money = m
	total_earned = te
	upgrades = u
	hp = h
	run_changed.emit()


func start_run() -> void:
	if not is_host():
		return
	_new_run()
	difficulty = Settings.difficulty
	begin_level()


func begin_level() -> void:
	if not is_host():
		return
	_merge_pending()
	if level >= 2:
		save_mp_run()    # purchases made in the shop are kept if the host quits mid-level
	in_game = true
	for id in players:
		if not upgrades.has(id):
			_init_player_run(id)
		if float(hp.get(id, 0.0)) <= 0.0:
			hp[id] = 1.0   # not revived during the level: back with 1 HP, buy a health pack
	send_run()
	rpc("_load_level", randi(), level, difficulty)


@rpc("authority", "call_local", "reliable")
func _load_level(s: int, l: int, diff: int) -> void:
	rejoin_wait = false
	level = l
	difficulty = diff
	in_game = true
	stop_listen()
	_main().start_world(s, l)


func _update_records(lvl: int) -> bool:
	var rec := false
	if lvl > Settings.best_level:
		Settings.best_level = lvl
		rec = true
	if total_earned > Settings.best_earned:
		Settings.best_earned = total_earned
		rec = true
	Settings.save_cfg()
	return rec


func add_owned(t: String, b := 1.0) -> int:
	var u := next_uid
	next_uid += 1
	owned.append({"u": u, "t": t, "b": b})
	return u


func consume_owned(u: int) -> void:
	if u <= 0:
		return
	for i in range(owned.size() - 1, -1, -1):
		if int(owned[i]["u"]) == u:
			owned.remove_at(i)


func set_owned_battery(u: int, b: float) -> void:
	for e in owned:
		if int(e["u"]) == u:
			e["b"] = b


func inv_uids() -> Dictionary:
	var out := {}
	for pid in inv:
		for e in inv[pid]:
			if e != null and int(e.get("u", 0)) > 0:
				out[int(e["u"])] = true
	return out


static func is_consumable(t: String) -> bool:
	return t.begins_with("up_") or t.begins_with("med_") or t.begins_with("g_") or t.begins_with("m_") or t == "i_crystal"


func server_level_complete(extracted: int, quota: int, extra := {}) -> void:
	if level == 1:
		add_owned("i_crystal", 1.0)   # free energy crystal after the first level, like the reference game
	money += extracted
	total_earned += extracted
	var stats := {"level": level, "extracted": extracted, "quota": quota}
	stats.merge(extra)
	level += 1
	in_game = false
	send_run()
	stats["earned"] = total_earned
	save_run()
	begin_shop(stats)


func begin_shop(stats: Dictionary) -> void:
	if not is_host():
		return
	_merge_pending()
	in_game = true
	for id in players:
		if float(hp.get(id, 0.0)) <= 0.0:
			hp[id] = maxf(1.0, max_hp(id) * 0.25)
	send_run()
	rpc("_load_shop", randi(), level, stats)


@rpc("authority", "call_local", "reliable")
func _load_shop(s: int, l: int, stats: Dictionary) -> void:
	rejoin_wait = false
	last_stats = stats
	level = l
	in_game = true
	if stats.has("earned"):
		total_earned = int(stats["earned"])
		_update_records(int(stats.get("level", 1)))
	_main().start_world(s, l, true)


@rpc("authority", "call_local", "reliable")
func _goto_shop(stats: Dictionary) -> void:
	last_stats = stats
	total_earned = int(stats.get("earned", total_earned))
	_update_records(int(stats.get("level", 1)))
	in_game = false
	_main().show_shop()


func request_buy(k: String) -> void:
	rpc_id(1, "_req_buy", k)


@rpc("any_peer", "call_local", "reliable")
func _req_buy(k: String) -> void:
	if not is_host() or in_game:
		return
	var id := sender()
	if not players.has(id) or not UPGRADE_PRICE.has(k):
		return
	var p := price(id, k)
	if money < p:
		return
	if k == "heal":
		if float(hp.get(id, 0.0)) >= max_hp(id) - 0.5:
			return
		hp[id] = minf(max_hp(id), float(hp.get(id, 0.0)) + max_hp(id) * 0.5)
	else:
		if up(id, k) >= MAX_UPGRADE:
			return
		var old_max := max_hp(id)
		upgrades[id][k] = up(id, k) + 1
		if k == "hp":
			hp[id] = float(hp.get(id, 0.0)) + (max_hp(id) - old_max)
	money -= p
	send_run()
	save_run()


## Everyone died online: the Taxman sends the crew to the disposal arena first.
func begin_arena() -> void:
	if not is_host():
		return
	_merge_pending()
	for id in players:
		hp[id] = max_hp(id)
	send_run()
	rpc("_load_arena", randi(), level)


@rpc("authority", "call_local", "reliable")
func _load_arena(s: int, l: int) -> void:
	rejoin_wait = false
	in_game = true
	_main().start_world(s, l, false, true)


func server_game_over() -> void:
	in_game = false
	rpc("_game_over", {"level": level, "earned": total_earned})


@rpc("authority", "call_local", "reliable")
func _game_over(stats: Dictionary) -> void:
	in_game = false
	if is_host() and not solo:
		delete_mp_save()
	forget_session()
	total_earned = int(stats.get("earned", total_earned))
	stats["record"] = _update_records(maxi(0, int(stats.get("level", 1)) - 1))
	last_stats = stats
	continue_snapshot = ""
	if solo:
		# keep the last save for a rewarded "continue" (once per run, from the last shop)
		if has_save():
			var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
			var txt := f.get_as_text() if f else ""
			var d = JSON.parse_string(txt)
			if d is Dictionary and not bool(d.get("cont", false)):
				continue_snapshot = txt
		delete_save()
	_main().show_gameover(stats)


func can_continue_run() -> bool:
	return solo and continue_snapshot != ""


## Rewarded "continue": back to the last shop of the lost run; the run can't be continued again.
func continue_run() -> void:
	var d = JSON.parse_string(continue_snapshot)
	continue_snapshot = ""
	if not (d is Dictionary):
		return
	d["cont"] = true
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))
		f.close()
	start_solo(true)


## Solo shop: rewarded cash bonus, once per shop visit.
func shop_bonus_amount() -> int:
	var C = preload("res://scripts/monetization_config.gd")
	return C.SHOP_BONUS_BASE + C.SHOP_BONUS_PER_LEVEL * level


func can_take_shop_bonus() -> bool:
	return solo and shop_bonus_level != level


func take_shop_bonus() -> int:
	if not can_take_shop_bonus():
		return 0
	var v := shop_bonus_amount()
	shop_bonus_level = level
	money += v
	send_run()
	save_run()
	return v


func back_to_lobby() -> void:
	if not is_host():
		return
	_merge_pending()
	away.clear()
	_new_run()
	send_run()
	rpc("_to_lobby")


@rpc("authority", "call_local", "reliable")
func _to_lobby() -> void:
	in_game = false
	_main().show_lobby()


# ------------------------------------------------------------------ LAN discovery

func _start_broadcast() -> void:
	_bc = PacketPeerUDP.new()
	_bc.set_broadcast_enabled(true)
	_bc.set_dest_address("255.255.255.255", DISC_PORT)
	_bc_t = 0.0


func _stop_broadcast() -> void:
	if _bc:
		_bc.close()
	_bc = null


func start_listen() -> void:
	stop_listen()
	found_hosts.clear()
	_listen = PacketPeerUDP.new()
	if _listen.bind(DISC_PORT) != OK:
		_listen = null


func stop_listen() -> void:
	if _listen:
		_listen.close()
	_listen = null


func local_ips() -> Array:
	var out := []
	for a in IP.get_local_addresses():
		if a.begins_with("192.168.") or a.begins_with("10.") or a.begins_with("172."):
			out.append(a)
	return out


func _process(delta: float) -> void:
	if relay:
		_relay_tick(delta)
	if _bc and not in_game:
		_bc_t -= delta
		if _bc_t <= 0.0:
			_bc_t = 1.0
			var msg := JSON.stringify({"g": GAME_ID, "n": Settings.player_name, "c": players.size()})
			_bc.put_packet(msg.to_utf8_buffer())
	if _listen:
		var changed := false
		while _listen.get_available_packet_count() > 0:
			var pkt := _listen.get_packet()
			var ip := _listen.get_packet_ip()
			var d = JSON.parse_string(pkt.get_string_from_utf8())
			if d is Dictionary and d.get("g", "") == GAME_ID:
				if not found_hosts.has(ip):
					changed = true
				found_hosts[ip] = {"name": str(d.get("n", "?")), "count": int(d.get("c", 1)), "t": Time.get_ticks_msec()}
		var now := Time.get_ticks_msec()
		for ip in found_hosts.keys():
			if now - int(found_hosts[ip]["t"]) > 4000:
				found_hosts.erase(ip)
				changed = true
		if changed:
			hosts_changed.emit()
