extends RefCounted
## Everything Google Play / AdMob needs, in one place. Replace the test IDs with your own before
## publishing (see STORE_SETUP.md). The in-app product IDs must match Play Console exactly.

# ---------------------------------------------------------------- in-app products (Play Console)
const REMOVE_ADS := "remove_ads"            # one-time: rewards without ad videos
const SUPPORTER := "supporter_pack"         # one-time: exclusive cosmetics + no ad videos
const TIPS := ["tip_1", "tip_3", "tip_5", "tip_10"]    # consumable "support the developer"
const NON_CONSUMABLE := [REMOVE_ADS, SUPPORTER]

# prices shown until Google Play answers (the real, localized price replaces them)
const FALLBACK_PRICE := {
	"remove_ads": "$1.99", "supporter_pack": "$4.99",
	"tip_1": "$0.99", "tip_3": "$2.99", "tip_5": "$4.99", "tip_10": "$9.99",
}

# ---------------------------------------------------------------- AdMob rewarded ads
# Google's public TEST units — they always serve test ads. The AdMob *App ID* goes into
# Project Settings → admob/general/android/app_id (the GitHub build sets it from a secret).
const REWARDED_UNIT_ANDROID := "ca-app-pub-3940256099942544/5224354917"
const REWARDED_UNIT_IOS := "ca-app-pub-3940256099942544/1712485313"

# ---------------------------------------------------------------- rewards
const SHOP_BONUS_BASE := 2000               # shop bonus = base + per level × level (solo)
const SHOP_BONUS_PER_LEVEL := 1000
