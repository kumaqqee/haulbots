extends Node
## Automated smoke tests: godot -- --autotest=solo|host|client|shots

var main: Node
var mode := "solo"
var errors := []


func _ready() -> void:
	print("[TEST] mode=", mode, " startup ms=", Time.get_ticks_msec())
	match mode:
		"solo":
			_solo()
		"host":
			_host()
		"client":
			_client()
		"shots":
			_shots()
		"menu":
			_menu_shots()
		"shopshot":
			_shopshot()
		"gallery":
			_gallery()
		"soak":
			_soak()
		"features":
			_features()
		"locshots":
			_loc_shots()
		"monsters":
			_monsters()
		"portraits":
			_portraits()
		"animshot":
			_animshot()
		"perf":
			_perf()
		"cartshot":
			_cartshot()
		"extrshot":
			_extrshot()
		"surplus":
			_surplus()
		"push":
			_push()
		"depart":
			_depart_test()
		"faces":
			_faces()
		"robotshot":
			_robotshot()
		"envshots":
			_envshots()
		"arena":
			_arena_test()
		"roomshots":
			_roomshots()
		"nav":
			_nav_test()
		"fling":
			_fling_test()
		"loadshot":
			_loadshot()
		"vanchase":
			_vanchase()
		"spawns":
			_spawns_test()
		"scroll":
			_scroll_test()
		"onlineui":
			_online_ui_test()
		"update":
			_update_test()
		"layout":
			_layout_test()
		"pad":
			_pad_test()
		"cosshot":
			_cosshot()
		"ach":
			_ach_test()
		"voice":
			_voice_test()
		"store":
			_store_test()
		"store_off":
			_store_off_test()
		"promo":
			var pr = load("res://scripts/promo.gd").new()
			pr.main = main
			add_child(pr)


func _wait(t: float) -> void:
	await get_tree().create_timer(t).timeout


func _check(cond: bool, msg: String) -> void:
	if cond:
		print("[TEST] OK   ", msg)
	else:
		print("[TEST] FAIL ", msg)
		errors.append(msg)


func _finish() -> void:
	if errors.is_empty():
		print("[TEST] ALL PASSED")
	else:
		print("[TEST] FAILURES: ", errors)
	get_tree().quit(0 if errors.is_empty() else 1)


func _shot(n: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	var p := "user://shot_%s.png" % n
	img.save_png(p)
	print("[TEST] shot ", ProjectSettings.globalize_path(p))


func _solo() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.5)
	var w = main.world
	_check(w != null, "world created")
	_check(w.started, "level started")
	_check(w.items.size() > 10, "items spawned: %d" % w.items.size())
	_check(w.monsters.size() >= 2, "monsters spawned: %d" % w.monsters.size())
	_check(w.extr.size() >= 1, "extraction points: %d" % w.extr.size())
	_check(w.quota_total > 0, "quota: %d" % w.quota_total)
	_check(w.local_player != null, "local player")
	# grab test: teleport next to a light item and pull it up
	var lp = w.local_player
	var target = null
	for it in w.items.values():
		if it.mass < 5.0 and it.base_value > 0 and it.global_position.y < 1.3:
			target = it
			break
	_check(target != null, "found light item")
	# move it to open floor first (few valuables per level now: it may sit inside a shelf)
	var cc0: Vector3 = w.gen.cell_center(w.gen.order[1])
	target.teleport(cc0 + Vector3(0.3, 0.4, -0.5))
	await _wait(1.2)
	var start_y: float = target.global_position.y
	lp.global_position = target.global_position + Vector3(0, 0.2, 1.8)
	await _wait(0.3)
	for i in 60:
		var tp: Vector3 = Vector3(target.global_position.x, start_y + 1.2, target.global_position.z)
		w.rpc_grab_update(target.item_id, tp, Vector3.ZERO)
		await get_tree().physics_frame
	_check(target.global_position.y > start_y + 0.3, "grab beam lifts item (%.2f -> %.2f)" % [start_y, target.global_position.y])
	w.rpc_grab_release(target.item_id, Vector3(0, 0, -1))
	# impact damage test
	await _wait(1.0)
	var v0: int = target.value
	target.global_position = Vector3(target.global_position.x, 2.5, target.global_position.z)
	target.linear_velocity = Vector3(0, -9, 0)
	target.hit_cd = 0.0
	await _wait(1.0)
	var still: bool = is_instance_valid(target) and w.items.has(target.item_id)
	_check(not still or target.value < v0, "impact reduces value (%d -> %s)" % [v0, str(target.value) if still else "broken"])
	# extraction: move enough items into the first zone
	var e: Dictionary = w.extr[0]
	var zone: Vector3 = e["pos"]
	var sum := 0
	var k := 0
	for it in w.items.values():
		if it.base_value <= 0 or it.mass > 15.0:
			continue
		it.linear_velocity = Vector3.ZERO
		it.global_position = zone + Vector3((k % 4) * 0.5 - 0.75, 0.3 + (k / 4) * 0.4, ((k / 2) % 2) * 0.5 - 0.25)
		it.hit_cd = 3.0
		sum += it.value
		k += 1
		if sum > e["goal"] * 1.7:
			break
	await _wait(1.5)
	_check(e["value"] >= e["goal"], "zone value counted %d / %d" % [e["value"], e["goal"]])
	print("[DBG] active=", w.active_extr, " started=", w.started, " goal=", e["goal"], " value=", e["value"])
	w.rpc_interact("extract", 0)
	await _wait(0.2)
	print("[DBG] extracting=", w.extracting)
	await _wait(3.8)
	_check(e["done"], "extraction point 1 done")
	_check(w.level_extracted > 0, "level extracted: %d" % w.level_extracted)
	# force-complete remaining points
	for i in range(1, w.extr.size()):
		w.extr[i]["done"] = true
	w.all_done = true
	w.active_extr = -1
	lp.global_position = w.truck_pos + Vector3(0, 0.2, 0)
	await _wait(0.5)
	w.rpc_interact("truck", 0)
	await _wait(1.0)
	_check(w.leaving, "van departure countdown started")
	var carts := 0
	for it in w.items.values():
		if it.type == "cart":
			carts += 1
	_check(carts == 0, "cart removed after the final extraction")
	await _wait(11.5)
	_check(main.world != null and main.world.shop_mode, "reached shop location")
	_check(Net.money > 0, "money after level: %d" % Net.money)
	_check(Net.has_save(), "save written")
	await _wait(1.0)
	w = main.world
	lp = w.local_player
	var shop_items := []
	for it in w.items.values():
		if it.is_shop():
			shop_items.append(it)
	_check(shop_items.size() >= 10, "shop stocked: %d items" % shop_items.size())
	Net.money = 50600
	var up_item = null
	for it in shop_items:
		if it.type == "up_strength":
			up_item = it
	if up_item == null:
		up_item = shop_items[0]
	var price: int = up_item.value
	var up_type: String = up_item.type
	var up_id: int = up_item.item_id
	up_item.teleport(w.gen.checkout_pos + Vector3(0, 0.4, 0))
	await _wait(1.0)
	_check(w.basket == price, "basket counts item price (%d / %d)" % [w.basket, price])
	w.rpc_interact("buy", 0)
	await _wait(0.3)
	_check(w.buying, "checkout countdown started")
	await _wait(3.2)
	_check(not w.items.has(up_id) and Net.money == 50600 - price, "purchase extracted the goods and took the cash (%d)" % Net.money)
	var found_owned := false
	for oe in Net.owned:
		if oe["t"] == up_type:
			found_owned = true
	_check(found_owned, "bought item is waiting for the van (%d owned)" % Net.owned.size())
	lp.global_position = w.truck_pos + Vector3(0, 0.2, 0)
	await _wait(0.4)
	w.rpc_interact("truck", 0)
	await _wait(2.5)
	_check(main.world != null and main.world.level_num == 2, "level 2 loaded")
	w = main.world
	await _wait(1.0)
	var in_van = null
	for it in w.items.values():
		if it.type == up_type and it.uid > 0:
			in_van = it
	_check(in_van != null and in_van.global_position.distance_to(w.truck_pos) < 4.0, "purchase appeared in the van")
	var crystal := false
	for it in w.items.values():
		if it.type == "i_crystal" and it.uid > 0:
			crystal = true
	_check(crystal, "free energy crystal after level 1")
	if in_van:
		var uk: String = up_type.substr(3) if up_type.begins_with("up_") else ""
		var before := Net.up(1, uk) if uk != "" else 0
		w.local_player.global_position = in_van.global_position + Vector3(0, 0, 1.0)
		w.rpc_use_item(in_van.item_id)
		await _wait(0.3)
		_check(uk == "" or Net.up(1, uk) == before + 1, "using the upgrade applies it (%s -> %d)" % [uk, Net.up(1, uk) if uk != "" else 0])
		var still_owned := false
		for oe2 in Net.owned:
			if oe2["t"] == up_type:
				still_owned = true
		_check(not still_owned or not up_type.begins_with("up_"), "used upgrade leaves the owned list")
	# monster AI sanity: wake all, let them run
	for m in w.monsters.values():
		m.dormant = 0.0
	await _wait(3.0)
	var moved := 0
	for m in w.monsters.values():
		if m.global_position.distance_to(m.net_pos) > 0.3:
			moved += 1
	_check(moved > 0, "monsters move (%d)" % moved)
	# kill a monster with damage
	var mm = w.monsters.values()[0]
	for cand in w.monsters.values():
		if cand.cfg["orb"][1] > 0:
			mm = cand
			break
	print("[TEST] killing ", mm.mtype)
	var mid: int = mm.mid
	mm.take_hit(9999.0)
	await _wait(1.5)
	_check(not w.monsters.has(mid), "monster died")
	var orbs := 0
	for it in w.items.values():
		if it.type == "orb":
			orbs += 1
	_check(orbs > 0, "orb dropped")
	# death -> game over
	w.server_damage_player(1, 99999.0, Vector3.ZERO)
	await _wait(4.0)
	_check(main.screen_name == "gameover", "game over screen (screen=%s)" % main.screen_name)
	_check(not Net.has_save(), "save deleted on game over")
	_finish()


func _host() -> void:
	_check(Net.host_game(), "host started")
	var t := 0.0
	while Net.players.size() < 2 and t < 20.0:
		await _wait(0.5)
		t += 0.5
	_check(Net.players.size() == 2, "client joined")
	Net.start_run()
	await _wait(4.0)
	var w = main.world
	_check(w != null and w.started, "host level started")
	print("[TEST] host items=", w.items.size(), " monsters=", w.monsters.size(), " players=", w.players.size())
	_check(w.players.size() == 2, "host sees 2 players")
	# wait for client to grab something and talk
	await _wait(8.0)
	var cid: int = Net.players.keys().filter(func(k): return k != 1)[0]
	print("[TEST] voice frames from client: ", w.voice.frames_received(cid))
	_check(w.voice.frames_received(cid) > 0 or w.voice._speak_t.has(cid), "voice packets received from client")
	print("[TEST] host grabs=", w.grabs)
	_check(w.get_meta("client_grabbed", false), "client grab reached host")
	var c = w.players.values().filter(func(p): return not p.is_local)[0]
	_check(c.net_pos.distance_to(Vector3.ZERO) > 0.01, "client position replicated: %s" % str(c.net_pos))
	_check(w._bubbles.has(cid) or w.get_meta("client_chat", false), "client chat line reached host")
	_check(int(Net.players[cid]["color"]) == 5, "client keeps chosen robot colour")
	Net.server_level_complete(20000, 10000)
	await _wait(3.0)
	_check(main.world != null and main.world.shop_mode, "host in shop")
	await _wait(8.0)
	_finish()


func _client() -> void:
	Settings.robot_color = 5
	await _wait(1.5)
	Net.join_game("127.0.0.1")
	var t := 0.0
	while main.world == null and t < 25.0:
		await _wait(0.5)
		t += 0.5
	_check(main.world != null, "client world loaded")
	await _wait(3.0)
	var w = main.world
	print("[TEST] client items=", w.items.size(), " monsters=", w.monsters.size(), " players=", w.players.size())
	_check(w.items.size() > 10, "client got items")
	_check(w.started, "client knows level started (HUD objective)")
	_check(w.extr.size() > 0 and w.extr[0]["goal"] > 0, "client got extraction goals")
	_check(w.monsters.size() >= 2, "client got monsters")
	_check(w.players.size() == 2, "client sees 2 players")
	# grab an item via rpc (as the real player code does)
	var lp = w.local_player
	var target = null
	var space: PhysicsDirectSpaceState3D = w.get_world_3d().direct_space_state
	for it in w.items.values():
		if it.mass < 5.0 and it.base_value > 0 and it.global_position.y < 1.3:
			var q := PhysicsRayQueryParameters3D.create(it.global_position + Vector3(0, 0.35, 0), it.global_position + Vector3(0, 1.8, 0), 1 | 4)
			q.exclude = [it.get_rid()]
			if space.intersect_ray(q).is_empty():
				target = it
				break
	var y0: float = target.global_position.y
	lp.global_position = target.global_position + Vector3(0, 0.2, 1.8)
	for i in 90:
		w.rpc_id(1, "rpc_grab_update", target.item_id, Vector3(target.net_pos.x, y0 + 1.2, target.net_pos.z) if i > 3 else target.global_position, Vector3.ZERO)
		await get_tree().physics_frame
	await _wait(0.5)
	_check(target.global_position.y > y0 + 0.3, "client sees replicated lift (%.2f -> %.2f)" % [y0, target.global_position.y])
	w.rpc_id(1, "rpc_grab_release", target.item_id, Vector3.ZERO)
	w.send_chat("hello from client")
	# synthetic voice: 1 s of 440 Hz at the mix rate
	var buf := PackedVector2Array()
	var mr := AudioServer.get_mix_rate()
	for i in int(mr):
		var v := sin(TAU * 440.0 * i / mr) * 0.5
		buf.append(Vector2(v, v))
	for c in 4:
		w.voice.feed(buf.slice(c * int(mr / 4), (c + 1) * int(mr / 4)))
		await _wait(0.1)
	var tt := 0.0
	while not (main.world and main.world.shop_mode) and tt < 25.0:
		await _wait(0.5)
		tt += 0.5
	await _wait(2.0)
	_check(main.world != null and main.world.shop_mode, "client moved to shop")
	var shop_n := 0
	for it in main.world.items.values():
		if it.is_shop():
			shop_n += 1
	_check(shop_n >= 10, "client sees shop stock: %d" % shop_n)
	_check(Net.money > 0, "client got team cash: %d" % Net.money)
	_finish()


func _shots() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(false)
	await _wait(2.5)
	var w = main.world
	var lp = w.local_player
	Net.inv[lp.peer_id] = [{"t": "w_shotgun", "b": 0.7}, null, {"t": "g_explosive", "b": 1.0}]
	await _shot("1_spawn")
	# look at an item room
	lp.global_position = LevelGenCenter(w, 1) + Vector3(0, 0.1, 2.5)
	lp.yaw = 0.0
	await _wait(1.0)
	await _shot("2_room")
	# grab something: bring a vase into the garage and hold it
	var target = null
	for it in w.items.values():
		if it.type in ["vase", "camera", "figurine", "flasks"]:
			target = it
			break
	lp.global_position = w.truck_pos + Vector3(0, 0.1, 0)
	lp.yaw = 0.0
	lp.pitch = -0.1
	target.teleport(w.truck_pos + Vector3(0.3, 1.0, -2.0))
	target.linear_velocity = Vector3.ZERO
	await _wait(0.8)
	lp.grabbed_id = target.item_id
	lp.grab_offset = Vector3.ZERO
	lp.hold_dist = 2.0
	for i in 6:
		await _wait(0.25)
		print("[DBG] item=", w.items.has(target.item_id), " pos=", target.global_position, " grabs=", w.grabs, " beam=", lp.beam.visible, " lp=", lp.global_position, " grabbed=", lp.grabbed_id)
	await _shot("3_grab")
	lp.release(Vector3.ZERO)
	# extraction point view
	var e: Dictionary = w.extr[0]
	lp.global_position = e["pos"] + Vector3(0, 0.05, 3.2)
	lp.yaw = 0.0
	lp.pitch = -0.25
	await _wait(1.0)
	await _shot("4_extraction")
	# monster view
	var m = w.monsters.values()[0]
	m.dormant = 999.0
	lp.global_position = m.global_position + Vector3(0, 0, 3.0)
	lp.yaw = 0.0
	lp.pitch = 0.1
	await _wait(1.0)
	await _shot("5_monster")
	w.hud._toggle_pause()
	await _wait(0.5)
	await _shot("6_pause")
	w.hud._toggle_pause()
	# holding a tracker in the van next to the charger
	lp.global_position = w.truck_pos + Vector3(0, 0.1, 0)
	var tid: int = w.spawn_item("t_extract", 0, lp.eye_pos() + lp.look_dir() * 1.0, Quaternion.IDENTITY, 0)
	await _wait(0.3)
	lp.grab_direct(tid)
	lp.yaw = PI * 0.5
	lp.pitch = -0.3
	await _wait(1.0)
	await _shot("7_tracker")
	get_tree().quit()


func LevelGenCenter(w, idx: int) -> Vector3:
	var c: Vector2i = w.gen.order[mini(idx, w.gen.order.size() - 1)]
	return Vector3(c.x * 8.0, 0.0, c.y * 8.0)


func _menu_shots() -> void:
	main.show_menu()
	await _wait(0.8)
	await _shot("m1_menu")
	main.show_help()
	await _wait(0.5)
	await _shot("m2_help")
	Net.start_solo(false)
	await _wait(1.0)
	Net.server_level_complete(12340, 9000)
	await _wait(0.8)
	await _shot("m3_shop")
	main.show_settings()
	await _wait(0.5)
	await _shot("m4_settings")
	var sp = get_tree().root.find_children("*", "Control", true, false).filter(func(c): return c.has_method("_show") and c.has_method("_build_hd"))
	if not sp.is_empty():
		sp[0]._show("tab_video")
		await _wait(0.3)
		await _shot("m4b_video")
	Net.host_game()
	Net.players[99] = {"name": "Friend", "color": 1}
	Net.players[98] = {"name": "Buddy", "color": 2}
	main.show_lobby()
	await _wait(0.8)
	await _shot("m5_lobby")
	Net.leave()
	main.show_join()
	await _wait(0.5)
	await _shot("m6_join")
	main.show_gameover({"level": 4, "earned": 45600})
	await _wait(0.5)
	await _shot("m7_gameover")
	get_tree().quit()


## Flat, empty test floor far from the level so random layouts can't block tests.
func _arena(w) -> Vector3:
	var c := Vector3(300, 0, 300)
	var sb := StaticBody3D.new()
	sb.collision_layer = 1
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(60, 1, 60)
	cs.shape = bs
	sb.add_child(cs)
	w.add_child(sb)
	sb.global_position = c - Vector3(0, 0.5, 0)
	return c + Vector3(0, 0.05, 0)


## Each monster type gets 8 s alone with a (non-hidden) player in an empty arena.
func _monsters() -> void:
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.level = 3
	Net.begin_level()
	await _wait(1.5)
	var w = main.world
	var lp = w.local_player
	for m in w.monsters.values():
		m.take_hit(99999.0)
	await _wait(1.0)
	var base: Vector3 = _arena(w)
	var MS = load("res://scripts/game/monster.gd")
	var only := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--only="):
			only = a.split("=")[1]
	for t in MS.TYPES.keys():
		if only != "" and t != only:
			continue
		lp.global_position = base + Vector3(0, 0.1, 3.0)
		Net.hp[lp.peer_id] = 100000.0
		lp.hp = 100000.0
		lp.yaw = 0.0
		lp.pitch = 0.0
		var pos := base + Vector3(0, 0.1, -3.0)
		if t == "eye":
			pos = base + Vector3(0, 3.2, -2.0)
		var id: int = w.spawn_monster(t, pos)
		var m = w.monsters[id]
		m.dormant = 0.0
		m.yaw = PI
		m.rotation.y = PI
		m.wait_t = 30.0
		var p0: Vector3 = m.global_position
		var moved := 0.0
		var states := {}
		for i in 40:
			await _wait(0.2)
			if not is_instance_valid(m):
				break
			states[m.state] = true
			moved = maxf(moved, m.global_position.distance_to(p0))
			if only != "":
				print("[DBG] t=%.1f st=%d pos=%s lp=%s cd=%.2f" % [i * 0.2, m.state, m.global_position, lp.global_position, m.cd])
			if lp.dead:
				break
		var dmg: float = 100000.0 - float(Net.hp.get(lp.peer_id, 0.0))
		print("[MON] %-10s moved=%.1f dmg=%.0f dead=%s states=%s" % [t, moved, dmg, lp.dead, states.keys()])
		if is_instance_valid(m) and m.state != 4:
			m.take_hit(99999.0)
		lp.apply_effect("carried", Vector3.ZERO, 0.0)
		await _wait(0.8)
	_finish()


func _features() -> void:
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.level = 2
	Net.begin_level()
	await _wait(1.5)
	var w = main.world
	_check(w.gen.location == 1, "level 2 is offices (loc=%d)" % w.gen.location)
	var types := {}
	for it in w.items.values():
		types[it.type] = true
	print("[TEST] item types: ", types.keys())
	_check(types.has("laptop") or types.has("computer") or types.has("figurine") or types.has("trophy"), "office items present")
	var lp = w.local_player
	for m in w.monsters.values():
		m.dormant = 999.0
	# crouch
	lp._set_crouch(true)
	_check(lp.crouching and lp.cap_shape.height < 1.2, "crouch shrinks capsule")
	lp._set_crouch(false)
	_check(not lp.crouching, "stand up")
	# mimic reveal
	var base: Vector3 = _arena(w)
	var mid: int = w.spawn_monster("mimic", base)
	var mm = w.monsters[mid]
	lp.global_position = base + Vector3(0, 0.1, 6.0)
	await _wait(0.6)
	_check(mm.disguised, "mimic disguised at distance")
	lp.global_position = base + Vector3(0, 0.1, 1.5)
	await _wait(0.6)
	_check(not mm.disguised and (mm.state == 2 or mm.state == 3), "mimic reveals when close (state=%d)" % mm.state)
	mm.take_hit(9999.0)
	await _wait(1.2)
	# watcher: creeps while unobserved, a direct look triggers a hunt
	var wid: int = w.spawn_monster("watcher", base + Vector3(0, 0, -4.8))
	var wm = w.monsters[wid]
	wm.dormant = 0.0
	lp.global_position = base + Vector3(0, 0.1, 2.0)
	lp.yaw = PI
	lp.pitch = 0.0
	await _wait(0.3)
	var p0: Vector3 = wm.global_position
	await _wait(1.5)
	print("[DBG] watcher p0=", p0, " now=", wm.global_position, " lp=", lp.global_position, " state=", wm.state, " base=", base)
	_check(wm.global_position.distance_to(p0) > 0.3, "watcher creeps when unobserved (%.2f)" % wm.global_position.distance_to(p0))
	var tow: Vector3 = wm.global_position - lp.global_position
	lp.yaw = atan2(-tow.x, -tow.z)
	await _wait(0.6)
	var ctr: Vector3 = wm.global_position + Vector3(0, 1.3, 0)
	print("[DBG] watcher d=%.2f dot=%.2f los=%s" % [lp.eye_pos().distance_to(ctr), lp.look_dir().dot((ctr - lp.eye_pos()).normalized()), wm._los(lp.eye_pos(), ctr)])
	_check(wm.state == 2, "watcher hunts when looked at (state=%d)" % wm.state)
	await _wait(0.4)
	_check(w.danger > 0.0, "danger level raised (%.2f)" % w.danger)
	wm.take_hit(99999.0)
	await _wait(0.5)
	lp.yaw = 0.0
	# --- hiding under furniture (REPO crawl)
	var roof := StaticBody3D.new()
	roof.collision_layer = 1
	var rcs := CollisionShape3D.new()
	var rbs := BoxShape3D.new()
	rbs.size = Vector3(1.6, 0.06, 1.0)
	rcs.shape = rbs
	roof.add_child(rcs)
	w.add_child(roof)
	var hpos: Vector3 = base + Vector3(0, 0.05, 2.0)
	lp.global_position = hpos
	roof.global_position = hpos + Vector3(0, 0.78, 0)
	lp._set_crouch(true)
	await _wait(0.4)
	_check(lp.under_cover, "crouched under a table counts as cover")
	var hid: int = w.spawn_monster("butcher", hpos + Vector3(0, 0.05, -3.5))
	var hm = w.monsters[hid]
	hm.dormant = 0.0
	hm.yaw = PI
	await _wait(2.5)
	_check(hm.state != 2 and float(hm.sus.get(lp.peer_id, 0.0)) < 0.5, "monster doesn't notice a hidden player (state=%d sus=%.2f)" % [hm.state, float(hm.sus.get(lp.peer_id, 0.0))])
	roof.queue_free()
	await _wait(0.1)
	lp._set_crouch(false)
	hm.global_position = hpos + Vector3(0, 0.05, -4.0)
	var tw: Vector3 = lp.global_position - hm.global_position
	hm.yaw = atan2(-tw.x, -tw.z)
	hm.rotation.y = hm.yaw
	hm.state = 0
	hm.wait_t = 20.0
	var t_spot := 0.0
	while not (hm.state in [2, 3, 5]) and t_spot < 3.0:
		await _wait(0.1)
		t_spot += 0.1
	_check(hm.state in [2, 3, 5] and t_spot > 0.5, "standing player is spotted after a delay (%.1fs)" % t_spot)
	hm.take_hit(99999.0)
	await _wait(0.5)
	# --- gear: inventory slots
	var pid: int = lp.peer_id
	var gid: int = w.spawn_item("w_pistol", 0, lp.eye_pos() + lp.look_dir() * 1.0, Quaternion.IDENTITY, 0)
	await _wait(0.3)
	w.gear.rpc_store(gid, 0)
	await _wait(0.3)
	_check(not w.items.has(gid) and Net.inv_of(pid)[0] != null and Net.inv_of(pid)[0]["t"] == "w_pistol", "store pistol in slot 1")
	w.gear.rpc_take(0)
	await _wait(0.5)
	_check(Net.inv_of(pid)[0] == null and lp.grabbed_id != -1, "take pistol from slot (held id=%d)" % lp.grabbed_id)
	var pistol = w.items.get(lp.grabbed_id)
	_check(pistol != null and pistol.type == "w_pistol", "held item is pistol")
	# --- pistol hitscan damages a monster and drains battery
	var bid: int = w.spawn_monster("brute", lp.global_position + Vector3(0, 0, -5.0))
	var bm = w.monsters[bid]
	bm.dormant = 999.0
	await _wait(0.4)
	var hpb: float = bm.hp
	var eye: Vector3 = lp.eye_pos()
	var aim: Vector3 = (bm.global_position + Vector3(0, 1.0, 0) - eye).normalized()
	if pistol:
		var b0: float = pistol.battery
		w.gear.rpc_use(pistol.item_id, eye, aim)
		await _wait(0.2)
		_check(bm.hp < hpb, "pistol hits monster (%.0f -> %.0f)" % [hpb, bm.hp])
		_check(pistol.battery < b0, "pistol uses battery (%.2f -> %.2f)" % [b0, pistol.battery])
	lp.force_release()
	await _wait(0.2)
	# --- melee
	var sid: int = w.spawn_item("w_sledge", 0, lp.eye_pos() + lp.look_dir() * 0.8, Quaternion.IDENTITY, 0)
	await _wait(0.2)
	bm.global_position = lp.global_position + Vector3(0, 0, -1.4)
	hpb = bm.hp
	w.gear.rpc_use(sid, lp.eye_pos(), Vector3(0, 0, -1))
	await _wait(0.2)
	_check(bm.hp < hpb and bm.stun_t > 0.0, "sledgehammer hits and stuns (%.0f -> %.0f)" % [hpb, bm.hp])
	# --- grenade
	if not is_instance_valid(bm) or bm.state == 4:
		bid = w.spawn_monster("brute", lp.global_position + Vector3(0, 0, -6.0))
		bm = w.monsters[bid]
		bm.dormant = 999.0
	bm.global_position = lp.global_position + Vector3(0, 0, -6.0)
	await _wait(0.2)
	hpb = bm.hp
	var grid: int = w.spawn_item("g_explosive", 0, bm.global_position + Vector3(0.6, 0.4, 0), Quaternion.IDENTITY, 0)
	await _wait(0.2)
	w.gear.rpc_use(grid, lp.eye_pos(), Vector3(0, 0, -1))
	await _wait(3.6)
	_check(not w.items.has(grid), "grenade exploded after fuse")
	_check(not is_instance_valid(bm) or bm.state == 4 or bm.hp < hpb, "explosion damages monster")
	# --- tranq sleeps a monster
	for om in w.monsters.values():
		if om.global_position.distance_to(lp.global_position) < 12.0:
			om.take_hit(99999.0)
	await _wait(1.0)
	var gm_id: int = w.spawn_monster("gremlin", lp.global_position + Vector3(0, 0, -4.0))
	var gm = w.monsters[gm_id]
	gm.dormant = 0.0
	var tq: int = w.spawn_item("w_tranq", 0, lp.eye_pos() + lp.look_dir() * 0.8, Quaternion.IDENTITY, 0)
	await _wait(0.3)
	var tdir: Vector3 = (gm.global_position + Vector3(0, 0.3, 0) - lp.eye_pos()).normalized()
	var tqq := PhysicsRayQueryParameters3D.create(lp.eye_pos(), lp.eye_pos() + tdir * 30.0, 1 | 4 | 8, [lp.get_rid(), w.items[tq].get_rid()])
	var th: Dictionary = lp.get_world_3d().direct_space_state.intersect_ray(tqq)
	print("[DBG] tranq ray hit: ", th.get("collider"), " gm=", gm, " d=", gm.global_position.distance_to(lp.global_position), " layer=", gm.collision_layer)
	w.gear.rpc_use(tq, lp.eye_pos(), tdir)
	await _wait(0.2)
	_check(gm.stun_t > 5.0, "tranquilizer puts monster to sleep (%.1f)" % gm.stun_t)
	# --- monsters can be grabbed and thrown
	var tgt: Vector3 = gm.global_position + Vector3(0, 1.2, 0)
	for i in 20:
		gm.grab_hold(tgt, Net.strength(pid) * 50.0 + 200.0)
		await get_tree().physics_frame
	_check(gm.state == 6, "light monster is lifted (state=%d)" % gm.state)
	gm.release_throw(Vector3(0, 2, -6))
	_check(gm.state == 7, "monster thrown")
	await _wait(1.5)
	# --- crystal feeds the charger
	var e0: float = Net.energy
	var cid: int = w.spawn_item("i_crystal", 0, lp.eye_pos() + lp.look_dir() * 0.8, Quaternion.IDENTITY, 0)
	await _wait(0.2)
	w.gear.rpc_use(cid, lp.eye_pos(), Vector3(0, 0, -1))
	await _wait(0.2)
	_check(Net.energy > e0, "energy crystal adds charges (%.1f -> %.1f)" % [e0, Net.energy])
	# --- tumble
	lp.stamina = 40.0
	lp._toggle_tumble()
	await _wait(0.3)
	_check(lp.tumbling, "tumble mode on")
	lp._toggle_tumble()
	await _wait(0.2)
	_check(not lp.tumbling, "tumble mode off")
	# --- cart value readout
	var cart = null
	for it in w.items.values():
		if it.type == "cart":
			cart = it
	_check(cart != null, "cart present in level")
	# minimap
	w.hud._toggle_map()
	await _wait(0.2)
	_check(w.visited.size() > 0, "visited cells tracked: %d" % w.visited.size())
	# ping
	w.rpc_ping(lp.global_position + Vector3(0, 0, -3))
	await _wait(0.2)
	_check(w.fx_root.get_child_count() > 0, "ping marker spawned")
	await _features19(w, lp, base)
	Net.level = 3
	Net.begin_level()
	await _wait(1.5)
	_check(main.world.gen.location == 2, "level 3 is lab")
	_finish()


## v1.9: chat + robot voice, drones (zero-g, recharge), rubber duck, wings, robot paint.
func _features19(w, lp, base: Vector3) -> void:
	w.send_chat("Привет, команда")
	await _wait(0.3)
	_check(w._bubbles.has(lp.peer_id), "chat bubble shown")
	_check(w.hud.chat_feed.get_child_count() > 0, "chat line in the feed")
	w.hud._toggle_chat()
	_check(w.hud.chat_open, "chat panel opens")
	await _wait(0.5)
	w.hud._send_chat(Settings.t("chat_q2"))
	await _wait(0.3)
	_check(not w.hud.chat_open, "chat closes after sending")
	_check(w.hud.chat_feed.get_child_count() >= 2, "quick phrase sent")
	# zero-gravity drone on a valuable
	lp.global_position = base + Vector3(0, 0.1, 3.0)
	var gid: int = w.spawn_item("trophy", 1000, base + Vector3(0, 0.3, 0), Quaternion.IDENTITY, 0)
	var zid: int = w.spawn_item("d_zerog", 0, base + Vector3(0.6, 0.4, 0), Quaternion.IDENTITY, 0)
	await _wait(0.8)
	var y0: float = w.items[gid].global_position.y
	w.gear.rpc_use(zid, base + Vector3(0.6, 0.8, 0.8), Vector3(-0.6, -0.5, -0.8))
	await _wait(1.2)
	var g = w.items[gid]
	_check(g.gravity_scale == 0.0, "zero-g drone removes gravity")
	lp.look_item = w.items[zid]
	w.hud._update_look(lp)
	_check(w.hud.lbl_look.text.contains(Settings.t("gd_d_zerog")), "shop gear shows what it does")
	_check(g.global_position.y > y0 + 0.15, "zero-g valuable floats (%.2f -> %.2f)" % [y0, g.global_position.y])
	# recharge drone on a drained pistol
	var pid2: int = w.spawn_item("w_pistol", 0, base + Vector3(-1.5, 0.3, 0), Quaternion.IDENTITY, 0)
	var rid: int = w.spawn_item("d_recharge", 0, base + Vector3(-1.5, 0.4, 0.6), Quaternion.IDENTITY, 0)
	await _wait(0.5)
	w.items[pid2].battery = 0.1
	w.gear.rpc_use(rid, base + Vector3(-1.5, 0.8, 1.2), Vector3(0, -0.4, -1))
	await _wait(2.0)
	_check(w.items[pid2].battery > 0.2, "recharge drone charges gear (%.2f)" % w.items[pid2].battery)
	# rubber duck: thrown near a monster it hops toward it
	var mid: int = w.spawn_monster("brute", base + Vector3(4.0, 0, -4.0))
	var mon = w.monsters[mid]
	mon.dormant = 999.0
	var hp0: float = mon.hp
	var did: int = w.spawn_item("w_duck", 0, base + Vector3(1.0, 1.5, -1.0), Quaternion.IDENTITY, 0)
	await _wait(0.2)
	var duck = w.items[did]
	duck.linear_velocity = Vector3(3.0, -7.0, -3.0)
	await _wait(2.5)
	_check(int(duck.get_meta("duck_hops", 0)) > 0, "duck bounces toward the monster (hops=%d)" % int(duck.get_meta("duck_hops", 0)))
	print("[TEST] duck monster hp ", hp0, " -> ", mon.hp)
	# wings: glide slows the fall while tumbling
	Net.upgrades[lp.peer_id]["wings"] = 1
	_check(Net.wing_time(lp.peer_id) > 1.0, "wings upgrade gives glide time")
	lp.global_position = base + Vector3(0, 7.0, 3.0)
	lp.velocity = Vector3.ZERO
	lp.stamina = 0.0
	await get_tree().physics_frame
	lp._toggle_tumble()
	Input.action_press("jump")
	await _wait(0.7)
	var gvy: float = lp.velocity.y
	var was_gliding: bool = lp.gliding
	Input.action_release("jump")
	_check(was_gliding and gvy > -2.5, "wings glide slows the fall (vy=%.2f)" % gvy)
	await _wait(1.5)
	lp._toggle_tumble()
	Net.upgrades[lp.peer_id]["wings"] = 0
	# robot paint
	_check(Net.COLORS.size() == 16, "16 robot colours")
	_check(lp.model != null, "robot model built with paint shader")


## v2.0 level variety: overview map (ceilings hidden) + views of a hall, a corridor and a small room.
func _roomshots() -> void:
	Settings.force_touch = true
	var lvl := int(OS.get_environment("HB_LEVEL")) if OS.get_environment("HB_LEVEL") != "" else 6
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.0)
	Net.level = lvl
	if OS.get_environment("HB_SEED") != "":
		Net.rpc("_load_level", int(OS.get_environment("HB_SEED")), lvl, 1)
	else:
		Net.begin_level()
	await _wait(3.0)
	var w = main.world
	var g = w.gen
	var halls := 0
	for r in g.rooms:
		if r.size() >= 2:
			halls += 1
	var cor := 0
	for c in g.inset:
		if g.inset[c] < 2.0:
			cor += 1
	print("[TEST] level %d cells=%d halls=%d corridors=%d small=%d" % [lvl, g.order.size(), halls, cor, g.inset.size() - cor])
	_check(g.order.size() > 8, "level has cells")
	for m in w.monsters.values():
		m.dormant = 999.0
		m.visible = false
	var lp = w.local_player
	w.hud.visible = false
	var dbg := OS.get_environment("HB_DBG")
	if dbg.contains("nohf"):
		w.env.fog_height_density = 0.0
	if dbg.contains("nofog"):
		w.env.fog_enabled = false
	if dbg.contains("nocone"):
		lp.set_light_cone(false)
	if dbg.contains("noprobe"):
		for n in g.root.get_children():
			if n is ReflectionProbe:
				n.queue_free()
	# 1) views
	var hall_c = null
	for r in g.rooms:
		if r.size() >= 3 or (r.size() == 2 and hall_c == null):
			hall_c = r
	if hall_c != null:
		var a: Vector3 = g.cell_center(hall_c[0])
		var b: Vector3 = g.cell_center(hall_c[hall_c.size() - 1])
		lp.global_position = a + (a - b).normalized() * 2.6 + Vector3(0, 0.1, 0)
		var dv: Vector3 = b - a
		lp.yaw = atan2(-dv.x, -dv.z)
		lp.pitch = -0.08
		await _wait(1.2)
		await _shot("room_hall")
	for c in g.inset:
		var hs: float = g.inset[c]
		var cc: Vector3 = g.cell_center(c)
		var d2 = null
		for d in g.DIRS:
			if g.conn.has(g.key(c, c + d)):
				d2 = Vector3(d.x, 0, d.y)
				break
		if d2 == null:
			continue
		lp.global_position = cc + d2 * 3.3 + Vector3(0, 0.1, 0)
		lp.yaw = atan2(d2.x, d2.z)
		lp.pitch = -0.05
		await _wait(1.0)
		await _shot("room_corridor" if hs < 2.0 else "room_small")
	# minimap with everything visited
	for c in g.order:
		w.visited[c] = true
	w.hud.visible = true
	w.hud._toggle_map()
	await _wait(0.4)
	await _shot("room_minimap")
	w.hud._toggle_map()
	w.hud.visible = false
	# 2) overview: hide ceilings, camera straight down
	var hide := StandardMaterial3D.new()
	hide.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	hide.albedo_color = Color(0, 0, 0, 0)
	var ceil_mats := []
	for k in g._mcache.keys():
		if str(k).begins_with("ceil"):
			ceil_mats.append(g._mcache[k])
	var stack := [g.root]
	while not stack.is_empty():
		var n = stack.pop_back()
		stack.append_array(n.get_children())
		if n is MeshInstance3D and n.mesh:
			for i in n.mesh.get_surface_count():
				if n.mesh.surface_get_material(i) in ceil_mats:
					n.set_surface_override_material(i, hide)
	var mn := Vector2(1e9, 1e9)
	var mx := Vector2(-1e9, -1e9)
	for c in g.order:
		mn = Vector2(minf(mn.x, c.x), minf(mn.y, c.y))
		mx = Vector2(maxf(mx.x, c.x), maxf(mx.y, c.y))
	var cam := Camera3D.new()
	cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	cam.size = maxf((mx.x - mn.x + 1.4) * 8.0 * 0.5625, (mx.y - mn.y + 1.4) * 8.0)
	w.add_child(cam)
	cam.global_position = Vector3((mn.x + mx.x) * 4.0, 40.0, (mn.y + mx.y) * 4.0)
	cam.rotation = Vector3(-PI / 2, 0, 0)
	cam.current = true
	cam.far = 100.0
	var dl := DirectionalLight3D.new()
	dl.rotation = Vector3(-1.2, 0.4, 0)
	dl.light_energy = 0.6
	w.add_child(dl)
	w.env.fog_enabled = false
	await _wait(1.0)
	await _shot("room_map")
	_finish()


## Monsters walk through corridor corners and small rooms of the v2.0 layouts.
func _nav_test() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.0)
	var tried := 0
	var ok_n := 0
	for sd in [11, 23, 37, 51, 77, 91]:
		Net.level = 6
		Net.rpc("_load_level", sd, 6, 1)
		await _wait(2.0)
		var w = main.world
		var g = w.gen
		for m in w.monsters.values():
			m.queue_free()
		w.monsters.clear()
		var lp = w.local_player
		lp.global_position = w.truck_pos + Vector3(0, 0.1, 0)
		for c in g.inset:
			var links := []
			for d in g.DIRS:
				if g.conn.has(g.key(c, c + d)):
					links.append(d)
			if links.size() < 2:
				continue
			var a: Vector2i = c + links[0]
			var b: Vector2i = c + links[1]
			var mid: int = w.spawn_monster("brute", g.cell_center(a) + Vector3(0, 0.1, 0))
			var mon = w.monsters[mid]
			mon.dormant = 999.0
			var target: Vector3 = g.cell_center(b)
			var trace := ["[TEST] path %s from %s" % [g.path_points(mon.global_position, target), mon.global_position]]
			var t := 0.0
			var fr := 0
			while t < 25.0 and mon.global_position.distance_to(target) > 1.2:
				fr += 1
				mon._move_to(target, 4.0, 1.0 / 60.0)
				await get_tree().physics_frame
				t += 1.0 / 60.0
				if fr % 60 == 0:
					trace.append("[TEST]   t=%.1f pos=%s path=%s stuck=%.2f spd=%.2f" % [t, mon.global_position, mon.path.slice(0, 3), mon.stuck_t, mon.speed_now])
			tried += 1
			var dd: float = mon.global_position.distance_to(target)
			if dd <= 1.2:
				ok_n += 1
			else:
				print("[TEST] nav stuck: inset ", c, " hs=", g.inset[c], " from ", a, " to ", b, " at ", mon.global_position, " d=", dd, " dest_theme=", g.cells[b], " hall=", g.rooms[g.room_of[b]].size())
				for line in trace.slice(trace.size() - 16):
					print(line)
				var sp: PhysicsDirectSpaceState3D = w.get_world_3d().direct_space_state
				for hy in [0.3, 1.0, 1.9]:
					var rq := PhysicsRayQueryParameters3D.create(mon.global_position + Vector3(0, hy, 0), target + Vector3(0, hy, 0), 1 | 2 | 4 | 8)
					rq.exclude = [mon.get_rid()]
					var rh := sp.intersect_ray(rq)
					print("[TEST]   ray y=", hy, " -> ", rh.get("position", "none"), " ", rh.get("collider", null))
				var shq := PhysicsShapeQueryParameters3D.new()
				shq.shape = mon.get_child(0).shape if mon.get_child(0) is CollisionShape3D else null
				for ch in mon.get_children():
					if ch is CollisionShape3D:
						shq.shape = ch.shape
						shq.transform = ch.global_transform
				shq.exclude = [mon.get_rid()]
				shq.collision_mask = 1 | 2 | 4
				print("[TEST]   overlaps ", sp.intersect_shape(shq, 8))
				var p0: Vector3 = mon.global_position
				var r2 = mon._move_to(target, 4.0, 1.0 / 60.0)
				print("[TEST]   move_to ret=", r2, " vel=", mon.velocity, " moved=", mon.global_position - p0, " path=", mon.path, " state=", mon.state, " grab_slow=", mon.grab_slow, " floor=", mon.is_on_floor(), " wall=", mon.is_on_wall())
				for k in mon.get_slide_collision_count():
					var cc2 = mon.get_slide_collision(k)
					print("[TEST]   c ", cc2.get_collider(), " n=", cc2.get_normal(), " p=", cc2.get_position())
				for k in mon.get_slide_collision_count():
					var col = mon.get_slide_collision(k).get_collider()
					print("[TEST]   hit ", col, " ", col.name if col else "", " pos=", mon.get_slide_collision(k).get_position())
			mon.queue_free()
			w.monsters.erase(mid)
			break
	print("[TEST] nav ok %d / %d" % [ok_n, tried])
	_check(tried > 0 and ok_n >= tried - 1, "monsters get through corridors and small rooms (%d/%d)" % [ok_n, tried])
	_finish()


## The menu shows "version X is out" when the server announces a newer release.
func _update_test() -> void:
	_check(Net.newer_version("2.10.0", "2.9.9") and not Net.newer_version("2.2", "2.2.0") and Net.newer_version("v3", "2.9") and not Net.newer_version("", "1.0"), "version comparison")
	Settings.relay_url = "http://127.0.0.1:8091"
	Settings.relay_region = "custom"
	Net._update_checked = false
	main.show_menu()
	var ok := false
	for i in 40:
		await _wait(0.25)
		if not Net.update_info.is_empty():
			ok = true
			break
	await _wait(0.3)
	_check(ok and str(Net.update_info.get("version", "")) == "9.9.9", "server announces 9.9.9 (%s)" % str(Net.update_info))
	_check(main.screen._update_slot.get_child_count() == 1, "the menu shows the update bar")
	_check(Net.update_link().ends_with(".apk") or OS.get_name() != "Android", "link: %s" % Net.update_link())
	if DisplayServer.get_name() != "headless":
		await _shot("upd_menu")
	_finish()


## Internet play screens against a local relay (tools: node server/relay.js on port 8089).
func _online_ui_test() -> void:
	print("[TEST] built-in relay: %s -> %s" % [Settings.relay_url, Net.relay_url()])
	_check(Net.relay_url() in ["wss://haulbots-relay.onrender.com", "wss://haulbots-relay-eu.onrender.com", "wss://haulbots-relay-us.onrender.com"] or FileAccess.file_exists(Settings.PATH), "built-in relay address on a fresh install (%s)" % Net.relay_url())
	_check(Settings.region_of_code("EAB3K") == "eu" and Settings.region_of_code("UQ7MM") == "us" and Settings.region_of_code("A2345") == "asia", "room code letter picks the region")
	Settings.relay_url = "http://127.0.0.1:8089"
	Settings.relay_region = "custom"
	Settings.player_name = "Tester"
	main.show_menu()
	await _wait(0.8)
	if DisplayServer.get_name() != "headless":
		await _shot("ol0_menu")
	main.show_online()
	await _wait(1.5)
	var scr = main.screen
	_check(main.screen_name == "online", "online screen opens")
	_check(scr.rooms_note.text == Settings.t("online_no_rooms") or scr.rooms_box.get_child_count() > 0, "public room list loads (%s)" % scr.rooms_note.text)
	if DisplayServer.get_name() != "headless":
		await _shot("ol1_online")
	# a wrong code: error message, back on the online screen
	scr.code_edit.text = "ZZZZZ"
	scr._join_code()
	var ok := false
	for i in 40:
		await _wait(0.25)
		if main.screen_name == "online" and i > 2:
			ok = true
			break
	_check(ok and Net.last_error == "no_room", "unknown code -> back to the screen with 'no room' (%s)" % Net.last_error)
	# create a public room: connecting screen, then the lobby with the code
	scr = main.screen
	scr.pub_check.button_pressed = true
	scr._create()
	ok = false
	for i in 60:
		await _wait(0.25)
		if main.screen_name == "lobby":
			ok = true
			break
	_check(ok and Net.relay_code.length() == 5, "create room -> lobby with code %s" % Net.relay_code)
	_check(Net.is_host() and Net.relay, "we host the online room")
	if DisplayServer.get_name() != "headless":
		await _shot("ol2_lobby")
	# the room shows up in the public list for others
	var lister = preload("res://scripts/autoload/relay_peer.gd").new()
	var got := []
	lister.rooms_listed.connect(func(r): got.append_array(r))
	lister.list_rooms(Net.relay_url(), Net.GAME_ID)
	for i in 40:
		lister.poll()
		await _wait(0.1)
		if got.size() > 0:
			break
	_check(got.any(func(r): return r.get("code", "") == Net.relay_code), "our public room is listed (%s)" % str(got))
	Net.leave()
	main.show_menu()
	await _wait(0.5)
	# no server address: clear message
	Settings.relay_url = ""
	main.show_online()
	await _wait(0.5)
	_check(main.screen.server_box.visible, "without an address the server field is open")
	_finish()


func _mev(kind: String, p: Vector2) -> void:
	var ev: InputEvent
	if kind == "move":
		var mm := InputEventMouseMotion.new()
		mm.button_mask = MOUSE_BUTTON_MASK_LEFT
		ev = mm
	else:
		var mb := InputEventMouseButton.new()
		mb.button_index = MOUSE_BUTTON_LEFT
		mb.pressed = kind == "down"
		if mb.pressed:
			mb.button_mask = MOUSE_BUTTON_MASK_LEFT
		ev = mb
	ev.position = p
	ev.global_position = p
	get_viewport().push_input(ev, true)
	await get_tree().process_frame


func _drag(a: Vector2, b: Vector2, steps := 10, release := true) -> void:
	await _mev("down", a)
	for i in range(1, steps + 1):
		await _mev("move", a.lerp(b, float(i) / steps))
	if release:
		await _mev("up", b)


## Settings list scrolls with a finger even when the drag starts on a slider, switch, dropdown or button.
func _scroll_test() -> void:
	main.show_settings()
	await _wait(0.8)
	var sp: Node = main.find_children("*", "Control", true, false).filter(func(n): return n.get_script() == preload("res://scripts/ui/settings_panel.gd"))[0]
	sp._show("tab_video")
	await _wait(0.4)
	var sc: ScrollContainer = sp._scroll
	var maxs: float = sc.get_v_scroll_bar().max_value - sc.get_v_scroll_bar().page
	print("[TEST] video tab: scroll range %.0f px, area %s" % [maxs, sc.get_global_rect()])
	_check(maxs > 50.0, "video tab is longer than the view (%.0f px to scroll)" % maxs)
	var in_view := func(c: Control) -> bool:
		var r: Rect2 = c.get_global_rect()
		return sc.get_global_rect().encloses(r)
	# 1) drag up starting on a slider: list scrolls, slider keeps its value
	var sliders: Array = sc.find_children("*", "HSlider", true, false).filter(func(x): return x.is_visible_in_tree() and in_view.call(x))
	_check(not sliders.is_empty(), "a slider is on screen")
	if not sliders.is_empty():
		var sl: HSlider = sliders[0]
		var v0 := sl.value
		var r: Rect2 = sl.get_global_rect()
		var a := r.position + Vector2(r.size.x * 0.25, r.size.y * 0.5)
		sc.scroll_vertical = 0
		await _drag(a, a + Vector2(0, -160))
		await _wait(0.1)
		_check(sc.scroll_vertical > 100, "drag that starts on a slider scrolls the list (%d px)" % sc.scroll_vertical)
		_check(absf(sl.value - v0) < 0.0001, "the slider keeps its value (%.2f -> %.2f)" % [v0, sl.value])
	# 2) drag starting on a switch: scrolls, the switch does not flip; a tap still flips it
	sc.get_node("TouchScroll").stop()
	sc.scroll_vertical = 250
	await _wait(0.3)
	var toggles: Array = sc.find_children("*", "CheckButton", true, false).filter(func(x): return x.is_visible_in_tree() and in_view.call(x))
	_check(not toggles.is_empty(), "a switch is on screen")
	if not toggles.is_empty():
		var cb: CheckButton = toggles[0]
		var st := cb.button_pressed
		var s0 := sc.scroll_vertical
		var c := cb.get_global_rect().get_center()
		await _drag(c, c + Vector2(0, -140))
		await _wait(0.1)
		_check(sc.scroll_vertical > s0 + 90 and cb.button_pressed == st, "drag on a switch scrolls without flipping it (%d -> %d px, %s -> %s)" % [s0, sc.scroll_vertical, st, cb.button_pressed])
		sc.get_node("TouchScroll").stop()
		sc.scroll_vertical = s0
		await _wait(0.3)
		if in_view.call(cb):
			c = cb.get_global_rect().get_center()
			await _mev("down", c)
			await _mev("up", c)
			await _wait(0.1)
			_check(cb.button_pressed != st, "a tap flips the switch")
			await _mev("down", c)
			await _mev("up", c)
	# 3) drag on a dropdown: no list pops up
	sc.get_node("TouchScroll").stop()
	sc.scroll_vertical = 0
	await _wait(0.2)
	var opts: Array = sc.find_children("*", "OptionButton", true, false).filter(func(x): return x.is_visible_in_tree() and in_view.call(x))
	if not opts.is_empty():
		var ob: OptionButton = opts[0]
		var c2 := ob.get_global_rect().get_center()
		await _drag(c2, c2 + Vector2(0, -140))
		await _wait(0.2)
		_check(not ob.get_popup().visible, "drag on a dropdown scrolls without opening it")
		_check(sc.scroll_vertical > 90, "... and the list moved (%d px)" % sc.scroll_vertical)
		# a plain tap still opens it
		sc.get_node("TouchScroll").stop()
		sc.scroll_vertical = 0
		await _wait(0.3)
		c2 = ob.get_global_rect().get_center()
		await _mev("down", c2)
		await _mev("up", c2)
		await _wait(0.2)
		_check(ob.get_popup().visible, "a tap opens the dropdown")
		ob.get_popup().hide()
		await _wait(0.2)
	# 4) a sideways drag on a slider moves the slider, not the list
	sc.get_node("TouchScroll").stop()
	sc.scroll_vertical = 0
	await _wait(0.2)
	if not sliders.is_empty():
		var sl2: HSlider = sliders[0]
		var v1 := sl2.value
		var r2: Rect2 = sl2.get_global_rect()
		var b0 := r2.position + Vector2(r2.size.x * 0.3, r2.size.y * 0.5)
		await _drag(b0, b0 + Vector2(r2.size.x * 0.4, 4))
		await _wait(0.1)
		_check(sl2.value != v1 and sc.scroll_vertical < 10, "sideways drag adjusts the slider (%.2f -> %.2f), list stays (%d)" % [v1, sl2.value, sc.scroll_vertical])
		sl2.value = v1
	# 5) a flick keeps rolling after the finger lifts
	sc.get_node("TouchScroll").stop()
	sc.scroll_vertical = 0
	await _wait(0.3)
	await _wait(0.2)
	var f0 := sc.get_global_rect().get_center() + Vector2(0, 120)
	await _mev("down", f0)
	for i in range(1, 6):
		await _mev("move", f0 + Vector2(0, -24.0 * i))
	await _mev("up", f0 + Vector2(0, -120))
	var at_release := sc.scroll_vertical
	await _wait(0.5)
	_check(sc.scroll_vertical > at_release + 10 or sc.scroll_vertical >= int(maxs) - 2, "a flick keeps the list rolling (%d -> %d)" % [at_release, sc.scroll_vertical])
	if DisplayServer.get_name() != "headless":
		await _shot("scroll_settings")
	_finish()


## Loot must sit still where it spawns: no piece inside furniture (shoved out, damaged) or in a wall.
func _spawns_test() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.0)
	var bad := 0
	var total := 0
	for sd in [3, 17, 29, 41, 58, 64, 73, 88, 95, 102, 117, 131]:
		for lvl in [2, 4, 6, 9]:
			Net.level = lvl
			Net.rpc("_load_level", sd, lvl, 1)
			var w = null
			for f in 300:
				await get_tree().physics_frame
				w = main.world
				if w != null and w.started and w.items.size() > 5:
					break
			var start := {}
			for it in w.items.values():
				if it.base_value > 0:
					start[it.item_id] = [it.global_position, it.value]
			await _wait(3.0)
			for id in start:
				total += 1
				var it = w.items.get(id)
				if it == null:
					bad += 1
					print("[TEST]   seed %d L%d: item %d broke right after spawning at %s" % [sd, lvl, id, start[id][0]])
					continue
				var moved: float = it.global_position.distance_to(start[id][0])
				if moved > 0.9 or it.value < int(start[id][1]) or it.global_position.y < -0.5:
					bad += 1
					print("[TEST]   seed %d L%d: %s spawned %s -> %s (moved %.2f), value %d -> %d, cell %s theme %s" % [sd, lvl, it.type, start[id][0], it.global_position, moved, int(start[id][1]), it.value, w.gen.cell_at(start[id][0]), w.gen.cells.get(w.gen.cell_at(start[id][0]), "-")])
	print("[TEST] spawn check: %d of %d pieces moved/damaged" % [bad, total])
	_check(bad <= total / 100, "loot stays where it spawned (%d of %d moved or damaged)" % [bad, total])
	_finish()


## Monsters chasing a robot into the van climb the ramp at its back instead of grinding its side.
func _vanchase() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.5)
	var w = main.world
	var g = w.gen
	for m in w.monsters.values():
		m.queue_free()
	w.monsters.clear()
	var lp = w.local_player
	var me: int = lp.peer_id
	var tb: Vector3 = g.truck_pos - Vector3(0, 0.5, 0)
	for sk in [1.0, -1.0]:
		for t in ["lurker", "skitter", "butcher", "gremlin", "brute"]:
			Net.hp[me] = 100.0
			lp.hp = 100.0
			lp.global_position = g.spawn_points[0]
			lp.velocity = Vector3.ZERO
			await _wait(0.3)
			var start: Vector3 = tb + g.truck_side * sk * 2.3 + g.truck_back * 0.8 + Vector3(0, 0.1, 0)
			var mid: int = w.spawn_monster(t, start)
			var m = w.monsters[mid]
			m.dormant = 0.0
			m.lurking = false
			m.sus[me] = 1.0
			m.target_pid = me
			m.state = 2    # CHASE
			var hp0 := float(Net.hp.get(me, 100.0))
			var hurt := false
			var gave_up := false
			var t0 := 0.0
			var tall: bool = float(m.cfg["height"]) > 2.05
			while t0 < 22.0:
				await _wait(0.25)
				t0 += 0.25
				lp.global_position = g.spawn_points[0]
				if float(Net.hp.get(me, 100.0)) < hp0:
					hurt = true
					break
				if m.state == 0 or m.state == 1:
					gave_up = true
					break
			print("[TEST]   %s (%s) from side %d: at %s after %.1fs, in van %s, state %d, hurt %s, gave up %s" % [t, "tall" if tall else "fits", int(sk), m.global_position, t0, g.in_van(m.global_position), m.state, hurt, gave_up])
			if tall:
				_check(hurt or gave_up, "%s (too tall for the van) attacks from the door or gives up (%.1fs)" % [t, t0])
			else:
				_check(hurt, "%s climbs the ramp and reaches the robot in the van (%.1fs)" % [t, t0])
			m.queue_free()
			w.monsters.erase(mid)
			await _wait(0.3)
	_finish()


func _fling_test() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(2.0)
	var w = main.world
	var base: Vector3 = _arena(w)
	w.local_player.global_position = base + Vector3(0, 0.1, 8.0)
	for t in ["bighead", "projector", "hunter", "watcher", "lurker", "howler", "skitter", "spewer", "levitator"]:
		var mid: int = w.spawn_monster(t, base)
		var m = w.monsters[mid]
		m.lurking = false
		m.dormant = 9999.0
		await _wait(0.5)
		var hp0: float = m.hp
		var iid: int = w.spawn_item("microscope", 3000, m.global_position + Vector3(0, 1.2, 2.2), Quaternion.IDENTITY, 0)
		await _wait(1.3)
		var it = w.items[iid]
		it.body_entered.connect(func(b): print("[TEST]   contact ", b, " speed ", it.last_vel.length()))
		print("[TEST]   mon layer ", m.collision_layer, " mask ", m.collision_mask, " item mask ", it.collision_mask, " layer ", it.collision_layer, " mon pos ", m.global_position, " children ", m.get_children().filter(func(c): return c is CollisionShape3D).size())
		it.teleport(m.global_position + Vector3(0, 1.2, 2.2))
		it.linear_velocity = (m.global_position + Vector3(0, float(m.cfg["height"]) * 0.5, 0) - it.global_position).normalized() * 9.0
		for i in 30:
			await get_tree().physics_frame
		print("[TEST] fling %s: hp %.0f -> %.0f, item at %s vel %s" % [t, hp0, m.hp, it.global_position, it.linear_velocity])
		m.queue_free()
		w.monsters.erase(mid)
		w.remove_item(iid, 0)
		await _wait(0.3)
	_finish()


func _loc_shots() -> void:
	Settings.force_touch = true
	Net.delete_save()
	for lvl in [2, 3]:
		Net.start_solo(true)
		Net._new_run()
		Net.level = lvl
		Net.begin_level()
		await _wait(2.0)
		var w = main.world
		for m in w.monsters.values():
			m.dormant = 999.0
		var lp = w.local_player
		var c: Vector2i = w.gen.order[mini(2, w.gen.order.size() - 1)]
		lp.global_position = w.gen.cell_center(c) + Vector3(0, 0.1, 3.0)
		lp.yaw = 0.0
		lp.pitch = -0.1
		await _wait(1.0)
		await _shot("loc%d" % lvl)
		if lvl == 3:
			var base: Vector3 = w.gen.cell_center(c)
			var mid: int = w.spawn_monster("mimic", base + Vector3(-0.8, 0.05, 0))
			var wid: int = w.spawn_monster("watcher", base + Vector3(1.0, 0, -1.0))
			w.monsters[wid].dormant = 999.0
			await _wait(0.8)
			await _shot("monsters2")
			w.monsters[mid].reveal(1)
			await _wait(0.6)
			lp.global_position = base + Vector3(0, 0.1, 3.0)
			await _wait(0.1)
			await _shot("mimic_open")
			w.hud._toggle_map()
			await _wait(0.3)
			await _shot("map")
	get_tree().quit()


func _soak() -> void:
	var t0 := Time.get_ticks_usec()
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.level = 6
	Net.difficulty = 2
	var t1 := Time.get_ticks_usec()
	Net.begin_level()
	print("[TEST] level build ms: ", (Time.get_ticks_usec() - t1) / 1000.0)
	var w = main.world
	await _wait(1.0)
	print("[TEST] rooms=", w.gen.order.size(), " items=", w.items.size(), " monsters=", w.monsters.size())
	for m in w.monsters.values():
		m.dormant = 0.0
	var lp = w.local_player
	lp.hp = 1e9
	Net.hp[1] = 1e9
	var phys := 0.0
	var proc := 0.0
	var n := 0
	var worst := 0.0
	var r := RandomNumberGenerator.new()
	for sec in 60:
		if sec % 5 == 0:
			lp.global_position = w.gen.random_point(r)
		# throw random items around to stress physics
		for it in w.items.values():
			if r.randf() < 0.02 and it.mass < 10.0:
				it.apply_central_impulse(Vector3(r.randf_range(-1, 1), 1.0, r.randf_range(-1, 1)) * it.mass * 3.0)
		for f in 10:
			await get_tree().create_timer(0.1).timeout
			var pp := Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0
			phys += pp
			proc += Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0
			worst = maxf(worst, pp)
			n += 1
	print("[TEST] avg physics ms=%.2f avg process ms=%.2f worst physics ms=%.2f" % [phys / n, proc / n, worst])
	print("[TEST] items left=", w.items.size(), " monsters=", w.monsters.size(), " mem MB=", OS.get_static_memory_usage() / 1048576.0)
	_check(phys / n < 8.0, "physics budget ok")
	_check(w.monsters.size() > 0, "monsters survive soak")
	_finish()


func _gallery() -> void:
	var ML = load("res://scripts/game/matlib.gd")
	var names := []
	var filt := ""
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--filter="):
			filt = a.split("=")[1]
	for f in DirAccess.get_files_at("res://assets/models"):
		if not f.ends_with(".glb"):
			continue
		var ok := filt == ""
		for pre in filt.split(",", false):
			if f.begins_with(pre):
				ok = true
		if ok:
			names.append(f.get_basename())
	names.sort()
	var root := Node3D.new()
	main.add_child(root)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.12, 0.12, 0.14)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.6, 0.6, 0.7)
	env.ambient_light_energy = 0.5
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sky.sky_material = sm
	env.sky = sky
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	we.environment = env
	root.add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation = Vector3(-0.8, 0.6, 0)
	sun.light_energy = 1.2
	root.add_child(sun)
	var cols := int(ceil(sqrt(names.size() * 1.6)))
	var sp := 0.75
	var big := false
	for a in OS.get_cmdline_user_args():
		if a == "--big":
			big = true
			sp = 3.0
	for i in names.size():
		var m: Node3D = ML.model(names[i])
		if m == null:
			continue
		root.add_child(m)
		var x := (i % cols) * sp
		var z := (i / cols) * sp * 0.9
		m.position = Vector3(x, 0.0, z)
		m.rotation.y = 0.5
		var l := Label3D.new()
		l.text = names[i]
		l.font_size = 28 if not big else 64
		l.pixel_size = 0.003
		l.position = Vector3(x, -0.4 if not big else -0.3, z + 0.3)
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		root.add_child(l)
	var cam := Camera3D.new()
	root.add_child(cam)
	var w := (cols - 1) * sp
	var rows := int(ceil(names.size() / float(cols)))
	var d := (rows - 1) * sp * 0.9
	cam.position = Vector3(w / 2.0, max(w, d) * 0.32 + 0.5, d + max(w, d) * 0.3 + 0.7)
	cam.look_at(Vector3(w / 2.0, 0, d / 2.0))
	cam.current = true
	await _wait(1.0)
	await _shot("gallery")
	get_tree().quit()


## One framed 3/4 shot per model: --filter=a,b,c  -> user://por_<name>.png
func _portraits() -> void:
	var ML = load("res://scripts/game/matlib.gd")
	var names := []
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--filter="):
			names = Array(a.split("=")[1].split(",", false))
	var root := Node3D.new()
	main.add_child(root)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.16, 0.16, 0.19)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.55, 0.56, 0.62)
	env.ambient_light_energy = 0.6
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	we.environment = env
	root.add_child(we)
	var key := DirectionalLight3D.new()
	key.rotation = Vector3(-0.7, 0.5, 0)
	key.light_energy = 1.5
	key.shadow_enabled = true
	root.add_child(key)
	var rim := DirectionalLight3D.new()
	rim.rotation = Vector3(-0.3, PI + 0.6, 0)
	rim.light_energy = 0.7
	rim.light_color = Color(0.7, 0.8, 1.0)
	root.add_child(rim)
	var floor_mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(20, 20)
	floor_mi.mesh = pm
	floor_mi.material_override = ML.plain(Color(0.22, 0.22, 0.25), 0.9)
	root.add_child(floor_mi)
	var cam := Camera3D.new()
	cam.fov = 35
	root.add_child(cam)
	cam.current = true
	for n in names:
		var m: Node3D = ML.model(n)
		if m == null:
			continue
		root.add_child(m)
		await get_tree().process_frame
		var aabb := AABB()
		var first := true
		for mi in m.find_children("*", "MeshInstance3D", true, false):
			var b: AABB = mi.global_transform * mi.get_aabb()
			aabb = b if first else aabb.merge(b)
			first = false
		var c := aabb.get_center()
		var r := maxf(aabb.size.length() * 0.5, 0.1)
		floor_mi.position.y = aabb.position.y
		var dir := Vector3(0.55, 0.35, -1.0).normalized()
		cam.position = c + dir * r / tan(deg_to_rad(cam.fov * 0.5)) * 1.05
		cam.look_at(c)
		await _wait(0.4)
		await _shot("por_" + n)
		m.queue_free()
		await get_tree().process_frame
	get_tree().quit()


func _animshot() -> void:
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.level = 3
	Net.begin_level()
	await _wait(1.5)
	var w = main.world
	var lp = w.local_player
	for m in w.monsters.values():
		m.take_hit(99999.0)
	await _wait(0.8)
	var base: Vector3 = _arena(w)
	var lt := OmniLight3D.new()
	lt.omni_range = 20.0
	lt.light_energy = 3.0
	w.add_child(lt)
	lt.global_position = base + Vector3(0, 4, 2)
	lp.global_position = base + Vector3(0, 0.1, 6.0)
	lp.yaw = 0.0
	Net.hp[lp.peer_id] = 100000.0
	lp.hp = 100000.0
	var types := ["butcher", "brute", "projector", "watcher", "lurker"]
	for i in types.size():
		var id: int = w.spawn_monster(types[i], base + Vector3(-4.0 + i * 2.0, 0.1, -4.0))
		var m = w.monsters[id]
		m.dormant = 0.0
	await _wait(1.3)
	await _shot("anim1")
	await _wait(0.25)
	await _shot("anim2")
	get_tree().quit()


func _shopshot() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.money = 42000
	Net.level = 2
	Net.begin_shop({"level": 1, "extracted": 42000, "quota": 30000})
	await _wait(2.0)
	var w = main.world
	var lp = w.local_player
	var cc: Vector3 = w.gen.cell_center(Vector2i(1, 0))
	lp.global_position = cc + Vector3(-3.0, 0.1, 0)
	lp.yaw = -PI / 2
	lp.pitch = -0.05
	await _wait(1.0)
	await _shot("shop1")
	lp.global_position = w.gen.checkout_pos + Vector3(-3.5, 0.1, 1.0)
	lp.yaw = -PI / 2 + 0.25
	await _wait(0.2)
	var n := 0
	for it in w.items.values():
		if it.is_shop() and n < 3:
			it.teleport(w.gen.checkout_pos + Vector3(-0.5 + n * 0.5, 0.4, 0))
			n += 1
	await _wait(1.2)
	await _shot("shop2")
	w._try_buy()
	await _wait(2.3)
	await _shot("shop2b")
	await _wait(1.5)
	lp.global_position = w.gen.spawn_points[0]
	lp.yaw = w.gen.truck_back.signed_angle_to(Vector3.FORWARD, Vector3.UP) + PI
	await _wait(0.8)
	await _shot("shop3")
	get_tree().quit()


## Render cost probe: draw calls / objects / primitives at several spots, occlusion on vs off.
func _perf() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(3.0)
	var w = main.world
	var lp = w.local_player
	var cells: Array = w.gen.order
	var tot := {true: [0, 0, 0], false: [0, 0, 0]}
	var n := 0
	for i in mini(8, cells.size()):
		var c: Vector2i = cells[(i * 3) % cells.size()]
		lp.global_position = w.gen.cell_center(c) + Vector3(0.5, 0.1, 0.5)
		for yaw in [0.0, PI / 2, PI, -PI / 2]:
			lp.yaw = yaw
			for occ in [true, false]:
				get_viewport().use_occlusion_culling = occ
				await get_tree().process_frame
				await get_tree().process_frame
				await get_tree().process_frame
				var dc := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)
				var ob := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME)
				var pr := RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME)
				tot[occ][0] += dc
				tot[occ][1] += ob
				tot[occ][2] += pr
			n += 1
	for occ in [true, false]:
		print("[PERF] occlusion=%s  draw_calls=%d objects=%d primitives=%d" % [occ, tot[occ][0] / n, tot[occ][1] / n, tot[occ][2] / n])
	get_viewport().use_occlusion_culling = true
	_finish()


func _cartshot() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(false)
	await _wait(2.5)
	var w = main.world
	var lp = w.local_player
	var cart = null
	for it in w.items.values():
		if it.type == "cart":
			cart = it
	var n := 0
	for it in w.items.values():
		if it.base_value > 0 and n < 2 and it.type in ["trophy", "vase", "camera", "figurine", "gem", "laptop"]:
			it.teleport(cart.global_position + Vector3(-0.2 + n * 0.4, 0.4, 0))
			n += 1
	await _wait(1.5)
	var cx: Vector3 = cart.global_transform.basis.x
	lp.global_position = cart.global_position + Vector3(0, 0.1, 0) + cart.global_transform.basis.z * 2.0 - cx * 0.6
	lp.yaw = atan2(cart.global_transform.basis.z.x, cart.global_transform.basis.z.z)
	lp.pitch = -0.45
	await _wait(1.0)
	await _shot("cart1")
	lp.global_position = cart.global_position - cx * 1.9 + Vector3(0, 0.1, 0)
	lp.yaw = atan2(-cx.x, -cx.z)
	lp.pitch = -0.4
	await _wait(0.6)
	await _shot("cart2")
	_finish()


func _extrshot() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.difficulty = 1
	Net.start_solo(false)
	await _wait(2.5)
	var w = main.world
	var lp = w.local_player
	var e: Dictionary = w.extr[0]
	var cdir: Vector3 = (e.get("console", e["pos"] + Vector3(2.15, 0, 0)) - e["pos"])
	cdir.y = 0.0
	cdir = cdir.normalized()
	lp.global_position = e["pos"] - cdir * 3.2 + Vector3(-cdir.z, 0, cdir.x) * 1.6 + Vector3(0, 0.1, 0)
	print("[TEST] console dir ", cdir)
	lp.yaw = atan2(-(e["pos"].x - lp.global_position.x), -(e["pos"].z - lp.global_position.z)) + PI
	lp.yaw = atan2(lp.global_position.x - e["pos"].x, lp.global_position.z - e["pos"].z)
	lp.pitch = -0.12
	await _wait(1.0)
	await _shot("x1_idle")
	var k := 0
	for it in w.items.values():
		if it.base_value > 0:
			it.teleport(e["pos"] + Vector3(-0.8 + (k % 4) * 0.5, 0.5 + (k / 4) * 0.4, -0.6 + (k % 3) * 0.5))
			k += 1
	await _wait(2.0)
	await _shot("x2_ready")
	w._try_extract(0)
	await _wait(3.0)
	await _shot("x3_tube")
	await _wait(1.2)
	await _shot("x4_after")
	_finish()


func _surplus() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.5)
	Net.level = 3
	Net.begin_level()
	await _wait(3.0)
	var w = main.world
	_check(w.extr.size() >= 2, "level 3 has %d points" % w.extr.size())
	var e: Dictionary = w.extr[0]
	var k := 0
	for it in w.items.values():
		if it.base_value > 0:
			it.teleport(e["pos"] + Vector3(-0.8 + (k % 4) * 0.5, 0.5 + (k / 4) * 0.4, -0.6 + (k % 3) * 0.5))
			k += 1
	await _wait(2.5)
	var v: int = e["value"]
	var goal: int = e["goal"]
	_check(v > goal, "overshoot %d > %d" % [v, goal])
	w._try_extract(0)
	await _wait(4.5)
	var bag = null
	for it in w.items.values():
		if it.type == "moneybag":
			bag = it
	_check(bag != null, "surplus money bag spawned")
	if bag:
		_check(bag.value > 0 and bag.value <= v - goal + 50, "bag value %d ~ surplus %d (items that slid off the pad don't count)" % [bag.value, v - goal])
	_check(w.level_extracted == goal, "only goal counted so far (%d)" % w.level_extracted)
	_check(w.active_extr == 1, "next point active")
	# protection: a valuable dropped onto the active pad or into the cart keeps its value
	var e2: Dictionary = w.extr[1]
	var vic = null
	for it in w.items.values():
		if it.base_value > 0 and it.type != "moneybag" and it.fragility > 0.5:
			vic = it
			break
	if vic == null:
		var vid: int = w.spawn_item("vase", 3000, e2["pos"] + Vector3(0, 2.2, 0), Quaternion.IDENTITY, 0)
		vic = w.items[vid]
	var v0: int = vic.value
	vic.teleport(e2["pos"] + Vector3(0.3, 2.2, 0.2))
	vic.linear_velocity = Vector3(0, -6.0, 0)
	await _wait(2.0)
	_check(vic.value == v0, "no damage on the pad (%d -> %d)" % [v0, vic.value])
	var cart = null
	for it in w.items.values():
		if it.type == "cart":
			cart = it
	vic.teleport(cart.global_position + Vector3(0, 1.8, 0))
	vic.linear_velocity = Vector3(0, -6.0, 0)
	await _wait(2.0)
	_check(vic.value == v0, "no damage in the cart (%d -> %d)" % [v0, vic.value])
	var vic_id: int = vic.item_id
	vic.teleport(w.gen.cell_center(w.gen.order[1]) + Vector3(0.2, 2.2, 0.3))
	vic.linear_velocity = Vector3(0, -6.0, 0)
	await _wait(2.0)
	_check(not w.items.has(vic_id) or w.items[vic_id].value < v0, "control: the same drop on a normal floor does damage")
	_finish()


## Walking into an item shoves it (body hitboxes).
func _push() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(3.0)
	var w = main.world
	var lp = w.local_player
	var it = null
	for x in w.items.values():
		if x.base_value > 0 and x.mass <= 4.0:
			it = x
			break
	var cc: Vector3 = w.gen.cell_center(w.gen.order[1])
	for x in w.items.values():
		if x != it and x.global_position.distance_to(cc) < 2.5:
			x.teleport(x.global_position + Vector3(0, 0, 0) + (x.global_position - cc).normalized() * 3.0)
	it.teleport(cc + Vector3(0, 0.4, -0.6))
	await _wait(1.0)
	var p0: Vector3 = it.global_position
	lp.global_position = it.global_position + Vector3(0, 0.1, 1.5)
	lp.global_position.y = cc.y + 0.1
	var dv: Vector3 = it.global_position - lp.global_position
	lp.yaw = atan2(-dv.x, -dv.z)
	Input.action_press("move_forward")
	for q in 8:
		await _wait(0.2)
		print("[DBG] lp=", lp.global_position, " it=", it.global_position, " vel=", lp.velocity, " coll=", lp.get_slide_collision_count())
	Input.action_release("move_forward")
	await _wait(0.5)
	var moved: float = Vector2(it.global_position.x - p0.x, it.global_position.z - p0.z).length()
	_check(moved > 0.3, "walking shoves the item (%.2f m)" % moved)
	_finish()


## Van leaves after 10 s; a robot left outside explodes.
func _depart_test() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await _wait(3.0)
	var w = main.world
	var e: Dictionary = w.extr[0]
	for it in w.items.values():
		if it.base_value > 0:
			it.teleport(e["pos"] + Vector3(randf_range(-0.8, 0.8), 0.6, randf_range(-0.8, 0.8)))
	await _wait(2.0)
	w._try_extract(0)
	await _wait(4.5)
	_check(w.all_done, "all points done")
	var lp = w.local_player
	lp.global_position = w.gen.cell_center(w.gen.order[1]) + Vector3(0, 0.1, 0)
	w._try_truck()
	await _wait(11.0)
	_check(lp.dead or main.world == null or Net.hp.get(1, 1.0) <= 0.0, "robot left outside exploded")
	_finish()


func _faces() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(false)
	await _wait(2.5)
	var w = main.world
	var lp = w.local_player
	Net.players[99] = {"name": "Buddy", "color": 1}
	w._add_player(99, 1)
	var bud = w.players[99]
	var base: Vector3 = w.gen.cell_center(w.gen.order[1])
	lp.global_position = base + Vector3(0, 0.25, 1.35)
	lp.yaw = 0.0
	lp.pitch = -0.05
	lp.flashlight.light_energy = 3.0
	bud.global_position = base + Vector3(0, 0.05, 0.0)
	bud.net_pos = bud.global_position
	bud.yaw = PI
	bud.net_yaw = PI
	bud.yaw = PI
	var shots := [0, 1, 2, 8, 16, 32]
	var names := ["neutral", "angry", "sad", "closed", "crazy", "happy"]
	for i in shots.size():
		bud.expr = shots[i]
		bud._blink_t = 99.0
		await _wait(0.6)
		await _shot("face_" + names[i])
	w.hud.expr_bar.visible = true
	lp.set_expr_bit(0)
	lp.set_expr_bit(5)
	await _wait(0.3)
	await _shot("face_hud")
	# chat: Buddy speaks (bubble), our panel open with quick phrases
	w.hud.expr_bar.visible = false
	lp.global_position = base + Vector3(0, 0.25, 2.6)
	bud.color = Net.COLORS[6]
	w._show_bubble(99, "Тут монстр за дверью, бежим к фургону!")
	w.hud.chat_log("Buddy", "Тут монстр за дверью, бежим к фургону!", Net.COLORS[1])
	await _wait(0.6)
	await _shot("chat_bubble")
	w.hud._toggle_chat()
	await _wait(0.3)
	await _shot("chat")
	_finish()


func _robotshot() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(false)
	await _wait(2.5)
	var w = main.world
	var lp = w.local_player
	w.hud.visible = false
	var d: Vector3 = -w.gen.truck_back
	var side := d.cross(Vector3.UP)
	var fy := atan2(-d.x, -d.z)
	var base: Vector3 = w.gen.truck_pos + d * 3.4
	base.y = 0.1
	var cosl := [{}, {"hat": "tophat", "acc": "shades"}, {"hat": "viking", "acc": "monocle"}, {"hat": "cowboy", "acc": "headphones", "fin": "gold"}, {"hat": "propeller", "acc": "scarf"}, {"hat": "halo", "acc": "bowtie"}]
	var buds := []
	for i in cosl.size():
		var pid := 90 + i
		Net.players[pid] = {"name": "B%d" % i, "color": i, "cos": cosl[i]}
		w._add_player(pid, i)
		var b = w.players[pid]
		var pos := base + side * (-2.2 + i * 0.88)
		b.global_position = pos
		b.net_pos = pos
		b.yaw = fy + PI + 0.4
		b.net_yaw = b.yaw
		b._blink_t = 99.0
		buds.append(b)
	lp.global_position = w.gen.truck_pos + d * 0.2 + Vector3(0, 0.1, 0)
	lp.yaw = fy
	lp.pitch = -0.15
	lp.flashlight.light_energy = 3.0
	await _wait(0.8)
	await _shot("robots_stand")
	for b in buds:
		b.yaw = fy + PI * 0.5
		b.net_yaw = b.yaw
	buds[1].crouching = true
	buds[2].crouching = true
	buds[3].tumbling = true
	buds[4].net_grab = 5
	await _wait(1.0)
	await _shot("robots_side")
	_finish()


func _envshots() -> void:
	Settings.force_touch = true
	Net.delete_save()
	var lvls := [] if "--shoponly" in OS.get_cmdline_user_args() else [1, 2, 3]
	for lvl in lvls:
		Net.start_solo(true)
		Net._new_run()
		Net.level = lvl
		Net.begin_level()
		await _wait(2.0)
		var w = main.world
		w.hud.visible = false
		for m in w.monsters.values():
			m.dormant = 999.0
		var lp = w.local_player
		var k := 0
		for c in w.gen.order:
			if c == w.gen.spawn_cell:
				continue
			if k >= 3:
				break
			var cc: Vector3 = w.gen.cell_center(c)
			var hs: float = float(w.gen.inset.get(c, 3.6))
			var o := Vector3(hs - 0.6, 0.1, hs - 0.6)
			lp.global_position = cc + o
			lp.velocity = Vector3.ZERO
			lp.yaw = atan2(o.x, o.z)
			lp.pitch = -0.18
			await _wait(0.7)
			await _shot("env%d_%d" % [lvl, k])
			k += 1
	Net.start_solo(true)
	Net._new_run()
	Net.money = 42000
	Net.level = 2
	Net.begin_shop({"level": 1, "extracted": 42000, "quota": 30000})
	await _wait(2.0)
	var w2 = main.world
	w2.hud.visible = false
	var lp2 = w2.local_player
	var cc2: Vector3 = w2.gen.cell_center(Vector2i(1, 0))
	lp2.global_position = cc2 + Vector3(-3.0, 0.1, 0)
	lp2.yaw = -PI / 2
	lp2.pitch = -0.1
	await _wait(1.0)
	await _shot("env_shop1")
	lp2.global_position = cc2 + Vector3(3.0, 0.1, 0)
	lp2.yaw = PI / 2
	await _wait(0.8)
	await _shot("env_shop2")
	_finish()


func _arena_test() -> void:
	Settings.force_touch = true
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.5)
	Net.players[99] = {"name": "Buddy", "color": 1}
	Net._init_player_run(99)
	Net._load_arena(1234, 3)
	await _wait(0.5)
	var w = main.world
	w.ready_peers[99] = true
	w._try_start()
	for q in 6:
		await _wait(0.3)
		print("[DBG] lp=", w.local_player.global_position, " dead=", w.local_player.dead, " hp=", Net.hp.get(1))
	_check(w != null and w.arena_mode, "arena loaded")
	_check(w.gen.tiles.size() == 5, "5 rings of plates (%d)" % w.gen.tiles.size())
	var weapons := 0
	for it in w.items.values():
		if it.type.begins_with("w_") or it.type.begins_with("g_") or it.type.begins_with("m_"):
			weapons += 1
	_check(weapons >= 6, "weapons scattered: %d" % weapons)
	var lp = w.local_player
	lp.global_position = Vector3(0, 0.3, 1.8)
	lp.yaw = PI
	lp.pitch = -0.3
	for q in 5:
		await _wait(0.15)
		print("[DBG2] lp=", lp.global_position, " dead=", lp.dead, " hp=", Net.hp.get(1), " vel=", lp.velocity)
	await _shot("arena1")
	w.arena_t = 16.0
	await _wait(0.8)
	await _shot("arena2")
	await _wait(2.5)
	_check(not w.gen.tiles.has(5), "outer ring dropped")
	_check(w.players.has(99) and not w.players[99].dead, "second robot alive")
	w.players[99].global_position = Vector3(0, -6.0, 0)
	w.players[99].net_pos = Vector3(0, -6.0, 0)
	await _wait(0.6)
	_check(w.players[99].dead, "falling into the pit kills")
	await _wait(1.0)
	_check(Settings.crown_name == Settings.player_name, "last robot standing gets the crown (%s)" % Settings.crown_name)
	await _shot("arena3")
	Settings.crown_name = ""
	Settings.save_cfg()
	_finish()


func _loadshot() -> void:
	main._boot_loading()
	await _wait(0.6)
	await _shot("load1")
	await _wait(1.0)
	await _shot("load2")
	await _wait(2.5)
	await _shot("load3")
	_finish()


## Settings → Controls → button layout editor: drag, resize, cancel, reset, and the game uses it.
func _layout_test() -> void:
	Settings.btn_layout = {}
	main.show_settings()
	await _wait(0.8)
	var sp: Node = main.find_children("*", "Control", true, false).filter(func(n): return n.get_script() == preload("res://scripts/ui/settings_panel.gd"))[0]
	sp._show("tab_controls")
	var btns: Array = sp._pages["tab_controls"].find_children("*", "Button", true, false).filter(func(b): return b.text == Settings.t("layout_open"))
	_check(btns.size() == 1, "controls tab has the layout button")
	sp.open_layout_editor()
	await _wait(0.5)
	var ed: Node = sp.get_node_or_null("TouchEditor")
	_check(ed != null, "editor opened")
	var t: Control = ed.touch
	var vs: Vector2 = t.size
	_check(t.edit_mode and t._visible_btn("throw") and t._visible_btn("pull"), "every button is shown while editing")
	# drag the jump button to the left side
	var j0: Vector2 = t.buttons["jump"]["pos"]
	var to := Vector2(vs.x * 0.3, vs.y * 0.55)
	await _drag(j0, to, 12)
	await _wait(0.1)
	var j1: Vector2 = t.buttons["jump"]["pos"]
	_check(j1.distance_to(to) < 4.0, "jump dragged (%s -> %s)" % [j0, j1])
	_check(Settings.btn_layout.has("jump"), "jump position stored")
	# a press on the top bar never grabs a button under it
	var ping0: Vector2 = t.buttons["ping"]["pos"]
	await _drag(Vector2(ping0.x, 40), Vector2(ping0.x - 200, 300), 6)
	_check(t.buttons["ping"]["pos"] == ping0 and t.selected == "jump", "presses on the top bar are ignored")
	# pick grab and make it bigger twice
	var g: Vector2 = t.buttons["grab"]["pos"]
	var r0: float = t.buttons["grab"]["r"]
	await _mev("down", g)
	await _mev("up", g)
	_check(t.selected == "grab", "tap selects grab")
	ed._resize(1.12)
	ed._resize(1.12)
	await _wait(0.1)
	var r1: float = t.buttons["grab"]["r"]
	_check(absf(r1 / r0 - 1.2544) < 0.02, "grab is 25%% bigger (%.0f -> %.0f px)" % [r0, r1])
	_check(t.buttons["grab"]["pos"].distance_to(g) < 1.0, "resizing keeps it in place")
	# the joystick
	var jh: Vector2 = t._joy_home
	await _drag(jh, jh + Vector2(60, -80), 8)
	_check(t._joy_home.distance_to(jh + Vector2(60, -80)) < 4.0 and Settings.btn_layout.has("joy"), "joystick moved")
	_check(ed._sel_lbl.text != "", "status line: %s" % ed._sel_lbl.text)
	if DisplayServer.get_name() != "headless":
		await _shot("layout_editor")
	ed._done()
	await _wait(0.3)
	_check(sp.get_node_or_null("TouchEditor") == null, "editor closed")
	var cf := ConfigFile.new()
	cf.load(Settings.PATH)
	var saved: Dictionary = cf.get_value("s", "btn_layout", {})
	_check(saved.has("jump") and saved.has("grab") and saved.has("joy"), "layout saved to the config (%s)" % str(saved.keys()))
	# the in-game controls use it at another screen size
	var tt = preload("res://scripts/ui/touch.gd").new()
	tt.size = vs * 1.25
	add_child(tt)
	tt.size = vs * 1.25
	tt._layout()
	var jf: Vector2 = tt.buttons["jump"]["pos"] / tt.size
	_check(jf.distance_to(j1 / vs) < 0.01, "game controls: jump at the same screen fraction (%s)" % jf)
	var base_r: float = 80.0 * (tt.size.y / 720.0) * Settings.btn_scale
	_check(absf(tt.buttons["grab"]["r"] / base_r - 1.2544) < 0.02, "game controls: grab keeps its size")
	_check(not tt._visible_btn("throw"), "game controls: throw hidden until something is held")
	tt.queue_free()
	# cancel restores the previous layout
	sp.open_layout_editor()
	await _wait(0.4)
	ed = sp.get_node("TouchEditor")
	var u0: Vector2 = ed.touch.buttons["use"]["pos"]
	await _drag(u0, u0 + Vector2(-150, 120), 8)
	_check(Settings.btn_layout.has("use"), "use moved in the second session")
	ed._cancel()
	await _wait(0.3)
	_check(not Settings.btn_layout.has("use") and Settings.btn_layout.has("jump"), "cancel restores the saved layout")
	# reset
	sp.open_layout_editor()
	await _wait(0.4)
	ed = sp.get_node("TouchEditor")
	ed._reset()
	_check(Settings.btn_layout.is_empty() and ed.touch.buttons["jump"]["pos"].distance_to(j0) < 1.0, "reset puts buttons back")
	ed._done()
	await _wait(0.2)
	# battery saver switch
	sp._show("tab_video")
	var bs := false
	for c in sp._pages["tab_video"].find_children("*", "Label", true, false):
		if c.text == Settings.t("battery_saver"):
			bs = true
	_check(bs, "video tab has the battery saver switch")
	sp._close()
	_finish()


## Bluetooth gamepad: sticks, buttons, triggers; the on-screen buttons hide while it is used.
func _pad_test() -> void:
	Net.delete_save()
	Settings.battery_saver = false
	Settings.apply()
	Net.start_solo(false)
	await _wait(2.0)
	var w = main.world
	var lp = w.local_player
	await _wait(0.5)
	_check(lp != null, "player ready")
	var hud = w.hud
	# left stick forward
	var p0: Vector3 = lp.global_position
	var yaw0: float = lp.yaw
	_joy_axis(JOY_AXIS_LEFT_Y, -1.0)
	await _wait(0.8)
	_check(Settings.pad_active, "stick switches to gamepad mode")
	var moved: float = Vector2(lp.global_position.x - p0.x, lp.global_position.z - p0.z).length()
	_check(moved > 1.0, "left stick walks (%.2f m)" % moved)
	var fwd := Vector3(-sin(yaw0), 0, -cos(yaw0))
	_check((lp.global_position - p0).normalized().dot(fwd) > 0.6, "... forward")
	_joy_axis(JOY_AXIS_LEFT_Y, 0.0)
	# right stick turns
	_joy_axis(JOY_AXIS_RIGHT_X, 1.0)
	await _wait(0.5)
	_joy_axis(JOY_AXIS_RIGHT_X, 0.0)
	_check(absf(angle_difference(lp.yaw, yaw0)) > 0.5, "right stick turns (%.2f rad)" % angle_difference(lp.yaw, yaw0))
	var pitch0: float = lp.pitch
	_joy_axis(JOY_AXIS_RIGHT_Y, -1.0)
	await _wait(0.3)
	_joy_axis(JOY_AXIS_RIGHT_Y, 0.0)
	_check(lp.pitch > pitch0 + 0.2 or (Settings.invert_y and lp.pitch < pitch0 - 0.2), "right stick looks up")
	# A jumps
	await _wait(0.6)
	var y0: float = lp.global_position.y
	_joy_btn(JOY_BUTTON_A, true)
	await get_tree().physics_frame
	await get_tree().physics_frame
	_joy_btn(JOY_BUTTON_A, false)
	await _wait(0.2)
	_check(lp.global_position.y > y0 + 0.2, "A jumps (%.2f -> %.2f)" % [y0, lp.global_position.y])
	await _wait(1.0)
	# B crouches (toggle)
	_joy_btn(JOY_BUTTON_B, true)
	await get_tree().physics_frame
	await get_tree().physics_frame
	_joy_btn(JOY_BUTTON_B, false)
	await _wait(0.3)
	_check(lp.crouching, "B crouches")
	_joy_btn(JOY_BUTTON_B, true)
	await get_tree().physics_frame
	await get_tree().physics_frame
	_joy_btn(JOY_BUTTON_B, false)
	await _wait(0.4)
	# RT grabs the item in front, LT throws it
	var target = null
	for it in w.items.values():
		if it.mass < 5.0 and it.base_value > 0:
			target = it
			break
	for attempt in 4:
		var cc0: Vector3 = w.gen.cell_center(w.gen.order[1 + attempt])
		target.teleport(cc0 + Vector3(0, 0.5, 0))
		await _wait(1.0)
		lp.global_position = target.global_position + Vector3(0, 0.1, 1.6)
		lp.velocity = Vector3.ZERO
		lp.yaw = 0.0
		await _wait(0.2)
		var to: Vector3 = target.global_position - (lp.global_position + Vector3(0, lp.head.position.y, 0))
		lp.yaw = atan2(-to.x, -to.z)
		lp.pitch = atan2(to.y, Vector2(to.x, to.z).length())
		await _wait(0.1)
		_joy_axis(JOY_AXIS_TRIGGER_RIGHT, 1.0)
		await _wait(0.6)
		if lp.grabbed_id == target.item_id:
			break
		_joy_axis(JOY_AXIS_TRIGGER_RIGHT, 0.0)
		await _wait(0.2)
	_check(lp.grabbed_id == target.item_id, "RT grabs the aimed item (%d)" % lp.grabbed_id)
	var hd0: float = lp.hold_dist
	_joy_btn(JOY_BUTTON_DPAD_UP, true)
	await _wait(0.4)
	_joy_btn(JOY_BUTTON_DPAD_UP, false)
	_check(lp.hold_dist > hd0 + 0.3, "D-pad up pushes the item away (%.2f -> %.2f)" % [hd0, lp.hold_dist])
	_joy_axis(JOY_AXIS_TRIGGER_LEFT, 1.0)
	var vmax := 0.0
	for i in 12:
		await get_tree().physics_frame
		vmax = maxf(vmax, target.linear_velocity.length())
		if i == 1:
			_joy_axis(JOY_AXIS_TRIGGER_LEFT, 0.0)
	_check(lp.grabbed_id == -1 and vmax > 1.5, "LT throws (%.1f m/s)" % vmax)
	_joy_axis(JOY_AXIS_TRIGGER_RIGHT, 0.0)
	await _wait(0.2)
	# Start pauses, Start again resumes
	_joy_btn(JOY_BUTTON_START, true)
	await _wait(0.1)
	_joy_btn(JOY_BUTTON_START, false)
	await _wait(0.2)
	_check(hud.is_paused(), "Start pauses")
	_joy_btn(JOY_BUTTON_START, true)
	await _wait(0.1)
	_joy_btn(JOY_BUTTON_START, false)
	await _wait(0.2)
	_check(not hud.is_paused(), "Start resumes")
	# a touch brings the on-screen buttons back
	var st := InputEventScreenTouch.new()
	st.index = 0
	st.position = Vector2(600, 300)
	st.pressed = true
	Input.parse_input_event(st)
	await get_tree().process_frame
	st = st.duplicate()
	st.pressed = false
	Input.parse_input_event(st)
	await _wait(0.1)
	_check(not Settings.pad_active, "a screen touch switches back to touch controls")
	# battery saver
	Settings.battery_saver = true
	Settings.apply()
	await _wait(0.2)
	_check(Engine.max_fps == 30 and Settings.eff_quality() == 0, "battery saver: 30 FPS, light preset")
	_check(absf(w._res_max - 0.595) < 0.01, "battery saver: 3D resolution %.2f" % w._res_max)
	Settings.battery_saver = false
	Settings.apply()
	await _wait(0.2)
	_check(Engine.max_fps == Settings.fps_cap and absf(w._res_max - [0.7, 0.85, 1.0][Settings.quality]) < 0.01, "battery saver off restores FPS and resolution")
	_finish()


func _joy_axis(axis: int, v: float) -> void:
	var e := InputEventJoypadMotion.new()
	e.device = 0
	e.axis = axis
	e.axis_value = v
	Input.parse_input_event(e)


func _joy_btn(b: int, down: bool) -> void:
	var e := InputEventJoypadButton.new()
	e.device = 0
	e.button_index = b
	e.pressed = down
	e.pressure = 1.0 if down else 0.0
	Input.parse_input_event(e)


## Renders every hat / accessory / finish on robots (front and 3/4 views) for a visual check.
func _cosshot() -> void:
	var ML = load("res://scripts/game/matlib.gd")
	var Cos = load("res://scripts/game/cosmetics.gd")
	if main.menu_bg:
		main._free_menu_bg()
	main.ui_layer.visible = false
	var root := Node3D.new()
	main.add_child(root)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.16, 0.16, 0.19)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.55, 0.56, 0.62)
	env.ambient_light_energy = 0.7
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true
	we.environment = env
	root.add_child(we)
	var key := DirectionalLight3D.new()
	key.rotation = Vector3(-0.6, 0.4, 0)
	key.light_energy = 1.6
	key.shadow_enabled = true
	root.add_child(key)
	var rim := DirectionalLight3D.new()
	rim.rotation = Vector3(-0.3, PI + 0.6, 0)
	rim.light_energy = 0.8
	root.add_child(rim)
	var cam := Camera3D.new()
	cam.fov = 30
	root.add_child(cam)
	cam.current = true
	var sets := [
		{"name": "hats", "list": Cos.HATS.map(func(h): return {"hat": h})},
		{"name": "accs", "list": Cos.ACCS.map(func(a): return {"acc": a}) + [{"acc": "bowtie", "hat": "tophat"}, {"acc": "scarf", "hat": "beanie"}]},
		{"name": "fins", "list": [{}] + Cos.FINS.map(func(f): return {"fin": f})},
	]
	for st in sets:
		var nodes := []
		var lst: Array = st["list"]
		var n := lst.size()
		for i in n:
			var col: Color = Net.COLORS[(i * 3) % Net.COLORS.size()]
			var cos: Dictionary = lst[i]
			var m: Node3D = ML.model("robot", {"M_player": Cos.paint(col, cos), "M_player_glow": ML.plain(col.lightened(0.2), 0.3, 0.0, 3.0)})
			root.add_child(m)
			m.position = Vector3((i - (n - 1) / 2.0) * 0.95, 0, 0)
			Cos.apply(ML.find(m, "head"), ML.find(m, "body"), cos, col)
			nodes.append(m)
		var w := n * 0.95
		for view in ["front", "side"]:
			for m in nodes:
				m.rotation.y = 0.0 if view == "front" else -0.9
			# robots face -Z: the camera looks at them from -Z
			var dist := w / (2.0 * tan(deg_to_rad(cam.fov * 0.5)) * (get_viewport().get_visible_rect().size.x / get_viewport().get_visible_rect().size.y)) + 1.2
			cam.position = Vector3(0, 1.45, -dist)
			cam.look_at(Vector3(0, 1.25, 0), Vector3.UP)
			await _wait(0.6)
			await _shot("cos_%s_%s" % [st["name"], view])
		for m in nodes:
			m.queue_free()
	_finish()


## Achievements unlock cosmetics; the collection screen equips them; robots wear them.
func _ach_test() -> void:
	Settings.achievements = {}
	Settings.ach_progress = {}
	Settings.cos_hat = ""
	Settings.cos_acc = ""
	Settings.cos_finish = ""
	var got := []
	Ach.unlocked.connect(func(id): got.append(id))
	Ach.event("extract")
	_check(Ach.is_unlocked("first_haul") and got == ["first_haul"], "first extraction unlocks First haul")
	_check(Ach.owned("hat", "cap") and not Ach.owned("hat", "halo") and Ach.owned("hat", ""), "the cap is owned, the halo is not")
	Ach.event("earn", 60000)
	Ach.event("earn", 60000)
	_check(Ach.is_unlocked("rich") and Ach.progress("earn") == 120000, "earnings add up ($%d)" % Ach.progress("earn"))
	Ach.level_started(5, false, false)
	Ach.level_started(3, false, false)
	_check(Ach.is_unlocked("lvl5") and Ach.progress("level") == 5, "level is a best value (%d)" % Ach.progress("level"))
	Ach.hurt_this_level = true
	Ach.event("clear")
	_check(not Ach.is_unlocked("flawless"), "a hurt robot gets no Not a scratch")
	Ach.level_started(6, false, false)
	Ach.event("clear")
	_check(Ach.is_unlocked("flawless"), "a clean level gives Not a scratch")
	for i in 40:
		Ach.add_time("glide", 0.8)
	_check(Ach.is_unlocked("pilot") and Ach.progress("glide") == 32, "glide seconds (%d)" % Ach.progress("glide"))
	await _wait(0.3)
	_check(Ach._layer != null and Ach._layer.get_child_count() == 1, "toast on screen")
	Ach.flush()
	var cf := ConfigFile.new()
	cf.load(Settings.PATH)
	_check((cf.get_value("s", "achievements", {}) as Dictionary).has("pilot"), "achievements saved")
	# collection screen
	main.show_collection()
	await _wait(0.6)
	var cs = main.screen
	_check(cs.tiles.has("hat:cap") and cs.tiles.has("hat:halo") and cs.tiles.has("fin:gold"), "wardrobe shows every item")
	cs._pick("hat", "halo")
	_check(Settings.cos_hat == "" and cs._hint.text.contains(Settings.t("ach_lvl10")), "a locked item tells how to get it")
	var tb: Button = cs.tiles["hat:cap"]
	var c := tb.get_global_rect().get_center()
	await _mev("down", c)
	await _mev("up", c)
	await _wait(0.2)
	_check(Settings.cos_hat == "cap", "tap equips the cap")
	cs._pick("fin", "chrome")
	cs._pick("acc", "scarf")
	await _wait(0.2)
	var r = main.menu_bg.robots[0] if main.menu_bg else null
	if r:
		_check(r["head"].has_node("CosHat") and r["body"].has_node("CosAcc"), "garage robot wears them")
	if DisplayServer.get_name() != "headless":
		await _wait(0.8)
		await _shot("collection")
		cs._show("achievements")
		await _wait(0.5)
		await _shot("achievements")
	cs._show("achievements")
	_check(cs._content.get_child_count() == Ach.LIST.size(), "achievement list")
	# in a level
	Net.delete_save()
	Net.start_solo(false)
	await _wait(2.0)
	var w = main.world
	var lp = w.local_player
	_check(lp.model_head.has_node("CosHat"), "the robot in the level wears the cap")
	w.ach("kill", 1)
	await _wait(0.1)
	_check(Ach.is_unlocked("hunter"), "host team event reaches the player")
	w.ach("buy", 3, lp.peer_id)
	w.ach("buy", 3, -lp.peer_id)
	await _wait(0.1)
	_check(Ach.progress("buy") == 3, "targeted events (%d)" % Ach.progress("buy"))
	var h0: float = Net.hp[lp.peer_id]
	w.rpc_player_hp(lp.peer_id, h0 - 5.0, false, Vector3.ZERO)
	_check(Ach.hurt_this_level, "damage is noticed")
	if DisplayServer.get_name() != "headless":
		await _shot("toast")
	Settings.cos_hat = ""
	Settings.cos_acc = ""
	Settings.cos_finish = ""
	Settings.save_cfg()
	_finish()


## Voice codec, voice activation, jitter buffer and push-to-talk (no network needed).
func _voice_test() -> void:
	var V = preload("res://scripts/game/voice.gd")
	# 1) IMA-ADPCM round trip on speech-like audio (two tones + noise, fading in)
	var pcm := PackedFloat32Array()
	pcm.resize(V.PKT)
	for i in V.PKT:
		var t: float = i / V.RATE
		pcm[i] = (sin(TAU * 220.0 * t) * 0.35 + sin(TAU * 1370.0 * t) * 0.15 + randf_range(-0.03, 0.03)) * minf(1.0, i / 60.0)
	var pk: PackedByteArray = V.encode(pcm, 77)
	var dec: PackedFloat32Array = V.decode(pk)
	var sig := 0.0
	var err := 0.0
	for i in V.PKT:
		sig += pcm[i] * pcm[i]
		err += (pcm[i] - dec[i]) * (pcm[i] - dec[i])
	var snr := 10.0 * log(sig / maxf(err, 1e-9)) / log(10.0)
	_check(pk.size() == 5 + V.PKT / 2 and dec.size() == V.PKT, "packet: %d bytes for 40 ms (%.0f kbit/s)" % [pk.size(), pk.size() * 8 / 40.0])
	_check(pk.decode_u16(0) == 77, "sequence number in the header")
	_check(snr > 18.0, "ADPCM quality: SNR %.1f dB" % snr)
	# loud start and full scale do not blow up
	var loud := PackedFloat32Array()
	loud.resize(V.PKT)
	for i in V.PKT:
		loud[i] = 1.0 if (i / 20) % 2 == 0 else -1.0
	var d2: PackedFloat32Array = V.decode(V.encode(loud, 1))
	var mx := 0.0
	for x in d2:
		mx = maxf(mx, absf(x))
	_check(mx <= 1.0 and mx > 0.8, "square wave survives (peak %.2f)" % mx)
	# 2) voice activation with hang time
	Settings.voice_mode = 2
	Settings.mic_sens = 0.5
	var v = V.new()
	add_child(v)
	await get_tree().process_frame
	var mr := AudioServer.get_mix_rate()
	var quiet := PackedVector2Array()
	quiet.resize(int(mr * 0.2))
	for i in quiet.size():
		var q := randf_range(-0.002, 0.002)
		quiet[i] = Vector2(q, q)
	v.feed(quiet)
	_check(not v.sending, "silence is not sent (threshold %.3f)" % v.vad_threshold())
	var tone := PackedVector2Array()
	tone.resize(int(mr * 0.2))
	for i in tone.size():
		var x := sin(TAU * 300.0 * i / mr) * 0.3
		tone[i] = Vector2(x, x)
	v.feed(tone)
	_check(v.sending and v.mic_level > 0.2, "talking opens the gate (level %.2f)" % v.mic_level)
	v._pcm.clear()
	v._hang_t = 0.1
	v.feed(quiet)
	_check(not v.sending, "the gate closes after the hang time")
	Settings.mic_sens = 1.0
	var th_hi: float = v.vad_threshold()
	Settings.mic_sens = 0.0
	_check(th_hi < v.vad_threshold(), "sensitivity lowers the threshold")
	Settings.mic_sens = 0.5
	# 3) push-to-talk needs the button
	Settings.voice_mode = 1
	v.world = self
	_check(not v._want_open(), "push-to-talk: closed until held")
	v.world = null
	v.queue_free()
	# 4) bus + settings
	Settings.voice_vol = 0.5
	Settings.voice_filter = false
	var v2 = V.new()
	v2.world = null
	add_child(v2)
	await get_tree().process_frame
	var b := AudioServer.get_bus_index("Voice")
	_check(b != -1 and absf(AudioServer.get_bus_volume_db(b) - linear_to_db(0.5)) < 0.1 and not AudioServer.is_bus_effect_enabled(b, 2), "voice bus: volume and filter follow the settings")
	Settings.voice_vol = 1.0
	Settings.voice_filter = true
	Settings.voice_mode = 2
	v2.queue_free()
	_finish()


class FakeBilling extends Node:
	var calls := []
	func start_connection(): calls.append("start")
	func query_product_details(ids, _t): calls.append("details:%d" % ids.size())
	func query_purchases(_t, _s := false): calls.append("purchases")
	func purchase(pid, _o := "", _f := "", _p := false) -> Dictionary:
		calls.append("buy:" + pid)
		return {"response_code": 0, "debug_message": ""}
	func consume_purchase(tok): calls.append("consume:" + tok)
	func acknowledge_purchase(tok): calls.append("ack:" + tok)


## Purchases, tips, the rewarded "continue" and shop bonus with a simulated store
## (run with HB_STORE_SIM=1), plus Google Play response parsing with a fake billing client.
func _store_test() -> void:
	var C = preload("res://scripts/monetization_config.gd")
	Settings.iap_owned = {}
	Settings.tips_total = 0
	Settings.cos_hat = ""
	_check(Store.sim and Store.purchases_available() and Store.rewards_supported(), "simulated store is up")
	# support screen: buy the pack and a tip
	main.show_store()
	await _wait(0.5)
	var ss = main.screen
	_check(ss.buy_buttons.has(C.SUPPORTER) and ss.buy_buttons.has(C.REMOVE_ADS) and ss.buy_buttons.has("tip_5"), "support screen lists the pack, no-ads and tips")
	_check(ss.buy_buttons[C.SUPPORTER].text == C.FALLBACK_PRICE[C.SUPPORTER], "price shown (%s)" % ss.buy_buttons[C.SUPPORTER].text)
	var got := []
	Store.purchased.connect(func(pid): got.append(pid))
	ss.buy_buttons[C.SUPPORTER].pressed.emit()
	await _wait(0.2)
	_check(Store.supporter() and Store.no_ads() and got == [C.SUPPORTER], "supporter pack bought")
	_check(main.screen.buy_buttons[C.SUPPORTER].disabled and main.screen.buy_buttons[C.SUPPORTER].text == Settings.t("sup_owned"), "the card shows it as owned")
	_check(Ach.owned("hat", "cowboy") and Ach.owned("fin", "lava"), "supporter cosmetics unlocked")
	_check(int(Settings.cosmetics().get("sup", 0)) == 1, "gold star badge in the cosmetics sent to teammates")
	main.screen.buy_buttons["tip_3"].pressed.emit()
	await _wait(0.2)
	_check(Store.tips() == 1, "a tip counts (%d)" % Store.tips())
	if DisplayServer.get_name() != "headless":
		await _wait(0.6)
		await _shot("support")
	# without the pack: rewarded flows
	Settings.iap_owned = {}
	# a solo run saved at the shop before level 3
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.5)
	Net.level = 3
	Net.money = 12345
	Net.save_run()
	Net._game_over({"level": 3, "earned": 20000})
	await _wait(0.4)
	var go = main.screen
	_check(go.continue_btn != null and go.continue_btn.text == Settings.t("go_continue_ad"), "game over offers 'continue (video)'")
	if DisplayServer.get_name() != "headless":
		await _shot("gameover_continue")
	go._continue()
	await _wait(2.0)
	var w = main.world
	_check(w != null and w.shop_mode and Net.level == 3 and Net.money == 12345 and Net.run_continued, "continued at the shop before level 3 with the money (%d, $%d)" % [Net.level, Net.money])
	# shop bonus
	var hud = w.hud
	_check(hud.bonus_btn != null, "shop shows the rewarded bonus")
	if DisplayServer.get_name() != "headless":
		await _wait(0.5)
		await _shot("shop_bonus")
	var m0 := Net.money
	hud.bonus_btn.pressed.emit()
	await _wait(0.8)
	_check(Net.money == m0 + Net.shop_bonus_amount() and hud.bonus_btn == null, "bonus paid once ($%d -> $%d)" % [m0, Net.money])
	_check(not Net.can_take_shop_bonus(), "no second bonus in this shop")
	if DisplayServer.get_name() != "headless":
		await _shot("shop_after_bonus")
	# the continued run can't be continued again
	Net.save_run()
	Net._game_over({"level": 3, "earned": 20000})
	await _wait(0.4)
	_check(main.screen.continue_btn == null, "no second continue in the same run")
	# bonus when no ad is ready
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.2)
	Net.level = 2
	Net.save_run()
	Net.begin_shop({})
	await _wait(1.5)
	Store.sim_ads = false
	var b2 = main.world.hud.bonus_btn
	_check(b2 != null, "bonus button in a new shop")
	var m1 := Net.money
	b2.pressed.emit()
	await _wait(0.6)
	_check(Net.money == m1 and is_instance_valid(b2), "no ad ready: nothing paid, button stays")
	Store.sim_ads = true
	# no-ads purchase: instant reward
	Settings.iap_owned = {C.REMOVE_ADS: true}
	main.world.hud._bonus_redraw()
	b2.pressed.emit()
	await _wait(0.3)
	_check(Net.money == m1 + Net.shop_bonus_amount(), "no-ads: bonus paid instantly")
	if DisplayServer.get_name() != "headless":
		await _wait(0.3)
	# Google Play responses (plugin 3.3 format) with a fake billing client
	Settings.iap_owned = {}
	Settings.tips_total = 0
	var fb := FakeBilling.new()
	add_child(fb)
	Store.billing = fb
	Store.sim = false
	Store._on_connected()
	_check("details:6" in fb.calls and "purchases" in fb.calls, "on connect: query products and purchases (%s)" % str(fb.calls))
	Store._on_product_details({"response_code": 0, "debug_message": "", "product_details": [
		{"product_id": "supporter_pack", "title": "Supporter pack (HAULBOTS)", "name": "Supporter pack", "description": "", "product_type": "inapp",
			"one_time_purchase_offer_details_list": [{"formatted_price": "₩6,500", "price_amount_micros": 6500000000, "price_currency_code": "KRW"}]},
		{"product_id": "tip_10", "product_type": "inapp", "status_code": 3}]})
	_check(Store.price("supporter_pack") == "₩6,500" and Store.price("tip_10") == C.FALLBACK_PRICE["tip_10"], "localized price from Play (%s); unknown product keeps the fallback" % Store.price("supporter_pack"))
	Store._on_purchases({"response_code": 0, "debug_message": "", "purchases": [
		{"product_ids": PackedStringArray(["supporter_pack"]), "purchase_state": 1, "purchase_token": "T1", "is_acknowledged": false},
		{"product_ids": PackedStringArray(["tip_1"]), "purchase_state": 1, "purchase_token": "T2", "is_acknowledged": false}]})
	_check(Store.supporter() and "ack:T1" in fb.calls and "consume:T2" in fb.calls, "restore: pack owned and acknowledged, unconsumed tip consumed")
	Store._on_consumed({"response_code": 0, "debug_message": "", "token": "T2"})
	_check(Store.tips() == 1, "tip counted after the consume")
	fb.calls.clear()
	Store.buy("remove_ads")
	_check("buy:remove_ads" not in fb.calls, "a product Play didn't return isn't bought blindly")
	Store.products["remove_ads"] = {"title": "No ads", "price": "₩2,500"}
	Store.buy("remove_ads")
	_check("buy:remove_ads" in fb.calls, "purchase flow started")
	var notes := []
	Store.note.connect(func(t): notes.append(t))
	Store._on_purchase_updated({"response_code": 0, "purchases": [{"product_ids": PackedStringArray(["remove_ads"]), "purchase_state": 2, "purchase_token": "T3"}]})
	_check(not Store.has("remove_ads") and Settings.t("iap_pending") in notes, "pending payment: not granted yet")
	Store._on_purchase_updated({"response_code": 0, "purchases": [{"product_ids": PackedStringArray(["remove_ads"]), "purchase_state": 1, "purchase_token": "T3", "is_acknowledged": false}]})
	_check(Store.has("remove_ads") and "ack:T3" in fb.calls, "paid: granted and acknowledged")
	Store._on_purchase_updated({"response_code": 7, "purchases": []})
	_check(fb.calls.count("purchases") >= 1, "already owned: re-query purchases")
	Store._on_purchases({"response_code": 0, "purchases": [{"product_ids": PackedStringArray(["remove_ads"]), "purchase_state": 1, "purchase_token": "T3", "is_acknowledged": true}]})
	_check(not Store.supporter() and Store.has("remove_ads"), "refunded pack is removed, the rest stays")
	Store.billing = null
	Store.sim = true
	Settings.iap_owned = {}
	Settings.tips_total = 0
	Settings.save_cfg()
	_finish()


## A normal build (no plugins, no simulation): purchases unavailable, no rewarded offers.
func _store_off_test() -> void:
	_check(not Store.sim and not Store.purchases_available() and not Store.rewards_supported(), "no store in a build without the plugins")
	main.show_store()
	await _wait(0.4)
	var ss = main.screen
	_check(ss.buy_buttons["supporter_pack"].disabled and ss.buy_buttons["tip_1"].disabled, "buttons are disabled")
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.2)
	Net.level = 3
	Net.save_run()
	Net._game_over({"level": 3, "earned": 1})
	await _wait(0.3)
	_check(main.screen.continue_btn == null, "no rewarded continue without ads")
	Net.delete_save()
	Net.start_solo(false)
	await _wait(1.2)
	Net.level = 2
	Net.save_run()
	Net.begin_shop({})
	await _wait(1.5)
	_check(main.world.hud.bonus_btn == null, "no shop bonus without ads")
	_finish()
