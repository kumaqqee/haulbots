extends "res://scripts/game/level_gen.gd"
## The between-level shop: truck bay + a two-room store with shelves and a checkout zone.

var checkout_pos := Vector3.ZERO
var checkout_button := Vector3.ZERO
var screen_pos := Vector3.ZERO
var screen_fwd := Vector3(-1, 0, 0)
var sign_pos := Vector3.ZERO
var shop_spots := []


func build(s: int, level: int, parent: Node3D) -> void:
	rng.seed = s
	location = 0
	var a := Vector2i(0, 0)
	var b := Vector2i(1, 0)
	var c := Vector2i(2, 0)
	cells = {a: "garage", b: "shop", c: "shop"}
	order = [a, b, c]
	conn = {}
	conn[key(a, b)] = {"a": a, "b": b, "t": 1}
	conn[key(b, c)] = {"a": b, "b": c, "t": 2}
	door_dir = Vector2i(1, 0)
	spawn_cell = a
	_graph()
	var cc2 := cell_center(c)
	checkout_pos = cc2 + Vector3(0.4, 0.02, 0)
	checkout_button = cc2 + Vector3(2.2, 0, 2.0)
	screen_pos = cc2 + Vector3(HR - WT / 2.0 - 0.12, 2.15, 0)
	sign_pos = cell_center(b) + Vector3(-HR + 0.3, 2.75, 0)
	_make_geometry(parent)


func _shelf(base: Vector3, along: Vector3, inward: Vector3) -> void:
	var c := base + inward * 0.28
	_add_model("shop_shelf", c, inward)
	var sa := along.abs()
	var ia := inward.abs()
	for z in [0.12, 0.72, 1.32, 1.88]:
		_add_shape(c + Vector3(0, z, 0), sa * 1.95 + Vector3(0, 0.05, 0) + ia * 0.55)
	_add_shape(c - inward * 0.27 + Vector3(0, 0.95, 0), sa * 1.95 + Vector3(0, 1.9, 0) + ia * 0.04)
	for sx in [-0.97, 0.97]:
		_add_shape(c + along * sx + Vector3(0, 0.95, 0), sa * 0.06 + Vector3(0, 1.9, 0) + ia * 0.55)
	for z in [0.76, 1.36]:
		for x in [-0.6, 0.0, 0.6]:
			shop_spots.append(c + along * x + Vector3(0, z + 0.05, 0))


func _furnish(_st, c: Vector2i) -> void:
	var cc := cell_center(c)
	_vis = false
	for d in [Vector2i(0, -1), Vector2i(0, 1)]:
		var normal := Vector3(d.x, 0, d.y)
		var inward := -normal
		var along := Vector3(1, 0, 0)
		var base := cc + normal * (HR - WT / 2.0)
		for x in ([-2.2, 0.0, 2.2] if c.x == 1 else [-2.2, 0.0]):
			_shelf(base + along * x, along, inward)
	if c.x == 2:
		var cpos := cc + Vector3(HR - WT / 2.0 - 0.4, 0, 0)
		_add_model("counter", cpos, Vector3(-1, 0, 0))
		_add_shape(cpos + Vector3(0, 0.52, 0), Vector3(0.8, 1.05, 2.3))
		_add_model("shopkeeper", cpos + Vector3(0.62, 0.0, 0.5), Vector3(-1, 0, 0))
		_add_shape(cpos + Vector3(0.62, 0.65, 0.5), Vector3(0.5, 1.3, 0.5))
		_add_model("tv", screen_pos + Vector3(0.06, 0, 0), Vector3(-1, 0, 0), 1.3, {"shadow": false})
		_add_model("sign_shop", cc + Vector3(HR - WT / 2.0 - 0.03, 2.75, -1.8), Vector3(-1, 0, 0), 1.0, {"shadow": false})
		_add_model("vending", cc + Vector3(3.3, 0, -3.3), Vector3(-1, 0, 0))
		_add_shape(cc + Vector3(3.3, 0.95, -3.3), Vector3(0.82, 1.9, 0.92))
		_add_model("plant", cc + Vector3(3.3, 0, 3.3), Vector3.FORWARD)
	else:
		_add_model("sign_tools", cc + Vector3(0, 2.6, -HR + WT / 2.0 + 0.03), Vector3(0, 0, 1), 1.0, {"shadow": false})
		_decal("poster_loot", cc + Vector3(0, 1.7, HR - WT / 2.0 - 0.05), Basis(Vector3(1, 0, 0), Vector3(0, 0, -1), Vector3(0, 1, 0)), Vector3(0.7, 0.4, 1.05), 1.0)
	_vis = true
	# checkout pad is built by the world (small extraction pad)
