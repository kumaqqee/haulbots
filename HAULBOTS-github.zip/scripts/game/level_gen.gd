extends RefCounted
## Deterministic procedural industrial complex: rooms, doors, furniture, lights, spots.

const ROOM := 8.0
const H := 3.2
const WT := 0.3
const DW := 1.8
const DH := 2.4
const HR := ROOM / 2.0
const DIRS := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
const FRAME := Color(0.2, 0.12, 0.07)

const THEMES := {
	# ---- 0: warehouse complex
	"warehouse": {"wt": "wall_corrugated", "ft": "floor_concrete", "wn": "wall_block", "ct": "ceiling_concrete", "wall": Color(0.47, 0.46, 0.44), "floor": Color(0.45, 0.45, 0.44), "light": Color(1.0, 0.72, 0.42), "pieces": ["rack", "rack", "crates", "pallet", "barrels", "forklift"]},
	"storage": {"wt": "wall_block", "ft": "floor_concrete", "wn": "metal", "ct": "ceiling_concrete", "wall": Color(0.47, 0.48, 0.48), "floor": Color(0.42, 0.42, 0.42), "light": Color(1.0, 0.82, 0.6), "pieces": ["crates", "barrels", "rack", "lockers", "crates"]},
	"office": {"wt": "wall_plaster", "ft": "floor_carpet", "wn": "wall_block", "ct": "ceiling_tiles", "wall": Color(0.48, 0.47, 0.45), "floor": Color(0.45, 0.46, 0.5), "light": Color(0.88, 0.95, 1.0), "pieces": ["desk", "desk", "cabinet", "lockers", "cooler", "desk"]},
	"meeting": {"wt": "wall_plaster", "ft": "floor_carpet", "wn": "wall_block", "ct": "ceiling_tiles", "wall": Color(0.46, 0.47, 0.5), "floor": Color(0.4, 0.42, 0.5), "light": Color(0.9, 0.95, 1.0), "pieces": ["table", "table", "cabinet", "board"]},
	"breakroom": {"wt": "wall_tiles", "ft": "floor_vinyl", "wn": "wall_block", "ct": "ceiling_tiles", "wall": Color(0.47, 0.47, 0.46), "floor": Color(0.45, 0.45, 0.45), "light": Color(1.0, 0.92, 0.8), "pieces": ["vending", "sofa", "table", "cooler", "vending"]},
	"archive": {"wt": "wall_block", "ft": "floor_wood", "wn": "metal", "ct": "ceiling_tiles", "wall": Color(0.46, 0.45, 0.43), "floor": Color(0.45, 0.45, 0.45), "light": Color(1.0, 0.85, 0.62), "pieces": ["shelf", "shelf", "cabinet", "crates"]},
	"dorm": {"wt": "wall_plaster", "ft": "floor_wood", "wn": "wall_block", "ct": "ceiling_tiles", "wall": Color(0.5, 0.46, 0.42), "floor": Color(0.45, 0.45, 0.45), "light": Color(1.0, 0.8, 0.55), "pieces": ["bed", "lockers", "bed", "cabinet"]},
	"lab": {"wt": "wall_tiles", "ft": "floor_vinyl", "wn": "wall_metal", "ct": "ceiling_tiles", "wall": Color(0.47, 0.48, 0.48), "floor": Color(0.47, 0.47, 0.48), "light": Color(0.7, 1.0, 0.82), "pieces": ["labbench", "labbench", "tank", "medcab", "tank"]},
	"servers": {"wt": "wall_metal", "ft": "floor_plate", "wn": "metal", "ct": "ceiling_concrete", "wall": Color(0.44, 0.46, 0.5), "floor": Color(0.45, 0.45, 0.45), "light": Color(0.55, 0.78, 1.0), "pieces": ["server", "server", "server", "terminal"]},
	"boiler": {"wt": "wall_brick", "ft": "floor_concrete", "wn": "wall_block", "ct": "ceiling_concrete", "wall": Color(0.47, 0.45, 0.43), "floor": Color(0.34, 0.33, 0.32), "light": Color(1.0, 0.6, 0.3), "pieces": ["boiler", "generator", "barrels", "crates", "panel"]},
	"garage": {"wt": "wall_block", "ft": "floor_concrete", "wn": "metal", "ct": "ceiling_concrete", "wall": Color(0.45, 0.46, 0.46), "floor": Color(0.4, 0.4, 0.4), "light": Color(0.95, 0.95, 1.0), "pieces": []},
	"shop": {"wt": "wall_metal", "ft": "floor_concrete", "wn": "metal", "ct": "ceiling_concrete", "wall": Color(0.5, 0.48, 0.46), "floor": Color(0.45, 0.45, 0.45), "light": Color(1.0, 0.82, 0.6), "pieces": []},
	# narrow hallways and small rooms (inset inside a grid cell), one set per location
	"corridor_0": {"wt": "wall_metal", "ft": "floor_plate", "wn": "metal", "ct": "ceiling_concrete", "wall": Color(0.46, 0.46, 0.46), "floor": Color(0.45, 0.45, 0.45), "light": Color(1.0, 0.7, 0.42), "pieces": []},
	"corridor_1": {"wt": "wall_plaster", "ft": "floor_vinyl", "wn": "wall_block", "ct": "ceiling_tiles", "wall": Color(0.47, 0.47, 0.46), "floor": Color(0.45, 0.45, 0.45), "light": Color(0.9, 0.95, 1.0), "pieces": []},
	"corridor_2": {"wt": "wall_metal", "ft": "floor_plate", "wn": "metal", "ct": "ceiling_concrete", "wall": Color(0.46, 0.45, 0.45), "floor": Color(0.42, 0.42, 0.42), "light": Color(1.0, 0.22, 0.14), "pieces": []},
	"closet_0": {"wt": "wall_block", "ft": "floor_concrete", "wn": "metal", "ct": "ceiling_concrete", "wall": Color(0.47, 0.47, 0.46), "floor": Color(0.42, 0.42, 0.42), "light": Color(1.0, 0.8, 0.55), "pieces": ["crates", "barrels", "lockers", "crates"]},
	"closet_1": {"wt": "wall_tiles", "ft": "floor_vinyl", "wn": "wall_tiles", "ct": "ceiling_tiles", "wall": Color(0.47, 0.47, 0.47), "floor": Color(0.45, 0.45, 0.45), "light": Color(0.95, 0.97, 1.0), "pieces": ["toilet", "sink", "toilet", "lockers"]},
	"closet_2": {"wt": "wall_metal", "ft": "floor_plate", "wn": "metal", "ct": "ceiling_concrete", "wall": Color(0.44, 0.46, 0.5), "floor": Color(0.42, 0.42, 0.42), "light": Color(0.6, 0.85, 1.0), "pieces": ["server", "panel", "medcab"]},
}
## Themes that can form big merged halls (2x1, 3x1, 2x2 cells) and what stands in their middle.
const HALL_THEMES := {"warehouse": "racks", "storage": "crates", "office": "desks", "meeting": "table", "archive": "shelves",
	"lab": "benches", "servers": "servers", "breakroom": "table"}
const AW := 2.6          # width of a corridor / doorway arm inside an inset cell
const LOCATION_ROOMS := [
	["warehouse", "warehouse", "storage", "office", "breakroom", "boiler"],
	["office", "office", "meeting", "archive", "breakroom", "dorm"],
	["lab", "lab", "servers", "office", "boiler", "storage"],
]

var rng := RandomNumberGenerator.new()
var location := 0
var cells := {}
var order := []
var conn := {}
var astar := AStar2D.new()
var cell_ids := {}
var door_pos := {}
var dist := {}
var spawn_cell := Vector2i.ZERO
var door_dir := Vector2i(1, 0)
var spawn_points := []
var truck_pos := Vector3.ZERO
var truck_button := Vector3.ZERO
var cart_pos := Vector3.ZERO
var extraction_cells := []
var extraction_points := []
var item_spots := []
var monster_cells := []
var lights := []
var root: Node3D
var body: StaticBody3D
var truck_back := Vector3.ZERO
var truck_side := Vector3.ZERO
var truck_screen := Vector3.ZERO
var _sts := {}
var _mk := "wall"
var _vis := true
var _th: Dictionary = {}
var _decor := []
var _mcache := {}
var room_of := {}        # cell -> room id (cells of one big hall share it)
var rooms := []          # room id -> Array of cells
var inset := {}          # cell -> half size of the inset room (corridors 1.3, small rooms 2.7)
var mask_tex: ImageTexture = null
var _mask_origin := Vector2i.ZERO
const ML = preload("res://scripts/game/matlib.gd")
const LOW_PIECES := ["table", "crates", "sofa", "desk", "labbench", "pallet", "barrels", "generator", "bed"]
var mat: StandardMaterial3D
var lamp_mat: StandardMaterial3D


static func key(a: Vector2i, b: Vector2i) -> String:
	if a.x < b.x or (a.x == b.x and a.y < b.y):
		return "%d,%d|%d,%d" % [a.x, a.y, b.x, b.y]
	return "%d,%d|%d,%d" % [b.x, b.y, a.x, a.y]


static func cell_center(c: Vector2i) -> Vector3:
	return Vector3(c.x * ROOM, 0.0, c.y * ROOM)


static func cell_at(p: Vector3) -> Vector2i:
	return Vector2i(roundi(p.x / ROOM), roundi(p.z / ROOM))


func conn_type(a: Vector2i, b: Vector2i) -> int:
	var k := key(a, b)
	if conn.has(k):
		return int(conn[k]["t"])
	return 0


func build(s: int, level: int, parent: Node3D) -> void:
	rng.seed = s
	location = (level - 1) % LOCATION_ROOMS.size()
	_layout(level)
	_group_rooms()
	_connect()
	_graph()
	_pick_special(level)
	_pick_insets()
	_make_geometry(parent)


func _make_geometry(parent: Node3D) -> void:
	root = Node3D.new()
	root.name = "Level"
	parent.add_child(root)
	body = StaticBody3D.new()
	body.name = "Static"
	body.collision_layer = 1
	body.collision_mask = 0
	root.add_child(body)
	mat = StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.92
	var nt := NoiseTexture2D.new()
	nt.width = 128
	nt.height = 128
	nt.seamless = true
	var fn := FastNoiseLite.new()
	fn.frequency = 0.06
	fn.fractal_octaves = 3
	nt.noise = fn
	var g := Gradient.new()
	g.set_color(0, Color(0.72, 0.72, 0.72))
	g.set_color(1, Color(1, 1, 1))
	nt.color_ramp = g
	mat.albedo_texture = nt
	mat.uv1_triplanar = true
	mat.uv1_scale = Vector3(0.6, 0.6, 0.6)
	lamp_mat = StandardMaterial3D.new()
	lamp_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lamp_mat.albedo_color = Color(1.0, 0.9, 0.7)
	_build_mask()
	for c in order:
		_build_cell(c)
	for r in rooms:
		if r.size() >= 2:
			_hall_features(r)


# ------------------------------------------------------------------ layout

func _nb_count(c: Vector2i) -> int:
	var n := 0
	for d in DIRS:
		if cells.has(c + d):
			n += 1
	return n


func _layout(level: int) -> void:
	var target := clampi(7 + level * 3, 8, 34)
	cells[Vector2i.ZERO] = "garage"
	order.append(Vector2i.ZERO)
	var guard := 0
	while order.size() < target and guard < 20000:
		guard += 1
		var base: Vector2i = order[rng.randi() % order.size()]
		var n: Vector2i = base + DIRS[rng.randi() % 4]
		if cells.has(n):
			continue
		var touches_spawn := (n - Vector2i.ZERO).length_squared() == 1
		if touches_spawn and _nb_count(Vector2i.ZERO) >= 1:
			continue
		if base == Vector2i.ZERO and _nb_count(Vector2i.ZERO) >= 1:
			continue
		cells[n] = ""
		order.append(n)
	var names: Array = LOCATION_ROOMS[location]
	for c in order:
		if c != Vector2i.ZERO:
			cells[c] = names[rng.randi() % names.size()]
	for d in DIRS:
		if cells.has(Vector2i.ZERO + d):
			door_dir = d


func _connect() -> void:
	var visited := {spawn_cell: true}
	var stack := [spawn_cell]
	while stack.size() > 0:
		var c: Vector2i = stack[stack.size() - 1]
		var nbs := []
		for d in DIRS:
			var n: Vector2i = c + d
			if cells.has(n) and not visited.has(n):
				nbs.append(n)
		if nbs.is_empty():
			stack.pop_back()
			continue
		var n: Vector2i = nbs[rng.randi() % nbs.size()]
		visited[n] = true
		var t := 2 if _same_room(c, n) else 1
		conn[key(c, n)] = {"a": c, "b": n, "t": t}
		stack.append(n)
	for c in order:
		for d in [Vector2i(1, 0), Vector2i(0, 1)]:
			var n: Vector2i = c + d
			if not cells.has(n) or conn.has(key(c, n)):
				continue
			if c == spawn_cell or n == spawn_cell:
				continue
			if _same_room(c, n):
				conn[key(c, n)] = {"a": c, "b": n, "t": 2}
			elif rng.randf() < 0.3:
				conn[key(c, n)] = {"a": c, "b": n, "t": 1}


func _graph() -> void:
	for i in order.size():
		cell_ids[order[i]] = i
		astar.add_point(i, Vector2(order[i].x, order[i].y))
	for k in conn:
		var a: Vector2i = conn[k]["a"]
		var b: Vector2i = conn[k]["b"]
		astar.connect_points(cell_ids[a], cell_ids[b])
		door_pos[k] = (cell_center(a) + cell_center(b)) * 0.5
	dist[spawn_cell] = 0
	var q := [spawn_cell]
	while q.size() > 0:
		var c: Vector2i = q.pop_front()
		for d in DIRS:
			var n: Vector2i = c + d
			if cells.has(n) and not dist.has(n) and conn.has(key(c, n)):
				dist[n] = dist[c] + 1
				q.append(n)


func _pick_special(level: int) -> void:
	var cands := order.duplicate()
	cands.erase(spawn_cell)
	cands.sort_custom(func(a, b): return dist.get(a, 0) > dist.get(b, 0))
	# extraction points per level like the reference game: 1 / 2 / 2 / 3 / 3 / 4 ... / 5 from level 15
	var want := 1 if level <= 1 else (2 if level <= 3 else (3 if level <= 5 else (4 if level <= 14 else 5)))
	want = mini(want, cands.size() - 1)
	for c in cands:
		if extraction_cells.size() >= want:
			break
		if dist.get(c, 0) < 2 and cands.size() > 4:
			continue
		var ok := true
		for e in extraction_cells:
			if absi(e.x - c.x) + absi(e.y - c.y) <= 1:
				ok = false
		if ok:
			extraction_cells.append(c)
	if extraction_cells.is_empty():
		extraction_cells.append(cands[0])
	# order the points so the nearest to spawn is first
	extraction_cells.sort_custom(func(a, b): return dist.get(a, 0) < dist.get(b, 0))
	for c in extraction_cells:
		extraction_points.append(cell_center(c) + Vector3(0, 0.02, 0))
	for c in order:
		if dist.get(c, 0) >= 2:
			monster_cells.append(c)
	if monster_cells.is_empty():
		for c in order:
			if c != spawn_cell:
				monster_cells.append(c)


# ------------------------------------------------------------------ queries

## Inside the van (its box, floor to roof)?
func in_van(p: Vector3) -> bool:
	if truck_back == Vector3.ZERO:
		return false
	var rel := p - (truck_pos - Vector3(0, 0.5, 0))
	return absf(rel.dot(truck_back)) < 1.62 and absf(rel.dot(truck_side)) < 1.18 and rel.y > -0.3 and rel.y < 3.0


func path_points(from: Vector3, to: Vector3) -> Array:
	var pts := _path_cells(from, to)
	# the van is entered only up the ramp at its open back: a straight line from the side runs into
	# its wall (monsters chasing a robot into the van used to grind against it forever)
	if truck_back != Vector3.ZERO:
		var tb := truck_pos - Vector3(0, 0.5, 0)
		var foot := tb - truck_back * 3.5
		var top := tb - truck_back * 1.1 + Vector3(0, 0.5, 0)
		var fin := in_van(from)
		var tin := in_van(to)
		if tin and not fin:
			var along := (from - tb).dot(truck_back)
			var on_ramp := absf((from - tb).dot(truck_side)) < 1.1 and along > -3.2 and along < -1.4
			pts.pop_back()
			if not on_ramp:
				pts.append(foot)
			pts.append(top)
			pts.append(to)
		elif fin and not tin:
			pts.push_front(foot)
			pts.push_front(top)
	return pts


func _path_cells(from: Vector3, to: Vector3) -> Array:
	var ca := cell_at(from)
	var cb := cell_at(to)
	if not cell_ids.has(ca) or not cell_ids.has(cb) or ca == cb:
		return [to]
	var ids := astar.get_id_path(cell_ids[ca], cell_ids[cb])
	var pts := []
	if inset.has(ca) and float(inset[ca]) < 2.0 and ids.size() > 1:
		var first: Vector3 = door_pos[key(ca, order[ids[1]])]
		if from.distance_to(first) > cell_center(ca).distance_to(first) + 0.3:
			pts.append(cell_center(ca))
	for j in range(1, ids.size()):
		var prev: Vector2i = order[ids[j - 1]]
		var cur: Vector2i = order[ids[j]]
		var dp: Vector3 = door_pos[key(prev, cur)]
		var axis := (cell_center(cur) - cell_center(prev)).normalized()
		if inset.has(prev) and j > 1:
			pts.append(cell_center(prev))     # turn inside the corridor instead of cutting the corner
		pts.append(dp - axis * 1.0)
		pts.append(dp + axis * 1.0)
	if inset.has(cb) and float(inset[cb]) < 2.0 and ids.size() > 1:
		var last: Vector3 = door_pos[key(order[ids[ids.size() - 2]], cb)]
		var ax2 := (cell_center(cb) - last).normalized()
		var rel := to - cell_center(cb)
		if absf(rel.x * ax2.z - rel.z * ax2.x) > 0.6:
			pts.append(cell_center(cb))
	pts.append(to)
	return pts


## Where the extraction console stands, relative to the pad: against a wall side of the room so
## the straight way in from every door stays clear (a pad corner when every side is open).
func console_offset(c: Vector2i) -> Vector3:
	for d in DIRS:
		var n: Vector2i = c + d
		if not cells.has(n) or conn_type(c, n) == 0:
			return Vector3(d.x, 0, d.y) * 2.15
	return Vector3(2.05, 0, 2.05)


func random_point(r: RandomNumberGenerator) -> Vector3:
	var c: Vector2i = order[r.randi() % order.size()]
	return spawn_point(c, r, 2.0)


## A free spot around a cell centre (kept inside corridors and small rooms).
func spawn_point(c: Vector2i, r: RandomNumberGenerator, amount := 1.5) -> Vector3:
	var ih := float(inset.get(c, 9.0))
	var a := minf(amount, ih - (0.7 if ih < 2.0 else 1.5))
	a = maxf(a, 0.0)
	if room_of.has(c) and rooms[room_of[c]].size() >= 2:
		var along := r.randf_range(-a, a)
		var across := r.randf_range(-0.4, 0.4)
		return cell_center(c) + (Vector3(along, 0.1, across) if r.randf() < 0.5 else Vector3(across, 0.1, along))
	return cell_center(c) + Vector3(r.randf_range(-a, a), 0.1, r.randf_range(-a, a))


func is_inside(p: Vector3) -> bool:
	return cells.has(cell_at(p))


# ------------------------------------------------------------------ geometry

func _add_shape(c: Vector3, s: Vector3) -> void:
	var cs := CollisionShape3D.new()
	var b := BoxShape3D.new()
	b.size = s
	cs.shape = b
	cs.position = c
	body.add_child(cs)


func _st() -> SurfaceTool:
	if not _sts.has(_mk):
		var t := SurfaceTool.new()
		t.begin(Mesh.PRIMITIVE_TRIANGLES)
		_sts[_mk] = t
	return _sts[_mk]


func _box(_unused, c: Vector3, s: Vector3, col: Color, collide: bool) -> void:
	if collide:
		_add_shape(c, s)
	if not _vis:
		return
	var st := _st()
	var h := s * 0.5
	for axis in 3:
		for sg in [-1.0, 1.0]:
			var n := Vector3.ZERO
			n[axis] = sg
			var u := Vector3.ZERO
			u[(axis + 1) % 3] = 1.0
			var v := Vector3.ZERO
			v[(axis + 2) % 3] = 1.0
			var fc: Vector3 = c + n * h[axis]
			var hu: Vector3 = u * h[(axis + 1) % 3]
			var hv: Vector3 = v * h[(axis + 2) % 3]
			var p0 := fc - hu - hv
			var p1 := fc + hu - hv
			var p2 := fc + hu + hv
			var p3 := fc - hu + hv
			var shade := 1.0 if axis == 1 else 0.9
			st.set_color(Color(col.r * shade, col.g * shade, col.b * shade))
			st.set_normal(n)
			if (p1 - p0).cross(p2 - p0).dot(n) < 0.0:
				st.add_vertex(p0); st.add_vertex(p1); st.add_vertex(p2)
				st.add_vertex(p0); st.add_vertex(p2); st.add_vertex(p3)
			else:
				st.add_vertex(p0); st.add_vertex(p2); st.add_vertex(p1)
				st.add_vertex(p0); st.add_vertex(p3); st.add_vertex(p2)


## Box in a wall-local frame: x = along wall, y = up, z = distance from wall face.
func _lbox(st, base: Vector3, along: Vector3, inward: Vector3, lc: Vector3, ls: Vector3, col: Color, collide := true) -> void:
	var c := base + along * lc.x + Vector3.UP * lc.y + inward * lc.z
	var s := along.abs() * ls.x + Vector3(0, ls.y, 0) + inward.abs() * ls.z
	_box(st, c, s, col, collide)


static var _halo_mat := {}
static var _shaft_mat: StandardMaterial3D = null


## Soft glow sprite around a lamp (reads as bloom even on low quality, costs one quad).
func _halo(pos: Vector3, col: Color, size: float) -> MeshInstance3D:
	var key := col.to_html()
	if not _halo_mat.has(key):
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
		m.albedo_texture = preload("res://scripts/game/fx.gd").soft_tex()
		m.albedo_color = Color(col.r, col.g, col.b, 0.28)
		m.no_depth_test = false
		m.disable_receive_shadows = true
		_halo_mat[key] = m
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = _halo_mat[key]
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.position = pos
	root.add_child(mi)
	ML.vis_range(mi, 24.0)
	return mi


## Faint cold moonlight falling through a window onto the floor.
func _moon_shaft(win: Vector3, inward: Vector3) -> void:
	if _shaft_mat == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 0.0))
		g.add_point(0.25, Color(1, 1, 1, 1.0))
		g.set_color(g.get_point_count() - 1, Color(1, 1, 1, 0.0))
		var gt := GradientTexture2D.new()
		gt.gradient = g
		gt.width = 64
		gt.height = 8
		_shaft_mat = StandardMaterial3D.new()
		_shaft_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_shaft_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		_shaft_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_shaft_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		_shaft_mat.albedo_texture = gt
		_shaft_mat.albedo_color = Color(0.45, 0.58, 0.9, 0.06)
		_shaft_mat.disable_receive_shadows = true
	var along := inward.cross(Vector3.UP).normalized()
	for k in 2:
		var q := QuadMesh.new()
		q.size = Vector2(3.2, 1.0)
		var mi := MeshInstance3D.new()
		mi.mesh = q
		mi.material_override = _shaft_mat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(mi)
		# slanted slab from the window down into the room; two crossed planes read as a volume
		var down := (inward * 0.8 + Vector3(0, -0.6, 0)).normalized()
		var side := along if k == 0 else (along * 0.5 + Vector3(0, 0.866, 0)).normalized()
		var nrm := down.cross(side).normalized()
		mi.global_transform = Transform3D(Basis(down, side, nrm), win + down * 1.55)
		ML.vis_range(mi, 18.0)


## Occlusion culling: walls hide whole rooms behind them (big win on weak GPUs, zero visual cost).
func _occluder(center: Vector3, size: Vector3) -> void:
	if not _vis:
		return
	var oc := OccluderInstance3D.new()
	var bo := BoxOccluder3D.new()
	bo.size = size
	oc.occluder = bo
	oc.position = center
	root.add_child(oc)


func _wall(_st_unused, c: Vector2i, d: Vector2i, door: bool, col: Color) -> void:
	var cc := cell_center(c)
	var normal := Vector3(d.x, 0, d.y)
	var along := Vector3(absi(d.y), 0, absi(d.x))
	var wc := cc + normal * HR
	var nt := normal.abs() * WT
	var dado := 1.0
	var white := Color(1, 1, 1)
	var segs := []
	if not door:
		segs.append([wc, ROOM + WT])
	else:
		var seg := HR - DW / 2.0 + WT / 2.0
		for sg in [-1.0, 1.0]:
			segs.append([wc + along * sg * (DW / 2.0 + seg / 2.0), seg])
	for sgm in segs:
		var sc: Vector3 = sgm[0]
		var ln: float = sgm[1]
		_mk = "wains"
		_box(null, sc + Vector3(0, dado / 2.0, 0), along * ln + Vector3(0, dado, 0) + nt, white, true)
		_mk = "wall"
		_box(null, sc + Vector3(0, (dado + H) / 2.0, 0), along * ln + Vector3(0, H - dado, 0) + nt, col, true)
		_occluder(sc + Vector3(0, H / 2.0, 0), along * maxf(0.1, ln - 0.3) + Vector3(0, H - 0.3, 0) + normal.abs() * WT * 0.5)
		_mk = "trim"
		_box(null, sc + Vector3(0, 0.07, 0), along * ln + Vector3(0, 0.14, 0) + normal.abs() * (WT + 0.05), white, false)
		_box(null, sc + Vector3(0, dado, 0), along * ln + Vector3(0, 0.05, 0) + normal.abs() * (WT + 0.04), white, false)
		_box(null, sc + Vector3(0, H - 0.06, 0), along * ln + Vector3(0, 0.12, 0) + normal.abs() * (WT + 0.08), white, false)
	if door:
		_mk = "wall"
		_box(null, wc + Vector3(0, (DH + H) / 2.0, 0), along * DW + Vector3(0, H - DH, 0) + nt, col, true)
		_decor.append({"model": "doorframe", "pos": wc, "fwd": normal, "scale": 1.0})
		if location != 2 and rng.randf() < 0.55:
			# an open door leaf resting against the wall inside this room
			var side := 1.0 if rng.randf() < 0.5 else -1.0
			var into := -normal
			var fwd := along
			if fwd.cross(Vector3.UP).dot(into) < 0.0:
				fwd = -fwd
			var hinge := wc + along * side * (DW / 2.0 - 0.03) + into * (WT / 2.0)
			_decor.append({"model": "door", "pos": hinge, "fwd": fwd, "scale": 1.0, "sx": 0.53})    # one leaf of a double door
			_add_shape(hinge + into * 0.45 + Vector3(0, 1.15, 0), into.abs() * 0.9 + along.abs() * 0.06 + Vector3(0, 2.3, 0))


const SurfaceShader = preload("res://assets/shaders/surface.gdshader")
static var _dirt_tex: NoiseTexture2D = null


static func dirt_texture() -> NoiseTexture2D:
	if _dirt_tex == null:
		var fn := FastNoiseLite.new()
		fn.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
		fn.frequency = 0.012
		fn.fractal_octaves = 5
		fn.seed = 77
		_dirt_tex = NoiseTexture2D.new()
		_dirt_tex.width = 256
		_dirt_tex.height = 256
		_dirt_tex.seamless = true
		_dirt_tex.generate_mipmaps = true
		_dirt_tex.noise = fn
	return _dirt_tex


## World surface material (see assets/shaders/surface.gdshader).
static func surface_material(tname: String, scale: float, tint: float, boost := 1.3, dirt := 0.5, rough_add := 0.0, ao := 1.0, nstr := 1.0) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = SurfaceShader
	m.set_shader_parameter("albedo_tex", ML.tex(tname))
	var tn: Texture2D = ML.tex(tname + "_n")
	if tn:
		m.set_shader_parameter("normal_tex", tn)
	m.set_shader_parameter("normal_strength", nstr if tn else 0.0)
	var tr: Texture2D = ML.tex(tname + "_r")
	if tr:
		m.set_shader_parameter("rough_tex", tr)
	else:
		m.set_shader_parameter("rough_add", 0.8)
		m.set_shader_parameter("rough_mul", 0.0)
	m.set_shader_parameter("uv_scale", scale)
	m.set_shader_parameter("tint_amount", tint)
	m.set_shader_parameter("tint_boost", boost)
	m.set_shader_parameter("dirt_tex", dirt_texture())
	m.set_shader_parameter("dirt_amount", dirt)
	m.set_shader_parameter("rough_add", rough_add if tr else 0.8)
	m.set_shader_parameter("ao_strength", ao)
	m.set_shader_parameter("room", ROOM)
	m.set_shader_parameter("half_room", HR - WT / 2.0)
	m.set_shader_parameter("room_h", H)
	return m


func _surface_mat(key: String) -> Material:
	var th := _th
	var ck: String = key + "|" + str(th.get("wt", "")) + str(th.get("ft", "")) + str(th.get("wn", "")) + str(th.get("ct", ""))
	if _mcache.has(ck):
		return _mcache[ck]
	var m: Material = null
	match key:
		"wall":
			m = surface_material(th["wt"], 0.42, 1.0, 1.25, 0.55)
		"wains":
			var wn: String = th["wn"]
			m = surface_material(wn, 0.55, 0.0 if wn in ["metal", "wall_metal", "wall_tiles"] else 0.6, 1.2, 0.6)
		"floor":
			var ft: String = th["ft"]
			# varnished wood, vinyl and tread plate are glossier than their maps (they reflect the room)
			var gloss := -0.14 if ft in ["floor_wood", "floor_vinyl", "floor_plate"] else 0.0
			m = surface_material(ft, 0.3 if ft in ["floor_vinyl", "floor_carpet"] else 0.34, 0.45 if ft in ["floor_carpet", "floor_concrete"] else 0.0, 1.0, 0.45, gloss)
		"ceil":
			m = surface_material(str(th.get("ct", "ceiling_tiles")), 0.3, 0.0, 1.0, 0.3, 0.1, 0.8)
		"trim":
			m = surface_material("metal", 1.0, 0.0, 1.0, 0.2, 0.0, 0.4)
		"rug":
			m = surface_material("hazard", 1.4, 0.0, 1.0, 0.35, 0.0, 0.5)
		_:
			var sm := StandardMaterial3D.new()
			sm.vertex_color_use_as_albedo = true
			sm.roughness = 0.85
			m = sm
	if mask_tex and m is ShaderMaterial:
		m.set_shader_parameter("use_mask", true)
		m.set_shader_parameter("cell_mask", mask_tex)
		m.set_shader_parameter("mask_origin", Vector2(_mask_origin))
	_mcache[ck] = m
	return m


## Per-room reflection probe (high quality only): parallax-corrected, captured once when the level loads.
func _probe(cc: Vector3, hs := HR) -> void:
	if Settings.eff_quality() < 2 or DisplayServer.get_name() == "headless":
		return
	var p := ReflectionProbe.new()
	p.size = Vector3(hs * 2.0 + 0.3, H + 0.3, hs * 2.0 + 0.3)
	p.box_projection = true
	p.interior = true
	p.enable_shadows = false
	p.update_mode = ReflectionProbe.UPDATE_ONCE
	p.max_distance = 12.0
	p.ambient_mode = ReflectionProbe.AMBIENT_DISABLED
	p.blend_distance = 0.8
	p.intensity = 0.9
	p.mesh_lod_threshold = 4.0
	root.add_child(p)
	p.global_position = cc + Vector3(0, H * 0.5, 0)


func _build_cell(c: Vector2i) -> void:
	_sts = {}
	var th: Dictionary = THEMES[cells[c]]
	_th = th
	var cc := cell_center(c)
	var wcol: Color = th["wall"]
	var tr := RandomNumberGenerator.new()
	tr.seed = int(room_of.get(c, 0)) * 7919 + rng.seed % 100000
	wcol = wcol.lerp(Color(tr.randf(), tr.randf(), tr.randf()), 0.07)
	var wtint := Color(minf(wcol.r * 1.7, 1.0), minf(wcol.g * 1.7, 1.0), minf(wcol.b * 1.7, 1.0))
	var ftint := Color.WHITE
	if th["ft"] in ["floor_carpet", "floor_concrete"]:
		var fc: Color = th["floor"]
		ftint = Color(minf(fc.r * 2.2, 1.0), minf(fc.g * 2.2, 1.0), minf(fc.b * 2.2, 1.0))
	_mk = "floor"
	_box(null, cc + Vector3(0, -0.1, 0), Vector3(ROOM, 0.2, ROOM), ftint, true)
	_mk = "ceil"
	_box(null, cc + Vector3(0, H + 0.1, 0), Vector3(ROOM, 0.2, ROOM), Color.WHITE, true)
	var hs := float(inset.get(c, HR))
	_probe(cc, hs)
	for d in DIRS:
		var n: Vector2i = c + d
		var own: bool = d == Vector2i(1, 0) or d == Vector2i(0, 1) or not cells.has(n)
		if not own:
			continue
		var t := conn_type(c, n) if cells.has(n) else 0
		if t == 2:
			continue
		_wall(null, c, d, t == 1, wtint)
	if c == spawn_cell:
		_build_garage(null, c)
	elif inset.has(c):
		_build_inset(c, hs, wtint)
		if hs > 2.0:
			_furnish_inset(c, hs)
		_floor_decals(cc, hs - 0.8)
	else:
		_furnish(null, c)
		_add_decals(c)
	var mesh := ArrayMesh.new()
	var keys := _sts.keys()
	for k in keys:
		var st: SurfaceTool = _sts[k]
		st.commit(mesh)
		mesh.surface_set_material(mesh.get_surface_count() - 1, _surface_mat(k))
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	root.add_child(mi)
	for dc in _decor:
		_spawn_decor(dc)
	_decor.clear()
	# ceiling lamp model + light
	var lname := "lamp_pendant"
	var tn: String = cells[c]
	if tn in ["office", "meeting", "breakroom", "lab", "servers", "shop", "archive", "dorm", "corridor_1", "closet_1", "closet_2", "garage"]:
		lname = "lamp_tube"
	elif tn == "corridor_2":
		lname = "beacon_red"
	var lamp := ML.model(lname, {}, false)
	if lamp:
		lamp.position = cc + Vector3(0, H, 0)
		if lname.begins_with("beacon"):
			lamp.rotation.x = PI       # hanging from the ceiling
		root.add_child(lamp)
		ML.vis_range(lamp, 26.0)
	var l := OmniLight3D.new()
	l.light_color = th["light"]
	l.light_energy = 1.35 if c != spawn_cell else 1.7
	if location == 2:
		l.light_energy *= 1.15
	l.omni_range = 8.5
	l.omni_attenuation = 1.45
	l.light_energy *= 1.05
	l.shadow_enabled = false
	l.omni_shadow_mode = OmniLight3D.SHADOW_DUAL_PARABOLOID
	l.shadow_bias = 0.06
	l.shadow_normal_bias = 1.5
	l.shadow_blur = 1.5
	l.light_size = 0.15
	# lights of far rooms stop costing anything
	l.distance_fade_enabled = true
	l.distance_fade_begin = 24.0
	l.distance_fade_length = 6.0
	l.distance_fade_shadow = 14.0
	l.position = cc + Vector3(0, H - 0.75, 0)
	if inset.has(c):
		l.omni_range = 3.2 + hs * 1.1
		l.light_energy *= 0.75 if hs < 2.0 else 0.9
	elif room_of.has(c) and rooms[room_of[c]].size() >= 2:
		l.omni_range = 9.5
	if tn == "shop":
		# the shop is a safe, well-lit store: brighter, wider, plus a fill light at shelf height
		l.light_energy *= 1.9
		l.omni_range = 10.0
		var fill := OmniLight3D.new()
		fill.light_color = Color(1.0, 0.93, 0.82)
		fill.light_energy = 0.9
		fill.omni_range = 7.0
		fill.position = cc + Vector3(0, 1.4, 0)
		root.add_child(fill)
	elif c != spawn_cell and rng.randf() < 0.08:
		l.light_energy *= 0.25        # a burnt-out lamp here and there: bring the flashlight
	if c == spawn_cell:
		l.position = cc - truck_back * 2.4 + Vector3(0, H - 0.5, 0)
		var inner := OmniLight3D.new()
		inner.light_color = Color(1.0, 0.95, 0.85)
		inner.light_energy = 0.3
		inner.omni_range = 3.5
		inner.position = truck_pos + Vector3(0, 1.8, 0)
		root.add_child(inner)
	root.add_child(l)
	var halo := _halo(l.position + Vector3(0, 0.25, 0), th["light"], 1.3)
	lights.append({"light": l, "base": l.light_energy, "flicker": c != spawn_cell and rng.randf() < 0.2, "lamp": lamp, "halo": halo})


static var _decal_tex := {}


static func decal_tex(n: String) -> Texture2D:
	if not _decal_tex.has(n):
		var p := "res://assets/decals/%s.png" % n
		_decal_tex[n] = load(p) if ResourceLoader.exists(p) else null
	return _decal_tex[n]


func _decal(tex: String, pos: Vector3, b: Basis, size: Vector3, alpha := 1.0) -> void:
	var t := decal_tex(tex)
	if t == null:
		return
	var d := Decal.new()
	d.texture_albedo = t
	d.size = size
	d.modulate = Color(1, 1, 1, alpha)
	d.albedo_mix = 1.0
	d.upper_fade = 0.2
	d.lower_fade = 0.2
	d.distance_fade_enabled = true
	d.distance_fade_begin = 13.0
	d.distance_fade_length = 4.0
	d.cull_mask = 1
	root.add_child(d)
	d.global_transform = Transform3D(b, pos)


## Grunge: stains, mould, cracks and drips on walls, dirt and scuffs on the floor, cobwebs in corners.
func _add_decals(c: Vector2i) -> void:
	var cc := cell_center(c)
	var clean := location == 2
	var inner := HR - WT / 2.0
	var n_wall := rng.randi_range(2, 4) if not clean else rng.randi_range(1, 2)
	for i in n_wall:
		var d: Vector2i = DIRS[rng.randi() % 4]
		var nb: Vector2i = c + d
		if cells.has(nb) and conn_type(c, nb) == 2:
			continue
		var normal := Vector3(d.x, 0, d.y)
		var along := Vector3(absi(d.y), 0, absi(d.x))
		var off := rng.randf_range(-3.0, 3.0)
		if cells.has(nb) and conn_type(c, nb) == 1 and absf(off) < 1.3:
			off = 2.2 * signf(off + 0.01)
		var kind: String = ["stain_water", "mould", "crack", "drips", "stain_water"][rng.randi() % 5]
		if clean:
			kind = ["crack", "scuffs"][rng.randi() % 2]
		var y := rng.randf_range(1.2, 2.5)
		var sz := rng.randf_range(0.8, 1.8)
		if kind == "drips":
			y = H - 0.9
			sz = rng.randf_range(1.0, 1.6)
		elif kind == "mould":
			y = rng.randf_range(0.4, 1.0) if rng.randf() < 0.5 else H - 0.5
		var yv := -normal
		var xv := yv.cross(Vector3.UP).normalized()
		var b := Basis(xv, yv, xv.cross(yv).normalized())
		_decal(kind, cc + normal * (inner - 0.05) + along * off + Vector3(0, y, 0), b, Vector3(sz, 0.5, sz * (1.6 if kind == "drips" else 1.0)), rng.randf_range(0.6, 1.0))
	for i in rng.randi_range(1, 3):
		var kind2: String = ["floor_dirt", "scuffs", "stain_water"][rng.randi() % 3]
		var b2 := Basis(Vector3.UP, rng.randf() * TAU)
		var sz2 := rng.randf_range(1.0, 2.4)
		_decal(kind2, cc + Vector3(rng.randf_range(-2.8, 2.8), 0.1, rng.randf_range(-2.8, 2.8)), b2, Vector3(sz2, 0.6, sz2), rng.randf_range(0.5, 0.9))
	if not clean and rng.randf() < 0.7:
		for k in rng.randi_range(1, 2):
			var sx := 1.0 if rng.randf() < 0.5 else -1.0
			var sz3 := 1.0 if rng.randf() < 0.5 else -1.0
			# ceiling decal projecting upwards; texture corner turned towards the room corner
			var b3 := Basis(Vector3.RIGHT, PI) * Basis(Vector3.UP, atan2(-sx, -sz3) + PI * 0.25)
			var corner := cc + Vector3(sx * (inner - 0.55), H - 0.1, sz3 * (inner - 0.55))
			_decal("cobweb", corner, b3, Vector3(1.2, 0.4, 1.2), 0.85)


func _spawn_decor(dc: Dictionary) -> void:
	if dc["model"] == "__ramp":
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = dc["size"]
		mi.mesh = bm
		mi.material_override = ML.named("M_metal")
		root.add_child(mi)
		mi.global_transform = dc["xf"]
		return
	var over := {}
	var m := ML.model(dc["model"], over, dc.get("shadow", true))
	if m == null:
		return
	root.add_child(m)
	var fwd: Vector3 = dc["fwd"]
	var bs := Basis.looking_at(fwd, Vector3.UP).scaled(Vector3.ONE * float(dc.get("scale", 1.0)))
	if dc.has("sx"):
		bs = bs * Basis.from_scale(Vector3(float(dc["sx"]), 1.0, 1.0))
	m.global_transform = Transform3D(bs, dc["pos"])
	var nm: String = dc["model"]
	var small := nm.begins_with("prop_")
	ML.vis_range(m, 14.0 if small else 26.0)


func _add_model(name: String, pos: Vector3, fwd: Vector3, scale := 1.0, extra := {}) -> void:
	var d := {"model": name, "pos": pos, "fwd": fwd, "scale": scale}
	d.merge(extra)
	_decor.append(d)


func _furnish(st: SurfaceTool, c: Vector2i) -> void:
	var th: Dictionary = THEMES[cells[c]]
	var pieces: Array = th["pieces"]
	var cc := cell_center(c)
	var is_extr := c in extraction_cells
	var cons_dir := console_offset(c).normalized() if is_extr else Vector3.ZERO
	for d in DIRS:
		var n: Vector2i = c + d
		var t := conn_type(c, n) if cells.has(n) else 0
		if t == 2:
			continue
		var normal := Vector3(d.x, 0, d.y)
		var inward := -normal
		var along := Vector3(absi(d.y), 0, absi(d.x))
		var base := cc + normal * (HR - WT / 2.0)
		var slots := [-2.4, 2.4] if t == 1 else [-2.4, 0.0, 2.4]
		if normal.dot(cons_dir) > 0.9:
			slots = [-2.4, 2.4]    # the extraction console stands in the middle of this wall side
		var outer := not cells.has(n)
		var mid_low := true
		for s in slots:
			if rng.randf() < 0.3:
				item_spots.append({"pos": base + along * s + inward * 0.9, "kind": "floor"})
				continue
			var piece: String = pieces[rng.randi() % pieces.size()]
			if piece == "forklift" and s != 0.0:
				piece = "crates"
			if s == 0.0 and not (piece in LOW_PIECES) and piece != "forklift":
				if outer or rng.randf() < 0.5:
					var lows: Array = pieces.filter(func(x): return x in LOW_PIECES)
					piece = lows[rng.randi() % lows.size()] if not lows.is_empty() else "crates"
			_piece(st, piece, base + along * s, along, inward, th)
		if t != 1:
			var wall_face := cc + normal * (HR - WT / 2.0 - 0.02)
			if outer and rng.randf() < 0.55:
				_add_model("window", wall_face + Vector3(0, 1.2, 0) + inward * 0.03, inward)
				_moon_shaft(wall_face + Vector3(0, 1.75, 0), inward)
			elif rng.randf() < 0.65:
				_wall_decor(cells[c], wall_face, along, inward)
	# floor clutter in corners
	var tnm: String = cells[c]
	var floor_props: Array = []
	if tnm in ["warehouse", "storage", "boiler"]:
		floor_props = ["prop_box", "prop_paintcans", "prop_bucket", "jerrycan", "cone", "boxes"]
	elif tnm in ["lab", "servers"]:
		floor_props = ["prop_box", "prop_bucket", "jerrycan"]
	else:
		floor_props = ["prop_box", "prop_papers", "prop_bucket"]
	if not is_extr:
		for k in rng.randi_range(0, 2):
			var corner := Vector3(3.2 * (1 if rng.randf() < 0.5 else -1), 0, 3.2 * (1 if rng.randf() < 0.5 else -1))
			_add_model(floor_props[rng.randi() % floor_props.size()], cc + corner + Vector3(rng.randf_range(-0.3, 0.3), 0, rng.randf_range(-0.3, 0.3)), Vector3.FORWARD.rotated(Vector3.UP, rng.randf() * TAU), 1.0, {"shadow": false})
	# hazard tape lanes on warehouse floors, centre floor spots
	if not is_extr and tnm in ["warehouse", "storage", "boiler"] and rng.randf() < 0.7:
		_mk = "rug"
		var lane_x := rng.randf() < 0.5
		for sg in [-1.0, 1.0]:
			var off := Vector3(0, 0, sg * 1.1) if lane_x else Vector3(sg * 1.1, 0, 0)
			_box(st, cc + off + Vector3(0, 0.008, 0), Vector3(5.0, 0.016, 0.16) if lane_x else Vector3(0.16, 0.016, 5.0), Color.WHITE, false)
		if rng.randf() < 0.6:
			_decal("arrow_floor", cc + Vector3(0, 0.1, 0), Basis(Vector3.UP, (0.0 if lane_x else PI * 0.5) + (PI if rng.randf() < 0.5 else 0.0)) * Basis(Vector3.UP, PI * 0.5), Vector3(0.9, 0.6, 0.9), 0.85)
	if tnm in ["office", "meeting", "breakroom", "dorm", "archive"] and rng.randf() < 0.55:
		var corner := Vector3(3.35 * (1 if rng.randf() < 0.5 else -1), 0, 3.35 * (1 if rng.randf() < 0.5 else -1))
		_add_model("plant", cc + corner, Vector3.FORWARD)
		_add_shape(cc + corner + Vector3(0, 0.3, 0), Vector3(0.4, 0.6, 0.4))
	if not is_extr:
		for i in rng.randi_range(0, 2):
			item_spots.append({"pos": cc + Vector3(rng.randf_range(-1.6, 1.6), 0.0, rng.randf_range(-1.2, 1.2)), "kind": "floor"})


## Something on a free wall: posters and signs, pipes, a fuse box, a vent, a wall lamp, a whiteboard.
func _wall_decor(tn: String, wall_face: Vector3, along: Vector3, inward: Vector3) -> void:
	var r := rng.randf()
	var off := along * rng.randf_range(-1.2, 1.2)
	if r < 0.4:
		var tex: String = ["poster_loot", "poster_safety", "sign_danger", "stencil_numbers", "sign_exit"][rng.randi() % 5]
		if tn in ["office", "meeting", "breakroom", "dorm"] and tex == "stencil_numbers":
			tex = "poster_safety"
		var sz := Vector3(0.7, 0.4, 1.05) if tex.begins_with("poster") else (Vector3(0.6, 0.4, 0.3) if tex in ["sign_exit", "stencil_numbers"] else Vector3(0.55, 0.4, 0.55))
		if tex == "stencil_numbers":
			sz = Vector3(1.1, 0.4, 0.55)
		var yv := -inward
		var xv := yv.cross(Vector3.UP).normalized()
		_decal(tex, wall_face + off + Vector3(0, 1.75 if tex != "sign_exit" else 2.45, 0), Basis(xv, yv, xv.cross(yv).normalized()), sz, 1.0)
	elif r < 0.6:
		if tn in ["warehouse", "storage", "boiler", "servers", "lab"]:
			_add_model("pipes", wall_face, inward, 1.0, {"shadow": false})
		else:
			_add_model("lamp_cage", wall_face + off + Vector3(0, 2.1, 0), inward, 1.0, {"shadow": false})
	elif r < 0.75:
		_add_model("fusebox", wall_face + off, inward, 1.0, {"shadow": false})
	elif r < 0.9:
		_add_model("vent", wall_face + off + Vector3(0, 0.15 if rng.randf() < 0.5 else 2.3, 0), inward, 1.0, {"shadow": false})
	else:
		_add_model("lamp_cage", wall_face + off + Vector3(0, 2.1, 0), inward, 1.0, {"shadow": false})


func _spot(base: Vector3, along: Vector3, inward: Vector3, lc: Vector3, kind: String) -> void:
	item_spots.append({"pos": base + along * lc.x + Vector3.UP * lc.y + inward * lc.z, "kind": kind})


## piece -> [model, distance of the model origin from the wall, scale]
const PIECE_MODEL := {"rack": ["rack", 0.42], "pallet": ["pallet", 0.55], "lockers": ["locker", 0.28], "desk": ["desk", 0.42],
	"cabinet": ["filing_cabinet", 0.34], "cooler": ["water_cooler", 0.2], "table": ["table", 1.0], "board": ["whiteboard", 0.3],
	"vending": ["vending", 0.42], "sofa": ["sofa", 0.45], "shelf": ["store_shelf", 0.27], "bed": ["bed", 1.0],
	"labbench": ["labbench", 0.42], "tank": ["lab_tank", 0.46], "medcab": ["med_cabinet", 0.0], "server": ["server_rack", 0.52],
	"terminal": ["terminal", 0.32], "boiler": ["boiler", 0.62], "generator": ["generator", 0.38], "panel": ["panel", 0.0],
	"toilet": ["toilet", 0.36], "sink": ["sink", 0.0]}


func _piece(st, piece: String, base: Vector3, along: Vector3, inward: Vector3, th: Dictionary) -> void:
	var has_model := ML.scene("table") != null
	if has_model:
		_vis = false
		if PIECE_MODEL.has(piece):
			var pm: Array = PIECE_MODEL[piece]
			var mname: String = pm[0]
			if mname == "labbench":
				mname = "lab_bench"
			var fwd := inward
			if piece == "generator":
				fwd = along
			_add_model(mname, base + inward * float(pm[1]), fwd)
		elif piece == "crates":
			_add_model("crate", base + along * -0.45 + inward * 0.45, inward.rotated(Vector3.UP, rng.randf_range(-0.2, 0.2)))
		elif piece == "barrels":
			_add_model("barrel", base + along * -0.36 + inward * 0.36, inward.rotated(Vector3.UP, rng.randf() * TAU))
			if rng.randf() < 0.7:
				_add_model("barrel", base + along * 0.3 + inward * 0.38, inward.rotated(Vector3.UP, rng.randf() * TAU))
		elif piece == "forklift":
			_add_model("forklift", base + inward * 0.75 + along * 0.25, along)
		if piece == "table" and rng.randf() < 0.7:
			for cx in [-0.45, 0.45]:
				_add_model("office_chair", base + along * cx + inward * 1.7, -inward.rotated(Vector3.UP, rng.randf_range(-0.35, 0.35)))
				_add_shape(base + along * cx + inward * 1.7 + Vector3(0, 0.45, 0), Vector3(0.5, 0.9, 0.5))
		elif piece == "desk" and rng.randf() < 0.85:
			_add_model("office_chair", base + along * -0.1 + inward * 1.05, -inward.rotated(Vector3.UP, rng.randf_range(-0.5, 0.5)))
			_add_shape(base + along * -0.1 + inward * 1.05 + Vector3(0, 0.45, 0), Vector3(0.5, 0.9, 0.5))
	_piece_shapes(st, piece, base, along, inward, th)
	_vis = true
	if has_model:
		_clutter(piece, base, along, inward)


func _prop(name: String, pos: Vector3, fwd: Vector3, scale := 1.0) -> void:
	_add_model(name, pos, fwd.rotated(Vector3.UP, rng.randf_range(-0.5, 0.5)), scale, {"shadow": false})


## Small decorative props on furniture (visual only).
func _clutter(piece: String, base: Vector3, along: Vector3, inward: Vector3) -> void:
	var P := func(lx: float, ly: float, lz: float) -> Vector3:
		return base + along * lx + Vector3.UP * ly + inward * lz
	match piece:
		"table":
			if rng.randf() < 0.5:
				_prop(["prop_papers", "prop_bottles", "prop_clipboard"][rng.randi() % 3], P.call(rng.randf_range(-0.6, 0.6), 0.765, 1.15), inward)
		"cabinet":
			if rng.randf() < 0.5:
				_prop(["prop_papers", "prop_box"][rng.randi() % 2], P.call(0.0, 1.33, 0.34), inward)
		"desk":
			if rng.randf() < 0.6:
				_prop("prop_clipboard", P.call(0.45, 0.765, 0.5), inward)
		"crates", "pallet":
			if rng.randf() < 0.5:
				_prop("prop_box", P.call(0.45, 0.0, 0.55), inward)
		"generator", "boiler", "barrels":
			if rng.randf() < 0.5:
				_prop(["prop_bucket", "prop_paintcans"][rng.randi() % 2], P.call(rng.randf_range(-0.8, 0.8), 0.0, 0.25), inward)


func _piece_shapes(st, piece: String, base: Vector3, along: Vector3, inward: Vector3, th: Dictionary) -> void:
	var c := Color(0.4, 0.4, 0.42)
	match piece:
		"rack":
			_lbox(st, base, along, inward, Vector3(0, 1.3, 0.42), Vector3(1.9, 2.6, 0.76), c)
			_spot(base, along, inward, Vector3(-0.5, 0.02, 1.0), "floor")
		"pallet":
			_lbox(st, base, along, inward, Vector3(0, 0.4, 0.55), Vector3(1.2, 0.8, 1.0), c)
			_spot(base, along, inward, Vector3(0.0, 0.85, 0.55), "top")
		"barrels":
			_lbox(st, base, along, inward, Vector3(-0.36, 0.45, 0.36), Vector3(0.58, 0.9, 0.58), c)
			_lbox(st, base, along, inward, Vector3(0.3, 0.45, 0.38), Vector3(0.58, 0.9, 0.58), c)
			_spot(base, along, inward, Vector3(-0.36, 0.92, 0.36), "top")
		"forklift":
			_lbox(st, base, along, inward, Vector3(0.0, 1.15, 0.75), Vector3(2.6, 2.3, 1.15), c)
			_spot(base, along, inward, Vector3(1.6, 0.02, 0.6), "floor")
		"crates":
			_lbox(st, base, along, inward, Vector3(-0.45, 0.4, 0.45), Vector3(0.8, 0.8, 0.8), c)
			if rng.randf() < 0.6:
				_lbox(st, base, along, inward, Vector3(0.45, 0.35, 0.4), Vector3(0.7, 0.7, 0.7), c)
				if not _vis:
					_add_model("crate", base + along * 0.45 + inward * 0.4, inward.rotated(Vector3.UP, 0.3), 0.875)
			_spot(base, along, inward, Vector3(-0.45, 0.84, 0.45), "top")
		"lockers":
			_lbox(st, base, along, inward, Vector3(0, 0.97, 0.28), Vector3(0.94, 1.94, 0.54), c)
			_spot(base, along, inward, Vector3(0.0, 0.02, 0.85), "floor")
		"desk":
			_lbox(st, base, along, inward, Vector3(0, 0.74, 0.42), Vector3(1.6, 0.05, 0.8), c)
			_lbox(st, base, along, inward, Vector3(-0.76, 0.36, 0.42), Vector3(0.05, 0.72, 0.7), c)
			_lbox(st, base, along, inward, Vector3(0.55, 0.42, 0.42), Vector3(0.42, 0.62, 0.7), c)
			_lbox(st, base, along, inward, Vector3(-0.15, 1.0, 0.2), Vector3(0.5, 0.34, 0.06), c, false)
			_spot(base, along, inward, Vector3(0.35, 0.79, 0.6), "top")
		"cabinet":
			_lbox(st, base, along, inward, Vector3(0, 0.66, 0.34), Vector3(0.52, 1.32, 0.66), c)
			_spot(base, along, inward, Vector3(0, 1.35, 0.34), "top")
		"cooler":
			_lbox(st, base, along, inward, Vector3(0, 0.7, 0.2), Vector3(0.34, 1.4, 0.34), c)
			_spot(base, along, inward, Vector3(0.6, 0.02, 0.4), "floor")
		"table":
			_lbox(st, base, along, inward, Vector3(0, 0.74, 1.0), Vector3(1.8, 0.05, 0.9), c)
			for lx in [-0.82, 0.82]:
				for lz in [0.62, 1.38]:
					_lbox(st, base, along, inward, Vector3(lx, 0.36, lz), Vector3(0.07, 0.72, 0.07), c)
			_spot(base, along, inward, Vector3(-0.45, 0.79, 1.0), "top")
			_spot(base, along, inward, Vector3(0.45, 0.79, 1.0), "top")
		"board":
			_lbox(st, base, along, inward, Vector3(0, 1.0, 0.3), Vector3(1.7, 2.0, 0.12), c)
			_spot(base, along, inward, Vector3(0.0, 0.02, 0.9), "floor")
		"vending":
			_lbox(st, base, along, inward, Vector3(0, 0.95, 0.42), Vector3(0.92, 1.9, 0.82), c)
			_spot(base, along, inward, Vector3(0.9, 0.02, 0.5), "floor")
		"sofa":
			_lbox(st, base, along, inward, Vector3(0, 0.22, 0.45), Vector3(1.9, 0.44, 0.85), c)
			_lbox(st, base, along, inward, Vector3(0, 0.6, 0.12), Vector3(1.9, 0.55, 0.25), c)
			_spot(base, along, inward, Vector3(0.4, 0.62, 0.5), "small")
		"shelf":
			_lbox(st, base, along, inward, Vector3(0, 1.0, 0.27), Vector3(1.95, 2.0, 0.5), c)
			_spot(base, along, inward, Vector3(-0.4, 1.95, 0.27), "small")
			_spot(base, along, inward, Vector3(0.4, 0.02, 0.8), "floor")
		"bed":
			_lbox(st, base, along, inward, Vector3(0, 0.3, 1.0), Vector3(0.95, 0.6, 1.95), c)
			_lbox(st, base, along, inward, Vector3(0, 0.45, 0.04), Vector3(0.95, 0.9, 0.06), c)
			_spot(base, along, inward, Vector3(0.0, 0.62, 1.3), "small")
		"labbench":
			_lbox(st, base, along, inward, Vector3(0, 0.47, 0.42), Vector3(1.8, 0.95, 0.8), c)
			_spot(base, along, inward, Vector3(-0.2, 1.0, 0.45), "top")
			_spot(base, along, inward, Vector3(0.25, 1.0, 0.55), "small")
		"tank":
			_lbox(st, base, along, inward, Vector3(0, 1.2, 0.46), Vector3(0.86, 2.4, 0.86), c)
			_spot(base, along, inward, Vector3(0.75, 0.02, 0.5), "floor")
		"medcab":
			_lbox(st, base, along, inward, Vector3(0, 1.45, 0.14), Vector3(0.64, 0.95, 0.28), c)
			_spot(base, along, inward, Vector3(0.0, 0.02, 0.5), "floor")
		"server":
			_lbox(st, base, along, inward, Vector3(0, 1.06, 0.52), Vector3(0.72, 2.12, 1.02), c)
			_spot(base, along, inward, Vector3(0.7, 0.02, 0.6), "floor")
		"terminal":
			_lbox(st, base, along, inward, Vector3(0, 0.45, 0.32), Vector3(0.92, 0.9, 0.62), c)
			_lbox(st, base, along, inward, Vector3(0, 1.15, 0.22), Vector3(0.56, 0.46, 0.46), c)
			_spot(base, along, inward, Vector3(0.33, 0.92, 0.42), "small")
		"boiler":
			_lbox(st, base, along, inward, Vector3(0, 1.1, 0.62), Vector3(1.15, 2.2, 1.15), c)
			_spot(base, along, inward, Vector3(1.0, 0.02, 0.6), "floor")
		"generator":
			_lbox(st, base, along, inward, Vector3(0, 0.45, 0.38), Vector3(1.22, 0.9, 0.68), c)
			_spot(base, along, inward, Vector3(0.2, 0.9, 0.38), "top")
		"panel":
			_lbox(st, base, along, inward, Vector3(0, 0.9, 0.13), Vector3(0.82, 1.2, 0.26), c)
			_spot(base, along, inward, Vector3(0.0, 0.02, 0.6), "floor")
		"toilet":
			_lbox(st, base, along, inward, Vector3(0, 0.4, 0.36), Vector3(0.45, 0.8, 0.62), c)
		"sink":
			_lbox(st, base, along, inward, Vector3(0, 0.75, 0.22), Vector3(0.55, 0.3, 0.45), c)
			_spot(base, along, inward, Vector3(0.0, 0.02, 0.6), "floor")


func _add_shape_basis(center: Vector3, size: Vector3, b: Basis) -> void:
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	cs.transform = Transform3D(b, center)
	body.add_child(cs)


func _build_garage(_st_unused, c: Vector2i) -> void:
	var cc := cell_center(c)
	var back := -Vector3(door_dir.x, 0, door_dir.y)
	var side := Vector3(absi(door_dir.y), 0, absi(door_dir.x))
	var ba := back.abs()
	var sa := side.abs()
	var tb := cc + back * 0.6
	truck_back = back
	truck_side = side
	truck_pos = tb + Vector3(0, 0.5, 0)
	_add_model("truck", tb, -back)
	var up := Vector3.UP
	_add_shape(tb + up * 0.45, sa * 2.4 + Vector3(0, 0.12, 0) + ba * 3.2)
	_add_shape(tb + side * 1.2 + up * 1.6, sa * 0.1 + Vector3(0, 2.2, 0) + ba * 3.2)
	_add_shape(tb - side * 1.2 + up * 1.6, sa * 0.1 + Vector3(0, 2.2, 0) + ba * 3.2)
	_add_shape(tb + up * 2.7, sa * 2.5 + Vector3(0, 0.1, 0) + ba * 3.2)
	_add_shape(tb + back * 1.6 + up * 1.6, sa * 2.4 + Vector3(0, 2.2, 0) + ba * 0.1)
	_add_shape(tb + back * 2.45 + up * 1.15, sa * 2.3 + Vector3(0, 1.4, 0) + ba * 1.5)
	_add_shape(tb + back * 2.6 + up * 2.1, sa * 2.2 + Vector3(0, 0.8, 0) + ba * 1.2)
	# loading ramp
	var top := tb - back * 1.6 + up * 0.5
	var bottom := tb - back * 2.9 + up * 0.0
	var z := (bottom - top).normalized()
	var x := side
	var y := z.cross(x).normalized()
	var rb := Basis(x, y, z)
	var rc := (top + bottom) * 0.5
	var rlen := top.distance_to(bottom)
	_add_shape_basis(rc, Vector3(2.0, 0.08, rlen), rb)
	_decor.append({"model": "__ramp", "xf": Transform3D(rb, rc), "size": Vector3(2.0, 0.08, rlen)})
	# hazard stripes in front of the truck
	_mk = "flat"
	var stripe := Color(0.95, 0.75, 0.1)
	for i in 5:
		_box(null, tb - back * (3.2 + 0.0) + side * (-1.0 + i * 0.5) + Vector3(0, 0.012, 0), sa * 0.25 + Vector3(0, 0.02, 0) + ba * 0.5, stripe, false)
	# garage decor
	_add_model("store_shelf", cc + side * (HR - 0.45) - back * 1.8, -side)
	_add_shape(cc + side * (HR - 0.45) - back * 1.8 + up * 0.95, sa * 0.55 + Vector3(0, 1.9, 0) + ba * 1.95)
	_add_model("crate", cc - side * (HR - 0.6) - back * 2.6, -side)
	_add_shape(cc - side * (HR - 0.6) - back * 2.6 + up * 0.4, Vector3(0.8, 0.8, 0.8))
	truck_button = tb + back * 1.15 + side * 0.75 + up * 0.51
	truck_screen = tb + back * 1.49 + up * 1.9
	cart_pos = cc - back * 2.6 + side * 2.0 + Vector3(0, 0.4, 0)
	spawn_points = [tb + side * 0.5 + back * 0.5 + up * 0.6, tb - side * 0.5 + back * 0.5 + up * 0.6, tb + side * 0.5 - back * 0.5 + up * 0.6, tb - side * 0.5 - back * 0.5 + up * 0.6]


# ------------------------------------------------------------------ room variety (v2.0)
## Big halls: neighbouring cells merged into one room (2x1, 3x1 or 2x2) with open connections,
## one theme and furniture islands in the middle; the rest stay single rooms.
func _group_rooms() -> void:
	var names: Array = LOCATION_ROOMS[location]
	var hallable := []
	for n in names:
		if HALL_THEMES.has(n):
			hallable.append(n)
	var protect := {spawn_cell: true}
	for d in DIRS:
		protect[spawn_cell + d] = true      # the first room stays a plain single room (tests + spawn view)
	var cand := order.duplicate()
	for i in range(cand.size() - 1, 0, -1):
		var j := rng.randi() % (i + 1)
		var tmp = cand[i]
		cand[i] = cand[j]
		cand[j] = tmp
	var want_halls := maxi(1, int(order.size() / 7.0))
	var made := 0
	for c in cand:
		if made >= want_halls:
			break
		if protect.has(c) or room_of.has(c):
			continue
		var shapes := [[Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)],
			[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0)], [Vector2i(0, 0), Vector2i(0, 1), Vector2i(0, 2)],
			[Vector2i(0, 0), Vector2i(1, 0)], [Vector2i(0, 0), Vector2i(0, 1)]]
		if rng.randf() < 0.35:
			shapes = shapes.slice(3)
		for sh in shapes:
			var group := []
			var ok := true
			for o in sh:
				var cc: Vector2i = c + o
				if not cells.has(cc) or protect.has(cc) or room_of.has(cc):
					ok = false
					break
				group.append(cc)
			if not ok:
				continue
			var theme: String = hallable[rng.randi() % hallable.size()] if not hallable.is_empty() else cells[c]
			for g in group:
				room_of[g] = rooms.size()
				cells[g] = theme
			rooms.append(group)
			made += 1
			break
	for c in order:
		if not room_of.has(c):
			room_of[c] = rooms.size()
			rooms.append([c])


func _same_room(a: Vector2i, b: Vector2i) -> bool:
	return room_of.has(a) and room_of.has(b) and room_of[a] == room_of[b] and rooms[room_of[a]].size() >= 2


## Corridors (straight, corner or junction hallways) and small rooms inside single cells.
func _pick_insets() -> void:
	var keep := {spawn_cell: true}
	for d in DIRS:
		keep[spawn_cell + d] = true
	for e in extraction_cells:
		keep[e] = true
	for c in order:
		if keep.has(c) or rooms[room_of[c]].size() >= 2:
			continue
		var links := []
		for d in DIRS:
			if cells.has(c + d) and conn.has(key(c, c + d)):
				links.append(d)
		var p := 0.0
		var hs := 2.7
		if links.size() == 2 and links[0] == -links[1]:
			p = 0.55
			hs = 1.3
		elif links.size() >= 3:
			p = 0.4
			hs = 1.3
		elif links.size() == 2:
			p = 0.3
			hs = 1.3 if rng.randf() < 0.6 else 2.7
		elif links.size() == 1:
			p = 0.35
		if rng.randf() >= p:
			continue
		inset[c] = hs
		cells[c] = ("corridor_%d" if hs < 2.0 else "closet_%d") % location
		if hs < 2.0:
			monster_cells.erase(c)
	if monster_cells.is_empty():
		for c in order:
			if c != spawn_cell and not inset.has(c):
				monster_cells.append(c)


## Per-cell wall mask (bit 1 +x, 2 -x, 4 +z, 8 -z) for the surface shader's corner shading:
## inside merged halls there is no fake corner darkness where cells meet.
func _build_mask() -> void:
	var mn := Vector2i(999, 999)
	for c in order:
		mn = Vector2i(mini(mn.x, c.x), mini(mn.y, c.y))
	_mask_origin = -mn + Vector2i(1, 1)
	var img := Image.create(64, 64, false, Image.FORMAT_R8)
	img.fill(Color(15.0 / 255.0, 0, 0))
	var bits := {Vector2i(1, 0): 1, Vector2i(-1, 0): 2, Vector2i(0, 1): 4, Vector2i(0, -1): 8}
	for c in order:
		var m := 0
		if not inset.has(c):
			for d in DIRS:
				var n: Vector2i = c + d
				if not (cells.has(n) and conn_type(c, n) == 2):
					m |= int(bits[d])
		var px: Vector2i = c + _mask_origin
		if px.x >= 0 and px.y >= 0 and px.x < 64 and px.y < 64:
			img.set_pixel(px.x, px.y, Color(m / 255.0, 0, 0))
	mask_tex = ImageTexture.create_from_image(img)


## Wall segment with wainscot, trims, collision and occluder (same look as the room walls).
func _wall_piece(sc: Vector3, along: Vector3, normal: Vector3, ln: float, col: Color) -> void:
	if ln <= 0.05:
		return
	var a := along.abs()
	var nt := normal.abs() * WT
	var dado := 1.0
	var white := Color(1, 1, 1)
	_mk = "wains"
	_box(null, sc + Vector3(0, dado / 2.0, 0), a * ln + Vector3(0, dado, 0) + nt, white, true)
	_mk = "wall"
	_box(null, sc + Vector3(0, (dado + H) / 2.0, 0), a * ln + Vector3(0, H - dado, 0) + nt, col, true)
	_occluder(sc + Vector3(0, H / 2.0, 0), a * maxf(0.1, ln - 0.3) + Vector3(0, H - 0.3, 0) + normal.abs() * WT * 0.5)
	_mk = "trim"
	_box(null, sc + Vector3(0, 0.07, 0), a * ln + Vector3(0, 0.14, 0) + normal.abs() * (WT + 0.05), white, false)
	_box(null, sc + Vector3(0, dado, 0), a * ln + Vector3(0, 0.05, 0) + normal.abs() * (WT + 0.04), white, false)
	_box(null, sc + Vector3(0, H - 0.06, 0), a * ln + Vector3(0, 0.12, 0) + normal.abs() * (WT + 0.08), white, false)


## Inset room: a square of half size hs in the middle of the cell plus AW-wide arms out to each door.
func _build_inset(c: Vector2i, hs: float, col: Color) -> void:
	var cc := cell_center(c)
	for d in DIRS:
		var n: Vector2i = c + d
		var normal := Vector3(d.x, 0, d.y)
		var along := Vector3(absi(d.y), 0, absi(d.x))
		var linked := cells.has(n) and conn.has(key(c, n))
		var face := cc + normal * (hs + WT / 2.0)
		if not linked:
			_wall_piece(face, along, normal, hs * 2.0 + WT * 2.0, col)
			if hs > 2.0 and rng.randf() < 0.5:
				_wall_decor(cells[c], cc + normal * (hs - 0.02), along, -normal)
			continue
		var side_len := hs - AW / 2.0
		if side_len > 0.05:
			for sg in [-1.0, 1.0]:
				_wall_piece(face + along * sg * (AW / 2.0 + side_len / 2.0 + WT / 2.0), along, normal, side_len + WT, col)
		# arm walls from the room out to the door in the cell edge
		var arm_len := (HR - WT / 2.0) - hs
		if arm_len > 0.05:
			for sg in [-1.0, 1.0]:
				var ac: Vector3 = cc + normal * (hs + arm_len / 2.0) + along * sg * (AW / 2.0 + WT / 2.0)
				_wall_piece(ac, normal, along, arm_len + WT, col)
			if hs < 2.0 and rng.randf() < 0.45:
				var sgn := 1.0 if rng.randf() < 0.5 else -1.0
				_add_model("lamp_cage", cc + normal * (hs + arm_len * 0.5) + along * sgn * (AW / 2.0 - 0.02) + Vector3(0, 2.1, 0), -along * sgn, 1.0, {"shadow": false})
	# pipes and a vent along corridors
	if hs < 2.0 and rng.randf() < 0.35:
		_decal("footprints", cc + Vector3(0, 0.1, 0), Basis(Vector3.UP, rng.randf() * TAU), Vector3(0.9, 0.6, 0.9), 0.6)


## Furniture along the closed walls of a small room.
func _furnish_inset(c: Vector2i, hs: float) -> void:
	var th: Dictionary = THEMES[cells[c]]
	var pieces: Array = th["pieces"]
	var cc := cell_center(c)
	for d in DIRS:
		var n: Vector2i = c + d
		if cells.has(n) and conn.has(key(c, n)):
			continue
		var normal := Vector3(d.x, 0, d.y)
		var along := Vector3(absi(d.y), 0, absi(d.x))
		var base := cc + normal * hs
		for s in ([-1.2, 1.2] if rng.randf() < 0.6 else [0.0]):
			if rng.randf() < 0.2:
				item_spots.append({"pos": base + along * s - normal * 0.8, "kind": "floor"})
				continue
			_piece(null, pieces[rng.randi() % pieces.size()], base + along * s, along, -normal, th)
	item_spots.append({"pos": cc + Vector3(rng.randf_range(-0.6, 0.6), 0.0, rng.randf_range(-0.6, 0.6)), "kind": "floor"})


func _floor_decals(cc: Vector3, r: float) -> void:
	for i in rng.randi_range(0, 2):
		var b2 := Basis(Vector3.UP, rng.randf() * TAU)
		var sz2 := rng.randf_range(0.8, 1.6)
		_decal(["floor_dirt", "scuffs", "stain_water"][rng.randi() % 3], cc + Vector3(rng.randf_range(-r, r), 0.1, rng.randf_range(-r, r)), b2, Vector3(sz2, 0.6, sz2), rng.randf_range(0.5, 0.9))


## Big halls: pillars where four cells meet and furniture islands in the middle of each cell.
func _hall_features(r: Array) -> void:
	_sts = {}
	var th: Dictionary = THEMES[cells[r[0]]]
	_th = th
	var kind: String = HALL_THEMES.get(cells[r[0]], "")
	var inroom := {}
	for c in r:
		inroom[c] = true
	# pillars at inner corners
	for c in r:
		if inroom.has(c + Vector2i(1, 0)) and inroom.has(c + Vector2i(0, 1)) and inroom.has(c + Vector2i(1, 1)):
			_pillar(cell_center(c) + Vector3(HR, 0, HR))
	var long_x := true
	if r.size() >= 2 and r[0].x == r[1].x:
		long_x = false
	# islands sit in the cell quadrants: the cross through the cell centre stays free, so paths
	# between doors and monster spawn points never run into furniture
	const OFF := {"table": 1.0, "rack": 0.42, "desk": 0.42, "crates": 0.45, "server": 0.52, "labbench": 0.42, "shelf": 0.27}
	for c in r:
		if c in extraction_cells:
			continue
		var cc := cell_center(c)
		var ax := Vector3(1, 0, 0) if long_x else Vector3(0, 0, 1)
		var bx := Vector3(0, 0, 1) if long_x else Vector3(1, 0, 0)
		var quads := [Vector2(1, 1), Vector2(-1, -1)] if rng.randf() < 0.5 else [Vector2(1, -1), Vector2(-1, 1)]
		if kind in ["servers"]:
			quads = [Vector2(1, 1), Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1)]
		for q in quads:
			var qp: Vector3 = cc + ax * q.x * 1.65 + bx * q.y * 1.6
			var out: Vector3 = bx * q.y          # towards the nearer long wall
			match kind:
				"table":
					_piece(null, "table", qp - out * OFF["table"], ax, out, th)
				"racks":
					_piece(null, "rack", qp - out * 0.02, ax, out, th)
					_piece(null, "rack", qp + out * 0.02, -ax, -out, th)
				"shelves":
					_piece(null, "shelf", qp, ax, out, th)
					_piece(null, "shelf", qp, -ax, -out, th)
				"benches":
					_piece(null, "labbench", qp, ax, out, th)
					_piece(null, "labbench", qp, -ax, -out, th)
				"servers":
					_piece(null, "server", qp - out * OFF["server"], ax, out, th)
				"desks":
					_piece(null, "desk", qp - out * OFF["desk"], ax, out, th)
				"crates":
					_piece(null, "crates", qp - out * OFF["crates"], ax, out, th)
	var mesh := ArrayMesh.new()
	for k in _sts.keys():
		var st: SurfaceTool = _sts[k]
		st.commit(mesh)
		mesh.surface_set_material(mesh.get_surface_count() - 1, _surface_mat(k))
	if mesh.get_surface_count() > 0:
		var mi := MeshInstance3D.new()
		mi.mesh = mesh
		root.add_child(mi)
	for dc in _decor:
		_spawn_decor(dc)
	_decor.clear()


func _pillar(p: Vector3) -> void:
	_mk = "wains"
	_box(null, p + Vector3(0, H / 2.0, 0), Vector3(0.62, H, 0.62), Color(1, 1, 1), true)
	_mk = "trim"
	_box(null, p + Vector3(0, 0.1, 0), Vector3(0.8, 0.2, 0.8), Color(1, 1, 1), false)
	_box(null, p + Vector3(0, H - 0.12, 0), Vector3(0.8, 0.24, 0.8), Color(1, 1, 1), false)
	_occluder(p + Vector3(0, H / 2.0, 0), Vector3(0.45, H - 0.3, 0.45))
