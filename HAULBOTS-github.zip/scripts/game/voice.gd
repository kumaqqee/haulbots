extends Node
## Proximity voice chat, REPO-style.
## Mic -> AudioEffectCapture -> 11 kHz mono -> voice activation (open mic) or push-to-talk ->
## IMA-ADPCM packets (40 ms, 4 bit, each one decodable alone) -> unreliable RPC -> per-speaker jitter
## buffer -> 3D voice at the robot's head, or at its severed head when the robot is broken.
## A "radio" bus gives robots their voice; monsters hear whoever talks (noise at the speaker).
## Also runs without a world as the mic test in Settings (level meter only).

const RATE := 11025.0
const PKT := 440                # samples per packet: 40 ms
const PRE := 3                  # packets buffered before a talk spurt starts playing (absorbs jitter)
const HANG := 0.5               # open mic keeps sending this long after the voice drops
const HEAR := 38.0              # nobody within this distance -> nothing is sent

const STEPS := [7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73,
	80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598,
	658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327,
	3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289,
	16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767]
const IDX := [-1, -1, -1, -1, 2, 4, 6, 8]

var world: Node = null
var talking := false            # the mic is open: push-to-talk held, or open mic not muted
var sending := false            # voice detected and packets going out
var muted := false              # open mic muted with the button
var ptt := false                # push-to-talk button held on screen
var mic_level := 0.0            # 0..1 peak of the local mic (settings meter, HUD, monsters)
var capture: AudioEffectCapture = null
var mic_player: AudioStreamPlayer = null
var speak_level := {}           # pid -> 0..1 loudness of what is playing (indicator, head bob)
var packets_in := {}            # pid -> packets received (tests, debug)
var packets_out := 0
var _step := 4.0
var _phase := 0.0
var _acc := 0.0
var _acc_n := 0
var _pcm := PackedFloat32Array()
var _seq := 0
var _hang_t := 0.0
var _voices := {}
var _speak_t := {}
static var _perm_asked := false    # ask once per app run, not every level
var _key_ptt := false


func _ready() -> void:
	_step = AudioServer.get_mix_rate() / RATE
	get_tree().on_request_permissions_result.connect(_on_perm)
	setup_bus()
	muted = not Settings.mic_open
	if world:
		Settings.changed.connect(_apply_settings)
	_apply_settings()


func _exit_tree() -> void:
	if Settings.changed.is_connected(_apply_settings):
		Settings.changed.disconnect(_apply_settings)
	if mic_player and mic_player.playing:
		mic_player.stop()


func _on_perm(perm: String, granted: bool) -> void:
	if perm.ends_with("RECORD_AUDIO") and granted and mic_player and mic_player.playing:
		mic_player.stop()
		mic_player.play()


## "Voice" bus: the robots' radio sound (band-limited, a little crunchy); volume from Settings.
static func setup_bus() -> void:
	if AudioServer.get_bus_index("Voice") != -1:
		return
	var b := AudioServer.bus_count
	AudioServer.add_bus(b)
	AudioServer.set_bus_name(b, "Voice")
	AudioServer.set_bus_send(b, "Master")
	var hp := AudioEffectHighPassFilter.new()
	hp.cutoff_hz = 320.0
	AudioServer.add_bus_effect(b, hp)
	var lp := AudioEffectLowPassFilter.new()
	lp.cutoff_hz = 3600.0
	AudioServer.add_bus_effect(b, lp)
	var d := AudioEffectDistortion.new()
	d.mode = AudioEffectDistortion.MODE_OVERDRIVE
	d.drive = 0.22
	d.pre_gain = 2.0
	d.post_gain = -3.0
	AudioServer.add_bus_effect(b, d)
	var ch := AudioEffectChorus.new()
	ch.voice_count = 2
	ch.dry = 0.85
	ch.wet = 0.35
	AudioServer.add_bus_effect(b, ch)


func _apply_settings() -> void:
	var b := AudioServer.get_bus_index("Voice")
	if b == -1:
		return
	AudioServer.set_bus_volume_db(b, linear_to_db(maxf(Settings.voice_vol, 0.0001)))
	AudioServer.set_bus_mute(b, Settings.voice_vol <= 0.001)
	for i in range(1, AudioServer.get_bus_effect_count(b)):
		AudioServer.set_bus_effect_enabled(b, i, Settings.voice_filter)
	if Settings.voice_mode == 0 and talking:
		_open_mic(false)


func _setup_mic() -> bool:
	if capture != null:
		return true
	var bus := AudioServer.get_bus_index("VoiceMic")
	if bus == -1:
		bus = AudioServer.bus_count
		AudioServer.add_bus(bus)
		AudioServer.set_bus_name(bus, "VoiceMic")
		AudioServer.set_bus_mute(bus, true)
		var cap := AudioEffectCapture.new()
		cap.buffer_length = 0.5
		AudioServer.add_bus_effect(bus, cap)
	capture = AudioServer.get_bus_effect(bus, 0) as AudioEffectCapture
	mic_player = AudioStreamPlayer.new()
	mic_player.stream = AudioStreamMicrophone.new()
	mic_player.bus = "VoiceMic"
	add_child(mic_player)
	return capture != null


func _open_mic(on: bool) -> void:
	if on and OS.get_name() == "Android" and not _perm_asked and not OS.get_granted_permissions().has("android.permission.RECORD_AUDIO"):
		_perm_asked = true
		OS.request_permission("android.permission.RECORD_AUDIO")
	if on and not _setup_mic():
		return
	if on == talking:
		return
	talking = on
	if mic_player:
		if on and not mic_player.playing:
			mic_player.play()
		elif not on and mic_player.playing:
			mic_player.stop()
	if capture:
		capture.clear_buffer()
	_pcm.clear()
	if not on:
		sending = false
		_hang_t = 0.0


## Mic button / V key. Push-to-talk: held state. Open mic: toggles mute.
func set_talking(on: bool) -> void:
	if Settings.voice_mode == 1:
		ptt = on
	elif Settings.voice_mode == 2:
		muted = not on
		Settings.mic_open = on
		Settings.save_cfg()


func toggle() -> void:
	if Settings.voice_mode == 2:
		set_talking(muted)


## The settings mic test: open the mic without a game.
func set_test(on: bool) -> void:
	_open_mic(on)


func vad_threshold() -> float:
	return lerpf(0.09, 0.006, clampf(Settings.mic_sens, 0.0, 1.0))


func _want_open() -> bool:
	if world == null:
		return talking    # settings meter: stays as set_test() left it
	if not Net.online or Settings.voice_mode == 0:
		return false
	if Settings.voice_mode == 1:
		return ptt or _key_ptt
	return not muted


func _process(delta: float) -> void:
	if world:
		_key_ptt = Settings.voice_mode == 1 and Input.is_action_pressed("talk") and not (world.hud and world.hud.chat_open)
		var want := _want_open()
		if want != talking:
			_open_mic(want)
		_play_voices(delta)
	if not talking or capture == null:
		mic_level = move_toward(mic_level, 0.0, delta * 2.0)
		sending = false
		return
	var n := capture.get_frames_available()
	if n > 0:
		feed(capture.get_buffer(n))


## Resample a block of mic frames (mix rate -> 11 kHz), detect voice, send full packets.
func feed(buf: PackedVector2Array) -> void:
	var peak := 0.0
	for f in buf:
		_acc += (f.x + f.y) * 0.5
		_acc_n += 1
		_phase += 1.0
		if _phase >= _step:
			_phase -= _step
			var v := clampf(_acc / _acc_n * 1.5, -1.0, 1.0)
			peak = maxf(peak, absf(v))
			_acc = 0.0
			_acc_n = 0
			_pcm.append(v)
			if _pcm.size() >= PKT:
				_packet(_pcm)
				_pcm = PackedFloat32Array()
	mic_level = maxf(mic_level * 0.85, peak)


func _packet(pcm: PackedFloat32Array) -> void:
	var s := 0.0
	for v in pcm:
		s += v * v
	var rms := sqrt(s / pcm.size())
	if Settings.voice_mode == 2 or world == null:
		if rms > vad_threshold():
			_hang_t = HANG
		else:
			_hang_t -= PKT / RATE
		sending = _hang_t > 0.0
	else:
		sending = true    # push-to-talk: everything while held
	if not sending or world == null or not Net.online or not _anyone_hears():
		return
	_seq = (_seq + 1) & 0xffff
	packets_out += 1
	rpc("rpc_voice", encode(pcm, _seq))
	if multiplayer.is_server():
		_noise(multiplayer.get_unique_id())


## Is anyone close enough to hear? (broken robots spectate someone: they may be anywhere)
func _anyone_hears() -> bool:
	var me = world.local_player
	if me == null:
		return false
	var src: Vector3 = world.chat_pos(me.peer_id)
	for p in world.players.values():
		if p == me:
			continue
		if p.dead or p.global_position.distance_to(src) < HEAR:
			return true
	return false


# ------------------------------------------------------------------ IMA-ADPCM

## [seq u16][predictor s16][step index u8][4-bit codes...]: every packet starts its own state.
static func encode(pcm: PackedFloat32Array, seq: int) -> PackedByteArray:
	var out := PackedByteArray()
	out.resize(5 + (pcm.size() + 1) / 2)
	var pred := clampi(int(pcm[0] * 32767.0), -32768, 32767)
	var idx := 0
	# pick a starting step size from the first samples so loud packets don't clip at the start
	var d0 := absi(int(pcm[mini(1, pcm.size() - 1)] * 32767.0) - pred)
	while idx < 60 and STEPS[idx] < d0:
		idx += 1
	out.encode_u16(0, seq)
	out.encode_s16(2, pred)
	out[4] = idx
	var byte := 0
	for i in pcm.size():
		var x := clampi(int(pcm[i] * 32767.0), -32768, 32767)
		var step: int = STEPS[idx]
		var diff := x - pred
		var code := 0
		if diff < 0:
			code = 8
			diff = -diff
		var dq := step >> 3
		if diff >= step:
			code |= 4
			diff -= step
			dq += step
		if diff >= step >> 1:
			code |= 2
			diff -= step >> 1
			dq += step >> 1
		if diff >= step >> 2:
			code |= 1
			dq += step >> 2
		pred = clampi(pred - dq if (code & 8) != 0 else pred + dq, -32768, 32767)
		idx = clampi(idx + IDX[code & 7], 0, 88)
		if (i & 1) == 0:
			byte = code
		else:
			out[5 + (i >> 1)] = byte | (code << 4)
	if (pcm.size() & 1) != 0:
		out[5 + (pcm.size() >> 1)] = byte
	return out


static func decode(data: PackedByteArray) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	if data.size() < 6:
		return out
	var pred := data.decode_s16(2)
	var idx := clampi(data[4], 0, 88)
	var n := (data.size() - 5) * 2
	out.resize(n)
	for i in n:
		var b := data[5 + (i >> 1)]
		var code := (b & 15) if (i & 1) == 0 else (b >> 4)
		var step: int = STEPS[idx]
		var dq := step >> 3
		if (code & 4) != 0:
			dq += step
		if (code & 2) != 0:
			dq += step >> 1
		if (code & 1) != 0:
			dq += step >> 2
		pred = clampi(pred - dq if (code & 8) != 0 else pred + dq, -32768, 32767)
		idx = clampi(idx + IDX[code & 7], 0, 88)
		out[i] = pred / 32768.0
	return out


# ------------------------------------------------------------------ playback

@rpc("any_peer", "call_remote", "unreliable_ordered", 2)
func rpc_voice(data: PackedByteArray) -> void:
	var pid := multiplayer.get_remote_sender_id()
	if world == null or not world.players.has(pid) or data.size() < 6:
		return
	packets_in[pid] = int(packets_in.get(pid, 0)) + 1
	if multiplayer.is_server():
		_noise(pid)
	var v = _voice_for(pid)
	if v == null:
		return
	var seq := data.decode_u16(0)
	var pcm := decode(data)
	var last: int = v["seq"]
	if last >= 0:
		var gap := (seq - last) & 0xffff
		if gap == 0 or gap > 0x8000:
			return    # duplicate / late
		if gap > 1 and gap <= 3 and not v["last"].is_empty():
			# lost packets: repeat the last one quieter instead of a click of silence
			for k in gap - 1:
				var fill := PackedFloat32Array(v["last"])
				var g := 0.5 / (k + 1)
				for i in fill.size():
					fill[i] *= g
				v["q"].append(fill)
	v["seq"] = seq
	v["last"] = pcm
	v["q"].append(pcm)
	v["t"] = 0.0
	if v["q"].size() > 12:
		v["q"] = v["q"].slice(v["q"].size() - 6)    # way behind: drop the backlog


## Monsters hear talking, at most every 0.4 s per speaker (host only).
var _noise_t := {}
func _noise(pid: int) -> void:
	var now := Time.get_ticks_msec()
	if now < int(_noise_t.get(pid, 0)):
		return
	_noise_t[pid] = now + 400
	var p = world.players.get(pid)
	if p:
		world.add_noise(world.chat_pos(pid), 0.35 if p.dead else 0.9)


func _voice_for(pid: int):
	if _voices.has(pid) and is_instance_valid(_voices[pid]["ap"]):
		return _voices[pid]
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = RATE
	gen.buffer_length = 0.5
	var ap := AudioStreamPlayer3D.new()
	ap.name = "Voice%d" % pid
	ap.stream = gen
	ap.bus = "Voice"
	ap.unit_size = 5.0
	ap.max_distance = HEAR
	ap.volume_db = 6.0
	ap.attenuation_filter_cutoff_hz = 6000.0
	world.add_child(ap)
	ap.global_position = _mouth(pid)
	ap.play()
	var v := {"ap": ap, "pb": ap.get_stream_playback(), "q": [], "seq": -1, "last": PackedFloat32Array(), "on": false, "t": 0.0}
	_voices[pid] = v
	return v


## Where a robot's voice comes from: its head, or its severed head when broken.
func _mouth(pid: int) -> Vector3:
	var p = world.players.get(pid)
	if p == null:
		return Vector3.ZERO
	if p.dead:
		return world.chat_pos(pid)
	return p.global_position + Vector3(0, 0.8 if p.tumbling else (1.2 if p.crouching else 1.55), 0)


func _play_voices(delta: float) -> void:
	for pid in _voices.keys():
		var v: Dictionary = _voices[pid]
		if not is_instance_valid(v["ap"]) or not world.players.has(pid):
			if is_instance_valid(v["ap"]):
				v["ap"].queue_free()
			_voices.erase(pid)
			speak_level.erase(pid)
			continue
		v["ap"].global_position = _mouth(pid)
		v["t"] += delta
		var q: Array = v["q"]
		if not v["on"]:
			# jitter buffer: start a talk spurt once a few packets are in (or it's a short one)
			if q.size() >= PRE or (q.size() > 0 and v["t"] > 0.15):
				v["on"] = true
		var lvl := 0.0
		if v["on"]:
			var pb: AudioStreamGeneratorPlayback = v["pb"]
			while not q.is_empty() and pb.get_frames_available() >= q[0].size():
				var pcm: PackedFloat32Array = q.pop_front()
				var fr := PackedVector2Array()
				fr.resize(pcm.size())
				var s := 0.0
				for i in pcm.size():
					fr[i] = Vector2(pcm[i], pcm[i])
					s += pcm[i] * pcm[i]
				pb.push_buffer(fr)
				lvl = maxf(lvl, sqrt(s / maxf(1.0, pcm.size())) * 4.0)
				_speak_t[pid] = 0.35
			if q.is_empty() and v["t"] > 0.3:
				v["on"] = false    # spurt over: the next one buffers again
		speak_level[pid] = maxf(float(speak_level.get(pid, 0.0)) - delta * 3.0, minf(lvl, 1.0))
	for pid in _speak_t.keys():
		_speak_t[pid] -= delta
		var p = world.players.get(pid)
		if p and p.name_label:
			p.name_label.modulate.a = 1.0 if _speak_t[pid] <= 0.0 else 0.6 + 0.4 * sin(Time.get_ticks_msec() * 0.02)
		if _speak_t[pid] <= -1.0:
			_speak_t.erase(pid)


## Who is talking right now (HUD list): pid -> level.
func speakers() -> Dictionary:
	var out := {}
	for pid in _speak_t:
		if _speak_t[pid] > 0.0:
			out[pid] = speak_level.get(pid, 0.0)
	if sending and world and world.local_player:
		out[world.local_player.peer_id] = mic_level
	return out


func frames_received(pid: int) -> int:
	return int(packets_in.get(pid, 0)) * PKT
