extends RefCounted
## Catalogue of valuables: stats and procedural models.

const DEFS := {
	# --- small (one hand)
	"trophy": {"v": [800, 1500], "mass": 1.2, "frag": 0.9, "glass": false},
	"camera": {"v": [1500, 3000], "mass": 1.0, "frag": 1.4, "glass": true},
	"gem": {"v": [3200, 6200], "mass": 1.5, "frag": 2.4, "glass": true},
	"crown": {"v": [2600, 5200], "mass": 1.2, "frag": 0.8, "glass": false},
	"goldbar": {"v": [4000, 7000], "mass": 3.0, "frag": 0.35, "glass": false},
	"cube": {"v": [900, 1800], "mass": 0.6, "frag": 1.0, "glass": false},
	"duck_gold": {"v": [1800, 3600], "mass": 1.0, "frag": 0.9, "glass": false},
	"figurine": {"v": [2000, 4000], "mass": 1.0, "frag": 2.2, "glass": true},
	"cash": {"v": [2500, 5000], "mass": 1.0, "frag": 0.0, "glass": false},
	# --- medium
	"vase": {"v": [2000, 4200], "mass": 3.0, "frag": 1.6, "glass": true},
	"painting": {"v": [2000, 4500], "mass": 3.0, "frag": 0.8, "glass": false},
	"laptop": {"v": [2500, 5000], "mass": 2.5, "frag": 1.3, "glass": true},
	"radio": {"v": [1500, 3200], "mass": 5.0, "frag": 0.8, "glass": false},
	"teddy": {"v": [1200, 2600], "mass": 1.5, "frag": 0.15, "glass": false},
	"toolbox": {"v": [1500, 3000], "mass": 6.0, "frag": 0.45, "glass": false},
	"microscope": {"v": [2800, 5200], "mass": 5.0, "frag": 1.0, "glass": false},
	"flasks": {"v": [1500, 3000], "mass": 2.0, "frag": 2.2, "glass": true},
	"powercell": {"v": [3500, 6500], "mass": 7.0, "frag": 1.4, "glass": true},
	"tv": {"v": [2500, 4500], "mass": 8.0, "frag": 1.2, "glass": true},
	"microwave": {"v": [2000, 3800], "mass": 9.0, "frag": 0.8, "glass": false},
	"computer": {"v": [3000, 6000], "mass": 12.0, "frag": 1.0, "glass": true},
	# --- heavy (two robots)
	"server": {"v": [6500, 10500], "mass": 28.0, "frag": 0.6, "glass": false},
	"safe": {"v": [8000, 13000], "mass": 42.0, "frag": 0.3, "glass": false},
	"statue": {"v": [7000, 11000], "mass": 30.0, "frag": 0.45, "glass": false},
	"aquarium": {"v": [9000, 15000], "mass": 36.0, "frag": 1.6, "glass": true},
	"orb": {"v": [0, 0], "mass": 4.0, "frag": 1.1, "glass": true},
	"moneybag": {"v": [0, 0], "mass": 2.5, "frag": 0.0, "glass": false},
	"up_hp": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_stamina": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_strength": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_range": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_speed": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_jump": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_tumble": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_crouch": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"up_wings": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"med_s": {"v": [0, 0], "mass": 1.0, "frag": 0.0, "glass": false, "cat": "med", "heal": 25.0, "store": true, "price": 4000},
	"med_m": {"v": [0, 0], "mass": 1.5, "frag": 0.0, "glass": false, "cat": "med", "heal": 50.0, "store": true, "price": 7000},
	"med_l": {"v": [0, 0], "mass": 2.5, "frag": 0.0, "glass": false, "cat": "med", "heal": 100.0, "store": true, "price": 10000},
	# weapons & gadgets (battery 0..1; cost = battery per use)
	"w_bat": {"v": [0, 0], "mass": 1.5, "frag": 0.0, "glass": false, "cat": "melee", "dmg": 40.0, "cost": 0.08, "cd": 0.55, "reach": 2.0, "melee": 3.0, "store": true, "price": 30000},
	"w_sledge": {"v": [0, 0], "mass": 5.0, "frag": 0.0, "glass": false, "cat": "melee", "dmg": 75.0, "cost": 0.1, "cd": 1.1, "reach": 2.2, "melee": 2.5, "store": true, "price": 36000},
	"w_pan": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false, "cat": "melee", "dmg": 30.0, "cost": 0.07, "cd": 0.6, "reach": 1.8, "melee": 3.0, "store": true, "price": 16000},
	"w_prod": {"v": [0, 0], "mass": 1.5, "frag": 0.0, "glass": false, "cat": "melee", "dmg": 5.0, "cost": 0.2, "cd": 0.8, "reach": 2.0, "melee": 1.5, "store": true, "price": 28000},
	"w_pistol": {"v": [0, 0], "mass": 1.2, "frag": 0.0, "glass": false, "cat": "gun", "dmg": 45.0, "cost": 0.125, "cd": 1.0, "store": true, "price": 20000},
	"w_shotgun": {"v": [0, 0], "mass": 3.0, "frag": 0.0, "glass": false, "cat": "gun", "dmg": 18.0, "cost": 0.2, "cd": 1.2, "store": true, "price": 45000},
	"w_tranq": {"v": [0, 0], "mass": 1.4, "frag": 0.0, "glass": false, "cat": "gun", "dmg": 0.0, "cost": 0.25, "cd": 1.0, "store": true, "price": 17000},
	"g_explosive": {"v": [0, 0], "mass": 0.5, "frag": 0.0, "glass": false, "cat": "throw", "store": true, "price": 3000},
	"g_stun": {"v": [0, 0], "mass": 0.5, "frag": 0.0, "glass": false, "cat": "throw", "store": true, "price": 3000},
	"g_shock": {"v": [0, 0], "mass": 0.5, "frag": 0.0, "glass": false, "cat": "throw", "store": true, "price": 3000},
	"m_explosive": {"v": [0, 0], "mass": 1.2, "frag": 0.0, "glass": false, "cat": "mine", "store": true, "price": 3000},
	"m_stun": {"v": [0, 0], "mass": 1.2, "frag": 0.0, "glass": false, "cat": "mine", "store": true, "price": 3000},
	"d_feather": {"v": [0, 0], "mass": 0.8, "frag": 0.0, "glass": false, "cat": "drone", "store": true, "price": 16000},
	"d_shield": {"v": [0, 0], "mass": 0.8, "frag": 0.0, "glass": false, "cat": "drone", "store": true, "price": 28000},
	"d_recharge": {"v": [0, 0], "mass": 0.8, "frag": 0.0, "glass": false, "cat": "drone", "store": true, "price": 22000},
	"d_zerog": {"v": [0, 0], "mass": 0.8, "frag": 0.0, "glass": false, "cat": "drone", "store": true, "price": 26000},
	"w_duck": {"v": [0, 0], "mass": 0.6, "frag": 0.0, "glass": false, "cat": "duck", "melee": 5.0, "cost": 0.0, "store": true, "price": 9000},
	"t_valuable": {"v": [0, 0], "mass": 0.4, "frag": 0.0, "glass": false, "cat": "tracker", "store": true, "price": 15000},
	"t_extract": {"v": [0, 0], "mass": 0.4, "frag": 0.0, "glass": false, "cat": "tracker", "store": true, "price": 6000},
	"i_crystal": {"v": [0, 0], "mass": 0.8, "frag": 0.0, "glass": false, "cat": "crystal", "store": true, "price": 8000},
	"i_pocketcart": {"v": [0, 0], "mass": 6.0, "frag": 0.0, "glass": false, "cat": "cart", "store": true, "price": 17000},
	"head": {"v": [0, 0], "mass": 2.0, "frag": 0.0, "glass": false},
	"cart": {"v": [0, 0], "mass": 20.0, "frag": 0.0, "glass": false},
}

# spawn tables per location: [small spots, table/cabinet tops, floor]
const TABLES := [
	[   # warehouse complex
		{"cash": 2.0, "goldbar": 1.2, "gem": 0.8, "camera": 1.5, "duck_gold": 1.0, "cube": 2.0, "trophy": 1.5},
		{"toolbox": 2.0, "radio": 1.5, "laptop": 1.2, "camera": 1.2, "crown": 0.8, "figurine": 1.0, "tv": 1.0, "trophy": 1.0},
		{"toolbox": 2.0, "tv": 1.2, "microwave": 1.5, "computer": 1.0, "powercell": 1.0, "safe": 0.8, "statue": 0.4},
	],
	[   # offices
		{"cash": 2.0, "figurine": 1.5, "cube": 1.5, "trophy": 2.0, "crown": 1.0, "duck_gold": 1.0, "gem": 0.6},
		{"laptop": 2.5, "vase": 1.5, "painting": 1.2, "radio": 1.0, "teddy": 1.2, "trophy": 1.0, "camera": 1.0},
		{"computer": 2.0, "painting": 1.5, "vase": 1.2, "teddy": 1.0, "microwave": 1.0, "safe": 0.8, "statue": 0.6, "aquarium": 0.5},
	],
	[   # lab
		{"gem": 1.5, "cube": 1.0, "cash": 1.0, "camera": 1.0, "flasks": 2.0},
		{"flasks": 2.5, "microscope": 2.0, "powercell": 1.2, "laptop": 1.5, "computer": 0.8},
		{"server": 1.2, "powercell": 2.0, "microscope": 1.5, "computer": 1.2, "safe": 0.5, "aquarium": 0.4},
	],
]
const HEAVY := ["statue", "safe", "server", "aquarium"]

static var _mats := {}
const ML = preload("res://scripts/game/matlib.gd")


static func pick_type(rng: RandomNumberGenerator, kind: String, level: int, loc := 0, always := false) -> String:
	if not always and rng.randf() < maxf(0.25, 0.45 - 0.03 * (level - 1)):
		return ""
	var t: Array = TABLES[loc % TABLES.size()]
	var table: Dictionary = t[0]
	if kind == "top":
		table = t[1]
	elif kind == "floor":
		table = (t[2] as Dictionary).duplicate()
		for h in HEAVY:
			if table.has(h):
				table[h] = table[h] + level * 0.15
	var total := 0.0
	for k in table:
		total += table[k]
	var r := rng.randf() * total
	for k in table:
		r -= table[k]
		if r <= 0.0:
			return k
	return table.keys()[0]


static func roll_value(rng: RandomNumberGenerator, type: String, level: int) -> int:
	var v: Array = DEFS[type]["v"]
	var base := rng.randi_range(v[0], v[1])
	# fewer valuables per level than before, so each one is worth more (and hurts more to break)
	return int(round(base * 1.35 * (1.0 + 0.15 * (level - 1)) / 10.0)) * 10


static func spawn_lift(type: String) -> float:
	# items are centred on their model: lift the spawn point by half their height
	if type == "cart":
		return 0.35
	var h: float = MODEL_H.get(type, 0.4)
	return h * 0.5 + 0.03


## Model heights (m) of the loot, for spawning them standing on the floor / furniture.
const MODEL_H := {"trophy": 0.28, "camera": 0.16, "gem": 0.18, "crown": 0.16, "goldbar": 0.1, "cube": 0.28, "duck_gold": 0.19,
	"figurine": 0.23, "cash": 0.15, "vase": 0.51, "painting": 0.56, "laptop": 0.24, "radio": 0.31, "teddy": 0.41, "toolbox": 0.31,
	"microscope": 0.44, "flasks": 0.23, "powercell": 0.38, "tv": 0.58, "microwave": 0.28, "computer": 0.42, "server": 1.2,
	"safe": 0.82, "statue": 1.42, "aquarium": 1.07}


static func mat(col: Color, emit := 0.0, metal := 0.0, alpha := 1.0) -> StandardMaterial3D:
	var key := "%s|%.2f|%.2f|%.2f" % [col.to_html(), emit, metal, alpha]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(col.r, col.g, col.b, alpha)
	m.metallic = metal
	m.roughness = 0.35 if metal > 0.0 else 0.7
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = emit
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_mats[key] = m
	return m


static func _mesh(parent: Node3D, mesh: Mesh, m: Material, pos: Vector3, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


static func _box(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b


static func _cyl(top: float, bottom: float, h: float, seg := 12) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = top
	c.bottom_radius = bottom
	c.height = h
	c.radial_segments = seg
	c.rings = 1
	return c


static func _sph(r: float, h := -1.0) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0 if h < 0.0 else h
	s.radial_segments = 14
	s.rings = 7
	return s


static func _shape(body: CollisionObject3D, shape: Shape3D, pos := Vector3.ZERO) -> void:
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.position = pos
	body.add_child(cs)


static func _bshape(size: Vector3) -> BoxShape3D:
	var b := BoxShape3D.new()
	b.size = size
	return b


static func _cshape(r: float, h: float) -> CylinderShape3D:
	var c := CylinderShape3D.new()
	c.radius = r
	c.height = h
	return c


static func _sshape(r: float) -> SphereShape3D:
	var s := SphereShape3D.new()
	s.radius = r
	return s


## Builds meshes + collision shapes under `body`. Returns the main colour.
static func build(type: String, body: RigidBody3D, extra: int, seed_v: int) -> Color:
	var r := RandomNumberGenerator.new()
	r.seed = seed_v
	var gold := mat(Color(1.0, 0.78, 0.3), 0.0, 0.9)
	var wood := mat(Color(0.35, 0.2, 0.1))
	var dark := mat(Color(0.08, 0.08, 0.08))
	var col := Color.WHITE
	if type == "w_duck":
		# rubber duck: bouncy, squeaky, hurts monsters it smacks into
		fit_model(body, "w_duck", {}, "sphere")
		return Color(1.0, 0.82, 0.12)
	if gear_shapes(type, body):
		_apply_model(type, body, r, col)
		return Color(0.6, 0.6, 0.65)
	if MODEL_H.has(type) or type in ["head", "w_duck_model"]:
		col = LOOT_COLOR.get(type, Color(0.8, 0.75, 0.6))
		var over := {}
		if type == "head":
			col = Net.COLORS[extra % Net.COLORS.size()] if extra >= 0 else Color.ORANGE
			over["M_player"] = ML.robot_paint(col)
		fit_model(body, type, over, "sphere" if type in ["head", "gem", "teddy"] else "box")
		return col
	match type:
		"up_hp", "up_stamina", "up_strength", "up_range", "up_speed", "up_jump", "up_tumble", "up_crouch", "up_wings":
			col = UP_COLORS[type]
			_mesh(body, _cyl(0.1, 0.1, 0.4), mat(col, 1.5), Vector3.ZERO)
			_shape(body, _cshape(0.12, 0.44))
		"med_s", "med_m", "med_l":
			var sc: float = {"med_s": 0.7, "med_m": 1.0, "med_l": 1.3}[type]
			col = Color(0.85, 0.15, 0.15)
			_mesh(body, _box(Vector3(0.3, 0.14, 0.2) * sc), mat(Color(0.85, 0.85, 0.85)), Vector3.ZERO)
			_shape(body, _bshape(Vector3(0.32, 0.16, 0.22) * sc))
		"moneybag":
			col = Color(0.72, 0.6, 0.38)
			_mesh(body, _sph(0.2), mat(col), Vector3.ZERO)
			_shape(body, _sshape(0.2), Vector3(0, 0.0, 0))
			_shape(body, _sshape(0.08), Vector3(0, 0.2, 0))
		"orb":
			col = Color(0.75, 0.3, 1.0)
			_mesh(body, _sph(0.22), mat(col, 1.6, 0.0, 0.9), Vector3.ZERO)
			_mesh(body, _sph(0.12), mat(Color(1, 0.9, 1), 2.5), Vector3.ZERO)
			var l := OmniLight3D.new()
			l.light_color = col
			l.omni_range = 3.0
			l.light_energy = 0.8
			body.add_child(l)
			_shape(body, _sshape(0.22))
		"cart":
			col = Color(0.9, 0.7, 0.15)
			_shape(body, _bshape(Vector3(1.04, 0.08, 0.82)), Vector3(0, -0.1, 0))
			_shape(body, _bshape(Vector3(1.04, 0.44, 0.06)), Vector3(0, 0.1, 0.41))
			_shape(body, _bshape(Vector3(1.04, 0.44, 0.06)), Vector3(0, 0.1, -0.41))
			_shape(body, _bshape(Vector3(0.06, 0.44, 0.82)), Vector3(0.51, 0.1, 0))
			_shape(body, _bshape(Vector3(0.06, 0.44, 0.82)), Vector3(-0.51, 0.1, 0))
			_shape(body, _sshape(0.1), Vector3(0.38, -0.3, 0.36))
			_shape(body, _sshape(0.1), Vector3(-0.38, -0.3, 0.36))
			_shape(body, _sshape(0.1), Vector3(0.38, -0.3, -0.36))
			_shape(body, _sshape(0.1), Vector3(-0.38, -0.3, -0.36))
			_shape(body, _bshape(Vector3(0.1, 0.12, 0.72)), Vector3(-0.72, 0.52, 0))   # handle (strong grip)
	_apply_model(type, body, r, col)
	return col


const LOOT_COLOR := {"trophy": Color(1.0, 0.78, 0.3), "crown": Color(1.0, 0.78, 0.3), "goldbar": Color(1.0, 0.78, 0.3), "duck_gold": Color(1.0, 0.78, 0.3),
	"gem": Color(0.3, 0.55, 1.0), "cash": Color(0.45, 0.75, 0.4), "vase": Color(0.2, 0.35, 0.8), "toolbox": Color(0.8, 0.15, 0.12),
	"powercell": Color(0.35, 0.9, 1.0), "flasks": Color(0.35, 1.0, 0.5), "figurine": Color(0.95, 0.95, 0.92), "teddy": Color(0.6, 0.4, 0.22)}


## Instances a model centred on the body and gives it a collision shape from its bounds
## ("box" or "sphere"). Works whatever the GLB origin is.
static func fit_model(body: Node3D, mname: String, over := {}, kind := "box") -> void:
	var m := ML.model(mname, over)
	if m == null:
		_shape(body as CollisionObject3D, _sshape(0.15))
		return
	var ab := AABB()
	var first := true
	for mi in m.find_children("*", "MeshInstance3D", true, false):
		var t := Transform3D.IDENTITY
		var n: Node = mi
		while n != m and n is Node3D:
			t = (n as Node3D).transform * t
			n = n.get_parent()
		var a := t * (mi as MeshInstance3D).get_aabb()
		ab = a if first else ab.merge(a)
		first = false
	var ctr := ab.get_center()
	m.position = -ctr
	body.add_child(m)
	ML.vis_range(m, 32.0, 4.0)
	var sz := ab.size
	if kind == "sphere":
		_shape(body as CollisionObject3D, _sshape(maxf(0.06, minf(sz.x, minf(sz.y, sz.z)) * 0.5)))
	else:
		_shape(body as CollisionObject3D, _bshape(Vector3(maxf(sz.x, 0.04), maxf(sz.y, 0.04), maxf(sz.z, 0.04)) * 0.94))


static func _apply_model(type: String, body: Node3D, r: RandomNumberGenerator, col: Color) -> void:
	var mname := type
	var over := {}
	match type:
		"up_hp", "up_stamina", "up_strength", "up_range", "up_speed", "up_jump", "up_tumble", "up_crouch", "up_wings":
			mname = "up_item"
			over["E_5ad8ff"] = ML.plain(col, 0.3, 0.0, 2.5)
		"med_s", "med_m", "med_l":
			mname = "medkit_" + type.substr(4)

	var m := ML.model(mname, over)
	if m == null:
		return
	for c in body.get_children():
		if c is MeshInstance3D:
			body.remove_child(c)
			c.queue_free()
	body.add_child(m)
	ML.vis_range(m, 32.0, 4.0)


const UP_COLORS := {"up_hp": Color(1.0, 0.35, 0.3), "up_stamina": Color(0.3, 0.7, 1.0), "up_strength": Color(1.0, 0.6, 0.1), "up_range": Color(0.75, 0.4, 1.0), "up_speed": Color(0.4, 1.0, 0.4), "up_jump": Color(1.0, 1.0, 0.4), "up_tumble": Color(0.3, 1.0, 0.9), "up_crouch": Color(0.9, 0.5, 1.0), "up_wings": Color(1.0, 0.75, 0.85)}
const DRONE_GLOW := {"d_feather": Color(0.62, 1.0, 0.69), "d_shield": Color(1.0, 0.82, 0.38), "d_recharge": Color(0.3, 0.72, 1.0), "d_zerog": Color(0.78, 0.42, 1.0)}


static func is_gear(type: String) -> bool:
	return DEFS.get(type, {}).has("cat")


static func can_store(type: String) -> bool:
	return DEFS.get(type, {}).get("store", false)


static func gear_shapes(type: String, body: RigidBody3D) -> bool:
	match type:
		"w_bat":
			_shape(body, _bshape(Vector3(0.09, 0.09, 0.82)), Vector3(0, 0, -0.155))
		"w_sledge":
			_shape(body, _bshape(Vector3(0.05, 0.05, 0.9)))
			_shape(body, _bshape(Vector3(0.12, 0.3, 0.13)), Vector3(0, 0, -0.45))
		"w_pan":
			_shape(body, _cshape(0.15, 0.05), Vector3(0, 0, -0.28))
			_shape(body, _bshape(Vector3(0.04, 0.03, 0.3)))
		"w_prod":
			_shape(body, _bshape(Vector3(0.05, 0.05, 0.7)), Vector3(0, 0, -0.1))
		"w_pistol":
			_shape(body, _bshape(Vector3(0.05, 0.14, 0.28)), Vector3(0, 0.01, -0.06))
		"w_shotgun":
			_shape(body, _bshape(Vector3(0.08, 0.12, 0.95)), Vector3(0, 0.02, -0.2))
		"w_tranq":
			_shape(body, _bshape(Vector3(0.05, 0.12, 0.38)), Vector3(0, 0.02, -0.1))
		"g_explosive", "g_stun", "g_shock":
			_shape(body, _sshape(0.07))
		"m_explosive", "m_stun":
			_shape(body, _cshape(0.15, 0.08), Vector3(0, 0.02, 0))
		"d_feather", "d_shield", "d_recharge", "d_zerog":
			_shape(body, _bshape(Vector3(0.26, 0.08, 0.26)))
		"t_valuable", "t_extract":
			_shape(body, _bshape(Vector3(0.09, 0.17, 0.06)))
		"i_crystal":
			_shape(body, _bshape(Vector3(0.14, 0.26, 0.14)))
		"i_pocketcart":
			_shape(body, _bshape(Vector3(0.6, 0.04, 0.4)), Vector3(0, -0.1, 0))
			_shape(body, _bshape(Vector3(0.6, 0.2, 0.03)), Vector3(0, 0.0, 0.2))
			_shape(body, _bshape(Vector3(0.6, 0.2, 0.03)), Vector3(0, 0.0, -0.2))
			_shape(body, _bshape(Vector3(0.03, 0.2, 0.4)), Vector3(0.3, 0.0, 0))
			_shape(body, _bshape(Vector3(0.03, 0.2, 0.4)), Vector3(-0.3, 0.0, 0))
			_shape(body, _bshape(Vector3(0.08, 0.08, 0.34)), Vector3(-0.42, 0.16, 0))   # handle
		_:
			return false
	return true


static func is_shop(type: String) -> bool:
	if DEFS.get(type, {}).has("price"):
		return true
	return type.begins_with("up_") or type.begins_with("med_")


const COLORS_SAFE := [Color(1.0, 0.55, 0.1), Color(0.2, 0.75, 1.0), Color(0.45, 1.0, 0.3), Color(1.0, 0.35, 0.65)]
