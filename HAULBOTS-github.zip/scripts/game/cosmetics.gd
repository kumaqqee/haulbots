extends RefCounted
## Robot cosmetics (achievement rewards): hats and accessories built from primitive meshes (no
## assets in the APK), finishes via the robot paint shader. Used by the in-game robots, the menu
## garage and the collection screen.

const ML = preload("res://scripts/game/matlib.gd")

const HATS := ["cap", "tophat", "beanie", "party", "chef", "viking", "propeller", "halo", "cowboy", "astro"]
const ACCS := ["bowtie", "shades", "scarf", "antenna", "monocle", "heart", "headphones"]
const FINS := ["chrome", "gold", "rust", "neon", "carbon", "lava"]
## Supporter pack exclusives (in-app purchase) — everything else comes from achievements.
const SUPPORTER_ITEMS := ["cowboy", "astro", "headphones", "carbon", "lava"]
const HEAD_TOP := 0.565   # top of the hood above the head node (robot.glb)
const EYE_Y := 0.285     # the single camera eye in the hood opening
const FACE_Z := -0.262


## Puts `cos` ({"hat", "acc", "fin"}) on a robot.glb instance. `head`/`body` are its nodes.
static func apply(head: Node3D, body: Node3D, cos: Dictionary, col: Color) -> void:
	for n in [head, body]:
		if n == null:
			continue
		for c in n.get_children():
			if c.name.begins_with("Cos"):
				n.remove_child(c)
				c.queue_free()
	var hat := str(cos.get("hat", ""))
	var acc := str(cos.get("acc", ""))
	if head and hat in HATS:
		var h := build_hat(hat, col)
		h.name = "CosHat"
		head.add_child(h)
	if acc in ACCS:
		var on_body: bool = acc in ["bowtie", "scarf"]
		var parent: Node3D = body if on_body else head
		if parent:
			var a := build_acc(acc, col)
			a.name = "CosAcc"
			parent.add_child(a)


static func paint(col: Color, cos: Dictionary) -> Material:
	var f := str(cos.get("fin", ""))
	return ML.robot_paint(col, f if f in FINS else "")


static func _mi(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


static func _cyl(top: float, bottom: float, h: float, seg := 20) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = top
	c.bottom_radius = bottom
	c.height = h
	c.radial_segments = seg
	c.rings = 1
	return c


static func _sph(r: float, h := -1.0, hemi := false, seg := 20) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = h if h > 0.0 else r * 2.0
	s.is_hemisphere = hemi
	s.radial_segments = seg
	s.rings = 10
	return s


static func _box(sz: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = sz
	return b


static func _torus(inner: float, outer: float) -> TorusMesh:
	var t := TorusMesh.new()
	t.inner_radius = inner
	t.outer_radius = outer
	t.rings = 24
	t.ring_segments = 10
	return t


static func _spin(n: Node3D, axis: String, period: float) -> void:
	n.ready.connect(func():
		var tw := n.create_tween().set_loops()
		tw.tween_property(n, "rotation:" + axis, TAU, period).from(0.0))


static func _bob(n: Node3D, amp: float, period: float) -> void:
	n.ready.connect(func():
		var y0 := n.position.y
		var tw := n.create_tween().set_loops().set_trans(Tween.TRANS_SINE)
		tw.tween_property(n, "position:y", y0 + amp, period * 0.5)
		tw.tween_property(n, "position:y", y0, period * 0.5))


static func build_hat(id: String, col: Color) -> Node3D:
	var n := Node3D.new()
	var t := HEAD_TOP
	match id:
		"cap":
			var m := ML.plain(col.darkened(0.25), 0.8)
			_mi(n, _sph(0.2, 0.2, true), m, Vector3(0, t - 0.035, 0), Vector3.ZERO, Vector3(1.25, 0.9, 1.05))
			_mi(n, _cyl(0.17, 0.17, 0.02), m, Vector3(0, t - 0.03, -0.2), Vector3.ZERO, Vector3(1.2, 1, 0.9))
			_mi(n, _sph(0.025), ML.plain(col.lightened(0.3), 0.6), Vector3(0, t + 0.15, 0))
		"tophat":
			var blk := ML.plain(Color(0.06, 0.06, 0.07), 0.5)
			_mi(n, _cyl(0.27, 0.27, 0.025), blk, Vector3(0, t - 0.01, 0))
			_mi(n, _cyl(0.16, 0.17, 0.32), blk, Vector3(0, t + 0.15, 0))
			_mi(n, _cyl(0.172, 0.176, 0.06), ML.plain(Color(0.7, 0.08, 0.08), 0.6), Vector3(0, t + 0.04, 0))
			n.rotation.z = 0.08
		"beanie":
			var m := ML.plain(col.lerp(Color(0.9, 0.9, 0.9), 0.25), 0.95)
			_mi(n, _sph(0.26, 0.32, true), m, Vector3(0, t - 0.1, 0), Vector3.ZERO, Vector3(1.12, 1.0, 1.0))
			_mi(n, _cyl(0.3, 0.3, 0.09), ML.plain(col.darkened(0.2), 0.95), Vector3(0, t - 0.06, 0), Vector3.ZERO, Vector3(1.0, 1, 0.9))
			_mi(n, _sph(0.07), ML.plain(Color(0.95, 0.95, 0.95), 1.0), Vector3(0, t + 0.2, 0))
		"party":
			var cone := _mi(n, _cyl(0.0, 0.14, 0.34), ML.plain(Color(0.2, 0.55, 0.95), 0.6), Vector3(0.05, t + 0.14, 0), Vector3(0, 0, -0.25))
			_mi(cone, _cyl(0.07, 0.1, 0.05), ML.plain(Color(1.0, 0.85, 0.1), 0.5), Vector3(0, -0.02, 0))
			_mi(cone, _cyl(0.035, 0.05, 0.04), ML.plain(Color(1.0, 0.25, 0.5), 0.5), Vector3(0, 0.08, 0))
			_mi(cone, _sph(0.045), ML.plain(Color(1.0, 0.25, 0.5), 0.7), Vector3(0, 0.18, 0))
		"chef":
			var w := ML.plain(Color(0.95, 0.95, 0.93), 0.9)
			_mi(n, _cyl(0.19, 0.19, 0.16), w, Vector3(0, t + 0.05, 0))
			for i in 5:
				var a := i * TAU / 5.0
				_mi(n, _sph(0.12), w, Vector3(cos(a) * 0.1, t + 0.2, sin(a) * 0.1))
			_mi(n, _sph(0.14), w, Vector3(0, t + 0.24, 0))
		"viking":
			var met := ML.plain(Color(0.55, 0.56, 0.6), 0.35, 0.9)
			_mi(n, _sph(0.3, 0.36, true), met, Vector3(0, t - 0.14, 0), Vector3.ZERO, Vector3(1.02, 1, 0.9))
			_mi(n, _cyl(0.305, 0.305, 0.05), ML.plain(Color(0.45, 0.3, 0.12), 0.7, 0.3), Vector3(0, t - 0.13, 0), Vector3.ZERO, Vector3(1.02, 1, 0.9))
			var bone := ML.plain(Color(0.93, 0.88, 0.75), 0.6)
			for sx in [-1.0, 1.0]:
				var hp := Node3D.new()
				hp.position = Vector3(sx * 0.27, t - 0.02, 0)
				hp.rotation.z = -sx * 1.0
				n.add_child(hp)
				_mi(hp, _cyl(0.0, 0.055, 0.24), bone, Vector3(0, 0.1, 0))
		"propeller":
			_mi(n, _sph(0.22, 0.22, true), ML.plain(Color(0.95, 0.25, 0.2), 0.8), Vector3(0, t - 0.06, 0), Vector3.ZERO, Vector3(1.15, 1, 1.05))
			_mi(n, _torus(0.235, 0.27), ML.plain(Color(0.2, 0.6, 1.0), 0.8), Vector3(0, t - 0.05, 0), Vector3.ZERO, Vector3(1.1, 0.6, 1.0))
			_mi(n, _sph(0.035), ML.plain(Color(0.3, 0.8, 0.3), 0.6), Vector3(0, t + 0.16, 0))
			_mi(n, _cyl(0.012, 0.012, 0.14), ML.plain(Color(0.2, 0.2, 0.2), 0.5, 0.5), Vector3(0, t + 0.2, 0))
			var rotor := Node3D.new()
			rotor.position = Vector3(0, t + 0.27, 0)
			n.add_child(rotor)
			for sx in [-1.0, 1.0]:
				_mi(rotor, _box(Vector3(0.2, 0.012, 0.05)), ML.plain(Color(1.0, 0.8, 0.1), 0.6), Vector3(sx * 0.11, 0, 0), Vector3(sx * 0.3, 0, 0))
			_spin(rotor, "y", 0.5)
		"cowboy":
			var leather := ML.plain(Color(0.45, 0.28, 0.14), 0.75)
			var brim := _mi(n, _cyl(0.36, 0.36, 0.025), leather, Vector3(0, t - 0.02, 0), Vector3.ZERO, Vector3(1.0, 1, 0.82))
			brim.rotation.x = 0.06
			_mi(n, _cyl(0.15, 0.19, 0.2), leather, Vector3(0, t + 0.09, 0), Vector3.ZERO, Vector3(1.0, 1, 0.85))
			_mi(n, _sph(0.15, 0.1, true), leather, Vector3(0, t + 0.19, 0), Vector3.ZERO, Vector3(1.0, 0.5, 0.85))
			_mi(n, _cyl(0.192, 0.195, 0.04), ML.plain(Color(0.12, 0.08, 0.05), 0.6), Vector3(0, t + 0.03, 0), Vector3.ZERO, Vector3(1.0, 1, 0.85))
			_mi(n, _sph(0.025), ML.plain(Color(1.0, 0.8, 0.3), 0.3, 1.0), Vector3(0.0, t + 0.03, -0.165))
		"astro":
			# glass bubble over the whole head, a white collar ring and a little light
			_mi(n, _sph(0.37, 0.74, false, 28), ML.plain(Color(0.75, 0.9, 1.0), 0.05, 0.0, 0.0, 0.18), Vector3(0, 0.25, 0))
			_mi(n, _torus(0.17, 0.25), ML.plain(Color(0.92, 0.93, 0.95), 0.5, 0.2), Vector3(0, -0.05, 0), Vector3.ZERO, Vector3(1, 0.8, 1))
			_mi(n, _sph(0.035), ML.plain(Color(0.5, 1.0, 0.6), 0.3, 0.0, 3.0), Vector3(0.24, 0.52, -0.2))
		"halo":
			var ring := _mi(n, _torus(0.16, 0.2), ML.plain(Color(1.0, 0.86, 0.35), 0.3, 0.2, 2.6), Vector3(0, t + 0.14, 0))
			_bob(ring, 0.035, 2.4)
	return n


static func build_acc(id: String, col: Color) -> Node3D:
	var n := Node3D.new()
	match id:
		"bowtie":
			# on the body node: its top (the neck) is 0.6 above it, the front at z -0.22
			var m := ML.plain(Color(0.75, 0.06, 0.1), 0.55)
			for sx in [-1.0, 1.0]:
				_mi(n, _cyl(0.0, 0.055, 0.1, 4), m, Vector3(sx * 0.05, 0.54, -0.235), Vector3(0, 0, sx * PI * 0.5))
			_mi(n, _box(Vector3(0.04, 0.045, 0.03)), m, Vector3(0, 0.54, -0.24))
		"scarf":
			var m := ML.plain(Color(0.85, 0.15, 0.12), 0.95)
			var st := ML.plain(Color(0.95, 0.95, 0.9), 0.95)
			_mi(n, _torus(0.18, 0.28), m, Vector3(0, 0.6, 0), Vector3.ZERO, Vector3(1.0, 1.4, 0.95))
			var tail := _mi(n, _box(Vector3(0.1, 0.26, 0.03)), m, Vector3(0.12, 0.44, -0.25), Vector3(0.12, 0, 0.12))
			_mi(tail, _box(Vector3(0.102, 0.03, 0.032)), st, Vector3(0, -0.07, 0))
			_mi(tail, _box(Vector3(0.102, 0.03, 0.032)), st, Vector3(0, -0.02, 0))
		"shades":
			# one wide visor-shade over the big eye, arms tucked into the hood
			var blk := ML.plain(Color(0.02, 0.02, 0.03), 0.15, 0.6)
			_mi(n, _box(Vector3(0.27, 0.11, 0.02)), blk, Vector3(0, EYE_Y, FACE_Z - 0.014))
			_mi(n, _box(Vector3(0.3, 0.02, 0.022)), blk, Vector3(0, EYE_Y + 0.05, FACE_Z - 0.014))
			for sx in [-1.0, 1.0]:
				_mi(n, _box(Vector3(0.015, 0.018, 0.08)), blk, Vector3(sx * 0.15, EYE_Y + 0.045, FACE_Z + 0.03))
		"antenna":
			var dark := ML.plain(Color(0.15, 0.15, 0.17), 0.5, 0.6)
			_mi(n, _cyl(0.012, 0.018, 0.34), dark, Vector3(0.2, HEAD_TOP + 0.12, 0.05), Vector3(0, 0, -0.12))
			var tip := _mi(n, _sph(0.045), ML.plain(col.lightened(0.3), 0.3, 0.0, 3.0), Vector3(0.22, HEAD_TOP + 0.3, 0.05))
			tip.name = "Tip"
		"monocle":
			var gold := ML.plain(Color(1.0, 0.78, 0.3), 0.25, 1.0)
			_mi(n, _torus(0.108, 0.124), gold, Vector3(0, EYE_Y, FACE_Z - 0.014), Vector3(PI * 0.5, 0, 0))
			_mi(n, _cyl(0.108, 0.108, 0.004), ML.plain(Color(0.8, 0.9, 1.0), 0.05, 0.0, 0.0, 0.25), Vector3(0, EYE_Y, FACE_Z - 0.014), Vector3(PI * 0.5, 0, 0))
			_mi(n, _cyl(0.004, 0.004, 0.22), gold, Vector3(0.1, EYE_Y - 0.17, FACE_Z - 0.01), Vector3(0, 0, 0.3))
		"headphones":
			var dark := ML.plain(Color(0.08, 0.08, 0.1), 0.4, 0.3)
			var accent := ML.plain(col.lightened(0.15), 0.35, 0.2, 0.6)
			var band := _mi(n, _torus(0.29, 0.345), dark, Vector3(0, EYE_Y + 0.03, 0), Vector3(0, 0, PI * 0.5), Vector3(1, 1, 0.55))
			band.name = "Band"
			for sx in [-1.0, 1.0]:
				_mi(n, _cyl(0.125, 0.125, 0.1), dark, Vector3(sx * 0.33, EYE_Y, 0.0), Vector3(0, 0, PI * 0.5))
				_mi(n, _cyl(0.09, 0.09, 0.105), accent, Vector3(sx * 0.338, EYE_Y, 0.0), Vector3(0, 0, PI * 0.5))
		"heart":
			var h := Node3D.new()
			h.position = Vector3(0.24, HEAD_TOP + 0.1, 0.0)
			n.add_child(h)
			var m := ML.plain(Color(1.0, 0.25, 0.4), 0.4, 0.0, 1.6)
			for sx in [-1.0, 1.0]:
				_mi(h, _sph(0.05), m, Vector3(sx * 0.037, 0.02, 0))
			_mi(h, _box(Vector3(0.075, 0.075, 0.07)), m, Vector3(0, -0.025, 0), Vector3(0, 0, PI * 0.25))
			_bob(h, 0.04, 1.6)
			_spin(h, "y", 3.0)
	return n
