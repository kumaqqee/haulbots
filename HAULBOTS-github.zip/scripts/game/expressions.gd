extends RefCounted
## Robot eye expressions like the reference game's Semibots: six toggles that can be combined.
## bit 0 angry, 1 sad, 2 suspicious, 3 eyes closed, 4 crazy, 5 happy.

const COUNT := 6
const KEYS := ["expr_angry", "expr_sad", "expr_sus", "expr_closed", "expr_crazy", "expr_happy"]


## -> {"up": upper-lid close 0..1, "tilt": inner-corner tilt (rad), "low": lower lid raise 0..1, "crazy": bool}
static func params(mask: int) -> Dictionary:
	var up := 0.0
	var tilt := 0.0
	var low := 0.0
	if mask & 1:
		up = maxf(up, 0.42)
		tilt += 0.5
	if mask & 2:
		up = maxf(up, 0.36)
		tilt -= 0.5
	if mask & 4:
		up = maxf(up, 0.52)
		low = maxf(low, 0.38)
	if mask & 8:
		up = 1.0
	if mask & 32:
		low = maxf(low, 0.62)
	return {"up": up, "tilt": clampf(tilt, -0.7, 0.7), "low": low, "crazy": (mask & 16) != 0}


## 2D preview of the robot's single eye (HUD buttons).
static func draw_face(ci: CanvasItem, c: Vector2, s: float, mask: int, col: Color, bg := Color(0.05, 0.05, 0.06)) -> void:
	var p := params(mask)
	var r := s * 0.36
	var pts := PackedVector2Array()
	for i in 32:
		var a := TAU * i / 32.0
		pts.append(c + Vector2(cos(a), sin(a)) * r)
	ci.draw_colored_polygon(pts, col)
	# pupil
	var pr := r * (0.25 if p["crazy"] else 0.44)
	var po := c + Vector2(0, r * 0.22 if mask & 2 else 0.0)
	ci.draw_circle(po, pr, bg)
	ci.draw_circle(po + Vector2(pr * 0.45, -pr * 0.45), maxf(1.5, pr * 0.22), col)
	var w := r * 1.25
	# upper lid: drops and tilts
	if p["up"] > 0.0:
		var drop: float = -r + p["up"] * r * 2.0
		var t: float = p["tilt"]
		var l0 := c + Vector2(-w, drop - t * w * 0.8)
		var l1 := c + Vector2(w, drop + t * w * 0.8)
		ci.draw_colored_polygon(PackedVector2Array([l0, l1, c + Vector2(w, -r - 4), c + Vector2(-w, -r - 4)]), bg)
	if p["up"] >= 1.0:
		ci.draw_line(c + Vector2(-r * 0.8, 0), c + Vector2(r * 0.8, 0), col, maxf(2.0, s * 0.05), true)
	# lower lid: a rising smile-arc
	if p["low"] > 0.0:
		var rise: float = r - p["low"] * r * 1.45
		var lp := PackedVector2Array()
		for i in 13:
			var x := -w + 2.0 * w * i / 12.0
			lp.append(c + Vector2(x, rise + (x / r) * (x / r) * p["low"] * r * 0.55))
		lp.append(c + Vector2(w, r + 4))
		lp.append(c + Vector2(-w, r + 4))
		ci.draw_colored_polygon(lp, bg)
	# rim
	ci.draw_arc(c, r, 0.0, TAU, 32, col.darkened(0.25), maxf(1.5, s * 0.035), true)
