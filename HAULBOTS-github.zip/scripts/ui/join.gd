extends Control
## Join screen: games found on the Wi-Fi as cards, plus a manual IP field.

const UI = preload("res://scripts/ui/ui.gd")

var main: Node
var list: VBoxContainer
var status: Label
var ip_edit: LineEdit
var _dots := 0.0


func _ready() -> void:
	UI.full(self)
	add_child(UI.backdrop())
	var vb := UI.panel_column(self, 760)
	vb.add_child(UI.title(Settings.t("host_games"), 42))
	var host := UI.button(Settings.t("lan_create"), _host, 460, 62, true)
	host.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(host)
	vb.add_child(UI.sep())
	status = UI.label(Settings.t("searching"), 20, UI.DIM)
	vb.add_child(status)
	list = VBoxContainer.new()
	list.add_theme_constant_override("separation", 8)
	vb.add_child(list)
	vb.add_child(UI.sep())
	vb.add_child(UI.label(Settings.t("manual_ip"), 18, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 8)
	ip_edit = LineEdit.new()
	ip_edit.placeholder_text = Settings.t("ip_hint")
	ip_edit.text = Settings.last_ip
	ip_edit.custom_minimum_size = Vector2(400, 58)
	ip_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ip_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER_DECIMAL
	hb.add_child(ip_edit)
	hb.add_child(UI.button(Settings.t("connect"), _manual, 220, 58, true))
	vb.add_child(hb)
	var back := UI.button(Settings.t("back"), _back, 300, 56)
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(back)
	Net.hosts_changed.connect(_refresh)
	Net.start_listen()
	_refresh()


func _process(delta: float) -> void:
	if Net.found_hosts.is_empty():
		_dots += delta * 2.5
		status.text = Settings.t("searching").trim_suffix("...").trim_suffix("…") + ".".repeat(1 + int(_dots) % 3) + "\n" + Settings.t("no_games")


func _refresh() -> void:
	for c in list.get_children():
		c.queue_free()
	if Net.found_hosts.is_empty():
		return
	status.text = Settings.t("searching")
	for ip in Net.found_hosts:
		var h: Dictionary = Net.found_hosts[ip]
		var card := PanelContainer.new()
		card.add_theme_stylebox_override("panel", UI.sb(Color(0.08, 0.08, 0.1, 0.9), Color(UI.ACCENT, 0.5), 1, 14, Vector4(16, 10, 12, 10)))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 14)
		card.add_child(row)
		var ic := Control.new()
		ic.custom_minimum_size = Vector2(44, 44)
		ic.draw.connect(func(): preload("res://scripts/ui/icons.gd").draw(ic, "users", ic.size / 2.0, 34.0, UI.ACCENT2))
		row.add_child(ic)
		var iv := VBoxContainer.new()
		iv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		iv.add_theme_constant_override("separation", 0)
		row.add_child(iv)
		iv.add_child(UI.label(str(h["name"]), 26, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT))
		iv.add_child(UI.label("%s  •  %s" % [Settings.t("players_short") % int(h["count"]), ip], 16, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
		row.add_child(UI.button(Settings.t("join_btn"), _join.bind(ip), 160, 56, true))
		list.add_child(card)


func _join(ip: String) -> void:
	Settings.last_ip = ip
	Settings.save_cfg()
	Net.stop_listen()
	main.show_connecting()
	Net.join_game(ip)


func _manual() -> void:
	var ip := ip_edit.text.strip_edges()
	if ip.is_valid_ip_address():
		_join(ip)
	else:
		main.toast(Settings.t("conn_failed"))


func _host() -> void:
	Net.stop_listen()
	if Net.host_game():
		main.show_lobby()
	else:
		Net.start_listen()
		main.toast(Settings.t("host_failed"))


func _back() -> void:
	Net.stop_listen()
	main.show_menu()


func _exit_tree() -> void:
	if Net.hosts_changed.is_connected(_refresh):
		Net.hosts_changed.disconnect(_refresh)
