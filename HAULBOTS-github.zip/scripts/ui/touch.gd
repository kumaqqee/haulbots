extends Control
## Multi-touch controls: floating joystick (left), look area (right), icon action buttons.
## Size and opacity follow Settings.btn_scale / Settings.btn_alpha.

const Icons = preload("res://scripts/ui/icons.gd")
const UI = preload("res://scripts/ui/ui.gd")

var move_vec := Vector2.ZERO
var sprint_on := false
var crouch_on := false
var tumble_on := false
var grabbing := false
var _look_acc := Vector2.ZERO
var _joy_idx := -1
var _joy_center := Vector2.ZERO
var _joy_pos := Vector2.ZERO
var _joy_home := Vector2.ZERO
var _look_idx := -1
var _look_last := Vector2.ZERO
var _u := 1.0
var buttons := {}
var edit_mode := false     # layout editor: every button shown, drag to move
var selected := ""
var edit_top := 0.0        # editor: presses above this belong to its top bar
var _drag := ""
var _drag_off := Vector2.ZERO
var _btn_touch := {}
var _pressed := {}
var _press_anim := {}

const ICON := {"grab": "grab", "jump": "jump", "throw": "throw", "use": "use", "pull": "up", "push": "down",
	"sprint": "run", "crouch": "crouch", "ping": "ping", "tumble": "tumble"}


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	resized.connect(_layout)
	Settings.changed.connect(_layout)
	_layout()


func _exit_tree() -> void:
	if Settings.changed.is_connected(_layout):
		Settings.changed.disconnect(_layout)


func _layout() -> void:
	var s := size
	if s.x < 10:
		s = get_viewport_rect().size
	_u = s.y / 720.0
	var u := _u
	var k := Settings.btn_scale
	buttons = {
		"grab": {"pos": Vector2(s.x - 150 * u, s.y - 175 * u), "r": 80 * u * k, "label": "btn_grab"},
		"jump": {"pos": Vector2(s.x - 325 * u, s.y - 95 * u), "r": 52 * u * k, "label": "btn_jump"},
		"throw": {"pos": Vector2(s.x - 320 * u, s.y - 255 * u), "r": 50 * u * k, "label": "btn_throw"},
		"use": {"pos": Vector2(s.x - 102 * u, s.y - 490 * u), "r": 46 * u * k, "label": "btn_use"},
		"pull": {"pos": Vector2(s.x - 455 * u, s.y - 262 * u), "r": 40 * u * k, "label": ""},
		"push": {"pos": Vector2(s.x - 455 * u, s.y - 160 * u), "r": 40 * u * k, "label": ""},
		"ping": {"pos": Vector2(s.x - 230 * u, s.y - 505 * u), "r": 38 * u * k, "label": "btn_ping"},
		"sprint": {"pos": Vector2(s.x - 100 * u, s.y - 355 * u), "r": 50 * u * k, "label": "btn_run"},
		"tumble": {"pos": Vector2(s.x - 240 * u, s.y - 380 * u), "r": 42 * u * k, "label": "btn_tumble"},
		"crouch": {"pos": Vector2(105 * u, s.y - 400 * u), "r": 46 * u * k, "label": "btn_crouch"},
	}
	# invisible hit areas over the HUD inventory slots (bottom centre, drawn by the HUD)
	var sw := 104.0 * 3 + 24.0
	for i in 3:
		var cx := s.x / 2.0 - sw / 2.0 + 52.0 + i * 116.0
		buttons["slot%d" % i] = {"pos": Vector2(cx, s.y - 12 - 39), "r": 48.0, "label": "", "hidden": true}
	for b in buttons:
		buttons[b]["down"] = false
	_joy_home = Vector2(200 * u, s.y - 180 * u)
	# the player's own layout (Settings → Controls → Button layout): positions are stored as a
	# fraction of the screen so they fit any phone
	for bk in Settings.btn_layout:
		var o = Settings.btn_layout[bk]
		if not (o is Array) or o.size() < 3:
			continue
		var p := Vector2(clampf(float(o[0]), 0.02, 0.98) * s.x, clampf(float(o[1]), 0.04, 0.98) * s.y)
		if bk == "joy":
			_joy_home = p
		elif buttons.has(bk):
			buttons[bk]["pos"] = p
			buttons[bk]["r"] = float(buttons[bk]["r"]) * clampf(float(o[2]), 0.5, 2.0)
	if _joy_idx == -1:
		_joy_center = _joy_home
		_joy_pos = _joy_home
	queue_redraw()


func _visible_btn(k: String) -> bool:
	if edit_mode:
		return not buttons[k].get("hidden", false)
	if k in ["throw", "pull", "push"]:
		return grabbing
	return true


func _hit_button(p: Vector2) -> String:
	var best := ""
	var bd := 1e9
	for k in buttons:
		if not _visible_btn(k):
			continue
		var b: Dictionary = buttons[k]
		var d := p.distance_to(b["pos"])
		if d <= b["r"] * 1.18 and d < bd:
			bd = d
			best = k
	return best


func take(k: String) -> bool:
	if _pressed.get(k, false):
		_pressed[k] = false
		return true
	return false


func held(k: String) -> bool:
	return buttons.has(k) and buttons[k]["down"]


func consume_look() -> Vector2:
	var v := _look_acc
	_look_acc = Vector2.ZERO
	return v


func reset() -> void:
	_joy_idx = -1
	_look_idx = -1
	move_vec = Vector2.ZERO
	_btn_touch.clear()
	_pressed.clear()
	for k in buttons:
		buttons[k]["down"] = false


func _process(delta: float) -> void:
	var any := false
	for k in _press_anim.keys():
		_press_anim[k] = maxf(0.0, _press_anim[k] - delta * 4.0)
		any = true
		if _press_anim[k] <= 0.0:
			_press_anim.erase(k)
	if any:
		queue_redraw()


func _input(e: InputEvent) -> void:
	if edit_mode:
		_edit_input(e)
		return
	if not is_visible_in_tree() or (Settings.pad_active and not (e is InputEventScreenTouch)):
		return
	if e is InputEventScreenTouch:
		if e.pressed:
			var b := _hit_button(e.position)
			if b != "":
				_btn_touch[e.index] = b
				buttons[b]["down"] = true
				_pressed[b] = true
				_press_anim[b] = 1.0
				if Settings.vibration:
					Sfx.vibrate(12)
				if b == "sprint":
					sprint_on = not sprint_on
			elif e.position.x < size.x * 0.42 and e.position.y > size.y * 0.25 and _joy_idx == -1:
				_joy_idx = e.index
				_joy_center = e.position
				_joy_pos = e.position
				move_vec = Vector2.ZERO
			elif _look_idx == -1 and e.position.y > 70 * _u:
				_look_idx = e.index
				_look_last = e.position
		else:
			if _btn_touch.has(e.index):
				buttons[_btn_touch[e.index]]["down"] = false
				_btn_touch.erase(e.index)
			if e.index == _joy_idx:
				_joy_idx = -1
				move_vec = Vector2.ZERO
				_joy_center = _joy_home
				_joy_pos = _joy_home
			if e.index == _look_idx:
				_look_idx = -1
		queue_redraw()
	elif e is InputEventScreenDrag:
		if e.index == _joy_idx:
			_joy_pos = e.position
			var r := 105.0 * _u
			var d: Vector2 = _joy_pos - _joy_center
			if d.length() > r:
				_joy_center += d.normalized() * (d.length() - r)
				d = d.normalized() * r
			move_vec = d / r
			queue_redraw()
		elif e.index == _look_idx:
			_look_acc += e.position - _look_last
			_look_last = e.position


# ------------------------------------------------------------------ layout editor

## Editor: press a button (or the joystick) and drag it; mouse events work for touches too.
func _edit_input(e: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			if e.position.y < edit_top:
				return
			var k := _hit_button(e.position)
			if k == "" and e.position.distance_to(_joy_home) < 110.0 * _u:
				k = "joy"
			if k != "":
				selected = k
				_drag = k
				_drag_off = (_joy_home if k == "joy" else buttons[k]["pos"]) - e.position
				queue_redraw()
		elif _drag != "":
			_store(_drag)
			_drag = ""
	elif e is InputEventMouseMotion and _drag != "":
		var s := size
		var p: Vector2 = (e.position + _drag_off).clamp(Vector2(20, maxf(40.0, edit_top + 20.0)), s - Vector2(20, 20))
		if _drag == "joy":
			_joy_home = p
			_joy_center = p
			_joy_pos = p
		else:
			buttons[_drag]["pos"] = p
		queue_redraw()


func _scale_of(k: String) -> float:
	var o = Settings.btn_layout.get(k)
	return float(o[2]) if o is Array and o.size() >= 3 else 1.0


func _store(k: String) -> void:
	var s := size
	var p: Vector2 = _joy_home if k == "joy" else buttons[k]["pos"]
	Settings.btn_layout[k] = [p.x / s.x, p.y / s.y, _scale_of(k)]


## +/- on the selected button.
func resize_selected(f: float) -> void:
	if selected == "" or selected == "joy":
		return
	_store(selected)
	var o: Array = Settings.btn_layout[selected]
	o[2] = clampf(float(o[2]) * f, 0.5, 2.0)
	Settings.btn_layout[selected] = o
	_layout()


func reset_layout() -> void:
	Settings.btn_layout = {}
	selected = ""
	_layout()


func set_crouch(c: bool) -> void:
	if c != crouch_on:
		crouch_on = c
		queue_redraw()


func set_tumble(t: bool) -> void:
	if t != tumble_on:
		tumble_on = t
		queue_redraw()


func set_grabbing(g: bool) -> void:
	if g != grabbing:
		grabbing = g
		queue_redraw()


func _draw() -> void:
	if Settings.pad_active and not edit_mode:
		return    # a gamepad is being played: no on-screen buttons
	var A := Settings.btn_alpha if not edit_mode else maxf(Settings.btn_alpha, 0.85)
	if edit_mode and selected != "":
		var sp: Vector2 = _joy_home if selected == "joy" else buttons[selected]["pos"]
		var sr: float = 112.0 * _u if selected == "joy" else float(buttons[selected]["r"]) + 10.0 * _u
		draw_circle(sp, sr, Color(UI.ACCENT, 0.18))
		draw_arc(sp, sr, 0, TAU, 48, Color(UI.ACCENT2, 0.95), 4.0 * _u, true)
	var font := UI.font("Rubik-Medium")
	# joystick: soft base, ring with tick marks, glossy knob
	var r := 105.0 * _u
	var active := _joy_idx != -1
	draw_circle(_joy_center, r, Color(0, 0, 0, 0.18 * A + (0.1 if active else 0.0)))
	draw_arc(_joy_center, r, 0, TAU, 64, Color(1, 1, 1, 0.35 * A), 3.0 * _u, true)
	for i in 4:
		var a := i * PI / 2.0
		var d := Vector2(cos(a), sin(a))
		draw_line(_joy_center + d * (r - 14 * _u), _joy_center + d * (r - 4 * _u), Color(1, 1, 1, 0.3 * A), 3.0 * _u)
	var knob := _joy_center + move_vec * r
	draw_circle(knob, 44 * _u, Color(0, 0, 0, 0.25 * A))
	draw_circle(knob, 40 * _u, Color(1, 1, 1, 0.3 * A + (0.15 if active else 0.0)))
	draw_arc(knob, 40 * _u, 0, TAU, 40, Color(1, 1, 1, 0.6 * A), 2.0 * _u, true)
	for k in buttons:
		if not _visible_btn(k) or buttons[k].get("hidden", false):
			continue
		var b: Dictionary = buttons[k]
		var rr: float = b["r"]
		var pa: float = _press_anim.get(k, 0.0)
		var col := Color(0.04, 0.045, 0.06, 0.42 * A)
		var ring := Color(1, 1, 1, 0.55 * A)
		var ic := Color(1, 1, 1, 0.95 * maxf(A, 0.55))
		var on := false
		if k == "grab":
			ring = Color(UI.ACCENT, 0.95 * maxf(A, 0.6))
			on = grabbing
		elif k == "sprint":
			on = sprint_on
		elif k == "crouch":
			on = crouch_on
		elif k == "tumble":
			on = tumble_on
		if on:
			col = Color(UI.ACCENT, 0.5 * maxf(A, 0.6))
			ring = Color(UI.ACCENT2, maxf(A, 0.7))
		if b["down"]:
			col = Color(col.r + 0.15, col.g + 0.1, col.b + 0.05, col.a + 0.25)
			rr *= 0.94
		# shadow, body, ring, press ripple
		draw_circle(b["pos"] + Vector2(0, 3 * _u), rr, Color(0, 0, 0, 0.25 * A))
		draw_circle(b["pos"], rr, col)
		draw_arc(b["pos"], rr - 1.5 * _u, 0, TAU, 48, ring, 3.0 * _u, true)
		draw_arc(b["pos"], rr - 7 * _u, PI * 1.1, PI * 1.9, 16, Color(1, 1, 1, 0.12 * A), 3.0 * _u, true)
		if pa > 0.0:
			draw_arc(b["pos"], rr + (1.0 - pa) * 18 * _u, 0, TAU, 48, Color(UI.ACCENT2, pa * 0.8), 3.0 * _u, true)
		var icon: String = ICON.get(k, "")
		if k == "grab" and grabbing:
			icon = "drop"
		var has_label: bool = str(b["label"]) != ""
		var isz := rr * (0.78 if not has_label else 0.62)
		var ipos: Vector2 = b["pos"] + Vector2(0, -rr * 0.12 if has_label else 0.0)
		Icons.draw(self, icon, ipos, isz, ic)
		if has_label:
			var text := Settings.t(b["label"])
			if k == "grab" and grabbing:
				text = Settings.t("btn_drop")
			var fs := int(clampf(rr * 0.27, 11.0, 20.0))
			var w := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
			draw_string(font, b["pos"] + Vector2(-w / 2.0, rr * 0.62), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.85 * maxf(A, 0.55)))
