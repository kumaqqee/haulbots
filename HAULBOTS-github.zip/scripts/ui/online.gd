extends Control
## Internet play: create a room (you host, friends get a 5-letter code), join with a code or
## from the list of public rooms. Everyone connects to the same relay server (server/relay.js);
## its address is set once at the bottom of this screen.

const UI = preload("res://scripts/ui/ui.gd")
const RelayPeer = preload("res://scripts/autoload/relay_peer.gd")

var main: Node
var status: Label
var code_edit: LineEdit
var pub_check: CheckButton
var rooms_box: VBoxContainer
var rooms_note: Label
var server_lbl: Label
var server_box: VBoxContainer
var url_edit: LineEdit
var _busy := false
var _wake_req: HTTPRequest = null
var _wake_t := 0.0
var _wake_cb: Callable
var _wake_code := ""     # room code being joined: its region's server is the one to wake
var _lister = null
var _rooms_got = null
var _list_t := 0.0
var region_row: HBoxContainer
var _pings := {}          # region -> ms (-1 measuring, -2 unreachable)
var _ping_reqs := []


func _ready() -> void:
	UI.full(self)
	add_child(UI.backdrop())
	var vb := UI.panel_column(self, 900, 540)
	var head := HBoxContainer.new()
	vb.add_child(head)
	var t := UI.title(Settings.t("online_title"), 40)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(t)
	head.add_child(UI.button(Settings.t("back"), _back, 200, 52))
	status = UI.label("", 18, UI.ACCENT2, HORIZONTAL_ALIGNMENT_LEFT)
	status.visible = false
	vb.add_child(status)
	# server region (like the reference game): Asia / Europe / USA, with pings on request
	var c0 := _card(vb)
	var rgh := HBoxContainer.new()
	rgh.add_theme_constant_override("separation", 10)
	c0.add_child(rgh)
	var rgl := UI.label(Settings.t("online_region"), 26, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	rgl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rgh.add_child(rgl)
	rgh.add_child(UI.button(Settings.t("online_ping"), _ping_all, 200, 50))
	c0.add_child(UI.label(Settings.t("online_region_sub"), 16, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	region_row = HBoxContainer.new()
	region_row.add_theme_constant_override("separation", 10)
	c0.add_child(region_row)
	_build_regions()
	# create a room
	var c1 := _card(vb)
	var ch := HBoxContainer.new()
	ch.add_theme_constant_override("separation", 14)
	c1.add_child(ch)
	var cv := VBoxContainer.new()
	cv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cv.add_theme_constant_override("separation", 2)
	ch.add_child(cv)
	cv.add_child(UI.label(Settings.t("online_create"), 26, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT))
	cv.add_child(UI.label(Settings.t("online_create_sub"), 16, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	var cb := UI.button(Settings.t("online_create"), _create, 280, 60, true)
	cb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ch.add_child(cb)
	pub_check = CheckButton.new()
	pub_check.text = Settings.t("online_public")
	pub_check.button_pressed = Settings.room_public
	pub_check.focus_mode = Control.FOCUS_NONE
	pub_check.add_theme_font_size_override("font_size", 18)
	for k in ["font_color", "font_pressed_color", "font_hover_color", "font_hover_pressed_color", "font_focus_color"]:
		pub_check.add_theme_color_override(k, UI.TEXT)
	pub_check.toggled.connect(func(b):
		Settings.room_public = b
		Settings.save_cfg())
	c1.add_child(pub_check)
	# join with a code
	var c2 := _card(vb)
	c2.add_child(UI.label(Settings.t("online_join"), 26, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT))
	var jh := HBoxContainer.new()
	jh.add_theme_constant_override("separation", 10)
	c2.add_child(jh)
	code_edit = LineEdit.new()
	code_edit.placeholder_text = Settings.t("online_code_hint")
	code_edit.text = Settings.last_room
	code_edit.max_length = 5
	code_edit.custom_minimum_size = Vector2(300, 60)
	code_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	code_edit.add_theme_font_size_override("font_size", 30)
	code_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	code_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_DEFAULT
	code_edit.text_changed.connect(func(tx):
		var up := _clean_code(tx)
		if up != tx:
			var cpos := code_edit.caret_column
			code_edit.text = up
			code_edit.caret_column = mini(cpos, up.length()))
	code_edit.text_submitted.connect(func(_tx): _join_code())
	jh.add_child(code_edit)
	jh.add_child(UI.button(Settings.t("join_btn"), _join_code, 200, 60, true))
	# public rooms
	var c3 := _card(vb)
	var rh := HBoxContainer.new()
	c3.add_child(rh)
	var rl := UI.label(Settings.t("online_rooms"), 26, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	rl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rh.add_child(rl)
	rh.add_child(UI.tile_button("refresh", "", _refresh_rooms, 64))
	rooms_note = UI.label("", 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT)
	c3.add_child(rooms_note)
	rooms_box = VBoxContainer.new()
	rooms_box.add_theme_constant_override("separation", 6)
	c3.add_child(rooms_box)
	# server address
	var c4 := _card(vb)
	var sh := HBoxContainer.new()
	sh.add_theme_constant_override("separation", 10)
	c4.add_child(sh)
	server_lbl = UI.label("", 18, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT)
	server_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	server_lbl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	sh.add_child(server_lbl)
	sh.add_child(UI.button(Settings.t("online_server_edit"), func(): server_box.visible = not server_box.visible, 200, 50))
	server_box = VBoxContainer.new()
	server_box.add_theme_constant_override("separation", 8)
	c4.add_child(server_box)
	server_box.add_child(UI.label(Settings.t("online_server_hint"), 16, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	url_edit = LineEdit.new()
	url_edit.text = Settings.relay_url
	url_edit.placeholder_text = "https://haulbots-relay.onrender.com"
	url_edit.custom_minimum_size = Vector2(0, 56)
	url_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_URL
	server_box.add_child(url_edit)
	var sv := UI.button(Settings.t("online_server_save"), _save_server, 380, 54, true)
	sv.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	server_box.add_child(sv)
	server_box.visible = Net.relay_url() == ""
	_show_server()
	if Net.relay_url() != "":
		_bg_wake()
	else:
		rooms_note.text = Settings.t("err_relay_no_url")


func _build_regions() -> void:
	for ch in region_row.get_children():
		ch.queue_free()
	for r in Settings.RELAY_REGIONS:
		var id: String = r[0]
		var txt := Settings.t("region_" + id)
		if _pings.has(id):
			var ms: int = _pings[id]
			txt += "  " + ("…" if ms == -1 else ("—" if ms == -2 else Settings.t("ms") % ms))
		var b := UI.button(txt, func(): _pick_region(id), 0, 56, Settings.relay_region == id)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 22)
		region_row.add_child(b)


func _pick_region(id: String) -> void:
	if id == Settings.relay_region:
		return
	Settings.set_region(id)
	url_edit.text = Settings.relay_url
	_show_server()
	_build_regions()
	_bg_wake()


## Ping every region (this wakes sleeping servers, so only on request).
func _ping_all() -> void:
	for rq in _ping_reqs:
		if is_instance_valid(rq):
			rq.queue_free()
	_ping_reqs.clear()
	for r in Settings.RELAY_REGIONS:
		var id: String = r[0]
		_pings[id] = -1
		var rq := HTTPRequest.new()
		rq.timeout = 80.0
		add_child(rq)
		_ping_reqs.append(rq)
		var t0 := Time.get_ticks_msec()
		var url := RelayPeer.normalize_url(r[1]).replace("wss://", "https://").replace("ws://", "http://") + "/health"
		rq.request_completed.connect(func(result: int, code: int, _h, _b):
			var ms := Time.get_ticks_msec() - t0
			if result == HTTPRequest.RESULT_SUCCESS and code == 200:
				if ms > 2500:
					# it was asleep: measure again now that it is awake
					var t1 := Time.get_ticks_msec()
					rq.request_completed.connect(func(r2: int, c2: int, _h2, _b2):
						_pings[id] = (Time.get_ticks_msec() - t1) if r2 == HTTPRequest.RESULT_SUCCESS and c2 == 200 else -2
						_build_regions(), CONNECT_ONE_SHOT)
					rq.request(url)
					return
				_pings[id] = ms
			else:
				_pings[id] = -2
			_build_regions(), CONNECT_ONE_SHOT)
		if rq.request(url) != OK:
			_pings[id] = -2
	_build_regions()


func _card(parent: Control) -> VBoxContainer:
	var card := PanelContainer.new()
	card.theme_type_variation = "Card"
	parent.add_child(card)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	card.add_child(v)
	return v


static func _clean_code(tx: String) -> String:
	var out := ""
	for ch in tx.to_upper():
		if (ch >= "A" and ch <= "Z") or (ch >= "0" and ch <= "9"):
			out += ch
	return out.substr(0, 5)


func _show_server() -> void:
	var u := Net.relay_url()
	server_lbl.text = "%s: %s" % [Settings.t("online_server"), u.replace("wss://", "").replace("ws://", "") if u != "" else Settings.t("online_server_none")]


func _say(msg: String) -> void:
	status.text = msg
	status.visible = msg != ""


# ------------------------------------------------------------------ server wake-up

## A free Render server sleeps after 15 idle minutes; the first request wakes it (up to a minute).
func _wake(then: Callable) -> void:
	if Net.relay_url() == "":
		main.toast(Settings.t("err_relay_no_url"))
		server_box.visible = true
		return
	if _busy:
		return
	_busy = true
	_wake_cb = then
	_wake_t = 0.0
	_say(Settings.t("online_waking"))
	if _wake_req == null:
		_wake_req = HTTPRequest.new()
		_wake_req.timeout = 80.0
		_wake_req.request_completed.connect(_on_woke)
		add_child(_wake_req)
	_wake_req.cancel_request()
	if _wake_req.request(Net.relay_http_url(_wake_code) + "/health") != OK:
		_on_woke(HTTPRequest.RESULT_CANT_CONNECT, 0, PackedStringArray(), PackedByteArray())


func _on_woke(result: int, code: int, _h: PackedStringArray, _b: PackedByteArray) -> void:
	_busy = false
	if result == HTTPRequest.RESULT_SUCCESS and code == 200:
		_say(Settings.t("online_server_ok"))
		if _wake_cb.is_valid():
			_wake_cb.call()
	else:
		_say("")
		main.toast(Settings.t("err_relay_unreachable"))


func _process(delta: float) -> void:
	if _busy:
		_wake_t += delta
		if _wake_t > 3.0:
			_say(Settings.t("online_waking_long"))
	if _lister:
		var lp = _lister
		lp.poll()
		_list_t += delta
		if _rooms_got != null:
			var got: Array = _rooms_got
			_rooms_got = null
			_lister = null
			_show_rooms(got)
		elif _list_t > 25.0 or lp.get_connection_status() == MultiplayerPeer.CONNECTION_DISCONNECTED:
			lp.close()
			_lister = null
			rooms_note.text = Settings.t("err_relay_unreachable")


# ------------------------------------------------------------------ actions

func _create() -> void:
	_wake_code = ""
	_wake(func():
		if Net.host_online(pub_check.button_pressed):
			main.show_connecting(Settings.t("online_creating"), true)
		else:
			main.toast(main.err_text()))


func _join_code() -> void:
	var c := _clean_code(code_edit.text)
	if c.length() != 5:
		main.toast(Settings.t("err_no_room"))
		return
	Settings.last_room = c
	Settings.save_cfg()
	_wake_code = c
	_wake(func(): _join(c))


func _join(c: String) -> void:
	main.show_connecting(Settings.t("online_joining") % c, true)
	Net.join_online(c)


## Wake the (maybe sleeping) free server in the background as soon as the screen opens, then
## load the public rooms; the buttons stay usable meanwhile.
func _bg_wake() -> void:
	rooms_note.text = Settings.t("online_waking")
	var rq := HTTPRequest.new()
	rq.timeout = 80.0
	add_child(rq)
	rq.request_completed.connect(func(result: int, code: int, _h, _b):
		rq.queue_free()
		if result == HTTPRequest.RESULT_SUCCESS and code == 200:
			_refresh_rooms()
		else:
			rooms_note.text = Settings.t("err_relay_unreachable"))
	if rq.request(Net.relay_http_url() + "/health") != OK:
		rooms_note.text = Settings.t("err_relay_unreachable")


func _refresh_rooms() -> void:
	if Net.relay_url() == "":
		return
	for ch in rooms_box.get_children():
		ch.queue_free()
	rooms_note.text = Settings.t("online_rooms_loading")
	_rooms_got = null
	_lister = RelayPeer.new()
	_list_t = 0.0
	_lister.rooms_listed.connect(_on_rooms)
	if _lister.list_rooms(Net.relay_url(), Net.GAME_ID) != OK:
		_lister = null
		rooms_note.text = Settings.t("err_relay_unreachable")


func _on_rooms(rooms: Array) -> void:
	_rooms_got = rooms    # handled in _process (don't drop the lister while it is still running)


func _show_rooms(rooms: Array) -> void:
	for ch in rooms_box.get_children():
		ch.queue_free()
	rooms_note.text = Settings.t("online_no_rooms") if rooms.is_empty() else ""
	for r in rooms:
		if not (r is Dictionary):
			continue
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var nm := UI.label("%s  •  %s" % [str(r.get("n", "?")), Settings.t("players_short") % int(r.get("c", 1))], 20, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
		nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nm.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(nm)
		var code := str(r.get("code", ""))
		row.add_child(UI.button(Settings.t("join_btn"), func():
			_wake_code = ""
			_wake(func(): _join(code)), 160, 52, true))
		rooms_box.add_child(row)


func _save_server() -> void:
	Settings.relay_url = url_edit.text.strip_edges()
	if Settings.relay_url == "":
		Settings.set_region(Settings.guess_region())    # empty field = back to the built-in servers
		url_edit.text = Settings.relay_url
	else:
		var rg := Settings._region_of_url(RelayPeer.normalize_url(Settings.relay_url).replace("wss://", "https://"))
		Settings.set_region(rg if rg != "" else "custom")
	_build_regions()
	_show_server()
	if Net.relay_url() == "":
		return
	_wake(func():
		server_box.visible = false
		_refresh_rooms())


func _back() -> void:
	main.show_menu()
