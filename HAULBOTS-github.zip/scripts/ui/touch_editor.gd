extends Control
## Button layout editor: the on-screen controls over a mock game view. Drag any button (or the
## joystick) to move it, pick one and press −/+ to resize. Saved as screen fractions, so the layout
## fits every phone. Opened from Settings → Controls (menu and pause menu).

const Touch = preload("res://scripts/ui/touch.gd")
const UI = preload("res://scripts/ui/ui.gd")

var on_close: Callable
var touch: Control
var _sel_lbl: Label
var _backup := {}
const BAR_H := 92.0


func _ready() -> void:
	UI.full(self)
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	_backup = Settings.btn_layout.duplicate(true)
	draw.connect(_draw_mock)
	resized.connect(queue_redraw)
	touch = Touch.new()
	touch.edit_mode = true
	touch.edit_top = BAR_H + 8.0
	add_child(touch)
	# top bar
	var bar := PanelContainer.new()
	bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	bar.custom_minimum_size.y = BAR_H
	bar.add_theme_stylebox_override("panel", UI.sb(Color(0.03, 0.03, 0.04, 0.92), Color(1, 1, 1, 0.08), 1, 0, Vector4(16, 8, 16, 8)))
	add_child(bar)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	bar.add_child(hb)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 0)
	hb.add_child(col)
	var t := UI.label(Settings.t("layout_title"), 26, UI.ACCENT, HORIZONTAL_ALIGNMENT_LEFT)
	t.autowrap_mode = TextServer.AUTOWRAP_OFF
	col.add_child(t)
	_sel_lbl = UI.label(Settings.t("layout_hint"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT)
	_sel_lbl.autowrap_mode = TextServer.AUTOWRAP_OFF
	_sel_lbl.clip_text = true
	col.add_child(_sel_lbl)
	hb.add_child(_small("−", func(): _resize(1.0 / 1.12)))
	hb.add_child(_small("+", func(): _resize(1.12)))
	hb.add_child(UI.button(Settings.t("layout_reset"), _reset, 170, 60))
	hb.add_child(UI.button(Settings.t("layout_cancel"), _cancel, 150, 60))
	hb.add_child(UI.button(Settings.t("layout_done"), _done, 170, 60, true))


func _small(txt: String, cb: Callable) -> Button:
	var b := UI.button(txt, cb, 64, 60)
	b.add_theme_font_size_override("font_size", 34)
	return b


func _process(_d: float) -> void:
	if touch == null:
		return
	var k: String = touch.selected
	if k == "":
		_sel_lbl.text = Settings.t("layout_hint")
	elif k == "joy":
		_sel_lbl.text = Settings.t("layout_sel_joy")
	else:
		var nm := Settings.t(touch.buttons[k]["label"]) if str(touch.buttons[k]["label"]) != "" else Settings.t("layout_btn_" + k)
		_sel_lbl.text = Settings.t("layout_sel") % [nm, int(round(touch._scale_of(k) * 100.0))]


func _resize(f: float) -> void:
	if touch.selected == "" or touch.selected == "joy":
		_sel_lbl.text = Settings.t("layout_pick")
		return
	Sfx.play("ui", null, -8.0, 1.3 if f > 1.0 else 0.9)
	touch.resize_selected(f)


func _reset() -> void:
	touch.reset_layout()


func _cancel() -> void:
	Settings.btn_layout = _backup
	_finish()


func _done() -> void:
	Settings.save_cfg()
	_finish()


func _finish() -> void:
	Settings.changed.emit()
	if on_close.is_valid():
		on_close.call()
	queue_free()


## A dim stand-in for the game view plus the HUD pieces the buttons must not cover.
func _draw_mock() -> void:
	var s := size
	draw_rect(Rect2(Vector2.ZERO, s), Color(0.07, 0.065, 0.075))
	var g := Color(1, 1, 1, 0.035)
	var step := 80.0
	var x := 0.0
	while x < s.x:
		draw_line(Vector2(x, 0), Vector2(x, s.y), g, 1.0)
		x += step
	var y := 0.0
	while y < s.y:
		draw_line(Vector2(0, y), Vector2(s.x, y), g, 1.0)
		y += step
	# floor horizon + crosshair
	draw_rect(Rect2(0, s.y * 0.58, s.x, s.y * 0.42), Color(0.1, 0.08, 0.06, 0.6))
	var c := s / 2.0
	draw_circle(c, 4.0, Color(1, 1, 1, 0.6))
	# the HUD inventory slots (bottom centre) and the status card (top left)
	var sw := 104.0 * 3 + 24.0
	for i in 3:
		var r := Rect2(s.x / 2.0 - sw / 2.0 + i * 116.0, s.y - 12 - 78, 104, 78)
		draw_rect(r, Color(1, 1, 1, 0.06))
		draw_rect(r, Color(1, 1, 1, 0.16), false, 2.0)
	draw_rect(Rect2(16, BAR_H + 14, 300, 70), Color(1, 1, 1, 0.05))
	var font := UI.font("Rubik-Medium")
	draw_string(font, Vector2(0, s.y * 0.42), Settings.t("layout_preview"), HORIZONTAL_ALIGNMENT_CENTER, s.x, 22, Color(1, 1, 1, 0.18))
