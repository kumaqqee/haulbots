extends Control
## Collection: achievements and the cosmetics they unlock. Pick a hat, an accessory and a finish —
## the robot in the garage behind the panel changes live. Friends see them in co-op.

const UI = preload("res://scripts/ui/ui.gd")
const Icons = preload("res://scripts/ui/icons.gd")
const TouchScroll = preload("res://scripts/ui/touch_scroll.gd")
const Cos = preload("res://scripts/game/cosmetics.gd")

var main: Node
var _content: VBoxContainer
var _scroll: ScrollContainer
var _tabs := {}
var _tab := "wardrobe"
var _hint: Label
var tiles := {}          # "slot:item" -> Button (tests)


func _ready() -> void:
	UI.full(self)
	_robot()
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.35)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UI.full(shade)
	add_child(shade)
	var m := MarginContainer.new()
	UI.full(m)
	m.add_theme_constant_override("margin_left", 36)
	m.add_theme_constant_override("margin_top", 20)
	m.add_theme_constant_override("margin_bottom", 20)
	m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(m)
	var pc := PanelContainer.new()
	pc.custom_minimum_size.x = 740
	pc.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	m.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	pc.add_child(vb)
	var top := HBoxContainer.new()
	vb.add_child(top)
	var t := UI.title(Settings.t("coll_title"), 40)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(t)
	var cnt := UI.label(Settings.t("coll_count") % [Ach.count_unlocked(), Ach.LIST.size()], 20, UI.ACCENT2, HORIZONTAL_ALIGNMENT_RIGHT)
	cnt.autowrap_mode = TextServer.AUTOWRAP_OFF
	cnt.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	top.add_child(cnt)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	vb.add_child(tabs)
	for k in ["wardrobe", "achievements"]:
		var b := Button.new()
		b.text = Settings.t("coll_" + k)
		b.theme_type_variation = "Tab"
		b.toggle_mode = true
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(240, 50)
		b.add_theme_font_size_override("font_size", 21)
		b.pressed.connect(_show.bind(k))
		tabs.add_child(b)
		_tabs[k] = b
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(_scroll)
	TouchScroll.attach(_scroll)
	_content = VBoxContainer.new()
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content.add_theme_constant_override("separation", 10)
	_scroll.add_child(_content)
	_hint = UI.label("", 17, UI.ACCENT2, HORIZONTAL_ALIGNMENT_LEFT)
	_hint.custom_minimum_size.y = 46
	vb.add_child(_hint)
	var back := UI.button(Settings.t("back"), _back, 300, 58)
	back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	vb.add_child(back)
	_show("wardrobe")


func _robot() -> void:
	if main and main.menu_bg:
		main.menu_bg.set_players([{"color": Net.my_color_index(), "name": Settings.player_name, "cos": Settings.cosmetics()}])


func _show(k: String) -> void:
	_tab = k
	for n in _tabs:
		_tabs[n].button_pressed = n == k
	for c in _content.get_children():
		_content.remove_child(c)
		c.queue_free()
	tiles.clear()
	_hint.text = Settings.t("coll_hint") if k == "wardrobe" else ""
	if _scroll.has_node("TouchScroll"):
		_scroll.get_node("TouchScroll").stop()
	_scroll.scroll_vertical = 0
	if k == "wardrobe":
		_slot_row("hat", Cos.HATS, Settings.cos_hat)
		_slot_row("acc", Cos.ACCS, Settings.cos_acc)
		_slot_row("fin", Cos.FINS, Settings.cos_finish)
	else:
		for a in Ach.LIST:
			_ach_row(a)


func _slot_row(slot: String, items: Array, cur: String) -> void:
	_content.add_child(UI.label(Settings.t("coll_slot_" + slot), 22, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT))
	var grid := GridContainer.new()
	grid.columns = 5
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	_content.add_child(grid)
	for it in [""] + items:
		grid.add_child(_tile(slot, it, it == cur))


func _tile(slot: String, item: String, on: bool) -> Button:
	var have := Ach.owned(slot, item)
	var b := Button.new()
	b.custom_minimum_size = Vector2(132, 84)
	b.focus_mode = Control.FOCUS_NONE
	b.clip_text = true
	var bg := Color(0.06, 0.06, 0.075, 0.85) if have else Color(0.04, 0.04, 0.045, 0.6)
	var border := UI.ACCENT if on else Color(1, 1, 1, 0.1 if have else 0.05)
	b.add_theme_stylebox_override("normal", UI.sb(bg, border, 3 if on else 1, 12, Vector4.ZERO))
	b.add_theme_stylebox_override("hover", UI.sb(bg.lightened(0.08), UI.ACCENT2 if have else border, 2, 12, Vector4.ZERO))
	b.add_theme_stylebox_override("pressed", UI.sb(Color(UI.ACCENT, 0.35), UI.ACCENT2, 2, 12, Vector4.ZERO))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	var name_txt := Settings.t("cos_none") if item == "" else Settings.t("cos_" + item)
	b.draw.connect(func():
		var f := UI.font("Rubik-Bold")
		var col := Color(1, 1, 1, 0.95) if have else Color(1, 1, 1, 0.35)
		if have:
			_draw_swatch(b, slot, item, Vector2(b.size.x / 2.0, 30))
		else:
			_draw_lock(b, Vector2(b.size.x / 2.0, 30), Color(1, 1, 1, 0.4))
		if item in Cos.SUPPORTER_ITEMS:
			Icons.draw(b, "star", Vector2(16, 16), 18.0, Color(1.0, 0.8, 0.3))
		b.draw_string(f, Vector2(4, 70), name_txt, HORIZONTAL_ALIGNMENT_CENTER, b.size.x - 8, 15, col)
		if on:
			b.draw_circle(Vector2(b.size.x - 14, 14), 7, UI.ACCENT))
	b.pressed.connect(func(): _pick(slot, item))
	tiles[slot + ":" + item] = b
	return b


## A tiny coloured mark per item so the grid reads at a glance.
func _draw_swatch(b: Control, slot: String, item: String, c: Vector2) -> void:
	if item == "":
		b.draw_arc(c, 13, 0, TAU, 24, Color(1, 1, 1, 0.35), 2.0)
		b.draw_line(c + Vector2(-9, 9), c + Vector2(9, -9), Color(1, 1, 1, 0.35), 2.0)
		return
	var col: Color = {"cap": Color(0.3, 0.5, 0.9), "tophat": Color(0.15, 0.15, 0.17), "beanie": Color(0.3, 0.8, 0.8),
		"party": Color(0.2, 0.55, 0.95), "chef": Color(0.95, 0.95, 0.93), "viking": Color(0.6, 0.6, 0.65),
		"propeller": Color(0.95, 0.25, 0.2), "halo": Color(1.0, 0.86, 0.35), "bowtie": Color(0.8, 0.1, 0.12),
		"shades": Color(0.1, 0.1, 0.12), "scarf": Color(0.85, 0.15, 0.12), "antenna": Color(0.5, 0.9, 1.0),
		"monocle": Color(1.0, 0.78, 0.3), "heart": Color(1.0, 0.3, 0.45), "chrome": Color(0.85, 0.87, 0.92),
		"gold": Color(1.0, 0.76, 0.3), "rust": Color(0.6, 0.3, 0.12), "neon": Color(0.3, 0.9, 1.0),
		"cowboy": Color(0.55, 0.34, 0.16), "astro": Color(0.75, 0.9, 1.0), "headphones": Color(0.9, 0.3, 0.9),
		"carbon": Color(0.16, 0.17, 0.19), "lava": Color(1.0, 0.42, 0.08)}.get(item, UI.ACCENT)
	if slot == "fin":
		b.draw_circle(c, 15, col)
		b.draw_arc(c, 15, 0, TAU, 32, Color(1, 1, 1, 0.5), 2.0)
		b.draw_circle(c + Vector2(-5, -5), 4, Color(1, 1, 1, 0.55))
	elif slot == "hat":
		b.draw_rect(Rect2(c + Vector2(-16, 6), Vector2(32, 5)), col)
		b.draw_colored_polygon(PackedVector2Array([c + Vector2(-10, 6), c + Vector2(10, 6), c + Vector2(8, -12), c + Vector2(-8, -12)]), col)
	else:
		Icons.draw(b, "star" if item != "heart" else "heart", c, 30.0, col)


func _draw_lock(b: Control, c: Vector2, col: Color) -> void:
	b.draw_arc(c + Vector2(0, -4), 8, PI, TAU, 12, col, 3.0)
	b.draw_rect(Rect2(c + Vector2(-11, -4), Vector2(22, 17)), col)


func _pick(slot: String, item: String) -> void:
	if not Ach.owned(slot, item):
		var a := Ach.source_of(slot, item)
		if not a.is_empty():
			_hint.text = Settings.t("coll_locked") % [Settings.t("ach_" + a[0]), Settings.t("ach_" + a[0] + "_d")]
		elif item in Cos.SUPPORTER_ITEMS:
			_hint.text = Settings.t("coll_supporter")
			if main and main.has_method("show_store"):
				main.show_store()
		Sfx.play("ui", null, -6.0, 0.7)
		return
	Sfx.play("ui")
	match slot:
		"hat":
			Settings.cos_hat = item
		"acc":
			Settings.cos_acc = item
		"fin":
			Settings.cos_finish = item
	Settings.save_cfg()
	_robot()
	_show("wardrobe")


func _ach_row(a: Array) -> void:
	var have := Ach.is_unlocked(a[0])
	var card := PanelContainer.new()
	card.theme_type_variation = "Card"
	if not have:
		card.modulate = Color(1, 1, 1, 0.8)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	card.add_child(hb)
	var ic := Control.new()
	ic.custom_minimum_size = Vector2(50, 50)
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ic.draw.connect(func():
		ic.draw_circle(Vector2(25, 25), 24, Color(1.0, 0.75, 0.25, 0.22) if have else Color(1, 1, 1, 0.06))
		if have:
			Icons.draw(ic, "trophy", Vector2(25, 25), 34.0, Color(1.0, 0.82, 0.35))
		else:
			_draw_lock(ic, Vector2(25, 25), Color(1, 1, 1, 0.35)))
	hb.add_child(ic)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(vb)
	var tl := UI.label(Settings.t("ach_" + a[0]), 22, UI.ACCENT2 if have else UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	tl.autowrap_mode = TextServer.AUTOWRAP_OFF
	vb.add_child(tl)
	vb.add_child(UI.label(Settings.t("ach_" + a[0] + "_d"), 16, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	var goal := int(a[2])
	var cur := mini(Ach.progress(a[1]), goal)
	if goal > 1 and not have:
		var pb := ProgressBar.new()
		pb.max_value = goal
		pb.value = cur
		pb.show_percentage = false
		pb.custom_minimum_size = Vector2(0, 10)
		pb.add_theme_stylebox_override("background", UI.sb(Color(1, 1, 1, 0.08), Color(0, 0, 0, 0), 0, 5, Vector4.ZERO))
		pb.add_theme_stylebox_override("fill", UI.sb(UI.ACCENT, Color(0, 0, 0, 0), 0, 5, Vector4.ZERO))
		vb.add_child(pb)
	var side := VBoxContainer.new()
	side.add_theme_constant_override("separation", 0)
	side.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(side)
	var st := UI.label(Settings.t("ach_done") if have else _fmt_prog(a[1], cur, goal), 17, UI.GOOD if have else UI.DIM, HORIZONTAL_ALIGNMENT_RIGHT)
	st.autowrap_mode = TextServer.AUTOWRAP_OFF
	side.add_child(st)
	var rw := UI.label(Settings.t("cos_" + a[3][1]), 16, UI.ACCENT if have else Color(1, 1, 1, 0.45), HORIZONTAL_ALIGNMENT_RIGHT)
	rw.autowrap_mode = TextServer.AUTOWRAP_OFF
	side.add_child(rw)
	_content.add_child(card)


func _fmt_prog(kind: String, cur: int, goal: int) -> String:
	if kind == "earn":
		return "$%s / $%s" % [Settings.money_k(cur), Settings.money_k(goal)]
	if kind == "glide":
		return "%d / %d %s" % [cur, goal, Settings.t("sec_short")]
	return "%d / %d" % [cur, goal]


func _back() -> void:
	main.show_menu()
