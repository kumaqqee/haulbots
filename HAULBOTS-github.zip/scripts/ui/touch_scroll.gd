extends Node
## Finger scrolling for a ScrollContainer, like a phone list: drag anywhere — also when the finger
## lands on a button, a switch, a slider, a dropdown or a card (Godot's own drag only works on
## empty space between them, so the settings list barely scrolled) — and flick to keep it rolling.
## A vertical drag cancels the button/slider it started on; a horizontal one is left to the slider.

const THRESH := 12.0      # px the finger moves before it counts as a scroll
const FRICTION := 0.04    # fraction of the flick speed left after one second

static var _owner: Node = null    # one gesture at a time (the topmost list takes it)

var sc: ScrollContainer
var _armed := false
var _scrolling := false
var _horizontal := false
var _synth := false
var _start := Vector2.ZERO
var _last := Vector2.ZERO
var _start_scroll := 0.0
var _vel := 0.0
var _last_t := 0
var _last_dt := 0.016
var _snap := {}


static func attach(s: ScrollContainer) -> void:
	var n: Node = load("res://scripts/ui/touch_scroll.gd").new()
	n.sc = s
	n.name = "TouchScroll"
	# Godot's own drag scroll fights with ours (and with the buttons): leave it only the wheel
	s.scroll_deadzone = 1000000
	s.add_child(n)


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS


func _exit_tree() -> void:
	if _owner == self:
		_owner = null


func _input(ev: InputEvent) -> void:
	if _synth or sc == null or not sc.is_visible_in_tree():
		return
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
		if ev.pressed:
			_vel = 0.0
			if _owner == null and _hits(ev.position):
				_owner = self
				_armed = true
				_scrolling = false
				_horizontal = false
				_start = ev.position
				_last = ev.position
				_start_scroll = sc.scroll_vertical
				_last_t = Time.get_ticks_usec()
				_snapshot()
		elif _owner == self:
			_owner = null
			_armed = false
			if _scrolling:
				_scrolling = false
				if float(Time.get_ticks_usec() - _last_t) / 1000000.0 > maxf(0.09, _last_dt * 1.6):
					_vel = 0.0    # finger stopped before letting go: no flick
				get_viewport().set_input_as_handled()
	elif ev is InputEventMouseMotion and _owner == self and _armed:
		var pos: Vector2 = ev.position
		var d := pos - _start
		if not _scrolling and not _horizontal:
			if absf(d.x) > THRESH and absf(d.x) > absf(d.y):
				_horizontal = true    # dragging a slider sideways: not a scroll
			elif absf(d.y) > THRESH and absf(d.y) >= absf(d.x):
				_begin(pos)
		if _scrolling:
			var now := Time.get_ticks_usec()
			var dt := maxf(float(now - _last_t) / 1000000.0, 0.001)
			_last_dt = dt
			_vel = lerpf(_vel, -(pos.y - _last.y) / dt, 0.4)
			_last = pos
			_last_t = now
			sc.scroll_vertical = int(round(_start_scroll - (pos.y - _start.y)))
			get_viewport().set_input_as_handled()


func _process(delta: float) -> void:
	if _scrolling or absf(_vel) < 15.0 or sc == null:
		return
	var before := sc.scroll_vertical
	sc.scroll_vertical = int(round(sc.scroll_vertical + _vel * delta))
	_vel *= pow(FRICTION, delta)
	if sc.scroll_vertical == before:
		_vel = 0.0    # hit the top or the bottom


## Stop a flick (e.g. when the page under it changes).
func stop() -> void:
	_vel = 0.0


func _hits(p: Vector2) -> bool:
	if not sc.get_global_rect().has_point(p):
		return false
	var bar := sc.get_v_scroll_bar()
	if bar and bar.visible and bar.get_global_rect().has_point(p):
		return false    # the scrollbar drags the normal way
	return true


func _begin(pos: Vector2) -> void:
	_scrolling = true
	_start = pos
	_last = pos
	_start_scroll = sc.scroll_vertical
	_last_t = Time.get_ticks_usec()
	# cancel whatever the finger went down on: slide it far off the control, let go there
	# (a button then doesn't fire, a switch doesn't flip, a slider stops grabbing)
	_synth = true
	var far := Vector2(pos.x, -10000.0)
	var mm := InputEventMouseMotion.new()
	mm.position = far
	mm.global_position = far
	mm.button_mask = MOUSE_BUTTON_MASK_LEFT
	get_viewport().push_input(mm, true)
	var mb := InputEventMouseButton.new()
	mb.position = far
	mb.global_position = far
	mb.button_index = MOUSE_BUTTON_LEFT
	mb.pressed = false
	get_viewport().push_input(mb, true)
	_synth = false
	# a press on a slider track jumps its value: put it back
	for s in _snap:
		if is_instance_valid(s) and s.value != _snap[s]:
			s.value = _snap[s]


func _snapshot() -> void:
	_snap.clear()
	for s in sc.find_children("*", "Slider", true, false):
		_snap[s] = s.value
