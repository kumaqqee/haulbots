extends Control
## "Support the game": supporter pack, no-ads, tips and restore — Google Play purchases.
## The robot in the garage behind the panel wears the supporter look as a preview.

const UI = preload("res://scripts/ui/ui.gd")
const Icons = preload("res://scripts/ui/icons.gd")
const TouchScroll = preload("res://scripts/ui/touch_scroll.gd")
const Cfg = preload("res://scripts/monetization_config.gd")

var main: Node
var _list: VBoxContainer
var _status: Label
var buy_buttons := {}      # pid -> Button (tests)


func _ready() -> void:
	UI.full(self)
	if main and main.menu_bg:
		main.menu_bg.set_players([{"color": Net.my_color_index(), "name": ("★ " if Store.badge() else "") + Settings.player_name,
			"cos": {"hat": "cowboy", "acc": "headphones", "fin": "lava"}}])
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.35)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UI.full(shade)
	add_child(shade)
	var m := MarginContainer.new()
	UI.full(m)
	m.add_theme_constant_override("margin_left", 36)
	m.add_theme_constant_override("margin_top", 20)
	m.add_theme_constant_override("margin_bottom", 20)
	m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(m)
	var pc := PanelContainer.new()
	pc.custom_minimum_size.x = 760
	pc.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	m.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	pc.add_child(vb)
	var t := UI.title(Settings.t("sup_title"), 40)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	vb.add_child(t)
	vb.add_child(UI.label(Settings.t("sup_sub"), 18, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	TouchScroll.attach(sc)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 12)
	sc.add_child(_list)
	_status = UI.label("", 17, UI.ACCENT2, HORIZONTAL_ALIGNMENT_LEFT)
	_status.custom_minimum_size.y = 26
	vb.add_child(_status)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	vb.add_child(row)
	row.add_child(UI.button(Settings.t("back"), func(): main.show_menu(), 220, 58))
	row.add_child(UI.button(Settings.t("sup_restore"), func(): Store.restore(), 300, 58))
	if Store.privacy_options_required():
		row.add_child(UI.button(Settings.t("sup_privacy"), func(): Store.show_privacy_options(), 260, 58))
	Store.changed.connect(_build)
	Store.note.connect(_on_note)
	_build()


func _exit_tree() -> void:
	if Store.changed.is_connected(_build):
		Store.changed.disconnect(_build)
	if Store.note.is_connected(_on_note):
		Store.note.disconnect(_on_note)


func _on_note(text: String) -> void:
	_status.text = text


func _build() -> void:
	for c in _list.get_children():
		_list.remove_child(c)
		c.queue_free()
	buy_buttons.clear()
	if not Store.purchases_available():
		var warn := UI.label(Settings.t("iap_unavailable"), 18, UI.ACCENT2, HORIZONTAL_ALIGNMENT_LEFT)
		_list.add_child(warn)
	_list.add_child(_card(Cfg.SUPPORTER, "star", Settings.t("sup_pack"), Settings.t("sup_pack_d"), UI.ACCENT))
	var noads_owned_by_pack := Store.supporter() and not Store.has(Cfg.REMOVE_ADS)
	_list.add_child(_card(Cfg.REMOVE_ADS, "play", Settings.t("sup_noads"),
		Settings.t("sup_noads_in_pack") if noads_owned_by_pack else Settings.t("sup_noads_d"), UI.GOOD, noads_owned_by_pack))
	# tips
	var card := PanelContainer.new()
	card.theme_type_variation = "Card"
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	card.add_child(v)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	v.add_child(hb)
	hb.add_child(_icon("heart", Color(1.0, 0.4, 0.5)))
	var tv := VBoxContainer.new()
	tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(tv)
	var tl := UI.label(Settings.t("sup_tips"), 24, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	tl.autowrap_mode = TextServer.AUTOWRAP_OFF
	tv.add_child(tl)
	tv.add_child(UI.label(Settings.t("sup_tips_d"), 16, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	var tips_row := HBoxContainer.new()
	tips_row.add_theme_constant_override("separation", 8)
	v.add_child(tips_row)
	for pid in Cfg.TIPS:
		var b := UI.button(Store.price(pid), func(): _buy(pid), 150, 56)
		b.add_theme_font_size_override("font_size", 22)
		b.disabled = not Store.purchases_available()
		tips_row.add_child(b)
		buy_buttons[pid] = b
	if Store.tips() > 0:
		v.add_child(UI.label(Settings.t("sup_tips_thanks") % Store.tips(), 17, Color(1.0, 0.75, 0.8), HORIZONTAL_ALIGNMENT_LEFT))
	_list.add_child(card)
	_list.add_child(UI.label(Settings.t("sup_note"), 15, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))


func _card(pid: String, icon: String, title: String, desc: String, col: Color, included := false) -> Control:
	var owned := Store.has(pid) or included
	var card := PanelContainer.new()
	card.theme_type_variation = "Card"
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	card.add_child(hb)
	hb.add_child(_icon(icon, col))
	var tv := VBoxContainer.new()
	tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tv.add_theme_constant_override("separation", 2)
	hb.add_child(tv)
	var tl := UI.label(title, 24, col if owned else UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	tl.autowrap_mode = TextServer.AUTOWRAP_OFF
	tv.add_child(tl)
	tv.add_child(UI.label(desc, 16, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	var b := UI.button(Settings.t("sup_owned") if owned else Store.price(pid), func(): _buy(pid), 170, 60, not owned)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	b.disabled = owned or not Store.purchases_available()
	hb.add_child(b)
	buy_buttons[pid] = b
	return card


func _icon(name: String, col: Color) -> Control:
	var ic := Control.new()
	ic.custom_minimum_size = Vector2(54, 54)
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ic.draw.connect(func():
		ic.draw_circle(Vector2(27, 27), 26, Color(col, 0.18))
		Icons.draw(ic, name, Vector2(27, 27), 32.0, col))
	return ic


func _buy(pid: String) -> void:
	_status.text = ""
	Store.buy(pid)
