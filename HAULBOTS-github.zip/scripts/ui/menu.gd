extends Control
## Main menu: logo, big action cards and small tiles on the left; profile (name + paint) and
## "what's new" on the right; the 3D garage with your robot behind everything.

const UI = preload("res://scripts/ui/ui.gd")

var main: Node
var _swatches := []
var _cards := []
var _update_slot: VBoxContainer


func _ready() -> void:
	UI.full(self)
	if main and main.menu_bg:
		main.menu_bg.set_players([{"color": Net.my_color_index(), "name": Settings.player_name, "cos": Settings.cosmetics()}])
	# left-side dark gradient so the text reads over the 3D scene
	var shade := TextureRect.new()
	var gt := GradientTexture2D.new()
	var g := Gradient.new()
	g.set_color(0, Color(0, 0, 0, 0.86))
	g.set_color(1, Color(0, 0, 0, 0.0))
	gt.gradient = g
	gt.fill_from = Vector2(0.0, 0.5)
	gt.fill_to = Vector2(0.6, 0.5)
	gt.width = 256
	gt.height = 8
	shade.texture = gt
	shade.stretch_mode = TextureRect.STRETCH_SCALE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UI.full(shade)
	add_child(shade)
	var margin := MarginContainer.new()
	UI.full(margin)
	margin.add_theme_constant_override("margin_left", 56)
	margin.add_theme_constant_override("margin_top", 30)
	margin.add_theme_constant_override("margin_bottom", 24)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(margin)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(vb)
	var logo := TextureRect.new()
	logo.texture = preload("res://assets/ui/title.png")
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
	logo.custom_minimum_size = Vector2(500, 86)
	logo.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	logo.pivot_offset = Vector2(250, 43)
	vb.add_child(logo)
	var tw := logo.create_tween().set_loops()
	tw.tween_property(logo, "modulate", Color(1.12, 1.06, 1.0), 2.2).set_trans(Tween.TRANS_SINE)
	tw.tween_property(logo, "modulate", Color(1, 1, 1), 2.2).set_trans(Tween.TRANS_SINE)
	var tag := UI.label(Settings.t("tagline"), 22, Color(0.9, 0.85, 0.78), HORIZONTAL_ALIGNMENT_LEFT)
	tag.autowrap_mode = TextServer.AUTOWRAP_OFF
	vb.add_child(tag)
	_update_slot = VBoxContainer.new()
	vb.add_child(_update_slot)
	var sp := Control.new()
	sp.custom_minimum_size.y = 6
	vb.add_child(sp)
	var rs := Net.recent_session()
	if not rs.is_empty() and not Net.online:
		var sub := Settings.t("menu_rejoin_sub_room") % str(rs.get("code", "")) if str(rs.get("mode", "")) == "relay" else Settings.t("menu_rejoin_sub_lan")
		_card(vb, UI.menu_card("join", Settings.t("menu_rejoin").to_upper(), sub, func(): main.start_reconnect(), true))
	var has_save := Net.has_save()
	if has_save and not rs.is_empty() and not Net.online:
		vb.add_theme_constant_override("separation", 5)    # five cards: keep the tiles on screen
	if has_save:
		_card(vb, UI.menu_card("play", Settings.t("menu_continue").to_upper(), Settings.t("menu_continue_sub") % Net.save_level(), func(): Net.start_solo(true), true))
	_card(vb, UI.menu_card("play" if not has_save else "star", Settings.t("menu_new").to_upper(), Settings.t("menu_new_sub"), func(): Net.start_solo(false), not has_save))
	_card(vb, UI.menu_card("globe", Settings.t("menu_online").to_upper(), Settings.t("menu_online_sub"), func(): main.show_online()))
	_card(vb, UI.menu_card("wifi", Settings.t("menu_lan").to_upper(), Settings.t("menu_lan_sub"), func(): main.show_join()))
	# settings / how to play / quit sit at the bottom left, away from the big cards
	var push := Control.new()
	push.size_flags_vertical = Control.SIZE_EXPAND_FILL
	push.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(push)
	var tiles := HBoxContainer.new()
	tiles.add_theme_constant_override("separation", 10)
	vb.add_child(tiles)
	tiles.add_child(UI.tile_button("gear", Settings.t("settings"), func(): main.show_settings(), 132))
	tiles.add_child(UI.tile_button("help", Settings.t("how_to_play"), func(): main.show_help(), 132))
	tiles.add_child(UI.tile_button("trophy", Settings.t("collection") + " %d/%d" % [Ach.count_unlocked(), Ach.LIST.size()], func(): main.show_collection(), 150))
	tiles.add_child(UI.tile_button("heart", Settings.t("support"), func(): main.show_store(), 132))
	tiles.add_child(UI.tile_button("power", Settings.t("quit"), func(): get_tree().quit(), 110))
	_cards.append(tiles)
	# staggered slide-in
	for i in _cards.size():
		var c: Control = _cards[i]
		c.modulate.a = 0.0
		var t2 := c.create_tween()
		t2.tween_interval(0.06 * i)
		t2.tween_property(c, "modulate:a", 1.0, 0.25)
	_build_profile()
	_build_news()
	if not Net.update_info.is_empty():
		_show_update(Net.update_info)
	Net.update_available.connect(_show_update)
	Net.check_update()
	var ver := UI.label("v" + Settings.VERSION + ("  •  HD" if HD.active() else ""), 16, Color(0.55, 0.55, 0.55), HORIZONTAL_ALIGNMENT_RIGHT)
	ver.autowrap_mode = TextServer.AUTOWRAP_OFF
	ver.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	ver.position += Vector2(-90, -24)
	add_child(ver)


## "Version X is out — download": a slim bar under the tagline.
func _show_update(info: Dictionary) -> void:
	if _update_slot == null or _update_slot.get_child_count() > 0:
		return
	var bar := PanelContainer.new()
	bar.add_theme_stylebox_override("panel", UI.sb(Color(0.1, 0.3, 0.12, 0.85), Color(UI.GOOD, 0.8), 1, 12, Vector4(14, 6, 8, 6)))
	bar.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	bar.custom_minimum_size.x = 520
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	bar.add_child(hb)
	var tv := VBoxContainer.new()
	tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tv.add_theme_constant_override("separation", 0)
	hb.add_child(tv)
	var t := UI.label(Settings.t("update_title") % str(info.get("version", "?")), 22, UI.GOOD, HORIZONTAL_ALIGNMENT_LEFT)
	t.autowrap_mode = TextServer.AUTOWRAP_OFF
	tv.add_child(t)
	tv.add_child(UI.label(Settings.t("update_hint"), 15, Color(0.85, 0.95, 0.85), HORIZONTAL_ALIGNMENT_LEFT))
	var link := Net.update_link()
	var b := UI.button(Settings.t("update_btn"), func():
		if link != "":
			OS.shell_open(link), 170, 50, true)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(b)
	_update_slot.add_child(bar)


func _exit_tree() -> void:
	if Net.update_available.is_connected(_show_update):
		Net.update_available.disconnect(_show_update)


func _card(parent: Control, c: Control) -> void:
	parent.add_child(c)
	_cards.append(c)


## Profile: name, paint swatches (the 3D robot repaints live) and your record.
func _build_profile() -> void:
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel", UI.sb(Color(0.03, 0.035, 0.045, 0.82), Color(1, 1, 1, 0.1), 1, 18, Vector4(18, 14, 18, 14)))
	card.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	card.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	card.grow_vertical = Control.GROW_DIRECTION_BEGIN
	card.offset_right = -36
	card.offset_bottom = -52
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 8)
	card.add_child(cv)
	var nb := HBoxContainer.new()
	nb.add_theme_constant_override("separation", 10)
	cv.add_child(nb)
	var nl := UI.label(Settings.t("name"), 20, UI.DIM)
	nl.autowrap_mode = TextServer.AUTOWRAP_OFF
	nb.add_child(nl)
	var name_edit := LineEdit.new()
	name_edit.text = Settings.player_name
	name_edit.max_length = 16
	name_edit.custom_minimum_size = Vector2(300, 50)
	name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_edit.text_changed.connect(func(t):
		Settings.player_name = t.strip_edges() if t.strip_edges() != "" else "Bot"
		Settings.save_cfg()
		if main and main.menu_bg:
			main.menu_bg.set_players([{"color": Net.my_color_index(), "name": Settings.player_name, "cos": Settings.cosmetics()}]))
	nb.add_child(name_edit)
	var cb := HBoxContainer.new()
	cb.add_theme_constant_override("separation", 10)
	cv.add_child(cb)
	var cl := UI.label(Settings.t("robot_paint"), 20, UI.DIM)
	cl.autowrap_mode = TextServer.AUTOWRAP_OFF
	cl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	cb.add_child(cl)
	var grid := GridContainer.new()
	grid.columns = 8
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	cb.add_child(grid)
	_swatches = make_swatches(grid, func(i):
		Settings.robot_color = i
		Settings.save_cfg()
		if main and main.menu_bg:
			main.menu_bg.set_players([{"color": i, "name": Settings.player_name, "cos": Settings.cosmetics()}])
		paint_swatches(_swatches, i))
	paint_swatches(_swatches, Net.my_color_index())
	if Settings.best_level > 0:
		var rec := UI.label("★ " + Settings.t("record") % [Settings.best_level, Settings.money(Settings.best_earned)], 18, Color(1.0, 0.82, 0.45), HORIZONTAL_ALIGNMENT_LEFT)
		rec.autowrap_mode = TextServer.AUTOWRAP_OFF
		cv.add_child(rec)
	add_child(card)


func _build_news() -> void:
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel", UI.sb(Color(0.03, 0.035, 0.045, 0.7), Color(UI.ACCENT, 0.5), 1, 16, Vector4(16, 10, 16, 12)))
	card.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	card.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	card.offset_right = -36
	card.offset_top = 28
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	card.add_child(v)
	var t := UI.label(Settings.t("menu_new2"), 20, UI.ACCENT2, HORIZONTAL_ALIGNMENT_LEFT)
	t.add_theme_font_override("font", UI.title_font())
	v.add_child(t)
	var b := UI.label(Settings.t("menu_new2_text"), 16, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	b.autowrap_mode = TextServer.AUTOWRAP_OFF
	v.add_child(b)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(card)


## Shared by the menu and the lobby: 16 paint buttons.
static func make_swatches(grid: GridContainer, on_pick: Callable) -> Array:
	var out := []
	for i in Net.COLORS.size():
		var sw := Button.new()
		sw.custom_minimum_size = Vector2(32, 32)
		sw.focus_mode = Control.FOCUS_NONE
		grid.add_child(sw)
		out.append(sw)
		sw.pressed.connect(func():
			Sfx.play("ui")
			on_pick.call(i))
	return out


static func paint_swatches(sw: Array, sel: int) -> void:
	for i in sw.size():
		var c: Color = Net.COLORS[i]
		var on := i == sel
		var bw := 4 if on else 1
		var st := UI.sb(c, Color.WHITE if on else Color(0, 0, 0, 0.6), bw, 8, Vector4.ZERO)
		for k in ["normal", "pressed", "hover_pressed"]:
			sw[i].add_theme_stylebox_override(k, st)
		sw[i].add_theme_stylebox_override("hover", UI.sb(c.lightened(0.2), Color.WHITE, bw, 8, Vector4.ZERO))
