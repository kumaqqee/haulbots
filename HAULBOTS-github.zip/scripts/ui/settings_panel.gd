extends Control
## Settings overlay with tabs (used from the main menu and the pause menu).

const UI = preload("res://scripts/ui/ui.gd")
const TouchScroll = preload("res://scripts/ui/touch_scroll.gd")
const TouchEditor = preload("res://scripts/ui/touch_editor.gd")

var on_close: Callable
var _lang_changed := false
var _pages := {}
var _tabs := {}
var _content: VBoxContainer
var _hd := {}
var _scroll: ScrollContainer


func _ready() -> void:
	UI.full(self)
	process_mode = Node.PROCESS_MODE_ALWAYS
	UI.dim(self, 0.72)
	var vb := UI.panel_column(self, 860)
	vb.add_child(UI.title(Settings.t("settings"), 44))
	var tabs := HBoxContainer.new()
	tabs.alignment = BoxContainer.ALIGNMENT_CENTER
	tabs.add_theme_constant_override("separation", 8)
	vb.add_child(tabs)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(800, 400)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	TouchScroll.attach(sc)
	_scroll = sc
	_content = VBoxContainer.new()
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(_content)
	for k in ["tab_game", "tab_controls", "tab_video", "tab_audio"]:
		var b := Button.new()
		b.text = Settings.t(k)
		b.theme_type_variation = "Tab"
		b.toggle_mode = true
		b.custom_minimum_size = Vector2(180, 52)
		b.add_theme_font_size_override("font_size", 22)
		b.focus_mode = Control.FOCUS_NONE
		b.pressed.connect(_show.bind(k))
		tabs.add_child(b)
		_tabs[k] = b
		var page := VBoxContainer.new()
		page.add_theme_constant_override("separation", 10)
		page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_content.add_child(page)
		_pages[k] = page
	_build_game(_pages["tab_game"])
	_build_controls(_pages["tab_controls"])
	_build_video(_pages["tab_video"])
	_build_audio(_pages["tab_audio"])
	var close := UI.button(Settings.t("close"), _close, 360, 64, true)
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(close)
	_show("tab_game")


func _show(k: String) -> void:
	Sfx.play("ui", null, -8.0, 1.2)
	for n in _pages:
		_pages[n].visible = n == k
		_tabs[n].button_pressed = n == k
	if _scroll:
		if _scroll.has_node("TouchScroll"):
			_scroll.get_node("TouchScroll").stop()
		_scroll.scroll_vertical = 0    # a new tab starts at its top


func _build_game(p: VBoxContainer) -> void:
	var lang := OptionButton.new()
	lang.add_item("Русский")
	lang.add_item("English")
	lang.selected = 0 if Settings.lang == "ru" else 1
	lang.item_selected.connect(func(i):
		Settings.lang = "ru" if i == 0 else "en"
		_lang_changed = true)
	_row(p, "language", lang)
	var diff := OptionButton.new()
	for k in ["diff_0", "diff_1", "diff_2"]:
		diff.add_item(Settings.t(k))
	diff.selected = Settings.difficulty
	diff.item_selected.connect(func(i): Settings.difficulty = i)
	_row(p, "difficulty", diff)
	_toggle(p, "show_detect", Settings.show_detect, func(b): Settings.show_detect = b)
	p.add_child(UI.label(Settings.t("detect_hint"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	_toggle(p, "vibration", Settings.vibration, func(b): Settings.vibration = b)
	var rt := UI.button(Settings.t("reset_tutorial"), func():
		Settings.tutorial_done = false
		Settings.save_cfg()
		var m := get_tree().root.get_node_or_null("Main")
		if m and m.has_method("toast"):
			m.toast(Settings.t("tutorial_reset_done")), 420, 56)
	rt.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	p.add_child(rt)


func _build_controls(p: VBoxContainer) -> void:
	_slider(p, "sensitivity", 0.2, 3.0, 0.05, Settings.sensitivity, func(v): Settings.sensitivity = v, "%.2f×")
	_toggle(p, "invert_y", Settings.invert_y, func(b): Settings.invert_y = b)
	_toggle(p, "cam_bob", Settings.cam_bob, func(b): Settings.cam_bob = b)
	_slider(p, "btn_scale", 0.7, 1.4, 0.05, Settings.btn_scale, func(v):
		Settings.btn_scale = v
		Settings.changed.emit(), "%d%%", 100.0)
	_slider(p, "btn_alpha", 0.25, 1.0, 0.05, Settings.btn_alpha, func(v):
		Settings.btn_alpha = v
		Settings.changed.emit(), "%d%%", 100.0)
	var ed := UI.button(Settings.t("layout_open"), open_layout_editor, 520, 60, true)
	ed.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	p.add_child(ed)
	p.add_child(UI.label(Settings.t("layout_open_hint"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	# Bluetooth gamepad
	var card := PanelContainer.new()
	card.theme_type_variation = "Card"
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	card.add_child(vb)
	var hb := HBoxContainer.new()
	vb.add_child(hb)
	var l := UI.label(Settings.t("pad_title"), 23, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(l)
	var pads := Input.get_connected_joypads()
	var st := UI.label(Settings.t("pad_on") % Input.get_joy_name(pads[0]) if pads.size() > 0 else Settings.t("pad_off"), 18,
			UI.GOOD if pads.size() > 0 else UI.DIM, HORIZONTAL_ALIGNMENT_RIGHT)
	st.autowrap_mode = TextServer.AUTOWRAP_OFF
	st.clip_text = true
	st.custom_minimum_size.x = 260
	hb.add_child(st)
	vb.add_child(UI.label(Settings.t("pad_map"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	p.add_child(card)


## Full-screen button layout editor on top of this panel.
func open_layout_editor() -> void:
	if has_node("TouchEditor"):
		return
	var ed := TouchEditor.new()
	ed.name = "TouchEditor"
	add_child(ed)


func _build_video(p: VBoxContainer) -> void:
	if not OS.has_feature("play"):
		_build_hd(p)    # the Google Play build can't read the Downloads folder (no all-files access)
	var q := OptionButton.new()
	for k in ["q_low", "q_med", "q_high"]:
		q.add_item(Settings.t(k))
	q.selected = Settings.quality
	q.item_selected.connect(func(i): Settings.quality = i)
	_row(p, "quality", q)
	_slider(p, "fov", 60.0, 100.0, 1.0, Settings.fov, func(v): Settings.fov = v, "%d°")
	_slider(p, "brightness", 0.7, 1.6, 0.05, Settings.brightness, func(v):
		Settings.brightness = v
		Settings.changed.emit(), "%d%%", 100.0)
	var fg := OptionButton.new()
	for k in ["fog_0", "fog_1", "fog_2"]:
		fg.add_item(Settings.t(k))
	fg.selected = Settings.fog_level
	fg.item_selected.connect(func(i):
		Settings.fog_level = i
		Settings.changed.emit())
	_row(p, "fog_level", fg)
	_toggle(p, "beam_haze", Settings.beam_haze, func(b):
		Settings.beam_haze = b
		Settings.changed.emit())
	p.add_child(UI.label(Settings.t("fog_hint"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	_toggle(p, "film_fx", Settings.film_fx, func(b):
		Settings.film_fx = b
		Settings.changed.emit())
	var fc := OptionButton.new()
	for v in [30, 60, 90]:
		fc.add_item("%d FPS" % v)
	fc.selected = [30, 60, 90].find(Settings.fps_cap) if Settings.fps_cap in [30, 60, 90] else 1
	fc.item_selected.connect(func(i):
		Settings.fps_cap = [30, 60, 90][i]
		Settings.apply())
	_row(p, "fps_cap", fc)
	_toggle(p, "battery_saver", Settings.battery_saver, func(b):
		Settings.battery_saver = b
		Settings.apply())
	p.add_child(UI.label(Settings.t("battery_hint"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	_toggle(p, "adaptive_res", Settings.adaptive_res, func(b):
		Settings.adaptive_res = b
		Settings.changed.emit())
	p.add_child(UI.label(Settings.t("adaptive_hint"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	_toggle(p, "show_fps", Settings.show_fps, func(b): Settings.show_fps = b)


func _build_hd(p: VBoxContainer) -> void:
	var card := PanelContainer.new()
	card.theme_type_variation = "Card"
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	card.add_child(vb)
	var hb := HBoxContainer.new()
	vb.add_child(hb)
	var l := UI.label(Settings.t("hd_pack"), 23, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(l)
	var st := UI.label("", 20, UI.ACCENT2, HORIZONTAL_ALIGNMENT_RIGHT)
	st.autowrap_mode = TextServer.AUTOWRAP_OFF
	hb.add_child(st)
	var info := UI.label(Settings.t("hd_hint"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT)
	vb.add_child(info)
	var btns := HBoxContainer.new()
	btns.add_theme_constant_override("separation", 10)
	btns.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(btns)
	var inst := UI.button(Settings.t("hd_install"), func(): HD.install(), 330, 54, true)
	var rem := UI.button(Settings.t("hd_remove"), func(): HD.uninstall(), 220, 54)
	var rst := UI.button(Settings.t("hd_restart"), func(): HD.restart(), 280, 54, true)
	for b in [inst, rem, rst]:
		btns.add_child(b)
	_hd = {"st": st, "info": info, "rem": rem, "rst": rst}
	HD.status_changed.connect(_hd_refresh)
	_hd_refresh()
	p.add_child(card)


func _hd_refresh(msg := "") -> void:
	var st: Label = _hd.st
	var info: Label = _hd.info
	if HD.active():
		st.text = Settings.t("hd_on") % ("%d" % HD.mounted.size())
		st.add_theme_color_override("font_color", UI.GOOD)
	else:
		st.text = Settings.t("hd_off")
		st.add_theme_color_override("font_color", UI.DIM)
	_hd.rem.visible = not HD.installed().is_empty()
	_hd.rst.visible = HD.pending_restart
	if HD.pending_restart and msg == "":
		msg = Settings.t("hd_pending")
	info.text = msg if msg != "" else Settings.t("hd_hint")
	info.add_theme_color_override("font_color", UI.ACCENT2 if msg != "" else UI.DIM)


func _build_audio(p: VBoxContainer) -> void:
	_slider(p, "volume", 0.0, 1.0, 0.05, Settings.volume, func(v):
		Settings.volume = v
		Settings.apply(), "%d%%", 100.0)
	_slider(p, "music_vol", 0.0, 1.0, 0.05, Settings.music_vol, func(v):
		Settings.music_vol = v
		Settings.apply(), "%d%%", 100.0)
	_toggle(p, "chat_voice", Settings.chat_voice, func(b): Settings.chat_voice = b)
	p.add_child(UI.label(Settings.t("chat_voice_hint"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	# proximity voice chat
	var vm := OptionButton.new()
	for k in ["vm_0", "vm_1", "vm_2"]:
		vm.add_item(Settings.t(k))
	vm.selected = clampi(Settings.voice_mode, 0, 2)
	vm.item_selected.connect(func(i):
		Settings.voice_mode = i
		Settings.changed.emit())
	_row(p, "voice_chat", vm)
	p.add_child(UI.label(Settings.t("voice_hint"), 17, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT))
	_slider(p, "voice_vol", 0.0, 1.5, 0.05, Settings.voice_vol, func(v):
		Settings.voice_vol = v
		Settings.changed.emit(), "%d%%", 100.0)
	_toggle(p, "voice_filter", Settings.voice_filter, func(b):
		Settings.voice_filter = b
		Settings.changed.emit())
	_slider(p, "mic_sens", 0.0, 1.0, 0.05, Settings.mic_sens, func(v): Settings.mic_sens = v, "%d%%", 100.0)
	_build_mic_test(p)


## Mic test: a live level bar with the voice-activation threshold marked on it.
var _mic_voice: Node = null
var _mic_meter: Control = null


func _build_mic_test(p: VBoxContainer) -> void:
	var card := PanelContainer.new()
	card.theme_type_variation = "Card"
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	card.add_child(hb)
	var btn := Button.new()
	btn.text = Settings.t("mic_test")
	btn.toggle_mode = true
	btn.focus_mode = Control.FOCUS_NONE
	btn.custom_minimum_size = Vector2(250, 50)
	btn.add_theme_font_size_override("font_size", 20)
	hb.add_child(btn)
	_mic_meter = Control.new()
	_mic_meter.custom_minimum_size = Vector2(300, 50)
	_mic_meter.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_mic_meter.draw.connect(func():
		var r := Rect2(0, 17, _mic_meter.size.x, 16)
		_mic_meter.draw_style_box(UI.sb(Color(0, 0, 0, 0.5), Color(1, 1, 1, 0.12), 1, 8, Vector4.ZERO), r)
		if _mic_voice:
			var lv: float = clampf(sqrt(_mic_voice.mic_level), 0.0, 1.0)
			var th: float = clampf(sqrt(_mic_voice.vad_threshold() * 2.0), 0.0, 1.0)
			var on: bool = _mic_voice.mic_level * 0.5 > _mic_voice.vad_threshold()
			_mic_meter.draw_rect(Rect2(r.position + Vector2(2, 2), Vector2((r.size.x - 4) * lv, r.size.y - 4)), UI.GOOD if on else UI.ACCENT2)
			_mic_meter.draw_line(Vector2(r.size.x * th, 10), Vector2(r.size.x * th, 40), Color(1, 1, 1, 0.8), 2.0))
	hb.add_child(_mic_meter)
	btn.toggled.connect(func(on):
		var m := get_tree().root.get_node_or_null("Main")
		var wv = m.world.voice if m and m.get("world") and m.world.voice else null
		if on:
			if wv and wv.talking:
				_mic_voice = wv    # in a game with the mic already open: just show it
				return
			if _mic_voice == null or _mic_voice == wv:
				_mic_voice = preload("res://scripts/game/voice.gd").new()
				add_child(_mic_voice)
			_mic_voice.set_test(true)
		elif _mic_voice and _mic_voice != wv:
			_mic_voice.set_test(false))
	p.add_child(card)


func _process(_d: float) -> void:
	if _mic_meter and is_instance_valid(_mic_voice) and _mic_voice.talking:
		_mic_meter.queue_redraw()


func _row(vb: VBoxContainer, key: String, ctrl: Control, value_lbl: Label = null) -> void:
	var card := PanelContainer.new()
	card.theme_type_variation = "Card"
	var hb := HBoxContainer.new()
	card.add_child(hb)
	var l := UI.label(Settings.t(key), 23, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	l.custom_minimum_size.x = 300
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	l.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(l)
	ctrl.size_flags_horizontal = Control.SIZE_SHRINK_END if ctrl is CheckButton else Control.SIZE_EXPAND_FILL
	ctrl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	if ctrl is OptionButton:
		# open the list on release: a scroll that starts on it must not pop it open
		ctrl.action_mode = BaseButton.ACTION_MODE_BUTTON_RELEASE
		ctrl.focus_mode = Control.FOCUS_NONE
	if ctrl is CheckButton:
		var sp := Control.new()
		sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(sp)
	hb.add_child(ctrl)
	if value_lbl:
		hb.add_child(value_lbl)
	vb.add_child(card)


func _toggle(vb: VBoxContainer, key: String, val: bool, cb: Callable) -> void:
	var c := CheckButton.new()
	c.button_pressed = val
	c.focus_mode = Control.FOCUS_NONE
	c.toggled.connect(func(b):
		Sfx.play("ui", null, -8.0, 1.5 if b else 0.9)
		cb.call(b))
	_row(vb, key, c)


func _slider(vb: VBoxContainer, key: String, mn: float, mx: float, step: float, val: float, cb: Callable, fmt := "%.2f", mul := 1.0) -> void:
	var s := HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = step
	s.value = val
	s.custom_minimum_size = Vector2(300, 44)
	s.focus_mode = Control.FOCUS_NONE
	var vl := UI.label(_fmt(fmt, val * mul), 22, UI.ACCENT2, HORIZONTAL_ALIGNMENT_RIGHT)
	vl.custom_minimum_size.x = 90
	vl.autowrap_mode = TextServer.AUTOWRAP_OFF
	s.value_changed.connect(func(v):
		vl.text = _fmt(fmt, v * mul)
		cb.call(v))
	_row(vb, key, s, vl)


static func _fmt(fmt: String, v: float) -> String:
	if fmt.contains("%d"):
		return fmt % int(round(v))
	return fmt % v


func _close() -> void:
	Settings.save_cfg()
	Settings.apply()
	if _lang_changed:
		var m := get_tree().root.get_node_or_null("Main")
		if m and m.has_method("refresh_screen"):
			m.call_deferred("refresh_screen")
	if on_close.is_valid():
		on_close.call()
	else:
		queue_free()
