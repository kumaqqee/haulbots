extends Control
## Co-op lobby: IP card, difficulty, the crew list and paint on the left; the robots by the van
## on the right (with their names over their heads).

const UI = preload("res://scripts/ui/ui.gd")
const Menu = preload("res://scripts/ui/menu.gd")

var main: Node
var list: VBoxContainer
var title: Label
var start_btn: Button
var _swatches := []
var _diff_lbl: Label = null


func _ready() -> void:
	UI.full(self)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.35)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shade.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
	shade.offset_right = 700
	add_child(shade)
	var margin := MarginContainer.new()
	UI.full(margin)
	margin.add_theme_constant_override("margin_left", 40)
	margin.add_theme_constant_override("margin_top", 14)
	margin.add_theme_constant_override("margin_bottom", 14)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(margin)
	var pc := PanelContainer.new()
	pc.custom_minimum_size.x = 620
	pc.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	pc.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	margin.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 7)
	pc.add_child(vb)
	var hb0 := HBoxContainer.new()
	vb.add_child(hb0)
	var t := UI.title(Settings.t("lobby").to_upper(), 40)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb0.add_child(t)
	title = UI.label("", 20, UI.DIM, HORIZONTAL_ALIGNMENT_RIGHT)
	title.autowrap_mode = TextServer.AUTOWRAP_OFF
	title.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb0.add_child(title)
	if Net.relay and Net.relay_code != "":
		# internet room: the code to share (shown to everyone, so anybody can invite the rest)
		var rc := PanelContainer.new()
		rc.add_theme_stylebox_override("panel", UI.sb(Color(0.25, 0.14, 0.04, 0.5), Color(UI.ACCENT, 0.7), 1, 12, Vector4(16, 8, 10, 8)))
		var rh := HBoxContainer.new()
		rc.add_child(rh)
		var rv := VBoxContainer.new()
		rv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		rv.add_theme_constant_override("separation", 0)
		rh.add_child(rv)
		rv.add_child(UI.label(Settings.t("room_code"), 16, Color(1, 0.85, 0.6), HORIZONTAL_ALIGNMENT_LEFT))
		var bigc := UI.label(" ".join(Net.relay_code.split("")), 40, UI.ACCENT2, HORIZONTAL_ALIGNMENT_LEFT)
		bigc.add_theme_font_override("font", UI.title_font())
		rv.add_child(bigc)
		rv.add_child(UI.label(Settings.t("room_code_hint"), 16, Color(1, 0.92, 0.82), HORIZONTAL_ALIGNMENT_LEFT))
		var code := Net.relay_code
		rh.add_child(UI.tile_button("copy", "", func():
			DisplayServer.clipboard_set(code)
			if main:
				main.toast(Settings.t("copied")), 78))
		vb.add_child(rc)
	elif Net.is_host():
		var ips := Net.local_ips()
		var ip := ", ".join(ips) if ips.size() > 0 else "?"
		var ipc := PanelContainer.new()
		ipc.add_theme_stylebox_override("panel", UI.sb(Color(0.1, 0.25, 0.12, 0.45), Color(UI.GOOD, 0.55), 1, 12, Vector4(16, 8, 10, 8)))
		var ih := HBoxContainer.new()
		ipc.add_child(ih)
		var iv := VBoxContainer.new()
		iv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		iv.add_theme_constant_override("separation", 0)
		ih.add_child(iv)
		var big := UI.label(ip, 32, UI.GOOD, HORIZONTAL_ALIGNMENT_LEFT)
		big.add_theme_font_override("font", UI.title_font())
		iv.add_child(big)
		iv.add_child(UI.label(Settings.t("lobby_ip_hint"), 16, Color(0.8, 0.95, 0.82), HORIZONTAL_ALIGNMENT_LEFT))
		var cp := UI.tile_button("copy", "IP", func():
			DisplayServer.clipboard_set(ip)
			if main:
				main.toast(Settings.t("copied")), 78)
		ih.add_child(cp)
		vb.add_child(ipc)
	var dh := HBoxContainer.new()
	dh.add_theme_constant_override("separation", 10)
	vb.add_child(dh)
	var dl := UI.label(Settings.t("difficulty"), 20, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT)
	dl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	dh.add_child(dl)
	if Net.is_host():
		var diff := OptionButton.new()
		for k in ["diff_0", "diff_1", "diff_2"]:
			diff.add_item(Settings.t(k))
		diff.selected = Settings.difficulty
		diff.custom_minimum_size = Vector2(260, 46)
		diff.item_selected.connect(func(i): Net.set_difficulty(i))
		dh.add_child(diff)
	else:
		_diff_lbl = UI.label(Settings.t("diff_%d" % Net.difficulty), 20, UI.ACCENT2)
		dh.add_child(_diff_lbl)
	list = VBoxContainer.new()
	list.add_theme_constant_override("separation", 6)
	vb.add_child(list)
	var ph := HBoxContainer.new()
	ph.add_theme_constant_override("separation", 10)
	vb.add_child(ph)
	var pl := UI.label(Settings.t("robot_paint"), 20, UI.DIM)
	pl.autowrap_mode = TextServer.AUTOWRAP_OFF
	pl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ph.add_child(pl)
	var grid := GridContainer.new()
	grid.columns = 16
	grid.add_theme_constant_override("h_separation", 4)
	grid.add_theme_constant_override("v_separation", 4)
	ph.add_child(grid)
	_swatches = Menu.make_swatches(grid, func(i): Net.request_color(i))
	for sw in _swatches:
		sw.custom_minimum_size = Vector2(28, 28)
	if Net.is_host() and Net.has_mp_save():
		var info := Net.mp_save_info()
		var ch := HBoxContainer.new()
		ch.add_theme_constant_override("separation", 10)
		vb.add_child(ch)
		var cb := UI.button(Settings.t("lobby_continue") % int(info.get("level", 1)), func(): Net.continue_mp(), 300, 52)
		ch.add_child(cb)
		var cl := UI.label(Settings.t("lobby_continue_hint"), 15, UI.DIM, HORIZONTAL_ALIGNMENT_LEFT)
		cl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		cl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		ch.add_child(cl)
	var bh := HBoxContainer.new()
	bh.add_theme_constant_override("separation", 10)
	vb.add_child(bh)
	if Net.is_host():
		start_btn = UI.button(Settings.t("start"), func(): Net.start_run(), 380, 62, true)
		bh.add_child(start_btn)
	else:
		var w := UI.label(Settings.t("waiting_host"), 20, UI.DIM)
		w.custom_minimum_size.x = 380
		bh.add_child(w)
	bh.add_child(UI.button(Settings.t("leave"), _leave, 180, 62))
	Net.players_changed.connect(_refresh)
	Net.run_changed.connect(_refresh)
	_refresh()


func _refresh() -> void:
	for c in list.get_children():
		c.queue_free()
	title.text = Settings.t("players_n") % Net.players.size()
	if start_btn:
		start_btn.text = Settings.t("start_n") % Net.players.size()
	if _diff_lbl:
		_diff_lbl.text = Settings.t("diff_%d" % Net.difficulty)
	var me := multiplayer.get_unique_id()
	var ids := Net.players.keys()
	ids.sort()
	for id in ids:
		var p: Dictionary = Net.players[id]
		var col: Color = Net.COLORS[int(p["color"]) % Net.COLORS.size()]
		var card := PanelContainer.new()
		card.add_theme_stylebox_override("panel", UI.sb(Color(col.r * 0.18, col.g * 0.18, col.b * 0.18, 0.75), Color(col, 0.55), 1, 12, Vector4(10, 3, 14, 3)))
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 12)
		card.add_child(hb)
		var face := Control.new()
		face.custom_minimum_size = Vector2(34, 34)
		face.draw.connect(func():
			face.draw_circle(face.size / 2.0, 16.0, col)
			for sx in [-7.0, 7.0]:
				face.draw_circle(face.size / 2.0 + Vector2(sx, -2), 5.0, Color(0.05, 0.06, 0.08))
				face.draw_circle(face.size / 2.0 + Vector2(sx, -2), 2.2, Color(1, 1, 1)))
		hb.add_child(face)
		var nl := UI.label(str(p["name"]), 21, col.lightened(0.35), HORIZONTAL_ALIGNMENT_LEFT)
		nl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		hb.add_child(nl)
		if id == me:
			var yl := UI.label(Settings.t("you"), 16, UI.TEXT)
			yl.autowrap_mode = TextServer.AUTOWRAP_OFF
			yl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			hb.add_child(yl)
		if id == 1:
			var hl := UI.label("★ HOST", 17, UI.ACCENT2)
			hl.autowrap_mode = TextServer.AUTOWRAP_OFF
			hl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			hb.add_child(hl)
		list.add_child(card)
	for i in range(Net.players.size(), 4):
		var empty := PanelContainer.new()
		empty.theme_type_variation = "Card"
		empty.modulate.a = 0.4
		empty.add_child(UI.label("— " + Settings.t("slot_empty") + " —", 17, UI.DIM))
		list.add_child(empty)
	Menu.paint_swatches(_swatches, int(Net.players.get(me, {}).get("color", Net.my_color_index())))
	if main and main.menu_bg:
		var arr := []
		for id in ids:
			arr.append(Net.players[id])
		main.menu_bg.set_players(arr)


func _leave() -> void:
	Net.leave()
	main.show_menu()


func _exit_tree() -> void:
	if Net.players_changed.is_connected(_refresh):
		Net.players_changed.disconnect(_refresh)
	if Net.run_changed.is_connected(_refresh):
		Net.run_changed.disconnect(_refresh)
