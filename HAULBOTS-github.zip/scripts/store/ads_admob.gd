extends Node
## AdMob rewarded ads (Poing Studios AdMob plugin, added by the GitHub Android build).
## Asks for consent first (UMP: required in the EU/UK), then keeps one rewarded ad loaded.
## Loaded only when the native plugin is present; classes are loaded by path so the game
## compiles without the addon.

signal ready_changed

const Cfg = preload("res://scripts/monetization_config.gd")
const API := "res://addons/admob/gdscript/src/"
const REQUIRED := 2          # ConsentInformation.ConsentStatus.REQUIRED
const PRIVACY_REQUIRED := 2  # PrivacyOptionsRequirementStatus.REQUIRED

var _ad = null
var _loading := false
var _started := false
var _retry_t := -1.0
var _loader = null


func _cls(path: String):
	return load(API + path)


func _ready() -> void:
	var ump = _cls("ump/api/UserMessagingPlatform.gd")
	var params = _cls("ump/core/ConsentRequestParameters.gd").new()
	var info = ump.consent_information
	info.update(params, func():
		if info.get_is_consent_form_available() and int(info.get_consent_status()) == REQUIRED:
			ump.load_consent_form(func(form):
				form.show(func(_err): _start()),
				func(_err): _start())
		else:
			_start(),
		func(_err): _start())


func _start() -> void:
	if _started:
		return
	_started = true
	_cls("api/MobileAds.gd").initialize()
	_load()


func _process(delta: float) -> void:
	if _retry_t > 0.0:
		_retry_t -= delta
		if _retry_t <= 0.0:
			_load()


func _unit() -> String:
	return Cfg.REWARDED_UNIT_IOS if OS.get_name() == "iOS" else Cfg.REWARDED_UNIT_ANDROID


func _load() -> void:
	if _loading or _ad != null or not _started:
		return
	_loading = true
	var cb = _cls("api/listeners/RewardedAdLoadCallback.gd").new()
	cb.on_ad_loaded = func(ad):
		_ad = ad
		_loading = false
		ready_changed.emit()
	cb.on_ad_failed_to_load = func(_err):
		_loading = false
		_retry_t = 45.0
	_loader = _cls("api/RewardedAdLoader.gd").new()
	_loader.load(_unit(), _cls("api/core/AdRequest.gd").new(), cb)


func is_ready() -> bool:
	return _ad != null


func show(_placement: String, on_reward: Callable, on_fail: Callable) -> void:
	var ad = _ad
	_ad = null
	ready_changed.emit()
	if ad == null:
		on_fail.call_deferred()
		return
	var st := {"earned": false, "done": false}
	var fsc = _cls("api/listeners/FullScreenContentCallback.gd").new()
	fsc.on_ad_dismissed_full_screen_content = func():
		ad.destroy()
		_load()
	fsc.on_ad_failed_to_show_full_screen_content = func(_err):
		ad.destroy()
		if not st["earned"]:
			on_fail.call_deferred()
		_load()
	ad.full_screen_content_callback = fsc
	var listener = _cls("api/listeners/OnUserEarnedRewardListener.gd").new()
	listener.on_user_earned_reward = func(_item):
		if not st["earned"]:
			st["earned"] = true
			on_reward.call_deferred()
	ad.show(listener)


func privacy_options_required() -> bool:
	var info = _cls("ump/api/UserMessagingPlatform.gd").consent_information
	return int(info.get_privacy_options_requirement_status()) == PRIVACY_REQUIRED


func show_privacy_options() -> void:
	_cls("ump/api/UserMessagingPlatform.gd").show_privacy_options_form(func(_err): pass)
