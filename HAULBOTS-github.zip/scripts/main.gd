extends Node
## Root: switches between menu screens and the game world.

const UI = preload("res://scripts/ui/ui.gd")
const WorldScript = preload("res://scripts/game/world.gd")
const MenuScreen = preload("res://scripts/ui/menu.gd")
const JoinScreen = preload("res://scripts/ui/join.gd")
const OnlineScreen = preload("res://scripts/ui/online.gd")
const LobbyScreen = preload("res://scripts/ui/lobby.gd")
const ShopScreen = preload("res://scripts/ui/shop.gd")
const GameOverScreen = preload("res://scripts/ui/gameover.gd")
const HelpScreen = preload("res://scripts/ui/help.gd")
const CollectionScreen = preload("res://scripts/ui/collection.gd")
const SupportScreen = preload("res://scripts/ui/support.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")
const MenuBG = preload("res://scripts/ui/menu_bg.gd")
const Loading = preload("res://scripts/ui/loading.gd")
var load_layer: CanvasLayer
var _warm := []   # resources pre-loaded on the loading screen (kept alive for the session)

var theme: Theme
var ui_layer: CanvasLayer
var screen: Control = null
var screen_name := ""
var world: Node = null
var _toast: Label
var menu_bg: Node3D = null


func _ready() -> void:
	theme = UI.make_theme()
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 10
	add_child(ui_layer)
	_toast = Label.new()
	_toast.add_theme_font_size_override("font_size", 26)
	_toast.add_theme_color_override("font_color", Color(1, 0.8, 0.4))
	_toast.add_theme_color_override("font_outline_color", Color.BLACK)
	_toast.add_theme_constant_override("outline_size", 8)
	_toast.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_toast.position.y -= 80
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	load_layer = CanvasLayer.new()
	load_layer.layer = 30
	add_child(load_layer)
	var toast_layer := CanvasLayer.new()
	toast_layer.layer = 20
	add_child(toast_layer)
	toast_layer.add_child(_toast)
	Net.session_ended.connect(_on_session_ended)
	Net.connect_failed.connect(_on_connect_failed)
	Net.connected_ok.connect(func():
		if Net.reconnecting:
			Net.reconnecting = false
		show_lobby())
	Net.room_ready.connect(func(_c):
		if screen_name == "connecting":
			show_lobby())
	Net.rejoin_waiting.connect(func(_l): show_rejoin_wait())
	get_tree().set_auto_accept_quit(true)
	get_tree().quit_on_go_back = false
	Sfx.start_ambience()
	var args := OS.get_cmdline_user_args()
	for a in args:
		if a == "--touch":
			Settings.force_touch = true
		if a.begins_with("--lang="):
			Settings.lang = a.split("=")[1]
	for a in args:
		if a == "--autotest=mp4":
			var mp = load("res://scripts/mp_test.gd").new()
			mp.name = "MPTest"
			mp.main = self
			add_child(mp)
			return
		if a.begins_with("--autotest="):
			var Tester = load("res://scripts/tester.gd")
			var t = Tester.new()
			t.main = self
			t.mode = a.split("=")[1]
			add_child(t)
			return
	_boot_loading()


func _boot_loading() -> void:
	var l := Loading.new()
	l.theme = theme
	l.min_time = 2.6
	l.paths = _warm_paths()
	load_layer.add_child(l)
	l.finished.connect(func():
		_warm = l.loaded_resources().duplicate()
		show_menu())


## Models and surface textures to warm up on the boot loading screen.
static func _warm_paths() -> Array:
	var out := []
	for dir in ["res://assets/models", "res://assets/tex", "res://assets/mtex"]:
		var d := DirAccess.open(dir)
		if d == null:
			continue
		for f in d.get_files():
			var n := f.trim_suffix(".import").trim_suffix(".remap")
			if (n.ends_with(".glb") or n.ends_with(".png")) and not out.has(dir + "/" + n):
				out.append(dir + "/" + n)
	return out


## Short loading cover between levels (the world is built underneath, then the cover fades).
func show_loading_cover(t := 1.1) -> void:
	var l := Loading.new()
	l.theme = theme
	l.min_time = t
	load_layer.add_child(l)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_on_back()


func _on_back() -> void:
	if world and world.hud:
		world.hud._toggle_pause()
	elif screen_name in ["join", "help", "settings"]:
		if screen_name == "join":
			Net.stop_listen()
		show_menu()
	elif screen_name == "menu":
		get_tree().quit()


func _set_screen(c: Control, n: String) -> void:
	clear_world()
	if screen:
		screen.queue_free()
	screen = c
	screen_name = n
	_ensure_menu_bg()
	c.theme = theme
	if "main" in c:
		c.main = self
	ui_layer.add_child(c)
	c.modulate.a = 0.0
	c.create_tween().tween_property(c, "modulate:a", 1.0, 0.25)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _ensure_menu_bg() -> void:
	Sfx.music(true)
	if menu_bg == null and not OS.get_cmdline_user_args().has("--nobg"):
		menu_bg = MenuBG.new()
		menu_bg.name = "MenuBG"
		add_child(menu_bg)


func _free_menu_bg() -> void:
	Sfx.music(false)
	if menu_bg:
		remove_child(menu_bg)
		menu_bg.queue_free()
		menu_bg = null


func _process(delta: float) -> void:
	_reconnect_tick(delta)


func clear_world() -> void:
	if world:
		remove_child(world)
		world.queue_free()
		world = null
		get_tree().paused = false


func refresh_screen() -> void:
	match screen_name:
		"menu":
			show_menu()
		"settings":
			show_settings()


func show_menu() -> void:
	_set_screen(MenuScreen.new(), "menu")


func show_join() -> void:
	_set_screen(JoinScreen.new(), "join")


func show_online() -> void:
	_set_screen(OnlineScreen.new(), "online")


## Text for the last connection error (relay codes like no_room / full / version).
func err_text() -> String:
	var k := "err_" + Net.last_error
	var t: String = Settings.t(k)
	return t if Net.last_error != "" and t != k else Settings.t("conn_failed")


func show_lobby() -> void:
	_set_screen(LobbyScreen.new(), "lobby")


func show_shop() -> void:
	_set_screen(ShopScreen.new(), "shop")


func show_help() -> void:
	_set_screen(HelpScreen.new(), "help")


func show_collection() -> void:
	_set_screen(CollectionScreen.new(), "collection")


func show_store() -> void:
	_set_screen(SupportScreen.new(), "store")


func show_gameover(stats: Dictionary) -> void:
	var g := GameOverScreen.new()
	g.stats = stats
	_set_screen(g, "gameover")


func show_settings() -> void:
	var holder := Control.new()
	holder.add_child(UI.backdrop())
	var sp := SettingsPanel.new()
	sp.on_close = func(): show_menu()
	holder.add_child(sp)
	_set_screen(holder, "settings")
	UI.full(holder)


func show_connecting(text := "", online := false) -> void:
	var c := Control.new()
	c.add_child(UI.backdrop())
	var vb := UI.centered_column(c, 640)
	vb.add_child(UI.label(text if text != "" else Settings.t("connecting"), 36, UI.ACCENT))
	vb.add_child(UI.button(Settings.t("cancel"), func():
		Net.leave()
		if online:
			show_online()
		else:
			show_join()))
	_set_screen(c, "connecting")
	UI.full(c)


func start_world(s: int, l: int, shop := false, arena := false) -> void:
	if screen:
		screen.queue_free()
		screen = null
	screen_name = "game"
	if not _is_autotest():
		show_loading_cover()
	clear_world()
	_free_menu_bg()
	world = WorldScript.new()
	world.name = "World"
	add_child(world)
	world.setup(s, l, shop, arena)


func toast(text: String) -> void:
	_toast.text = text
	_toast.modulate.a = 1.0
	var tw := _toast.create_tween()
	tw.tween_interval(2.5)
	tw.tween_property(_toast, "modulate:a", 0.0, 0.8)


func _on_session_ended(reason: String) -> void:
	if reason in Net.REJOINABLE and not Net.recent_session().is_empty():
		start_reconnect()
		return
	show_menu()
	toast(Settings.t(reason))


# ------------------------------------------------------------------ coming back after a drop

var _rc_label: Label = null
var _rc_next := 0.0
var _rc_left := 0.0
var _rc_busy := false
var _rc_n := 0


## Lost the connection mid-run (or the app was closed): keep trying to get back into the same
## room for a while; the host restores our robot.
func start_reconnect() -> void:
	Net.reconnecting = true
	_rc_next = 0.5
	_rc_left = 75.0
	_rc_busy = false
	_rc_n = 0
	clear_world()
	var c := Control.new()
	c.add_child(UI.backdrop())
	var vb := UI.centered_column(c, 720)
	vb.add_child(UI.label(Settings.t("rc_title"), 40, UI.ACCENT))
	_rc_label = UI.label("", 24, UI.TEXT)
	vb.add_child(_rc_label)
	vb.add_child(UI.button(Settings.t("cancel"), func():
		Net.reconnecting = false
		Net.leave()
		show_menu()))
	_set_screen(c, "reconnect")
	UI.full(c)


func _reconnect_tick(delta: float) -> void:
	if not Net.reconnecting:
		return
	_rc_left -= delta
	if _rc_label and is_instance_valid(_rc_label):
		_rc_label.text = Settings.t("rc_trying") % [maxi(1, _rc_n), int(ceil(maxf(_rc_left, 0.0)))]
	if _rc_left <= 0.0 and not _rc_busy:
		Net.reconnecting = false
		Net.leave()
		show_menu()
		toast(Settings.t("rc_failed"))
		return
	if _rc_busy:
		return
	_rc_next -= delta
	if _rc_next <= 0.0:
		_rc_busy = true
		_rc_n += 1
		Net.rejoin_session()


func show_rejoin_wait() -> void:
	if world:
		clear_world()
	var c := Control.new()
	c.add_child(UI.backdrop())
	var vb := UI.centered_column(c, 760)
	vb.add_child(UI.label(Settings.t("rejoin_title"), 40, UI.GOOD))
	vb.add_child(UI.label(Settings.t("rejoin_sub") % Net.level, 22, UI.TEXT))
	vb.add_child(UI.button(Settings.t("leave"), func():
		Net.forget_session()
		Net.leave()
		show_menu()))
	_set_screen(c, "rejoin_wait")
	UI.full(c)


func _on_connect_failed() -> void:
	if Net.reconnecting:
		_rc_busy = false
		_rc_next = 3.0
		if Net.last_error in ["no_room", "version", "full"]:
			_rc_left = 0.0    # the room is gone: no point in retrying
		return
	if Net.last_mode == "relay":
		show_online()
		toast(err_text())
	else:
		show_join()
		toast(Settings.t("conn_failed"))


func _is_autotest() -> bool:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--autotest="):
			return true
	return false
