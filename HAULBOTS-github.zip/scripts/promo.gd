extends Node
## Store trailer / screenshot director (not exported). Each run stages one scene of the real game
## and records it with Godot's Movie Maker:
##   godot --path . --write-movie out.avi --fixed-fps 30 --resolution 1920x1080 -- --autotest=promo --scene=explore
## Prints "[PROMO] mark <frame>" where the usable footage starts and quits at the end.

var main: Node
var scene := ""
var w
var lp
var t


func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--scene="):
			scene = a.split("=")[1]
	Settings.lang = "en"
	Settings.force_touch = true
	Settings.tutorial_done = true
	Settings.show_fps = false
	Settings.adaptive_res = false      # rendering is slow here: never lower the resolution
	Settings.quality = 2
	Settings.battery_saver = false
	Settings.fps_cap = 60
	Settings.btn_layout = {}
	Settings.btn_alpha = 0.75
	Settings.voice_mode = 2
	Settings.chat_voice = false
	for a in Ach.LIST:
		Settings.achievements[a[0]] = 1
	Settings.cos_hat = "cap"
	Settings.cos_acc = ""
	Settings.cos_finish = ""
	Settings.player_name = "You"
	Settings.robot_color = 0
	Settings.crown_name = ""
	call_deferred("_run")


func _process(_d: float) -> void:
	# the level-1 tip pill would sit over every shot
	if w and is_instance_valid(w) and w.hud and w.hud.msg_box:
		for c in w.hud.msg_box.get_children():
			var l := c.get_child(0) as Label if c.get_child_count() > 0 else null
			if l and l.text == Settings.t("msg_tip1"):
				c.queue_free()


func _run() -> void:
	if has_method("_s_" + scene):
		await call("_s_" + scene)
	else:
		push_error("no scene " + scene)
	print("[PROMO] end ", Engine.get_frames_drawn())
	get_tree().quit()


func mark() -> void:
	print("[PROMO] mark ", Engine.get_frames_drawn())


func wait(s: float) -> void:
	await get_tree().create_timer(s).timeout


func frames(n: int) -> void:
	for i in n:
		await get_tree().process_frame


## Start a level (fixed seed) with extra fake teammates (pid -> [name, colour, cosmetics]).
func start_level(seed: int, level := 1, mates := {}) -> void:
	Net.delete_save()
	Net.start_solo(false)
	await wait(0.3)
	for pid in mates:
		var m: Array = mates[pid]
		Net.players[pid] = {"name": m[0], "color": m[1], "uid": "fake%d" % pid, "cos": m[2]}
		Net._init_player_run(pid)
	Net.level = level
	Net._load_level(seed, level, 1)
	await wait(0.2)
	w = main.world
	for pid in mates:
		w.ready_peers[pid] = true
	w._try_start()
	await wait(0.6)
	lp = w.local_player
	t = w.hud.touch


## Walk the local robot along points with the on-screen joystick (it shows on screen).
func walk_to(p: Vector3, speed_k := 1.0, look_ahead := true) -> void:
	var guard := 0
	while guard < 600:
		guard += 1
		var d := Vector3(p.x - lp.global_position.x, 0, p.z - lp.global_position.z)
		if d.length() < 0.35:
			break
		if look_ahead:
			var want := atan2(-d.x, -d.z)
			lp.yaw = lerp_angle(lp.yaw, want, 0.12)
		var local := d.normalized().rotated(Vector3.UP, -lp.yaw)
		t.move_vec = Vector2(local.x, local.z) * speed_k
		t._joy_pos = t._joy_center + t.move_vec * 105.0 * t._u
		t.queue_redraw()
		await get_tree().physics_frame
	t.move_vec = Vector2.ZERO
	t.queue_redraw()


func turn_to(p: Vector3, dur := 0.6, pitch := 0.0) -> void:
	var d: Vector3 = p - (lp.global_position + Vector3(0, 1.4, 0))
	var y1 := atan2(-d.x, -d.z)
	var p1 := atan2(d.y, Vector2(d.x, d.z).length()) if pitch == 0.0 else pitch
	var y0: float = lp.yaw
	var p0: float = lp.pitch
	var n := int(dur * 60)
	for i in n:
		var k := smoothstep(0.0, 1.0, float(i + 1) / n)
		lp.yaw = lerp_angle(y0, y1, k)
		lp.pitch = lerpf(p0, p1, k)
		await get_tree().physics_frame


## Press an on-screen button (press animation + the game reads it like a real tap).
func tap(k: String) -> void:
	t._pressed[k] = true
	t.buttons[k]["down"] = true
	t._press_anim[k] = 1.0
	t.queue_redraw()
	await frames(6)
	t.buttons[k]["down"] = false
	t.queue_redraw()


# ------------------------------------------------------------------ scenes

func _s_test() -> void:
	await start_level(4242)
	mark()
	t.move_vec = Vector2(0, -1)
	await wait(2.0)
	t.move_vec = Vector2.ZERO


var shot_dir := "/tmp/promo/shots"

func still(n: String) -> void:
	await RenderingServer.frame_post_draw
	DirAccess.make_dir_recursive_absolute(shot_dir)
	var img := get_viewport().get_texture().get_image()
	img.convert(Image.FORMAT_RGB8)
	img.save_png("%s/%s.png" % [shot_dir, n])
	print("[PROMO] still ", n)


## Layout survey for picking seeds/spots.
func _s_survey() -> void:
	var seed := 4242
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--seed="):
			seed = int(a.split("=")[1])
	await start_level(seed)
	await wait(2.5)
	var g = w.gen
	print("[SURVEY] seed ", seed, " cells ", g.order.size(), " truck ", w.truck_pos, " back ", g.truck_back, " spawn ", g.spawn_points[0])
	for i in mini(6, g.order.size()):
		print("[SURVEY] cell ", i, " ", g.order[i], " ", g.cell_center(g.order[i]))
	for e in w.extr:
		print("[SURVEY] extr ", e["pos"], " console ", e.get("console"))
	for it in w.items.values():
		if it.base_value > 0:
			print("[SURVEY] item ", it.type, " $", it.value, " ", it.global_position)
	for m in w.monsters.values():
		print("[SURVEY] monster ", m.mtype, " ", m.global_position)
	for m in w.monsters.values():
		m.dormant = 9999.0
	# views
	lp.global_position = g.spawn_points[0]
	lp.yaw = atan2(g.truck_back.x, g.truck_back.z) + PI
	await wait(0.5)
	await still("sv_%d_spawn" % seed)
	for i in [1, 2, 3]:
		var c: Vector3 = g.cell_center(g.order[mini(i, g.order.size() - 1)])
		lp.global_position = c + Vector3(0, 0.1, 2.8)
		lp.yaw = 0.0
		lp.pitch = -0.15
		await wait(0.6)
		await still("sv_%d_cell%d" % [seed, i])
	var e0: Dictionary = w.extr[0]
	lp.global_position = e0["pos"] + Vector3(0, 0.1, 3.2)
	lp.yaw = 0.0
	lp.pitch = -0.3
	await wait(0.6)
	await still("sv_%d_extr" % seed)


func clean_hud() -> void:
	if w == null or w.hud == null:
		return
	for c in w.hud.root.get_children():
		if c is VBoxContainer and c.get_child_count() == 3 and c.get_child(1) is ColorRect:
			c.queue_free()    # level intro card
	if w.hud.msg_box:
		for c in w.hud.msg_box.get_children():
			c.queue_free()


func calm_monsters() -> void:
	for m in w.monsters.values():
		m.dormant = 9999.0


func item_of(types: Array, near := Vector3.INF):
	var best = null
	var bd := 1e9
	for it in w.items.values():
		if it.type in types and it.base_value > 0:
			var d: float = 0.0 if near == Vector3.INF else it.global_position.distance_to(near)
			if d < bd:
				bd = d
				best = it
	return best


func place(p: Vector3, yaw: float, pitch := 0.0) -> void:
	lp.global_position = p
	lp.velocity = Vector3.ZERO
	lp.yaw = yaw
	lp.pitch = pitch


func yaw_to(from: Vector3, to: Vector3) -> float:
	return atan2(-(to.x - from.x), -(to.z - from.z))


const MATES := {
	1001: ["Alpha", 5, {"hat": "tophat", "acc": "bowtie"}],
	1002: ["Bravo", 9, {"hat": "viking", "fin": "gold"}],
	1003: ["Charlie", 12, {"hat": "propeller", "acc": "shades"}],
}
const CREW := [
	{"color": 0, "name": "You", "cos": {"hat": "cap"}},
	{"color": 5, "name": "Alpha", "cos": {"hat": "tophat", "acc": "bowtie"}},
	{"color": 9, "name": "Bravo", "cos": {"hat": "viking", "fin": "gold"}},
	{"color": 12, "name": "Charlie", "cos": {"hat": "propeller", "acc": "shades"}},
]


var MENU_ANG := float(OS.get_environment("MENU_ANG")) if OS.get_environment("MENU_ANG") != "" else 0.0
var MENU_DIST := float(OS.get_environment("MENU_DIST")) if OS.get_environment("MENU_DIST") != "" else 3.6
var MENU_H := float(OS.get_environment("MENU_H")) if OS.get_environment("MENU_H") != "" else 0.45


func _s_menu() -> void:
	main.show_menu()
	await wait(0.4)
	var bg = main.menu_bg
	bg.set_players(CREW)
	# two rows so the whole crew fits in the garage doorway
	# the crew steps out of the garage doorway into the lit room in front of it
	var rows := [Vector2(-0.45, -2.3), Vector2(0.47, -2.25), Vector2(-1.2, -1.6), Vector2(1.22, -1.55)]
	for i in bg.robots.size():
		var r: Node3D = bg.robots[i]["node"]
		var o: Vector2 = rows[i]
		r.global_position = bg.center + bg.side * o.x + bg.back * o.y
		r.basis = Basis.looking_at(-bg.back.rotated(Vector3.UP, -o.x * 0.25), Vector3.UP)
	main.screen.visible = false
	bg.set_process(false)
	var focus: Vector3 = bg.center - bg.back * 1.95 + Vector3(0, 0.95, 0)
	# soft warm fill from the camera side so the crew reads on a phone screen
	var fill := OmniLight3D.new()
	fill.light_color = Color(1.0, 0.86, 0.7)
	fill.light_energy = 1.6
	fill.omni_range = 6.0
	bg.add_child(fill)
	fill.global_position = focus - bg.back * 2.2 + Vector3(0, 1.1, 0)
	var t0 := 0.0
	var marked := false
	while t0 < 5.8:
		bg._process(get_process_delta_time())    # idle animations and flickering lamps
		var k := t0 / 5.8
		var dir: Vector3 = (-bg.back).rotated(Vector3.UP, MENU_ANG - k * 0.16)
		bg.cam.global_position = focus + dir * (MENU_DIST - k * 0.7) + Vector3(0, MENU_H, 0)
		bg.cam.look_at(focus + Vector3(0, 0.5, 0), Vector3.UP)    # crew in the lower half, logo above
		bg.cam.h_offset = 0.0
		if t0 >= 0.3 and not marked:
			marked = true
			mark()
		if absf(t0 - 2.4) < 0.02:
			await still("menu")
		t0 += get_process_delta_time()
		await get_tree().process_frame


func _s_explore() -> void:
	await start_level(777)
	calm_monsters()
	var g = w.gen
	mark()
	var pts: Array = g.path_points(lp.global_position, g.cell_center(g.order[2]) + Vector3(0, 0, 1.5))
	for i in pts.size():
		await walk_to(pts[i], 0.85)
		if i == 2:
			await still("explore")
	await turn_to(g.cell_center(g.order[4]) + Vector3(0, 1.2, 0), 0.8)
	await wait(0.6)


func _s_grab() -> void:
	await start_level(777)
	calm_monsters()
	clean_hud()
	var it = item_of(["gem", "camera", "trophy"], Vector3(5.15, 1.0, -5.2))
	var ip: Vector3 = it.global_position
	var stand := ip + Vector3(1.9, 0, 1.2)
	stand.y = 0.1
	place(stand, yaw_to(stand, ip), -0.25)
	await wait(0.4)
	clean_hud()
	mark()
	await turn_to(ip, 0.5)
	await wait(0.5)
	await tap("grab")
	await frames(2)
	if lp.grabbed_id == -1:
		lp.grab_direct(it.item_id)
	await wait(0.6)
	await still("grab")
	# pull it closer and walk with it
	t.buttons["pull"]["down"] = true
	await wait(0.5)
	t.buttons["pull"]["down"] = false
	await walk_to(stand + Vector3(1.5, 0, -1.0), 0.6, false)
	await wait(0.4)
	# careful: a hard throw into the wall costs money (fragile!)
	await turn_to(stand + Vector3(4.0, 1.2, 0.0), 0.35)
	await tap("throw")
	await wait(0.25)
	await still("fragile")
	await wait(1.6)


func _s_extract() -> void:
	await start_level(777)
	calm_monsters()
	var e: Dictionary = w.extr[0]
	var k := 0
	for it in w.items.values():
		if it.base_value > 0 and k < 6 and not (it.type in ["safe", "statue", "server", "aquarium"]):
			it.teleport(e["pos"] + Vector3(-0.7 + (k % 3) * 0.7, 0.5, -0.4 + (k / 3) * 0.8))
			k += 1
	var cpos: Vector3 = e["console"]
	var cdir: Vector3 = (cpos - e["pos"]).normalized()
	var side := Vector3(-cdir.z, 0, cdir.x)
	var stand: Vector3 = cpos - cdir * 0.2 + side * 1.4
	stand.y = 0.1
	place(stand, yaw_to(stand, e["pos"] + side * 0.4), -0.3)
	await wait(1.5)
	clean_hud()
	mark()
	await wait(0.6)
	await turn_to(cpos + Vector3(0, 1.1, 0), 0.5)
	await tap("use")
	w._try_extract(0)
	# back off so the whole tube is in view when it comes down
	var away: Vector3 = stand - e["pos"]
	away.y = 0.0
	away = away.normalized()
	await turn_to(e["pos"] + Vector3(0, 1.3, 0), 0.5)
	await walk_to(stand + away * 1.9, 0.75, false)
	await turn_to(e["pos"] + Vector3(0, 1.7, 0), 0.4)
	await wait(0.9)
	await still("extract")
	await wait(2.6)


func _s_monster() -> void:
	await start_level(777)
	calm_monsters()
	var g = w.gen
	var a: Vector3 = g.cell_center(g.order[2])
	var b: Vector3 = g.cell_center(g.order[4])
	place(a + Vector3(0, 0.1, 1.0), yaw_to(a, b), 0.02)
	var mid: int = w.spawn_monster("lurker", b + Vector3(0, 0.1, -2.0))
	var m = w.monsters[mid]
	await wait(0.8)
	clean_hud()
	mark()
	t.move_vec = Vector2(0, -0.45)
	await wait(0.6)
	t.move_vec = Vector2.ZERO
	m.dormant = 0.0
	m.target_pid = lp.peer_id
	m.state = 2
	await wait(1.3)
	await still("monster")
	await wait(0.6)
	# run!
	await tap("sprint")
	await turn_to(a + Vector3(0, 1.4, 8.0), 0.35, 0.0)
	var back: Vector3 = a + Vector3(0, 0.1, 9.0)
	await walk_to(back, 1.0, false)
	await wait(2.2)


func _s_coop() -> void:
	await start_level(777, 1, MATES)
	calm_monsters()
	var g = w.gen
	var c: Vector3 = g.cell_center(g.order[1])
	# a heavy grandfather clock in the middle of the room: four beams lift it together
	var gid: int = w.spawn_item("statue", 12000, c + Vector3(0, 0.1, -1.0), Quaternion.IDENTITY, 0)
	var big = w.items[gid]
	var spots := {1001: Vector3(-2.4, 0.1, -2.2), 1002: Vector3(2.5, 0.1, -2.0), 1003: Vector3(-1.2, 0.1, -3.9)}
	for pid in spots:
		var p = w.players[pid]
		p.global_position = c + spots[pid]
		p.set_net(c + spots[pid], yaw_to(c + spots[pid], big.global_position), 0.0, gid)
		p.expr = 32
	place(c + Vector3(0.3, 0.1, 3.3), yaw_to(c + Vector3(0.3, 0, 3.3), big.global_position), -0.02)
	await wait(0.8)
	lp.grab_direct(gid)
	lp.hold_dist = 3.2
	clean_hud()
	mark()
	var t0 := 0.0
	while t0 < 5.6:
		var lift := minf(1.2, t0 * 0.6)
		var tgt: Vector3 = c + Vector3(sin(t0 * 0.7) * 0.8, 0.6 + lift, -1.0)
		for pid in spots:
			w.grabs[pid] = {"id": gid, "target": tgt, "offset": Vector3.ZERO, "t": w.game_time, "kind": "item"}
			var pp: Vector3 = c + spots[pid] + Vector3(sin(t0 * 0.7) * 0.5, 0, 0)
			w.players[pid].set_net(pp, yaw_to(pp, big.global_position), atan2(big.global_position.y - 1.4, pp.distance_to(big.global_position)), gid)
		if absf(t0 - 1.0) < 0.02:
			w._show_bubble(1003, "Lift it together!")
		if absf(t0 - 2.6) < 0.02:
			w._show_bubble(1001, "To the van!")
		if absf(t0 - 3.4) < 0.02:
			await still("coop")
		t0 += get_physics_process_delta_time()
		await get_tree().physics_frame
	for pid in spots:
		w.grabs.erase(pid)


func _s_shop() -> void:
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.money = 64000
	Net.level = 3
	Net.begin_shop({})
	await wait(1.5)
	w = main.world
	lp = w.local_player
	t = w.hud.touch
	var cc: Vector3 = w.gen.cell_center(Vector2i(1, 0))
	place(cc + Vector3(-3.4, 0.1, 0.4), -PI / 2, -0.12)
	await wait(0.8)
	clean_hud()
	mark()
	await walk_to(cc + Vector3(-0.8, 0.1, 0.3), 0.5, false)
	await wait(0.3)
	await still("shop")
	await turn_to(cc + Vector3(1.0, 0.6, 2.2), 0.8)
	await wait(1.8)


func _s_arena() -> void:
	Net.delete_save()
	Net.start_solo(false)
	await wait(0.3)
	for pid in MATES:
		var mt: Array = MATES[pid]
		Net.players[pid] = {"name": mt[0], "color": mt[1], "uid": "fake%d" % pid, "cos": mt[2]}
		Net._init_player_run(pid)
	Net._load_arena(1234, 3)
	await wait(0.3)
	w = main.world
	for pid in MATES:
		w.ready_peers[pid] = true
	w._try_start()
	await wait(0.6)
	lp = w.local_player
	t = w.hud.touch
	var spots := {1001: Vector3(3.2, 0.3, -2.0), 1002: Vector3(-3.0, 0.3, -2.8), 1003: Vector3(0.6, 0.3, -5.6)}
	for pid in spots:
		w.players[pid].global_position = spots[pid]
		w.players[pid].set_net(spots[pid], yaw_to(spots[pid], Vector3(0, 0, 3)), 0.0, -1)
		w.players[pid].expr = 1
	place(Vector3(0, 0.3, 4.2), 0.0, -0.18)
	await wait(0.5)
	clean_hud()
	mark()
	w.arena_t = 15.0
	var t0 := 0.0
	var fall_dir := Vector3(-1.0, 0, -0.35).normalized()
	var y_start: float = lp.yaw
	while t0 < 5.6:
		for pid in spots:
			var pp: Vector3 = spots[pid] + Vector3(sin(t0 * 1.3 + pid) * 0.8, 0, cos(t0 * 1.1 + pid) * 0.5)
			if pid == 1002 and t0 > 1.2:
				# Bravo backs off the rim and drops into the pit
				pp = spots[pid] + fall_dir * (t0 - 1.2) * 3.2
				var r := Vector2(pp.x, pp.z).length()
				pp.y = 0.3 - maxf(0.0, r - 9.0) * 2.2
			w.players[pid].set_net(pp, yaw_to(pp, lp.global_position), 0.0, -1)
		lp.yaw = lerp_angle(y_start, y_start + 0.35, smoothstep(1.0, 3.2, t0))
		if absf(t0 - 2.2) < 0.02:
			await still("arena")
		t0 += get_physics_process_delta_time()
		await get_tree().physics_frame


func _s_collection() -> void:
	main.show_collection()
	await wait(0.6)
	var cs = main.screen
	mark()
	await wait(0.8)
	for k in ["hat:viking", "acc:scarf", "hat:halo"]:
		var b: Button = cs.tiles[k]
		var c := b.get_global_rect().get_center()
		await _click(c)
		await wait(0.7)
		cs = main.screen
	await still("collection")
	await wait(1.4)


func _click(p: Vector2) -> void:
	for down in [true, false]:
		var mb := InputEventMouseButton.new()
		mb.button_index = MOUSE_BUTTON_LEFT
		mb.pressed = down
		mb.position = p
		mb.global_position = p
		get_viewport().push_input(mb, true)
		await frames(3)


## Grab in the lit chandelier room: beam a vase up, carry it, knock it, throw it.
func _s_grab2() -> void:
	await start_level(777)
	calm_monsters()
	var g = w.gen
	var c: Vector3 = g.cell_center(g.order[1])
	var vid: int = w.spawn_item("vase", 4200, c + Vector3(0.6, 0.4, -0.2), Quaternion.IDENTITY, 0)
	var it = w.items[vid]
	var stand := c + Vector3(-0.2, 0.1, 2.6)
	place(stand, yaw_to(stand, c + Vector3(0.6, 0, -0.2)), -0.3)
	await wait(1.2)
	clean_hud()
	mark()
	await wait(0.4)
	await turn_to(it.global_position, 0.4)
	await wait(0.3)
	await tap("grab")
	await frames(2)
	if lp.grabbed_id == -1:
		lp.grab_direct(vid)
	lp.hold_dist = 2.2
	await turn_to(it.global_position + Vector3(0, 1.0, 0), 0.6)
	await wait(0.5)
	await still("grab")
	# walk with it, then swing it into the wall: a hit costs money
	await walk_to(stand + Vector3(1.7, 0, -0.9), 0.55, false)
	lp.hold_dist = 2.6
	var y0: float = lp.yaw
	for i in 18:
		lp.yaw = y0 - 0.13 * i
		await get_tree().physics_frame
	await wait(0.6)
	await still("fragile")
	await turn_to(c + Vector3(-2.5, 1.2, -3.2), 0.4)
	await tap("throw")
	await wait(1.6)


## Shop: walk up to the shelves, aim at a weapon (price tag), beam it off the shelf.
func _s_shop2() -> void:
	Net.delete_save()
	Net.start_solo(true)
	Net._new_run()
	Net.money = 64000
	Net.level = 3
	Net.begin_shop({})
	await wait(1.5)
	w = main.world
	lp = w.local_player
	t = w.hud.touch
	var cc: Vector3 = w.gen.cell_center(Vector2i(1, 0))
	var best = null
	var bd := 1e9
	for it in w.items.values():
		if it.is_shop() and (it.type.begins_with("w_") or it.type.begins_with("d_")):
			var d: float = it.global_position.distance_to(cc)
			if d < bd:
				bd = d
				best = it
	var ip: Vector3 = best.global_position
	var out: Vector3 = cc - ip
	out.y = 0.0
	out = out.normalized()
	var stand: Vector3 = ip + out * 2.6
	stand.y = 0.1
	var start: Vector3 = stand + out * 1.6 + out.rotated(Vector3.UP, PI / 2) * 1.0
	start.y = 0.1
	place(start, yaw_to(start, ip), -0.1)
	await wait(0.8)
	clean_hud()
	mark()
	await walk_to(stand, 0.6, false)
	await turn_to(ip, 0.4)
	await wait(0.5)
	await still("shop")
	await tap("grab")
	await frames(2)
	if lp.grabbed_id == -1:
		lp.grab_direct(best.item_id)
	lp.hold_dist = 1.6
	await wait(1.6)
