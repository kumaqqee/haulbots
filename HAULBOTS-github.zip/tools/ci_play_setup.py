"""Prepares the project for the Google Play build (used by .github/workflows/android.yml).
- enables the Google Play Billing and AdMob editor plugins (their exporters add the native libraries)
- writes the AdMob App ID into Project Settings (a GitHub secret; Google's test App ID if empty)
- writes the AdMob rewarded ad unit into scripts/monetization_config.gd (a GitHub secret; test unit if empty)
- patches the Android build template to compile/target API 36 (Google Play rule since Aug 2026)
Usage: python3 tools/ci_play_setup.py [admob_app_id] [rewarded_unit_id]"""
import os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
app_id = (sys.argv[1] if len(sys.argv) > 1 else "").strip() or TEST_APP_ID
unit = (sys.argv[2] if len(sys.argv) > 2 else "").strip()
for v, pat in ((app_id, r"^ca-app-pub-\d+~\d+$"), (unit, r"^(ca-app-pub-\d+/\d+)?$")):
    if not re.match(pat, v):
        sys.exit("AdMob id looks wrong: %r (App ID has '~', ad unit has '/')" % v)

p = os.path.join(ROOT, "project.godot")
s = open(p, encoding="utf-8").read()
plugins = 'enabled=PackedStringArray("res://addons/GodotGooglePlayBilling/plugin.cfg", "res://addons/admob/plugin.cfg")'
if "[editor_plugins]" in s:
    s = re.sub(r"\[editor_plugins\]\s*\n\s*enabled=PackedStringArray\([^)]*\)", "[editor_plugins]\n\n" + plugins, s)
else:
    s = s.rstrip("\n") + "\n\n[editor_plugins]\n\n" + plugins + "\n"
s = re.sub(r"\n\[admob\][^\[]*", "\n", s)
s = s.rstrip("\n") + '\n\n[admob]\n\ngeneral/android/enabled=true\ngeneral/android/app_id="%s"\ngeneral/ios/enabled=false\n' % app_id
open(p, "w", encoding="utf-8").write(s)
print("project.godot: plugins enabled, AdMob app id", "TEST" if app_id == TEST_APP_ID else app_id[:24] + "…")

if unit:
    mp = os.path.join(ROOT, "scripts", "monetization_config.gd")
    m = open(mp, encoding="utf-8").read()
    m = re.sub(r'const REWARDED_UNIT_ANDROID := "[^"]*"', 'const REWARDED_UNIT_ANDROID := "%s"' % unit, m)
    open(mp, "w", encoding="utf-8").write(m)
    print("monetization_config.gd: rewarded unit", unit[:24] + "…")
else:
    print("monetization_config.gd: rewarded unit unchanged (test unit unless you edited it)")

cfg = os.path.join(ROOT, "android", "build", "config.gradle")
if os.path.exists(cfg):
    c = open(cfg, encoding="utf-8").read()
    c = re.sub(r"compileSdk\s*:\s*\d+", "compileSdk         : 36", c)
    c = re.sub(r"targetSdk\s*:\s*\d+", "targetSdk          : 36", c)
    open(cfg, "w", encoding="utf-8").write(c)
    gp = os.path.join(ROOT, "android", "build", "gradle.properties")
    g = open(gp, encoding="utf-8").read() if os.path.exists(gp) else ""
    if "suppressUnsupportedCompileSdk" not in g:
        g = g.rstrip("\n") + "\nandroid.suppressUnsupportedCompileSdk=36\n"
        open(gp, "w", encoding="utf-8").write(g)
    print("android/build: compile/target SDK 36")
else:
    print("android/build not installed yet — run again after installing the build template")
