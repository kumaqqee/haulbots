"""Gear, shop items and mission objects, art v3."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *

STEEL = "L_metal_8a8f99"
DARK = "L_metal_2a2d33"
GUN = "L_metal_25272c"
GRIP = "L_rubber_1c1d22"
HAZ = "L_paint_e8b420"


def ycyl(r, length, y, z=0.0, x=0.0, material=STEEL, verts=16, r2=None, bevel=0.0):
    """Cylinder along +Y centred at (x, y, z)."""
    return cyl(r, length, (x, y, z), material, verts, r2=r2, rot=(-math.pi / 2, 0, 0), bevel=bevel)


# ---------------------------------------------------------------- the grab gadget (first person)
def gadget():
    reset()
    Z = 0.062
    P = "M_player"
    body = [ycyl(0.046, 0.26, 0.0, Z, material="L_metal_3a3f47", verts=24, bevel=0.01),
            ycyl(0.058, 0.06, 0.16, Z, material="L_metal_2a2d33", verts=24, bevel=0.008),
            ycyl(0.064, 0.025, 0.2, Z, material=P, verts=24, bevel=0.005),
            ycyl(0.05, 0.02, 0.22, Z, material="L_metal_15161a", verts=24),
            ycyl(0.036, 0.012, 0.232, Z, material="M_player_glow", verts=24)]
    rings = [ycyl(0.05, 0.012, y, Z, material=P, verts=24) for y in (-0.06, 0.02, 0.1)]
    coils = [ycyl(0.049, 0.01, -0.02 + i * 0.02, Z, material="L_metal_b06a2a", verts=20) for i in range(3)]
    top = box((0.05, 0.16, 0.03), (0, 0.0, Z + 0.055), "L_metal_2a2d33", 0.008)
    vents = [box((0.04, 0.008, 0.012), (0, -0.05 + i * 0.025, Z + 0.072), "L_metal_15161a", 0.0) for i in range(4)]
    tank = cyl(0.022, 0.09, (0.05, -0.05, Z + 0.02), "G_ffffff", 12, rot=(-math.pi / 2, 0, 0))
    tank_glow = cyl(0.016, 0.08, (0.05, -0.05, Z + 0.02), "M_player_glow", 10, rot=(-math.pi / 2, 0, 0))
    tank_caps = [ycyl(0.025, 0.012, y, Z + 0.02, x=0.05, material=DARK) for y in (-0.1, 0.0)]
    grip = box((0.04, 0.05, 0.14), (0, -0.09, -0.03), GRIP, 0.012, rot=(-0.25, 0, 0))
    trig = box((0.012, 0.02, 0.035), (0, -0.04, 0.005), "L_metal_9a9ea8", 0.004)
    guard = skin([(0, -0.06, 0.02, 0.006), (0, -0.03, -0.01, 0.006), (0, -0.065, -0.025, 0.006)], material=DARK, subdiv=1)
    back = ycyl(0.04, 0.05, -0.15, Z, material=DARK, verts=20, bevel=0.008)
    cable = skin([(0, -0.17, Z - 0.02, 0.008), (0.02, -0.18, -0.03, 0.008), (0.01, -0.13, -0.08, 0.007)], material="L_rubber_c03020", subdiv=1)
    parts = body + rings + coils + vents + tank_caps + [top, tank, tank_glow, grip, trig, guard, back, cable]
    o = join(parts, "gadget")
    set_origin(o, (0, 0, 0))
    save("gadget", [o], tex=256, tris=2500, split=False)


# ---------------------------------------------------------------- weapons
def w_bat():
    reset()
    bat = lathe([(0.016, 0.0), (0.02, 0.01), (0.017, 0.03), (0.017, 0.22), (0.024, 0.4), (0.035, 0.58), (0.038, 0.66), (0.034, 0.69), (0.0, 0.7)], "L_wood_9a6a3a", 16)
    knob = cyl(0.024, 0.015, (0, 0, 0.005), "L_wood_6a4a2a", 14)
    tape = cyl(0.02, 0.17, (0, 0, 0.11), "L_fabric_2a2a2a", 14)
    tape2 = cyl(0.033, 0.05, (0, 0, 0.5), "L_fabric_d8d0b0", 14)
    nails = []
    for i in range(7):
        a = i * 2.3
        z = 0.5 + (i % 4) * 0.045
        r = 0.026 + 0.01 * (z - 0.5) / 0.15
        n = cyl(0.003, 0.06, (math.cos(a) * r, math.sin(a) * r, z), STEEL, 4, rot=(0, math.pi / 2, a))
        nails.append(n)
    j = join([bat, knob, tape, tape2] + nails, "bat")
    j.rotation_euler = (-math.pi / 2, 0, 0)
    j.location = (0, -0.35, 0)
    prop_save("w_bat", [j], tris=800, center=True)


def w_sledge():
    reset()
    handle = cyl(0.018, 0.8, (0, 0, 0.4), "L_wood_8a5a32", 10)
    grip = cyl(0.021, 0.18, (0, 0, 0.1), GRIP, 10)
    head = box((0.24, 0.08, 0.09), (0, 0, 0.82), DARK, 0.012)
    faces = [cyl(0.05, 0.02, (s * 0.125, 0, 0.82), "L_metal_9a9ea8", 14, rot=(0, math.pi / 2, 0), bevel=0.005) for s in (1, -1)]
    wedge = box((0.04, 0.09, 0.03), (0, 0, 0.775), "L_metal_5a5e66", 0.004)
    stripe = box((0.06, 0.082, 0.092), (0, 0, 0.82), HAZ, 0.0)
    j = join([handle, grip, head, wedge, stripe] + faces, "sl")
    j.rotation_euler = (-math.pi / 2, 0, 0)
    prop_save("w_sledge", [j], tris=600, center=True)


def w_pan():
    reset()
    pan = lathe([(0.0, 0.0), (0.12, 0.0), (0.135, 0.01), (0.14, 0.045), (0.133, 0.047), (0.127, 0.012), (0.0, 0.012)], "L_metal_2a2a2e", 28)
    handle = box((0.03, 0.2, 0.02), (0, -0.23, 0.035), "L_wood_3a2414", 0.008, rot=(0.15, 0, 0))
    rivet = sphere(0.008, (0, -0.135, 0.04), STEEL, 6, 3)
    egg = [cyl(0.05, 0.004, (0.02, 0.02, 0.013), "L_paint_f0ece0", 14), sphere(0.02, (0.02, 0.02, 0.016), "L_paint_e8a020", 10, 5, (1, 1, 0.5))]
    prop_save("w_pan", [pan, handle, rivet] + egg, tris=600, center=True)


def w_prod():
    reset()
    shaft = ycyl(0.016, 0.4, 0.1, material="L_plastic_1a1c22", verts=12)
    grip = ycyl(0.022, 0.16, -0.17, material=GRIP, verts=12)
    guard = ycyl(0.03, 0.02, -0.08, material=HAZ, verts=12)
    box_ = box((0.04, 0.06, 0.04), (0, -0.04, 0.02), HAZ, 0.008)
    tips = [ycyl(0.004, 0.06, 0.33, x=s * 0.012, material=STEEL, verts=6) for s in (1, -1)]
    spark = sphere(0.018, (0, 0.37, 0), "E_7ad8ff", 8, 4)
    led = box((0.012, 0.012, 0.006), (0, -0.03, 0.042), "E_4aff7a", 0.002)
    prop_save("w_prod", [shaft, grip, guard, box_, spark, led] + tips, tris=600, center=True)


def w_pistol():
    reset()
    slide = box((0.03, 0.17, 0.035), (0, 0.02, 0.06), GUN, 0.006)
    frame = box((0.028, 0.15, 0.025), (0, 0.015, 0.03), "L_metal_3a3d44", 0.005)
    grip = box((0.03, 0.045, 0.1), (0, -0.04, -0.02), GRIP, 0.008, rot=(-0.25, 0, 0))
    barrel = ycyl(0.008, 0.02, 0.11, 0.06, material="L_metal_101012", verts=10)
    tg = skin([(0, 0.0, 0.02, 0.004), (0, 0.03, -0.005, 0.004), (0, -0.005, -0.01, 0.004)], material=GUN, subdiv=1)
    sights = [box((0.006, 0.01, 0.01), (0, y, 0.082), "L_metal_101012", 0.0) for y in (-0.05, 0.095)]
    dot = box((0.004, 0.004, 0.004), (0, 0.095, 0.088), "E_4aff7a", 0.0)
    prop_save("w_pistol", [slide, frame, grip, barrel, tg, dot] + sights, tris=500, center=True)


def w_shotgun():
    reset()
    barrel = ycyl(0.016, 0.45, 0.17, 0.05, material=GUN, verts=12)
    tube = ycyl(0.014, 0.36, 0.12, 0.022, material=GUN, verts=12)
    pump = ycyl(0.022, 0.12, 0.15, 0.025, material="L_wood_6a3a1c", verts=12, bevel=0.004)
    recv = box((0.036, 0.16, 0.06), (0, -0.1, 0.035), "L_metal_3a3d44", 0.008)
    stock = box((0.035, 0.24, 0.07), (0, -0.3, 0.0), "L_wood_6a3a1c", 0.012, rot=(0.18, 0, 0))
    pad = box((0.037, 0.02, 0.08), (0, -0.425, -0.025), GRIP, 0.006, rot=(0.18, 0, 0))
    tg = skin([(0, -0.08, 0.0, 0.004), (0, -0.05, -0.025, 0.004), (0, -0.09, -0.03, 0.004)], material=GUN, subdiv=1)
    shells = [cyl(0.008, 0.03, (0.02, -0.1 + i * 0.022, 0.04), "L_plastic_c0302a", 8) for i in range(3)]
    prop_save("w_shotgun", [barrel, tube, pump, recv, stock, pad, tg] + shells, tris=700, center=True)


def w_tranq():
    reset()
    body = box((0.034, 0.2, 0.05), (0, 0.0, 0.05), "L_plastic_e8e4da", 0.012)
    barrel = ycyl(0.01, 0.16, 0.16, 0.06, material=DARK, verts=10)
    vial = cyl(0.016, 0.06, (0, -0.02, 0.095), "G_d8f0ff", 12)
    liq = cyl(0.012, 0.045, (0, -0.02, 0.092), "E_4aff7a", 10)
    grip = box((0.03, 0.045, 0.1), (0, -0.07, -0.01), "L_plastic_2a6a4a", 0.008, rot=(-0.25, 0, 0))
    stripe = box((0.036, 0.04, 0.052), (0, 0.06, 0.05), "L_plastic_2a6a4a", 0.006)
    dart = [ycyl(0.004, 0.05, 0.25, 0.06, material=STEEL, verts=6), cyl(0.008, 0.012, (0, 0.27, 0.06), "L_plastic_e8b420", 6, r2=0.0, rot=(-math.pi / 2, 0, 0))]
    prop_save("w_tranq", [body, barrel, vial, liq, grip, stripe] + dart, tris=600, center=True)


def w_duck():
    reset()
    Y = "L_plastic_f0c020"
    body = meta("b", [("ell", (0, -0.02, 0.07), 0.08, (1.0, 1.25, 0.8)), ("ell", (0, -0.1, 0.1), 0.03, (0.8, 1.0, 0.8))], Y, 0.012)
    head = sphere(0.055, (0, 0.06, 0.15), Y, 16, 8)
    beak = meta("bk", [("ell", (0, 0.115, 0.14), 0.03, (1.1, 1.2, 0.45))], "L_plastic_e86a1a", 0.008)
    eyes = [sphere(0.009, (s * 0.025, 0.105, 0.165), "C_101010", 6, 3) for s in (1, -1)]
    prop_save("w_duck", [body, head, beak] + eyes, tris=900, center=True)


# ---------------------------------------------------------------- throwables & mines
def g_explosive():
    reset()
    body = meta("b", [("ell", (0, 0, 0.06), 0.055, (1.0, 1.0, 1.2))], "L_metal_4a5a3a", 0.008)
    grooves = [lathe([(0.05, z - 0.003), (0.057, z), (0.05, z + 0.003)], "L_metal_2a3a1e", 16, cap_bottom=False) for z in (0.035, 0.06, 0.085)]
    cap = cyl(0.022, 0.03, (0, 0, 0.13), DARK, 10)
    lever = box((0.015, 0.06, 0.008), (0, 0.022, 0.12), STEEL, 0.003, rot=(0.4, 0, 0))
    ring = lathe([(0.015, -0.003), (0.02, 0.0), (0.015, 0.003)], STEEL, 12, cap_bottom=False, pos=(0.025, 0, 0.145))
    ring.rotation_euler = (0, math.pi / 2, 0)
    prop_save("g_explosive", [body, cap, lever, ring] + grooves, tris=600, center=True)


def g_stun():
    reset()
    body = cyl(0.04, 0.11, (0, 0, 0.055), "L_metal_c8ccd0", 14, bevel=0.006)
    holes = [cyl(0.008, 0.012, (math.cos(a) * 0.04, math.sin(a) * 0.04, z), "L_metal_15161a", 6, rot=(0, math.pi / 2, a)) for a in [i * 1.05 for i in range(6)] for z in (0.04, 0.075)]
    band = cyl(0.042, 0.02, (0, 0, 0.1), HAZ, 14)
    cap = cyl(0.02, 0.025, (0, 0, 0.12), DARK, 10)
    lever = box((0.015, 0.05, 0.008), (0, 0.02, 0.115), STEEL, 0.003, rot=(0.4, 0, 0))
    prop_save("g_stun", [body, band, cap, lever] + holes, tris=600, center=True)


def g_shock():
    reset()
    core = sphere(0.045, (0, 0, 0.06), "E_5ae8ff", 12, 6)
    cage = [lathe([(0.055, -0.004), (0.06, 0.0), (0.055, 0.004)], "L_metal_b06a2a", 16, cap_bottom=False, pos=(0, 0, 0.06)) for _ in range(3)]
    for i, c in enumerate(cage):
        c.rotation_euler = (math.pi / 2, 0, i * math.pi / 3)
    caps = [cyl(0.03, 0.03, (0, 0, z), DARK, 12, bevel=0.005) for z in (0.0, 0.12)]
    pin = cyl(0.006, 0.03, (0, 0, 0.145), STEEL, 6)
    prop_save("g_shock", [core, pin] + cage + caps, tris=700, center=True)


def m_explosive():
    reset()
    body = cyl(0.15, 0.05, (0, 0, 0.025), "L_metal_4a5a3a", 24, bevel=0.01)
    top = cyl(0.11, 0.015, (0, 0, 0.055), "L_metal_3a4a2e", 24, bevel=0.004)
    plate = cyl(0.05, 0.012, (0, 0, 0.067), DARK, 16)
    led = sphere(0.012, (0.0, 0.07, 0.065), "E_ff2a14", 8, 4)
    bolts = [sphere(0.01, (math.cos(a) * 0.13, math.sin(a) * 0.13, 0.05), STEEL, 6, 3) for a in [i * math.tau / 6 for i in range(6)]]
    stripe = [box((0.06, 0.01, 0.02), (math.cos(a) * 0.15, math.sin(a) * 0.15, 0.03), HAZ, 0.0, rot=(0, 0, a + math.pi / 2)) for a in [i * math.tau / 8 for i in range(8)]]
    prop_save("m_explosive", [body, top, plate, led] + bolts + stripe, tris=700, center=True)


def m_stun():
    reset()
    body = cyl(0.14, 0.05, (0, 0, 0.025), HAZ, 24, bevel=0.01)
    top = cyl(0.1, 0.02, (0, 0, 0.055), DARK, 24, bevel=0.004)
    coil = [lathe([(0.06 + i * 0.015, -0.004), (0.063 + i * 0.015, 0.0), (0.06 + i * 0.015, 0.004)], "E_5ae8ff", 20, cap_bottom=False, pos=(0, 0, 0.068)) for i in range(2)]
    led = sphere(0.012, (0.0, 0.0, 0.07), "E_5ae8ff", 8, 4)
    prop_save("m_stun", [body, top, led] + coil, tris=600, center=True)


# ---------------------------------------------------------------- drones & trackers
def _drone(name, accent, emblem):
    reset()
    hull = meta("hull", [("ell", (0, 0, 0.04), 0.07, (1.0, 1.0, 0.45))], "L_plastic_2a2c33", 0.01)
    shell = meta("shell", [("ell", (0, 0, 0.055), 0.06, (1.0, 1.0, 0.35))], accent, 0.01)
    eye = sphere(0.018, (0, 0.06, 0.04), "E_" + emblem, 8, 4)
    arms, rotors = [], []
    for a in (math.pi / 4, 3 * math.pi / 4, 5 * math.pi / 4, 7 * math.pi / 4):
        x, y = math.cos(a) * 0.1, math.sin(a) * 0.1
        arms.append(box((0.1, 0.018, 0.012), (x / 2, y / 2, 0.04), "L_plastic_2a2c33", 0.004, rot=(0, 0, a)))
        rotors.append(cyl(0.022, 0.025, (x, y, 0.045), DARK, 10))
        rotors.append(cyl(0.045, 0.004, (x, y, 0.06), "G_c8d0d8", 16))
        rotors.append(lathe([(0.046, 0.0), (0.05, 0.0), (0.05, 0.012), (0.046, 0.012)], accent, 16, cap_bottom=False, pos=(x, y, 0.052)))
    skid = [box((0.008, 0.12, 0.008), (s * 0.04, 0, 0.004), DARK, 0.002) for s in (1, -1)]
    mark = cyl(0.025, 0.004, (0, 0, 0.075), "E_" + emblem, 12)
    prop_save(name, [hull, shell, eye, mark] + arms + rotors + skid, tris=1200, center=True)


def d_feather():
    _drone("d_feather", "L_plastic_e8e4da", "ffffff")


def d_shield():
    _drone("d_shield", "L_plastic_2a6ad8", "5ad8ff")


def d_recharge():
    _drone("d_recharge", "L_plastic_3aa040", "4aff7a")


def d_zerog():
    _drone("d_zerog", "L_plastic_8a3ad8", "c87aff")


def t_valuable():
    reset()
    body = box((0.1, 0.05, 0.14), (0, 0, 0.07), HAZ, 0.012)
    scr = box((0.075, 0.01, 0.07), (0, 0.026, 0.09), "L_plastic_101012", 0.004)
    sweep = cyl(0.03, 0.004, (0, 0.032, 0.09), "E_4aff7a", 16, rot=(math.pi / 2, 0, 0))
    rings = [lathe([(0.02 + i * 0.008, -0.001), (0.022 + i * 0.008, 0.0), (0.02 + i * 0.008, 0.001)], "E_1a8a3a", 16, cap_bottom=False, pos=(0, 0.035, 0.09)) for i in range(2)]
    for r in rings:
        r.rotation_euler = (math.pi / 2, 0, 0)
    ant = cyl(0.005, 0.06, (0.035, 0, 0.17), DARK, 6)
    knob = sphere(0.009, (0.035, 0, 0.2), "E_ff3a2a", 6, 3)
    btn = [box((0.016, 0.01, 0.01), (x, 0.027, 0.035), "L_plastic_2a2c33", 0.002) for x in (-0.02, 0.02)]
    prop_save("t_valuable", [body, scr, sweep, ant, knob] + rings + btn, tris=500, center=True)


def t_extract():
    reset()
    body = box((0.09, 0.045, 0.13), (0, 0, 0.065), "L_plastic_2a6ad8", 0.012)
    scr = box((0.07, 0.01, 0.06), (0, 0.024, 0.085), "L_plastic_101012", 0.004)
    arrow = cyl(0.022, 0.004, (0, 0.03, 0.085), "E_5ad8ff", 3, rot=(math.pi / 2, 0, 0))
    ant = cyl(0.005, 0.05, (-0.03, 0, 0.155), DARK, 6)
    led = sphere(0.008, (0.03, 0.024, 0.03), "E_4aff7a", 6, 3)
    prop_save("t_extract", [body, scr, arrow, ant, led], tris=400, center=True)


# ---------------------------------------------------------------- medkits & misc
def _medkit(name, w, d, h):
    reset()
    body = box((w, d, h), (0, 0, h / 2), "L_plastic_e8e4da", 0.015)
    band = box((w + 0.004, d * 0.25, h + 0.004), (0, 0, h / 2), "L_plastic_c0302a", 0.008)
    cross = [box((w * 0.32, 0.01, h * 0.12), (0, d / 2 + 0.003, h / 2), "L_plastic_c0302a", 0.002), box((w * 0.1, 0.01, h * 0.42), (0, d / 2 + 0.003, h / 2), "L_plastic_c0302a", 0.002)]
    handle = skin([(-w * 0.2, 0, h, 0.008), (-w * 0.15, 0, h + 0.04, 0.008), (w * 0.15, 0, h + 0.04, 0.008), (w * 0.2, 0, h, 0.008)], material=GRIP, subdiv=1)
    latches = [box((0.02, 0.012, 0.025), (s * w * 0.35, d / 2 + 0.004, h * 0.75), STEEL, 0.003) for s in (1, -1)]
    prop_save(name, [body, band, handle] + cross + latches, tris=500, center=True)


def med_s():
    _medkit("medkit_s", 0.2, 0.13, 0.08)


def med_m():
    _medkit("medkit_m", 0.28, 0.18, 0.12)


def med_l():
    _medkit("medkit_l", 0.38, 0.24, 0.16)


def i_crystal():
    reset()
    base = cyl(0.06, 0.03, (0, 0, 0.015), DARK, 12, bevel=0.005)
    claws = [box((0.012, 0.012, 0.09), (math.cos(a) * 0.045, math.sin(a) * 0.045, 0.06), STEEL, 0.003, rot=(math.sin(a) * 0.25, -math.cos(a) * 0.25, 0)) for a in (0, 2.09, 4.19)]
    bm = bmesh.new()
    n = 6
    top = bm.verts.new((0, 0, 0.24))
    ring = [bm.verts.new((math.cos(a) * 0.04, math.sin(a) * 0.04, 0.12)) for a in [i * math.tau / n for i in range(n)]]
    bot = bm.verts.new((0, 0, 0.03))
    for i in range(n):
        bm.faces.new((ring[i], ring[(i + 1) % n], top))
        bm.faces.new((ring[(i + 1) % n], ring[i], bot))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    cr = mesh_obj("cr", bm, "E_5ae8ff")
    prop_save("i_crystal", [base, cr] + claws, tris=300, center=True)


def i_pocketcart():
    reset()
    frame = box((0.5, 0.3, 0.06), (0, 0, 0.08), HAZ, 0.012)
    bed = box((0.46, 0.26, 0.02), (0, 0, 0.115), "L_metal_5a5e66", 0.004)
    handle = [box((0.02, 0.02, 0.24), (-0.26, s * 0.12, 0.2), DARK, 0.004, rot=(0, -0.6, 0)) for s in (1, -1)] + [cyl(0.012, 0.26, (-0.33, 0, 0.3), GRIP, 8, rot=(math.pi / 2, 0, 0))]
    wheels = [cyl(0.04, 0.03, (x, y, 0.04), GRIP, 12, rot=(math.pi / 2, 0, 0)) for x in (-0.18, 0.18) for y in (-0.16, 0.16)]
    stripe = box((0.1, 0.302, 0.062), (0.15, 0, 0.08), "L_paint_15151a", 0.0)
    prop_save("i_pocketcart", [frame, bed, stripe] + handle + wheels, tris=600, center=True)


def moneybag():
    reset()
    sack = meta("s", [("ell", (0, 0, 0.15), 0.17, (1.0, 1.0, 0.95)), ("ell", (0, 0, 0.3), 0.07, (1.0, 1.0, 1.0))], "L_fabric_b8a070", 0.016)
    displace(sack, 0.01, 0.05)
    tie = lathe([(0.06, 0.29), (0.07, 0.3), (0.06, 0.31)], "L_fabric_5a4020", 14, cap_bottom=False)
    top = meta("t", [("ell", (0, 0, 0.36), 0.06, (1.2, 1.2, 0.6))], "L_fabric_b8a070", 0.012)
    dollar = [box((0.02, 0.01, 0.1), (0, 0.17, 0.15), "L_paint_2a6a3a", 0.003), box((0.07, 0.01, 0.02), (0, 0.172, 0.18), "L_paint_2a6a3a", 0.003),
              box((0.07, 0.01, 0.02), (0, 0.172, 0.12), "L_paint_2a6a3a", 0.003)]
    snap_objs(dollar, sack, 0.4)
    prop_save("moneybag", [sack, tie, top] + dollar, tris=900, center=True)


def orb():
    reset()
    core = sphere(0.14, (0, 0, 0.2), "E_b04aff", 16, 8)
    shell = sphere(0.17, (0, 0, 0.2), "G_d8b0ff", 16, 8)
    cage = []
    for i in range(4):
        r = lathe([(0.175, -0.006), (0.185, 0.0), (0.175, 0.006)], DARK, 20, cap_bottom=False, pos=(0, 0, 0.2))
        r.rotation_euler = (math.pi / 2, 0, i * math.pi / 4)
        cage.append(r)
    caps = [cyl(0.06, 0.03, (0, 0, z), DARK, 12, bevel=0.006) for z in (0.025, 0.375)]
    prop_save("orb", [core, shell] + cage + caps, tris=1200, center=True)


def up_item():
    reset()
    body = cyl(0.06, 0.16, (0, 0, 0.08), "L_metal_3a4656", 14, bevel=0.008)
    band = cyl(0.062, 0.04, (0, 0, 0.08), "E_5ad8ff", 14)
    caps = [cyl(0.065, 0.025, (0, 0, z), HAZ, 14, bevel=0.005) for z in (0.0125, 0.1475)]
    plug = cyl(0.02, 0.03, (0, 0, 0.175), STEEL, 8)
    prop_save("up_item", [body, band, plug] + caps, tris=400, center=True)


# ---------------------------------------------------------------- mission objects
def cart():
    reset()
    Y = "L_paint_e8b420"
    tub = [box((1.0, 0.8, 0.06), (0, 0, 0.3), "L_metal_5a5e66", 0.01)]
    for s in (1, -1):
        tub.append(box((1.0, 0.04, 0.42), (0, s * 0.4, 0.5), Y, 0.012))
        tub.append(box((0.04, 0.8, 0.42), (s * 0.5, 0, 0.5), Y, 0.012))
    tub += [box((1.02, 0.05, 0.04), (0, s * 0.41, 0.72), DARK, 0.008) for s in (1, -1)]
    tub += [box((0.05, 0.82, 0.04), (s * 0.51, 0, 0.72), DARK, 0.008) for s in (1, -1)]
    tub += [box((0.02, 0.03, 0.38), (x, s * 0.42, 0.5), "L_paint_15151a", 0.0) for x in (-0.3, 0.0, 0.3) for s in (1, -1)]
    handle = [box((0.04, 0.04, 0.4), (-0.62, s * 0.3, 0.75), DARK, 0.006, rot=(0, -0.5, 0)) for s in (1, -1)] + [cyl(0.025, 0.66, (-0.72, 0, 0.92), GRIP, 10, rot=(math.pi / 2, 0, 0))]
    wheels = []
    for x in (-0.38, 0.38):
        for s in (1, -1):
            wheels.append(cyl(0.1, 0.06, (x, s * 0.36, 0.1), GRIP, 16, rot=(math.pi / 2, 0, 0), bevel=0.01))
            wheels.append(cyl(0.05, 0.065, (x, s * 0.36, 0.1), STEEL, 10, rot=(math.pi / 2, 0, 0)))
            wheels.append(box((0.05, 0.05, 0.12), (x, s * 0.36, 0.22), DARK, 0.006))
    disp = box((0.18, 0.03, 0.1), (-0.52, 0, 0.78), "L_plastic_101012", 0.008, rot=(0, -0.4, 0))
    dscr = box((0.14, 0.01, 0.06), (-0.53, 0.0, 0.79), "E_4aff7a", 0.003, rot=(0, -0.4, math.pi / 2))
    prop_save("cart", tub + handle + wheels + [disp, dscr], tex=512, tris=2500, center=True)


def extractor():
    reset()
    p = [box((0.5, 0.45, 0.12), (0, 0, 0.06), DARK, 0.02),
         box((0.36, 0.32, 0.9), (0, 0, 0.55), "L_paint_3a4656", 0.04),
         box((0.4, 0.36, 0.08), (0, 0.02, 1.02), DARK, 0.02),
         box((0.3, 0.02, 0.24), (0, 0.17, 0.72), "L_plastic_101012", 0.01),
         box((0.26, 0.01, 0.18), (0, 0.181, 0.72), "E_4aff7a", 0.006),
         box((0.08, 0.03, 0.08), (0, 0.17, 0.42), "L_plastic_c0302a", 0.01)]
    p += [box((0.04, 0.34, 0.9), (s * 0.2, 0, 0.55), HAZ, 0.004) for s in (1, -1)]
    p += [box((0.042, 0.06, 0.03), (s * 0.2, 0.0, 0.3 + i * 0.12), "L_paint_15151a", 0.0, rot=(0.6, 0, 0)) for s in (1, -1) for i in range(5)]
    p += [cyl(0.03, 0.05, (0.12, 0.0, 1.08), "E_ffb04a", 10), cyl(0.02, 0.4, (-0.12, -0.05, 1.25), DARK, 8)]
    prop_save("extractor", p, tex=256, tris=900)


def zone_ring():
    reset()
    ring = lathe([(1.3, 0.0), (1.45, 0.0), (1.45, 0.12), (1.3, 0.12)], DARK, 40, cap_bottom=False, smooth=False)
    haz = lathe([(1.45, 0.02), (1.46, 0.02), (1.46, 0.1), (1.45, 0.1)], HAZ, 40, cap_bottom=False, smooth=False)
    lights = [box((0.2, 0.06, 0.03), (math.cos(a) * 1.38, math.sin(a) * 1.38, -0.01), "E_4aff7a", 0.0, rot=(0, 0, a + math.pi / 2)) for a in [i * math.pi / 6 for i in range(12)]]
    tube = cyl(0.25, 0.8, (0, 0, 0.5), DARK, 16)
    grill = cyl(0.27, 0.06, (0, 0, 0.12), "L_metal_5a5e66", 16)
    struts = [box((1.3, 0.06, 0.06), (math.cos(a) * 0.7, math.sin(a) * 0.7, 0.1), DARK, rot=(0, 0, a)) for a in [0, 2.09, 4.19]]
    o = join([ring, haz, tube, grill] + lights + struts, "zone_ring")
    set_origin(o, (0, 0, 0))
    save("zone_ring", [o], tex=256, tris=1500, split=False)


def truck():
    """The crew's van: worn beige box van, cargo open at +Y (robots ride inside), cab at -Y."""
    reset()
    B = "L_paint_c8bc9a"
    p = [box((2.4, 3.2, 0.12), (0, 0, 0.45), "L_metal_5a5e66", 0.0)]
    p += [box((2.4, 3.2, 0.02), (0, 0, 0.52), "L_metal_6a6e78", 0.0)]
    for s in (1, -1):
        p.append(box((0.08, 3.2, 2.2), (s * 1.2, 0, 1.6), B, 0.02))
        p += [box((0.03, 3.1, 0.04), (s * 1.15, 0, z), STEEL) for z in (0.9, 1.5, 2.1)]
        p.append(box((0.1, 3.0, 0.22), (s * 1.25, 0, 1.4), "L_paint_c0302a", 0.0))
        p.append(box((0.1, 1.2, 0.5), (s * 1.25, 0.3, 2.0), "L_paint_e8e4da", 0.02))
        p.append(box((0.1, 0.6, 0.2), (s * 1.255, 0.3, 2.0), "L_paint_2a2c33", 0.0))
    p.append(box((2.48, 3.3, 0.1), (0, 0, 2.72), B, 0.03))
    p.append(box((2.4, 0.08, 2.2), (0, -1.6, 1.6), B))
    p += [box((0.06, 0.06, 2.3), (s * 1.2, 1.62, 1.6), "L_metal_5a5e66", 0.01) for s in (1, -1)]
    p.append(box((2.5, 0.12, 0.12), (0, 1.62, 0.5), HAZ, 0.01))
    p += [box((0.12, 0.13, 0.13), (-1.0 + i * 0.25, 1.625, 0.5), "L_paint_15151a", 0.0, rot=(0, 0.7, 0)) for i in range(9)]
    # cab
    p.append(box((2.3, 1.5, 1.4), (0, -2.45, 1.15), B, 0.1, 3))
    p.append(box((2.2, 1.15, 0.8), (0, -2.55, 2.1), B, 0.14, 3))
    p.append(box((2.0, 0.05, 0.62), (0, -3.12, 2.1), "G_3a5a7a", 0.03, rot=(-0.2, 0, 0)))
    p += [box((0.05, 0.9, 0.55), (s * 1.12, -2.5, 2.1), "G_3a5a7a", 0.02) for s in (1, -1)]
    p.append(box((2.36, 0.25, 0.32), (0, -3.25, 0.72), DARK, 0.05))
    p.append(box((1.0, 0.05, 0.3), (0, -3.2, 1.25), "L_metal_15161a", 0.02))
    p += [box((0.3, 0.05, 0.16), (s * 0.85, -3.21, 1.2), "E_fff0c0", 0.02) for s in (1, -1)]
    p += [box((0.04, 0.2, 0.12), (s * 1.2, -2.0, 2.0), DARK, 0.01) for s in (1, -1)]
    p += [box((0.16, 0.02, 0.1), (0, -3.24, 0.72), "L_paint_e8e4da", 0.004)]
    rust = [sphere(0.12, (s * 1.24, y, 0.9), "L_rust_7a4a22", 8, 4, (0.15, 1.6, 0.8)) for s, y in ((1, -1.0), (-1, 0.8), (1, -2.9))]
    p += rust
    for x in (-1.15, 1.15):
        for y in (-2.4, -0.2, 1.0):
            p.append(cyl(0.42, 0.3, (x, y, 0.42), "L_rubber_1c1d22", 20, rot=(0, math.pi / 2, 0), bevel=0.04))
            p.append(cyl(0.22, 0.32, (x, y, 0.42), "L_metal_9a9ea8", 12, rot=(0, math.pi / 2, 0)))
    p.append(box((0.9, 0.08, 0.55), (0, -1.54, 1.9), "L_plastic_101012", 0.02))
    p.append(box((0.8, 0.02, 0.45), (0, -1.5, 1.9), "E_12302a", 0.0))
    p += [box((0.1, 0.05, 0.25), (s * 1.1, 1.62, 0.8), "E_ff2010", 0.01) for s in (1, -1)]
    p.append(box((0.5, 0.04, 0.12), (0, 1.62, 2.5), "E_ffb04a", 0.01))
    prop_save("truck", p, tex=512, tris=3500)


def charger():
    reset()
    p = [box((0.9, 0.6, 0.1), (0, 0, 0.05), DARK, 0.02), box((0.5, 0.3, 1.2), (0, -0.15, 0.65), "L_paint_3a4656", 0.04),
         box((0.4, 0.02, 0.3), (0, 0.005, 0.95), "L_plastic_101012", 0.01), box((0.34, 0.01, 0.12), (0, 0.016, 0.98), "E_4aff7a", 0.004),
         box((0.36, 0.02, 0.04), (0, 0.005, 0.85), "E_ffb04a", 0.004)]
    p += [box((0.52, 0.06, 0.06), (0, -0.15, 0.2 + i * 0.12), HAZ, 0.0) for i in range(2)]
    p += [cyl(0.02, 0.4, (s * 0.15, 0.05, 0.5), "L_rubber_1c1d22", 8, rot=(0.6, 0, 0)) for s in (1, -1)]
    p += [box((0.06, 0.06, 0.1), (s * 0.15, 0.17, 0.35), "L_plastic_c0302a", 0.01) for s in (1, -1)]
    p.append(box((0.6, 0.5, 0.02), (0, 0.1, 0.11), "L_metal_5a5e66", 0.0))
    prop_save("charger", p, tex=256, tris=900)


def button():
    reset()
    post = cyl(0.08, 0.9, (0, 0, 0.45), "L_paint_3a4656", 14, bevel=0.01)
    base = cyl(0.25, 0.06, (0, 0, 0.03), DARK, 20, bevel=0.01)
    haz = [box((0.1, 0.02, 0.04), (math.cos(a) * 0.2, math.sin(a) * 0.2, 0.06), HAZ, 0.0, rot=(0, 0, a + math.pi / 2)) for a in [i * math.tau / 8 for i in range(8)]]
    housing = box((0.3, 0.3, 0.14), (0, 0, 0.97), HAZ, 0.03)
    bev = cyl(0.11, 0.03, (0, 0, 1.055), DARK, 18)
    btn = cyl(0.09, 0.06, (0, 0, 1.09), "E_ff2a14", 18, bevel=0.02)
    prop_save("button", [post, base, housing, bev, btn] + haz, tex=256, tris=900)


run([gadget, w_bat, w_sledge, w_pan, w_prod, w_pistol, w_shotgun, w_tranq, w_duck, g_explosive, g_stun, g_shock, m_explosive, m_stun,
     d_feather, d_shield, d_recharge, d_zerog, t_valuable, t_extract, med_s, med_m, med_l, i_crystal, i_pocketcart, moneybag, orb, up_item,
     cart, extractor, zone_ring, truck, charger, button])
