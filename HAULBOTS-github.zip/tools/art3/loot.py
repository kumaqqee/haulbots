"""Loot / valuables, art v3 (single piece, origin bottom centre, metres)."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *

GOLD = "L_gold_e8b040"
STEEL = "L_metal_8a8f99"
DARK = "L_metal_2a2d33"


def trophy():
    reset()
    base = [box((0.14, 0.14, 0.04), (0, 0, 0.02), "L_wood_3a2414", 0.006), box((0.1, 0.1, 0.03), (0, 0, 0.055), "L_stone_1a1a1e", 0.005)]
    plate = box((0.07, 0.006, 0.02), (0, 0.07, 0.025), GOLD, 0.002)
    cup = lathe([(0.012, 0.07), (0.02, 0.09), (0.012, 0.12), (0.03, 0.15), (0.075, 0.2), (0.085, 0.27), (0.082, 0.28), (0.07, 0.21), (0.0, 0.2)], GOLD, 24, cap_bottom=True)
    handles = [skin([(s * 0.075, 0, 0.26, 0.008), (s * 0.12, 0, 0.24, 0.008), (s * 0.11, 0, 0.19, 0.008), (s * 0.06, 0, 0.18, 0.008)], material=GOLD, subdiv=1) for s in (1, -1)]
    star = cyl(0.02, 0.006, (0, 0.07, 0.22), "L_paint_c0302a", 5, rot=(math.pi / 2, 0, 0))
    prop_save("trophy", base + [plate, cup, star] + handles, tris=900, center=True)


def camera():
    reset()
    body = box((0.16, 0.07, 0.1), (0, 0, 0.05), "L_leather_1e1c1a", 0.012)
    top = box((0.12, 0.06, 0.03), (0.0, 0, 0.115), "L_metal_b0b4bc", 0.008)
    prism = box((0.05, 0.05, 0.03), (0.0, 0, 0.14), "L_metal_b0b4bc", 0.008)
    lens = cyl(0.04, 0.07, (0, 0.06, 0.05), DARK, 20, rot=(math.pi / 2, 0, 0), bevel=0.004)
    ring = cyl(0.043, 0.015, (0, 0.08, 0.05), "L_metal_b0b4bc", 20, rot=(math.pi / 2, 0, 0))
    glass = cyl(0.03, 0.004, (0, 0.096, 0.05), "G_5a8aff", 20, rot=(math.pi / 2, 0, 0))
    dial = cyl(0.015, 0.012, (0.05, 0, 0.135), "L_metal_b0b4bc", 12)
    flash = box((0.03, 0.01, 0.015), (-0.055, 0.036, 0.09), "E_f4f6ff", 0.003)
    prop_save("camera", [body, top, prism, lens, ring, glass, dial, flash], tris=800, center=True)


def gem():
    reset()
    bm = bmesh.new()
    n = 8
    top = bm.verts.new((0, 0, 0.2))
    tab = [bm.verts.new((math.cos(a) * 0.05, math.sin(a) * 0.05, 0.18)) for a in [i * math.tau / n for i in range(n)]]
    gir = [bm.verts.new((math.cos(a) * 0.1, math.sin(a) * 0.1, 0.13)) for a in [(i + 0.5) * math.tau / n for i in range(n)]]
    bot = bm.verts.new((0, 0, 0.0))
    bm.faces.new(tab)
    for i in range(n):
        bm.faces.new((tab[i], tab[(i + 1) % n], gir[i]))
        bm.faces.new((tab[(i + 1) % n], gir[(i + 1) % n], gir[i]))
        bm.faces.new((gir[i], gir[(i + 1) % n], bot))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    shell = mesh_obj("gem", bm, "G_2a6aff")
    core = sphere(0.06, (0, 0, 0.11), "E_3a7aff", 10, 6, (1, 1, 1.1))
    prop_save("gem", [shell, core], tris=400, center=True)


def crown():
    reset()
    band = lathe([(0.1, 0.0), (0.105, 0.0), (0.105, 0.06), (0.1, 0.06)], GOLD, 28, cap_bottom=False)
    spikes_ = []
    for i in range(8):
        a = i * math.tau / 8
        c = cyl(0.025, 0.07, (math.cos(a) * 0.1, math.sin(a) * 0.1, 0.09), GOLD, 4, r2=0.0, smooth=False)
        c.rotation_euler = (0, 0, a + math.pi / 4)
        spikes_.append(c)
        spikes_.append(sphere(0.012, (math.cos(a) * 0.1, math.sin(a) * 0.1, 0.13), GOLD, 6, 3))
    gems = [sphere(0.016, (math.cos(a) * 0.107, math.sin(a) * 0.107, 0.03), "E_c0202a" if i % 2 else "E_2a5aff", 8, 4, (0.6, 0.6, 1)) for i, a in enumerate([i * math.tau / 6 for i in range(6)])]
    cushion = sphere(0.09, (0, 0, 0.03), "L_fabric_8a1a2a", 14, 7, (1, 1, 0.5))
    prop_save("crown", [band, cushion] + spikes_ + gems, tris=900, center=True)


def goldbar():
    reset()
    def bar(x, y, z, rz=0.0):
        b = box((0.2, 0.08, 0.05), (x, y, z), GOLD, 0.012, rot=(0, 0, rz))
        return b
    bars = [bar(0, -0.05, 0.025), bar(0.01, 0.05, 0.025, 0.05), bar(0.0, 0.0, 0.075, 1.5708)]
    stamps = [box((0.06, 0.03, 0.004), (0.0, 0.0, 0.101), "L_gold_c8902a", 0.0, rot=(0, 0, 1.5708))]
    prop_save("goldbar", bars + stamps, tris=400, center=True)


def cube():
    reset()
    cols = ["L_plastic_c0302a", "L_plastic_e86a1a", "L_plastic_2a6ad8", "L_plastic_3aa040", "L_plastic_e8e4da", "L_plastic_e8b420"]
    S = 0.18
    parts = [box((S, S, S), (0, 0, S / 2), "L_plastic_101012", 0.01)]
    k = S / 3
    faces = [((1, 0, 0), 0), ((-1, 0, 0), 1), ((0, 1, 0), 2), ((0, -1, 0), 3), ((0, 0, 1), 4), ((0, 0, -1), 5)]
    rnd = random.Random(4)
    for n, ci in faces:
        for i in range(3):
            for j in range(3):
                u, v = (i - 1) * k, (j - 1) * k
                if n[0]:
                    pos, sz = (n[0] * (S / 2 + 0.002), u, S / 2 + v), (0.004, k * 0.86, k * 0.86)
                elif n[1]:
                    pos, sz = (u, n[1] * (S / 2 + 0.002), S / 2 + v), (k * 0.86, 0.004, k * 0.86)
                else:
                    pos, sz = (u, v, S / 2 + n[2] * (S / 2 + 0.002)), (k * 0.86, k * 0.86, 0.004)
                c = cols[ci] if rnd.random() < 0.7 else rnd.choice(cols)
                parts.append(box(sz, pos, c, 0.003))
    prop_save("cube", parts, tris=1200, center=True)


def duck_gold():
    reset()
    body = meta("b", [("ell", (0, -0.02, 0.07), 0.08, (1.0, 1.25, 0.8)), ("ell", (0, -0.1, 0.1), 0.03, (0.8, 1.0, 0.8))], GOLD, 0.012)
    head = sphere(0.055, (0, 0.06, 0.15), GOLD, 16, 8)
    beak = meta("bk", [("ell", (0, 0.115, 0.14), 0.03, (1.1, 1.2, 0.45))], "L_paint_e86a1a", 0.008)
    eyes = [sphere(0.009, (s * 0.025, 0.105, 0.165), "C_101010", 6, 3) for s in (1, -1)]
    prop_save("duck_gold", [body, head, beak] + eyes, tris=900, center=True)


def figurine():
    reset()
    P = "L_ceramic_f0ece4"
    base = cyl(0.07, 0.02, (0, 0, 0.01), "L_ceramic_2a4a8a", 20, bevel=0.004)
    body = meta("b", [("ell", (0, -0.01, 0.09), 0.055, (1.0, 1.1, 1.3)), ("ball", (0, 0.02, 0.17), 0.045)], P, 0.008)
    ears = [cyl(0.018, 0.035, (s * 0.025, 0.02, 0.215), P, 4, r2=0.0, smooth=False) for s in (1, -1)]
    tail = skin([(0, -0.06, 0.05, 0.01), (0.05, -0.08, 0.08, 0.009), (0.06, -0.05, 0.13, 0.007)], material=P, subdiv=1)
    eyes = [sphere(0.007, (s * 0.017, 0.058, 0.18), "L_ceramic_2a4a8a", 6, 3) for s in (1, -1)]
    bell = sphere(0.01, (0, 0.05, 0.135), GOLD, 6, 3)
    paint = [sphere(0.015, (0.03, 0.03, 0.1), "L_ceramic_2a4a8a", 6, 3, (1, 1, 1.5))]
    prop_save("figurine", [base, body, tail, bell] + ears + eyes + paint, tris=900, center=True)


def cash():
    reset()
    parts = []
    for i, (x, y, z, rz) in enumerate([(-0.05, 0, 0.025, 0.05), (0.05, 0.005, 0.025, -0.03), (0.0, 0.0, 0.075, 0.1), (-0.04, 0.0, 0.125, -0.08)]):
        parts.append(box((0.155, 0.07, 0.048), (x, y, z), "L_paper_6a9a5a", 0.003, rot=(0, 0, rz)))
        parts.append(box((0.03, 0.074, 0.05), (x, y, z), "L_paper_d8d0b0", 0.002, rot=(0, 0, rz)))
    prop_save("cash", parts, tris=500, center=True)


def vase():
    reset()
    v = lathe([(0.05, 0.0), (0.07, 0.01), (0.12, 0.12), (0.135, 0.22), (0.11, 0.33), (0.06, 0.42), (0.05, 0.47), (0.075, 0.5), (0.07, 0.51), (0.04, 0.48)], "L_ceramic_1e3a7a", 28, cap_bottom=True)
    bands = [lathe([(r - 0.002, z), (r + 0.004, z + 0.01), (r - 0.002, z + 0.02)], "L_gold_d8a840", 28, cap_bottom=False) for r, z in ((0.13, 0.2), (0.12, 0.29), (0.07, 0.41))]
    flowers = []
    for i in range(6):
        a = i * math.tau / 6
        flowers.append(sphere(0.02, (math.cos(a) * 0.134, math.sin(a) * 0.134, 0.245), "L_ceramic_e8e4da", 8, 4, (1, 0.3, 1)))
        flowers[-1].rotation_euler = (0, 0, a + math.pi / 2)
    prop_save("vase", [v] + bands + flowers, tris=1200, center=True)


def painting():
    reset()
    W, H = 0.6, 0.45
    frame = [box((W + 0.08, 0.04, 0.05), (0, 0, H + 0.075), "L_gold_c8902a", 0.01), box((W + 0.08, 0.04, 0.05), (0, 0, 0.075), "L_gold_c8902a", 0.01),
             box((0.05, 0.04, H + 0.08), (W / 2 + 0.02, 0, H / 2 + 0.075), "L_gold_c8902a", 0.01), box((0.05, 0.04, H + 0.08), (-W / 2 - 0.02, 0, H / 2 + 0.075), "L_gold_c8902a", 0.01)]
    canvas = [box((W, 0.01, H * 0.45), (0, 0.01, 0.1 + H * 0.775), "L_paint_d89050", 0.0), box((W, 0.01, H * 0.25), (0, 0.01, 0.1 + H * 0.43), "L_paint_4a6a8a", 0.0),
              box((W, 0.01, H * 0.3), (0, 0.01, 0.1 + H * 0.15), "L_paint_3a5a2a", 0.0)]
    hills = [sphere(0.14, (x, 0.012, 0.1 + H * 0.3), "L_paint_2a4020", 12, 6, (1.4, 0.05, 0.6)) for x in (-0.15, 0.12)]
    sun = cyl(0.045, 0.01, (0.17, 0.017, 0.1 + H * 0.8), "L_paint_f0d070", 16, rot=(math.pi / 2, 0, 0))
    stand = [box((0.03, 0.18, 0.03), (s * 0.22, -0.08, 0.015), "L_wood_3a2414", 0.005) for s in (1, -1)]
    objs = frame + canvas + hills + [sun] + stand
    for o in frame + canvas + hills + [sun]:
        o.rotation_euler.x += -0.18
    prop_save("painting", objs, tris=600, center=True)


def laptop():
    reset()
    base = box((0.34, 0.24, 0.02), (0, 0, 0.01), "L_plastic_2a2c33", 0.006)
    keys = box((0.28, 0.12, 0.004), (0, 0.02, 0.021), "L_plastic_101012", 0.002)
    pad = box((0.08, 0.05, 0.003), (0, -0.075, 0.021), "L_plastic_3a3d44", 0.002)
    lid = box((0.34, 0.015, 0.23), (0, -0.13, 0.125), "L_plastic_2a2c33", 0.006, rot=(-0.25, 0, 0))
    scr = box((0.3, 0.004, 0.19), (0, -0.12, 0.128), "E_3aa0d8", 0.004, rot=(-0.25, 0, 0))
    logo = cyl(0.015, 0.003, (0, -0.142, 0.13), "L_metal_b0b4bc", 12, rot=(math.pi / 2 - 0.25, 0, 0))
    stick = box((0.06, 0.05, 0.003), (0.1, 0.05, 0.022), "L_paper_e8d040", 0.0, rot=(0, 0, 0.3))
    prop_save("laptop", [base, keys, pad, lid, scr, logo, stick], tris=500, center=True)


def radio():
    reset()
    body = box((0.36, 0.18, 0.24), (0, 0, 0.12), "L_wood_6a3a1c", 0.025)
    grille = box((0.18, 0.01, 0.16), (-0.07, 0.092, 0.13), "L_fabric_c8b080", 0.01)
    slats = [box((0.005, 0.012, 0.16), (-0.14 + i * 0.03, 0.098, 0.13), "L_wood_3a1e0c", 0.0) for i in range(6)]
    dial = box((0.12, 0.01, 0.07), (0.1, 0.092, 0.16), "E_f0c060", 0.006)
    needle = box((0.004, 0.012, 0.06), (0.09, 0.098, 0.16), "C_c0302a", 0.0)
    knobs = [cyl(0.02, 0.025, (x, 0.1, 0.07), "L_plastic_2a1a10", 12, rot=(math.pi / 2, 0, 0), bevel=0.003) for x in (0.06, 0.13)]
    handle = skin([(-0.12, 0, 0.24, 0.01), (-0.1, 0, 0.3, 0.01), (0.1, 0, 0.3, 0.01), (0.12, 0, 0.24, 0.01)], material="L_leather_2a1a10", subdiv=1)
    feet = [box((0.03, 0.03, 0.01), (x, y, 0.005), DARK, 0.002) for x in (-0.15, 0.15) for y in (-0.06, 0.06)]
    prop_save("radio", [body, grille, dial, needle, handle] + slats + knobs + feet, tris=900, center=True)


def teddy():
    reset()
    F = "L_fur_8a5a32"
    body = meta("b", [("ell", (0, 0, 0.14), 0.11, (1.0, 0.85, 1.1)), ("ball", (0, 0.01, 0.3), 0.09)], F, 0.012)
    muzzle = sphere(0.04, (0, 0.08, 0.28), "L_fur_c8a070", 10, 5, (1.1, 0.8, 0.8))
    nose = sphere(0.015, (0, 0.115, 0.29), "L_plastic_101010", 6, 3)
    ears = [sphere(0.035, (s * 0.07, 0.0, 0.38), F, 10, 5, (1, 0.6, 1)) for s in (1, -1)]
    eyes = [sphere(0.012, (s * 0.035, 0.08, 0.32), "L_plastic_101010", 6, 3) for s in (1, -1)]
    arms = [meta("a", [("ell", (s * 0.11, 0.04, 0.16), 0.04, (0.9, 0.9, 1.6), (0.4, 0, 0.5 * s))], F, 0.01) for s in (1, -1)]
    legs = [meta("l", [("ell", (s * 0.06, 0.07, 0.04), 0.045, (0.9, 1.4, 0.8))], F, 0.01) for s in (1, -1)]
    patch = box((0.05, 0.01, 0.05), (0.04, 0.09, 0.14), "L_fabric_4a6a8a", 0.004, rot=(0, 0.3, 0))
    stitch = [box((0.004, 0.012, 0.03), (-0.04 + i * 0.012, 0.095, 0.18), "C_1a1010", 0.0) for i in range(3)]
    bow = [sphere(0.025, (s * 0.025, 0.07, 0.22), "L_fabric_c0302a", 6, 3, (1.2, 0.5, 0.8)) for s in (1, -1)]
    prop_save("teddy", [body, muzzle, nose, patch] + ears + eyes + arms + legs + stitch + bow, tris=1400, center=True)


def toolbox():
    reset()
    R = "L_paint_b8261e"
    parts = [box((0.5, 0.24, 0.2), (0, 0, 0.1), R, 0.015), box((0.5, 0.24, 0.05), (0, 0, 0.225), R, 0.012),
             box((0.52, 0.25, 0.015), (0, 0, 0.2), "L_metal_2a2d33", 0.004)]
    parts += [box((0.06, 0.02, 0.04), (x, 0.125, 0.2), STEEL, 0.004) for x in (-0.18, 0.18)]
    parts.append(skin([(-0.12, 0, 0.25, 0.012), (-0.1, 0, 0.3, 0.012), (0.1, 0, 0.3, 0.012), (0.12, 0, 0.25, 0.012)], material=DARK, subdiv=1))
    parts.append(box((0.12, 0.01, 0.05), (0, 0.122, 0.1), "L_paint_e8e4da", 0.003))
    prop_save("toolbox", parts, tris=600, center=True)


def microscope():
    reset()
    W = "L_paint_e8e4da"
    base = box((0.18, 0.22, 0.03), (0, 0, 0.015), "L_paint_2a2c33", 0.01)
    arm = skin([(0, -0.08, 0.03, 0.03), (0, -0.09, 0.18, 0.028), (0, -0.04, 0.3, 0.025)], material=W, subdiv=1)
    stage = box((0.12, 0.12, 0.012), (0, 0.02, 0.13), DARK, 0.004)
    tube = cyl(0.025, 0.18, (0, 0.0, 0.3), W, 14, rot=(0.4, 0, 0))
    eye = cyl(0.018, 0.06, (0, -0.06, 0.4), DARK, 12, rot=(0.4, 0, 0))
    turret = cyl(0.035, 0.03, (0, 0.03, 0.22), DARK, 14)
    objs = [cyl(0.008, 0.05, (math.cos(a) * 0.02, 0.03 + math.sin(a) * 0.02, 0.185), STEEL, 6) for a in (0, 2.1, 4.2)]
    knob = cyl(0.03, 0.02, (0.07, -0.08, 0.12), DARK, 14, rot=(0, math.pi / 2, 0))
    slide = box((0.07, 0.025, 0.003), (0, 0.02, 0.138), "G_c8e8ff", 0.0)
    prop_save("microscope", [base, arm, stage, tube, eye, turret, knob, slide] + objs, tris=900, center=True)


def flasks():
    reset()
    rack = [box((0.34, 0.12, 0.02), (0, 0, 0.01), "L_wood_6a4a2a", 0.004), box((0.34, 0.12, 0.015), (0, 0, 0.09), "L_wood_6a4a2a", 0.004)]
    rack += [box((0.015, 0.015, 0.1), (x, y, 0.05), "L_wood_6a4a2a", 0.002) for x in (-0.16, 0.16) for y in (-0.05, 0.05)]
    cols = ["4aff7a", "4ac8ff", "ff4ad8", "e8ff4a"]
    for i, x in enumerate((-0.12, -0.04, 0.04, 0.12)):
        h = 0.16 + 0.03 * (i % 2)
        rack.append(cyl(0.028, h, (x, 0, 0.02 + h / 2), "G_d8f0ff", 12))
        rack.append(cyl(0.024, h * 0.55, (x, 0, 0.025 + h * 0.275), "E_" + cols[i], 12))
        rack.append(cyl(0.02, 0.02, (x, 0, 0.03 + h), "L_rubber_6a3a1a", 10))
    rack.append(lathe([(0.06, 0.0), (0.06, 0.01), (0.02, 0.1), (0.015, 0.14), (0.0, 0.14)], "G_d8f0ff", 16, pos=(0.0, 0.11, 0.0)))
    rack.append(lathe([(0.055, 0.0), (0.05, 0.03), (0.0, 0.03)], "E_4aff7a", 16, pos=(0.0, 0.11, 0.005)))
    prop_save("flasks", rack, tris=1100, center=True)


def powercell():
    reset()
    body = cyl(0.11, 0.34, (0, 0, 0.17), "L_metal_3a4656", 16, bevel=0.01)
    caps = [cyl(0.12, 0.04, (0, 0, z), "L_paint_e8b420", 16, bevel=0.008) for z in (0.02, 0.32)]
    win = cyl(0.112, 0.18, (0, 0, 0.17), "G_5ae8ff", 16)
    core = cyl(0.06, 0.2, (0, 0, 0.17), "E_5ae8ff", 12)
    bars = [box((0.02, 0.24, 0.2), (0, 0, 0.17), "L_metal_2a2d33", 0.004, rot=(0, 0, a)) for a in (0, math.pi / 2)]
    term = [cyl(0.02, 0.04, (x, 0, 0.36), STEEL, 8) for x in (-0.05, 0.05)]
    stripe = [box((0.04, 0.01, 0.02), (0.0, 0.12, 0.33), "L_paint_15151a", 0.0, rot=(0, 0.6, 0))]
    prop_save("powercell", [body, win, core] + caps + bars + term + stripe, tris=900, center=True)


def tv():
    reset()
    case = box((0.42, 0.34, 0.32), (0, -0.02, 0.18), "L_plastic_4a4a44", 0.03)
    back = box((0.28, 0.16, 0.22), (0, -0.24, 0.18), "L_plastic_3a3a34", 0.03)
    bez = box((0.34, 0.03, 0.26), (0, 0.15, 0.19), "L_plastic_1a1a1a", 0.02)
    scr = box((0.28, 0.01, 0.2), (0, 0.165, 0.19), "E_8ac8c8", 0.02)
    knobs = [cyl(0.018, 0.02, (0.19, 0.12, 0.12 + i * 0.07), "L_plastic_2a2a2a", 10, rot=(0, math.pi / 2, 0)) for i in range(2)]
    feet = [box((0.04, 0.04, 0.02), (x, y, 0.01), "L_rubber_1c1d22", 0.004) for x in (-0.15, 0.15) for y in (-0.1, 0.1)]
    ant = [cyl(0.006, 0.3, (s * 0.06, -0.05, 0.45), STEEL, 6, rot=(0, -0.5 * s, 0)) for s in (1, -1)]
    prop_save("tv", [case, back, bez, scr] + knobs + feet + ant, tris=700, center=True)


def microwave():
    reset()
    body = box((0.48, 0.34, 0.28), (0, 0, 0.14), "L_paint_d8d4c8", 0.015)
    door = box((0.32, 0.02, 0.22), (-0.06, 0.17, 0.14), "L_plastic_1a1c22", 0.01)
    win = box((0.24, 0.01, 0.15), (-0.07, 0.181, 0.14), "G_2a3a2a", 0.006)
    light = box((0.22, 0.005, 0.13), (-0.07, 0.172, 0.14), "E_ffd080", 0.004)
    panel = box((0.1, 0.012, 0.22), (0.18, 0.172, 0.14), "L_plastic_2a2c33", 0.006)
    disp = box((0.07, 0.01, 0.025), (0.18, 0.18, 0.22), "E_4aff7a", 0.003)
    btn = [box((0.02, 0.01, 0.016), (0.16 + (i % 3) * 0.022, 0.18, 0.17 - (i // 3) * 0.024), "L_plastic_8a8f99", 0.003) for i in range(9)]
    handle = box((0.015, 0.03, 0.16), (0.11, 0.19, 0.14), STEEL, 0.006)
    prop_save("microwave", [body, door, win, light, panel, disp, handle] + btn, tris=700, center=True)


def computer():
    reset()
    B = "L_plastic_c8bea0"
    tower = box((0.18, 0.4, 0.38), (-0.22, 0, 0.19), B, 0.015)
    drive = [box((0.12, 0.01, 0.03), (-0.22, 0.202, 0.3 - i * 0.05), "L_plastic_8a8270", 0.004) for i in range(2)]
    led = box((0.015, 0.01, 0.01), (-0.17, 0.205, 0.08), "E_4aff7a", 0.002)
    mon = box((0.34, 0.32, 0.3), (0.08, -0.02, 0.27), B, 0.03)
    monb = box((0.22, 0.16, 0.2), (0.08, -0.22, 0.27), B, 0.03)
    scr = box((0.27, 0.01, 0.21), (0.08, 0.145, 0.275), "E_3aff8a", 0.02)
    lines = [box((0.2 - i * 0.03, 0.005, 0.01), (0.06 - i * 0.015, 0.152, 0.33 - i * 0.03), "E_c8ffd8", 0.0) for i in range(4)]
    stand = box((0.16, 0.16, 0.06), (0.08, 0.0, 0.07), B, 0.01)
    kb = box((0.36, 0.13, 0.03), (0.0, 0.25, 0.015), B, 0.006, rot=(0, 0, 0.05))
    prop_save("computer", [tower, led, mon, monb, scr, stand, kb] + drive + lines, tris=900, center=True)


def server():
    reset()
    cab = box((0.6, 0.8, 1.2), (0, 0, 0.6), "L_paint_1e2028", 0.02)
    door = box((0.54, 0.02, 1.1), (0, 0.405, 0.6), "L_metal_3a3d44", 0.01)
    units = []
    for i in range(9):
        z = 0.15 + i * 0.11
        units.append(box((0.5, 0.012, 0.08), (0, 0.418, z), "L_metal_15161a", 0.004))
        for k in range(4):
            col = ["E_4aff7a", "E_4ac8ff", "E_ffb04a"][(i + k) % 3] if (i * 7 + k) % 5 else "E_ff3a2a"
            units.append(box((0.015, 0.006, 0.01), (-0.2 + k * 0.03, 0.426, z + 0.02), col, 0.0))
        units.append(box((0.18, 0.006, 0.04), (0.12, 0.426, z), "L_metal_5a5e66", 0.002))
    vents = [box((0.4, 0.01, 0.02), (0, 0.42, 1.12 + i * 0.03), "L_metal_15161a", 0.0) for i in range(2)]
    wheels = [cyl(0.04, 0.03, (x, y, 0.04), "L_rubber_1c1d22", 10, rot=(0, math.pi / 2, 0)) for x in (-0.25, 0.25) for y in (-0.33, 0.33)]
    handle = box((0.02, 0.04, 0.3), (0.24, 0.43, 0.65), STEEL, 0.006)
    prop_save("server", [cab, door, handle] + units + vents + wheels, tex=512, tris=2500, center=True)


def safe():
    reset()
    S = "L_paint_3a4a3a"
    body = box((0.7, 0.65, 0.8), (0, 0, 0.42), S, 0.04)
    door = box((0.6, 0.04, 0.68), (0, 0.33, 0.42), "L_paint_2e3c2e", 0.02)
    hinge = [cyl(0.03, 0.12, (-0.31, 0.34, z), DARK, 10) for z in (0.25, 0.6)]
    dial = cyl(0.08, 0.04, (0.05, 0.365, 0.5), "L_metal_b0b4bc", 20, rot=(math.pi / 2, 0, 0), bevel=0.006)
    dial_c = cyl(0.03, 0.05, (0.05, 0.37, 0.5), DARK, 12, rot=(math.pi / 2, 0, 0))
    ticks = [box((0.006, 0.01, 0.018), (0.05 + math.cos(a) * 0.07, 0.388, 0.5 + math.sin(a) * 0.07), "L_paint_e8e4da", 0.0, rot=(0, -a, 0)) for a in [i * math.tau / 12 for i in range(12)]]
    handle = [cyl(0.015, 0.16, (0.05, 0.4, 0.3), STEEL, 8, rot=(0, math.pi / 2, 0))] + [cyl(0.015, 0.05, (0.05 + s * 0.08, 0.38, 0.3), STEEL, 8, rot=(math.pi / 2, 0, 0)) for s in (1, -1)]
    plate = box((0.22, 0.01, 0.06), (0, 0.355, 0.7), "L_gold_c8902a", 0.004)
    feet = [box((0.08, 0.08, 0.04), (x, y, 0.02), DARK, 0.006) for x in (-0.3, 0.3) for y in (-0.27, 0.27)]
    prop_save("safe", [body, door, dial, dial_c, plate] + hinge + ticks + handle + feet, tex=512, tris=1800, center=True)


def statue():
    reset()
    plinth = [box((0.42, 0.42, 0.7), (0, 0, 0.35), "L_marble_d8d0c4", 0.02), box((0.5, 0.5, 0.06), (0, 0, 0.03), "L_marble_b8b0a4", 0.01),
              box((0.48, 0.48, 0.05), (0, 0, 0.725), "L_marble_b8b0a4", 0.01)]
    plaque = box((0.22, 0.01, 0.08), (0, 0.215, 0.5), GOLD, 0.004)
    B = "L_metal_8a5a2a"
    bust = meta("bust", [("ell", (0, 0, 0.86), 0.24, (1.35, 0.75, 0.55)), ("ell", (0, 0, 0.98), 0.18, (1.25, 0.8, 0.6)), ("ell", (0, 0, 1.08), 0.07, (1.0, 1.0, 1.2)),
                         ("ell", (0, 0.02, 1.26), 0.14, (0.85, 0.95, 1.1)), ("ell", (0, 0.13, 1.24), 0.03, (0.6, 1.0, 1.4)),
                         ("ell", (0, 0.06, 1.14), 0.075, (1.2, 0.9, 0.5))], B, 0.012)
    displace(bust, 0.004, 0.03)
    hair = meta("hair", [("ell", (0, -0.015, 1.34), 0.14, (0.95, 0.98, 0.65))], "L_metal_6a4420", 0.012)
    displace(hair, 0.01, 0.02)
    prop_save("statue", plinth + [plaque, bust, hair], tex=512, tris=2400, center=True)


def aquarium():
    reset()
    W, D, H = 0.9, 0.42, 0.55
    stand = box((W + 0.04, D + 0.04, 0.45), (0, 0, 0.225), "L_wood_3a2414", 0.015)
    frame = [box((W + 0.02, D + 0.02, 0.03), (0, 0, 0.465), "L_plastic_1a1c22", 0.005), box((W + 0.02, D + 0.02, 0.05), (0, 0, 0.45 + H + 0.025), "L_plastic_1a1c22", 0.008)]
    glass = box((W, D, H), (0, 0, 0.45 + H / 2 + 0.015), "G_b8e0f0", 0.004)
    water = box((W - 0.03, D - 0.03, H * 0.85), (0, 0, 0.48 + H * 0.425), "G_2a7ac0", 0.0)
    gravel = box((W - 0.03, D - 0.03, 0.05), (0, 0, 0.505), "L_stone_8a7a5a", 0.005)
    plant = [skin([(x, y, 0.53, 0.012), (x + 0.02, y, 0.7, 0.01), (x - 0.01, y, 0.85, 0.005)], material="L_skin_3a8a3a", subdiv=1) for x, y in ((-0.3, -0.1), (-0.27, 0.05), (0.32, -0.08))]
    fish = [meta("f", [("ell", (0.05, 0.02, 0.75), 0.06, (1.6, 0.5, 1.0))], "L_plastic_e86a1a", 0.008),
            cyl(0.025, 0.02, (-0.02, 0.02, 0.75), "L_plastic_e86a1a", 3, rot=(math.pi / 2, 0, 0)),
            meta("f2", [("ell", (-0.2, -0.05, 0.65), 0.05, (1.6, 0.5, 1.0))], "L_plastic_e8d040", 0.008)]
    lamp = box((W * 0.6, 0.06, 0.02), (0, 0, 0.45 + H + 0.06), "E_c8f0ff", 0.004)
    rock = sphere(0.07, (0.15, 0.05, 0.53), "L_stone_5a5650", 8, 4, (1.4, 1, 0.8))
    prop_save("aquarium", [stand, glass, water, gravel, lamp, rock] + frame + plant + fish, tex=512, tris=2000, center=True)


run([trophy, camera, gem, crown, goldbar, cube, duck_gold, figurine, cash, vase, painting, laptop, radio, teddy, toolbox,
     microscope, flasks, powercell, tv, microwave, computer, server, safe, statue, aquarium])
