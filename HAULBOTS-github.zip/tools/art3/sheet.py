"""Compose transparent renders into dark reference sheets (template style).
python3 sheet.py <out.png> <title> <cols> <cell_px> <render_dir> name=Label [name=Label ...]
A name may be '#Section title' to start a new section row."""
import sys, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FONT = "/home/claude/haulbots/assets/fonts/RussoOne.ttf"
FONT2 = "/home/claude/haulbots/assets/fonts/Rubik-Medium.ttf"
BG = (11, 15, 22)
CARD = (20, 27, 38)
CARD2 = (26, 35, 49)
EDGE = (44, 60, 82)
TXT = (214, 224, 236)
DIM = (130, 146, 166)


def card_bg(w, h):
    im = Image.new("RGB", (w, h), CARD)
    d = ImageDraw.Draw(im)
    # soft vertical gradient + spotlight
    for y in range(h):
        k = y / h
        c = tuple(int(CARD2[i] * (1 - k) + CARD[i] * k) for i in range(3))
        d.line([(0, y), (w, y)], fill=c)
    spot = Image.new("L", (w, h), 0)
    ImageDraw.Draw(spot).ellipse([w * 0.1, h * 0.05, w * 0.9, h * 0.85], fill=60)
    spot = spot.filter(ImageFilter.GaussianBlur(w * 0.12))
    glow = Image.new("RGB", (w, h), (70, 92, 120))
    im = Image.composite(glow, im, spot)
    return im


def make(out, title, cols, cell, rdir, items, sub=""):
    f_title = ImageFont.truetype(FONT, 34)
    f_sec = ImageFont.truetype(FONT, 24)
    f_lab = ImageFont.truetype(FONT2, max(14, cell // 15))
    pad = 14
    lab_h = max(26, cell // 9)
    rows = []          # list of (section, [items])
    cur = None
    for it in items:
        if it.startswith("#"):
            cur = (it[1:], [])
            rows.append(cur)
        else:
            if cur is None:
                cur = ("", [])
                rows.append(cur)
            cur[1].append(it)
    W = pad + cols * (cell + pad)
    H = 70 + (28 if sub else 0)
    for sec, its in rows:
        H += (40 if sec else 0) + ((len(its) + cols - 1) // cols) * (cell + lab_h + pad)
    H += 30
    im = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(im)
    d.text((pad, 16), title, font=f_title, fill=TXT)
    y = 66
    if sub:
        d.text((pad, y - 6), sub, font=ImageFont.truetype(FONT2, 18), fill=DIM)
        y += 28
    for sec, its in rows:
        if sec:
            d.text((pad, y + 4), sec.upper(), font=f_sec, fill=(232, 196, 64))
            d.line([(pad, y + 36), (W - pad, y + 36)], fill=EDGE, width=2)
            y += 44
        for i, it in enumerate(its):
            name, _, label = it.partition("=")
            cx = pad + (i % cols) * (cell + pad)
            cy = y + (i // cols) * (cell + lab_h + pad)
            cb = card_bg(cell, cell + lab_h)
            p = os.path.join(rdir, name + ".png")
            if os.path.exists(p):
                r = Image.open(p).convert("RGBA").resize((cell, cell), Image.LANCZOS)
                cb.paste(r, (0, 0), r)
            cd = ImageDraw.Draw(cb)
            cd.rectangle([0, cell, cell, cell + lab_h], fill=(14, 19, 27))
            tw = cd.textlength(label or name, font=f_lab)
            cd.text(((cell - tw) / 2, cell + (lab_h - f_lab.size) / 2 - 2), label or name, font=f_lab, fill=TXT)
            cd.rectangle([0, 0, cell - 1, cell + lab_h - 1], outline=EDGE, width=2)
            im.paste(cb, (cx, cy))
        y += ((len(its) + cols - 1) // cols) * (cell + lab_h + pad)
    d.text((pad, H - 26), "HAULBOTS · art v3 · low-poly / stylized / mobile / dark atmosphere", font=ImageFont.truetype(FONT2, 15), fill=DIM)
    im.save(out)
    print("SHEET", out, im.size)


if __name__ == "__main__":
    a = sys.argv[1:]
    make(a[0], a[1], int(a[2]), int(a[3]), a[4], a[5:])
