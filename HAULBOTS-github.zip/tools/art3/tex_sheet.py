import numpy as np, os, sys
from PIL import Image
sys.path.insert(0, os.path.dirname(__file__))
import sheet as SH
T = "/home/claude/art3/tex"
R = "/home/claude/art3/renders/tex"
os.makedirs(R, exist_ok=True)
names = [("wall_metal","Стена: металл"),("wall_block","Стена: блоки"),("wall_tiles","Стена: плитка"),("wall_plaster","Стена: штукатурка"),("wall_brick","Стена: кирпич"),("wall_corrugated","Стена: профлист"),
 ("floor_concrete","Пол: бетон"),("floor_plate","Пол: рифлёный"),("floor_vinyl","Пол: винил"),("floor_carpet","Пол: ковролин"),("floor_wood","Пол: доски"),("floor_grate","Пол: решётка"),
 ("ceiling_tiles","Потолок: плитка"),("ceiling_concrete","Потолок: бетон"),("hazard","Полосы"),("metal","Металл"),("wood_crate","Дерево ящиков"),("plastic_dark","Пластик"),("rust","Ржавчина"),("asphalt","Асфальт"),("ground","Земля")]
L = np.array([-0.5, 0.6, 0.65]); L /= np.linalg.norm(L)
for n, _ in names:
    a = np.array(Image.open(f"{T}/{n}.png").convert("RGB")) / 255.0
    nm = np.array(Image.open(f"{T}/{n}_n.png").convert("RGB")) / 255.0 * 2 - 1
    r = np.array(Image.open(f"{T}/{n}_r.png").convert("L")) / 255.0
    d = np.clip((nm * L).sum(-1), 0, 1)
    spec = np.clip(d, 0, 1) ** (2 + (1 - r) * 30) * (1 - r) * 0.5
    lit = a * (0.35 + 0.85 * d)[..., None] + spec[..., None]
    t = np.tile(np.clip(lit, 0, 1), (2, 2, 1))
    im = Image.fromarray((t * 255).astype(np.uint8)).resize((512, 512), Image.LANCZOS)
    im.save(f"{R}/{n}.png")
dec = [("oil_stain","Масляное пятно"),("crack","Трещина"),("footprints","Следы"),("arrow_floor","Стрелка"),("sign_exit","EXIT"),("sign_danger","Опасно"),("poster_loot","Плакат"),("poster_safety","Плакат ТБ"),("stencil_numbers","Трафарет")]
for n, _ in dec:
    im = Image.open(f"{T}/decals/{n}.png").convert("RGBA")
    w, h = im.size
    k = 440 / max(w, h)
    im = im.resize((int(w * k), int(h * k)), Image.LANCZOS)
    c = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
    bg = Image.open(f"{R}/floor_concrete.png").convert("RGBA") if n in ("oil_stain","crack","footprints","arrow_floor") else Image.open(f"{R}/wall_block.png").convert("RGBA")
    c = bg.copy()
    c.alpha_composite(im, ((512 - im.size[0]) // 2, (512 - im.size[1]) // 2))
    c.save(f"{R}/d_{n}.png")
items = ["#Стены"] + [f"{n}={l}" for n, l in names[:6]] + ["#Полы"] + [f"{n}={l}" for n, l in names[6:12]] + ["#Потолки и материалы"] + [f"{n}={l}" for n, l in names[12:]] + ["#Декали"] + [f"d_{n}={l}" for n, l in dec]
SH.make("/home/claude/art3/sheets/textures.png", "Текстуры и декали (повтор 2×2, с картой нормалей)", 6, 220, R, items)
