"""Helpers for tileable procedural PBR textures (numpy + PIL + scipy).
Everything works on a periodic N x N grid in UV space [0,1): any feature that leaves the tile on one
side comes back on the other, so every map tiles seamlessly by construction.
Used by textures.py (HAULBOTS art v3)."""
import math
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage
from scipy.spatial import cKDTree

N = 512
Y, X = (np.mgrid[0:N, 0:N].astype(np.float32) + 0.5) / N      # v (rows, down), u (cols, right)
PY, PX = np.mgrid[0:N, 0:N].astype(np.float32)                  # pixel indices
FONT = "/home/claude/haulbots/assets/fonts/RussoOne.ttf"
FONT2 = "/home/claude/haulbots/assets/fonts/Rubik-Bold.ttf"
FONT3 = "/home/claude/haulbots/assets/fonts/Rubik-Medium.ttf"
_cache = {}


# ------------------------------------------------------------------ basics
def C(h):
    return np.array([int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)], np.float32)


def ss(a, b, x):
    t = np.clip((x - a) / (b - a + 1e-9), 0, 1)
    return t * t * (3 - 2 * t)


def mix(a, b, t):
    a = np.asarray(a, np.float32)
    b = np.asarray(b, np.float32)
    t = np.asarray(t, np.float32)
    if t.ndim == 2 and (a.ndim == 3 or b.ndim == 3 or a.ndim == 1 or b.ndim == 1):
        t = t[..., None]
    return a * (1 - t) + b * t


def blur(a, s):
    if s <= 0:
        return a
    if a.ndim == 3:
        return ndimage.gaussian_filter(a, (s, s, 0), mode="wrap")
    return ndimage.gaussian_filter(a, s, mode="wrap")


def warp(a, dx, dy):
    """Sample a at (x+dx, y+dy) (pixels), periodic."""
    coords = [PY + dy, PX + dx]
    if a.ndim == 3:
        return np.dstack([ndimage.map_coordinates(a[..., c], coords, order=1, mode="grid-wrap") for c in range(a.shape[2])])
    return ndimage.map_coordinates(a, coords, order=1, mode="grid-wrap")


def rnd_lut(seed, n=4096):
    return np.random.default_rng(seed).random(n).astype(np.float32)


def hash_id(ids, seed):
    """Random 0..1 per integer id (array)."""
    lut = rnd_lut(seed)
    return lut[(ids.astype(np.int64) * 7919 + seed * 31) % len(lut)]


# ------------------------------------------------------------------ noise
def noise(freq, seed, aniso=1.0, angle=0.0, power=1.0):
    """Tileable gaussian noise (zero mean, unit std). freq ~ features per tile.
    aniso > 1 stretches the features along `angle` (radians, 0 = along u)."""
    key = (freq, seed, aniso, angle, power)
    if key in _cache:
        return _cache[key]
    r = np.random.default_rng(seed)
    w = r.standard_normal((N, N))
    ky = np.fft.fftfreq(N)[:, None] * N
    kx = np.fft.fftfreq(N)[None, :] * N
    c, s = math.cos(angle), math.sin(angle)
    ka = kx * c + ky * s
    kb = -kx * s + ky * c
    k = np.sqrt((ka * aniso) ** 2 + kb ** 2)
    k[0, 0] = 1.0
    filt = np.exp(-(k / freq) ** 2) / k ** power
    filt[0, 0] = 0.0
    out = np.real(np.fft.ifft2(np.fft.fft2(w) * filt)).astype(np.float32)
    out = (out - out.mean()) / (out.std() + 1e-9)
    _cache[key] = out
    return out


def fbm(seed, base=4, octaves=4, gain=0.5, aniso=1.0, angle=0.0):
    acc = np.zeros((N, N), np.float32)
    amp = 1.0
    for i in range(octaves):
        acc += noise(base * 2 ** i, seed + i * 101, aniso, angle, power=0.0) * amp
        amp *= gain
    return (acc - acc.mean()) / (acc.std() + 1e-9)


def ridged(seed, base=4, octaves=3, aniso=1.0, angle=0.0):
    """1 at the zero-crossings of an fbm -> network of thin lines (cracks, veins)."""
    return 1.0 - np.abs(fbm(seed, base, octaves, 0.55, aniso, angle))


def voronoi(n, seed, jitter=0.9):
    """Periodic jittered-grid Voronoi with ~n x n cells.
    Returns F1 (px), edge (exact px distance to the nearest cell border), id, cell centre arrays."""
    key = ("vor", n, seed, jitter)
    if key in _cache:
        return _cache[key]
    r = np.random.default_rng(seed)
    gy, gx = np.mgrid[0:n, 0:n].astype(np.float64)
    pts = np.stack([(gy + 0.5 + (r.random((n, n)) - 0.5) * jitter) / n,
                    (gx + 0.5 + (r.random((n, n)) - 0.5) * jitter) / n], -1).reshape(-1, 2) % 1.0
    pts *= N
    tree = cKDTree(pts, boxsize=N)
    q = np.stack([PY.ravel() + 0.5, PX.ravel() + 0.5], -1)
    d, idx = tree.query(q, k=2)
    p1 = pts[idx[:, 0]]
    p2 = pts[idx[:, 1]]
    dv = p2 - p1
    dv -= N * np.round(dv / N)
    dist12 = np.sqrt((dv ** 2).sum(-1)) + 1e-6
    edge = (d[:, 1] ** 2 - d[:, 0] ** 2) / (2 * dist12)
    res = (d[:, 0].reshape(N, N).astype(np.float32), edge.reshape(N, N).astype(np.float32),
           idx[:, 0].reshape(N, N), pts)
    _cache[key] = res
    return res


def grid(nu, nv, offset_rows=0.0, seed=0, jitter_rows=False):
    """Regular (optionally running-bond) grid. Returns local u, v (0..1), cell size px (w, h),
    distance to cell edge in px, cell ids."""
    fv = Y * nv
    iv = np.floor(fv)
    off = (iv * offset_rows) % 1.0
    if jitter_rows:
        off = hash_id(iv, seed)
    fu = (X * nu + off)
    iu = np.floor(fu)
    lu, lv = fu - iu, fv - iv
    iu = iu % nu
    cw, ch = N / nu, N / nv
    d = np.minimum(np.minimum(lu, 1 - lu) * cw, np.minimum(lv, 1 - lv) * ch)
    ids = (iv * 97 + iu).astype(np.int64)
    return lu, lv, cw, ch, d, ids


# ------------------------------------------------------------------ painting with wrap-around
class WrapCanvas:
    """PIL canvas (supersampled) where every primitive is drawn 9x with +-N offsets, so shapes crossing
    the border wrap around. get() returns an N x N float array."""

    def __init__(self, ss_=2, mode="L", fill=0):
        self.s = ss_
        self.W = N * ss_
        self.mode = mode
        self.im = Image.new(mode, (self.W, self.W), fill)
        self.d = ImageDraw.Draw(self.im)

    def _offs(self):
        W = self.W
        return [(ox, oy) for ox in (-W, 0, W) for oy in (-W, 0, W)]

    def _p(self, pts, ox, oy):
        s = self.s
        return [(x * s + ox, y * s + oy) for x, y in pts]

    def poly(self, pts, fill):
        for ox, oy in self._offs():
            self.d.polygon(self._p(pts, ox, oy), fill=fill)

    def line(self, pts, width, fill, caps=True):
        s = self.s
        for ox, oy in self._offs():
            pp = self._p(pts, ox, oy)
            self.d.line(pp, fill=fill, width=max(1, int(round(width * s))), joint="curve")
            if caps:
                r = width * s / 2
                for x, y in (pp[0], pp[-1]):
                    self.d.ellipse([x - r, y - r, x + r, y + r], fill=fill)

    def ellipse(self, cx, cy, rx, ry, fill, angle=0.0, segs=28):
        ca, sa = math.cos(angle), math.sin(angle)
        pts = []
        for i in range(segs):
            t = i / segs * 2 * math.pi
            x, y = math.cos(t) * rx, math.sin(t) * ry
            pts.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
        self.poly(pts, fill)

    def text(self, x, y, txt, size, fill, font=FONT, anchor="mm"):
        f = ImageFont.truetype(font, int(size * self.s))
        for ox, oy in self._offs():
            self.d.text((x * self.s + ox, y * self.s + oy), txt, font=f, fill=fill, anchor=anchor)

    def get(self):
        a = np.asarray(self.im, np.float32)
        if self.s > 1:
            a = a.reshape(N, self.s, N, self.s, *a.shape[2:]).mean((1, 3))
        return a / 255.0 if self.mode in ("L", "RGB", "RGBA") else a


def daubs(seed, count=260, length=(20, 70), width=(8, 22), angle=None, ajit=math.pi, soft=1.2):
    """Painterly brush-daub layer: overlapping flat strokes of random tone, in [-1, 1].
    Later strokes cover earlier ones (like paint), edges softened by `soft` px."""
    r = np.random.default_rng(seed)
    cv = WrapCanvas(1, "F", 0.0)
    for _ in range(count):
        x, y = r.random() * N, r.random() * N
        a = (angle if angle is not None else 0.0) + (r.random() - 0.5) * ajit
        ln = r.uniform(*length)
        w = r.uniform(*width)
        cv.ellipse(x, y, ln / 2, w / 2, float(r.uniform(-1, 1)), a, 20)
    out = np.asarray(cv.im, np.float32)
    return blur(out, soft)


def scratches(seed, count=40, length=(10, 60), width=(0.8, 1.6), angle=None, ajit=math.pi, curve=0.15, ss_=3):
    """Thin scratch lines (0..1)."""
    r = np.random.default_rng(seed)
    cv = WrapCanvas(ss_, "L", 0)
    for _ in range(count):
        x, y = r.random() * N, r.random() * N
        a = (angle if angle is not None else r.random() * math.pi * 2) + (r.random() - 0.5) * ajit
        ln = r.uniform(*length)
        pts = []
        steps = 6
        for i in range(steps + 1):
            t = i / steps
            a2 = a + math.sin(t * 3) * curve
            pts.append((x + math.cos(a2) * ln * t, y + math.sin(a2) * ln * t))
        cv.line(pts, r.uniform(*width), int(r.uniform(120, 255)), caps=False)
    return cv.get()


def drips(src, length=60, decay=0.97, seed=0, streak_freq=40):
    """Downward streaks (rust / water) from a 0..1 source mask, periodic."""
    s = src.astype(np.float32).copy()
    acc = s.copy()
    for _ in range(length):
        s = np.roll(s, 1, axis=0) * decay
        acc = np.maximum(acc, s)
    st = ss(-0.3, 1.2, noise(streak_freq, seed + 3, aniso=8.0, angle=math.pi / 2, power=0.0))
    return acc * (0.35 + 0.65 * st)


def grime(seed, base=3, lo=0.2, hi=1.4):
    """Large soft stains 0..1."""
    return ss(lo, hi, fbm(seed, base, 4, 0.55))


# ------------------------------------------------------------------ height / shading helpers
def curv(h, r=3.0):
    """Local curvature: >0 on convex edges, <0 in crevices."""
    return h - blur(h, r)


def normal_map(h, strength):
    """OpenGL / Y+ normal map (Godot). h in arbitrary units, strength scales slopes."""
    hb = blur(h, 0.6)
    dx = (np.roll(hb, -1, 1) - np.roll(hb, 1, 1)) * 0.5 * strength
    dy = (np.roll(hb, -1, 0) - np.roll(hb, 1, 0)) * 0.5 * strength
    nz = np.ones_like(hb)
    l = np.sqrt(dx * dx + dy * dy + nz * nz)
    return np.stack([-dx / l, dy / l, nz / l], -1)      # +x right, +y up (rows grow downward)


def kuwahara(img, r=3):
    """Painterly edge-preserving flattening (periodic)."""
    lum = img @ np.array([0.3, 0.59, 0.11], np.float32) if img.ndim == 3 else img
    k = r + 1
    m = np.stack([ndimage.uniform_filter(img[..., c], k, mode="wrap") for c in range(3)], -1) if img.ndim == 3 \
        else ndimage.uniform_filter(img, k, mode="wrap")
    ml = ndimage.uniform_filter(lum, k, mode="wrap")
    m2 = ndimage.uniform_filter(lum * lum, k, mode="wrap")
    var = m2 - ml * ml
    sh = r // 2
    best = None
    bvar = None
    for dy in (-sh, sh):
        for dx in (-sh, sh):
            v = np.roll(var, (dy, dx), (0, 1))
            mm = np.roll(m, (dy, dx), (0, 1))
            if best is None:
                best, bvar = mm, v
            else:
                sel = v < bvar
                best = np.where(sel[..., None] if img.ndim == 3 else sel, mm, best)
                bvar = np.minimum(v, bvar)
    return best


def finish(alb, h, cav=0.5, edge=0.25, edge_col=None, bake=0.10, bake_str=4.0, cav_r=3.0):
    """Stylized bake: cavity darkening, convex-edge highlight, soft top-left light from the height."""
    c = curv(h, cav_r)
    c = c / (np.abs(c).max() + 1e-6)
    out = alb * np.clip(1.0 + np.minimum(c, 0) * cav * 2.0, 0.35, 1.0)[..., None]
    if edge > 0:
        e = np.clip(c, 0, 1) * edge * 2.0
        tgt = alb * 1.6 + 0.04 if edge_col is None else edge_col
        out = mix(out, tgt, np.clip(e, 0, 1))
    if bake > 0:
        n = normal_map(h, bake_str)
        L = np.array([-0.45, 0.55, 0.70], np.float32)
        L /= np.linalg.norm(L)
        d = n @ L - L[2]
        out = out * (1.0 + d * bake * 2.0)[..., None]
    return np.clip(out, 0, 1)


def save_set(out_dir, name, alb, h, rough, nstr):
    os.makedirs(out_dir, exist_ok=True)
    a8 = (np.clip(alb, 0, 1) * 255 + 0.5).astype(np.uint8)
    Image.fromarray(a8, "RGB").save(os.path.join(out_dir, name + ".png"))
    n = normal_map(h, nstr)
    Image.fromarray((np.clip(n * 0.5 + 0.5, 0, 1) * 255 + 0.5).astype(np.uint8), "RGB").save(os.path.join(out_dir, name + "_n.png"))
    Image.fromarray((np.clip(rough, 0, 1) * 255 + 0.5).astype(np.uint8), "L").save(os.path.join(out_dir, name + "_r.png"))
    return a8


def seam_score(path):
    """Ratio of the colour jump across the wrap border to the typical jump between neighbouring pixels.
    ~1 = seamless."""
    a = np.asarray(Image.open(path).convert("RGB"), np.float32)
    inner_x = np.abs(np.diff(a, axis=1)).mean()
    inner_y = np.abs(np.diff(a, axis=0)).mean()
    wrap_x = np.abs(a[:, 0] - a[:, -1]).mean()
    wrap_y = np.abs(a[0] - a[-1]).mean()
    return wrap_x / (inner_x + 1e-6), wrap_y / (inner_y + 1e-6)
