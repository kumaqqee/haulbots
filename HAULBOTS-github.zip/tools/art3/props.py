"""Environment props, furniture, lights and interactive objects, art v3 (origin bottom centre;
wall-mounted things: origin at the wall contact, facing +Y)."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *

STEEL = "L_metal_8a8f99"
DARK = "L_metal_2a2d33"
GREY = "L_paint_5a6470"
HAZ = "L_paint_e8b420"
BLK = "L_paint_15151a"
WOOD = "L_wood_8a5a32"
RUB = "L_rubber_1c1d22"


def text_mesh(txt, size, pos, material, extrude=0.01, rot=(math.pi / 2, 0, math.pi), font="/home/claude/haulbots/assets/fonts/RussoOne.ttf"):
    cu = bpy.data.curves.new("t", "FONT")
    cu.body = txt
    cu.size = size
    cu.extrude = extrude
    cu.align_x = "CENTER"
    cu.align_y = "CENTER"
    try:
        cu.font = bpy.data.fonts.load(font)
    except Exception:
        pass
    ob = bpy.data.objects.new("t", cu)
    bpy.context.scene.collection.objects.link(ob)
    ob.location = pos
    ob.rotation_euler = rot
    for o in bpy.context.selected_objects:
        o.select_set(False)
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    bpy.ops.object.convert(target="MESH")
    me = bpy.context.view_layer.objects.active
    me.data.materials.clear()
    me.data.materials.append(mat(material))
    return me


def hazard_band(w, d, z, h=0.08, n=8):
    out = [box((w + 0.004, d + 0.004, h), (0, 0, z), HAZ, 0.0)]
    for i in range(n):
        out.append(box((w / n * 0.5, d + 0.008, h * 1.02), (-w / 2 + (i + 0.5) * w / n, 0, z), BLK, 0.0, rot=(0, 0.6, 0)))
    return out


# ================================================================ warehouse
def crate():
    reset()
    W = "L_wood_9a6a3a"
    p = [box((0.8, 0.8, 0.8), (0, 0, 0.4), W, 0.01)]
    for s in (1, -1):
        for ax in (0, 1):
            for z in (0.06, 0.74):
                sz = (0.84, 0.06, 0.1) if ax == 0 else (0.06, 0.84, 0.1)
                pos = (0, s * 0.41, z) if ax == 0 else (s * 0.41, 0, z)
                p.append(box(sz, pos, "L_wood_6a4022", 0.008))
        p.append(box((0.06, 0.06, 0.8), (s * 0.41, 0.41, 0.4), "L_wood_6a4022", 0.008))
        p.append(box((0.06, 0.06, 0.8), (s * 0.41, -0.41, 0.4), "L_wood_6a4022", 0.008))
        p.append(box((0.84, 0.06, 0.1), (0, s * 0.41, 0.4), "L_wood_6a4022", 0.008, rot=(0, 0.75, 0)))
    p.append(box((0.3, 0.01, 0.12), (0.12, 0.445, 0.55), "L_paper_d8d0b0", 0.0))
    p.append(text_mesh("FRAGILE", 0.06, (0.12, 0.452, 0.55), "L_paint_a02a20", 0.002))
    prop_save("crate", p, tris=900)


def crate_metal():
    reset()
    p = [box((1.0, 0.6, 0.55), (0, 0, 0.275), "L_paint_4a5a4a", 0.03), box((1.04, 0.64, 0.08), (0, 0, 0.52), "L_paint_3a4a3a", 0.02)]
    p += [box((0.08, 0.04, 0.06), (s * 0.35, 0.32, 0.46), DARK, 0.01) for s in (1, -1)]
    p += [box((0.04, 0.66, 0.5), (x, 0, 0.27), "L_paint_3a4a3a", 0.008) for x in (-0.3, 0.3)]
    p += [box((0.1, 0.05, 0.03), (s * 0.53, 0, 0.35), DARK, 0.008) for s in (1, -1)]
    p.append(text_mesh("B-07", 0.1, (0, 0.322, 0.28), "L_paint_d8d0b0", 0.002))
    prop_save("crate_metal", p, tris=700)


def barrel():
    reset()
    b = cyl(0.29, 0.88, (0, 0, 0.44), "L_paint_2a5a9a", 20, bevel=0.01)
    rims = [cyl(0.3, 0.03, (0, 0, z), "L_paint_1e4a80", 20) for z in (0.02, 0.3, 0.58, 0.86)]
    lid = cyl(0.27, 0.01, (0, 0, 0.885), "L_metal_5a6a7a", 20)
    cap = cyl(0.04, 0.02, (0.15, 0, 0.895), DARK, 10)
    label = cyl(0.292, 0.18, (0, 0, 0.44), "L_paint_e8b420", 20)
    sym = box((0.12, 0.01, 0.12), (0, 0.293, 0.44), BLK, 0.0, rot=(0, 0.785, 0))
    rust = sphere(0.1, (0.2, 0.2, 0.15), "L_rust_7a4a22", 8, 4, (1, 0.25, 1.4))
    rust.rotation_euler = (0, 0, 0.785)
    prop_save("barrel", [b, lid, cap, label, sym, rust] + rims, tris=700)


def cone():
    reset()
    base = box((0.36, 0.36, 0.04), (0, 0, 0.02), "L_rubber_1c1d22", 0.01)
    c = cyl(0.14, 0.62, (0, 0, 0.35), "L_plastic_e85a1a", 16, r2=0.025)
    stripes = [cyl(0.115 - i * 0.04, 0.07, (0, 0, 0.25 + i * 0.16), "L_plastic_e8e4da", 16, r2=0.105 - i * 0.04) for i in range(2)]
    prop_save("cone", [base, c] + stripes, tris=400)


def rack():
    reset()
    B = "L_paint_2a5a9a"
    O = "L_paint_e86a1a"
    p = []
    for x in (-0.9, 0.9):
        for y in (-0.35, 0.35):
            p.append(box((0.06, 0.06, 2.6), (x, y, 1.3), B, 0.008))
    for z in (0.15, 1.0, 1.85):
        for y in (-0.35, 0.35):
            p.append(box((1.86, 0.06, 0.1), (0, y, z), O, 0.008))
        p.append(box((1.8, 0.7, 0.03), (0, 0, z + 0.06), "L_wood_8a6a40", 0.004))
    p += [box((0.02, 0.02, 0.9), (x, -0.35, 0.55), B, 0.0, rot=(0, 0.75 * (1 if x > 0 else -1), 0)) for x in (-0.89, 0.89)]
    rnd = random.Random(3)
    for z in (0.21, 1.06, 1.91):
        x = -0.8
        while x < 0.7:
            w = rnd.uniform(0.3, 0.5)
            h = rnd.uniform(0.25, 0.55)
            p.append(box((w, 0.55, h), (x + w / 2, 0, z + h / 2), rnd.choice(["L_paper_a07a48", "L_paper_b08a58", "L_paper_907048"]), 0.01))
            p.append(box((w * 0.9, 0.56, 0.04), (x + w / 2, 0, z + h * 0.8), "L_paper_d8c8a0", 0.0))
            x += w + 0.05
    prop_save("rack", p, tex=512, tris=2500)


def pallet():
    reset()
    p = [box((1.2, 1.0, 0.03), (0, 0, 0.135), "L_wood_a07a48", 0.004)]
    p += [box((1.2, 0.12, 0.1), (0, y, 0.07), "L_wood_8a6038", 0.006) for y in (-0.44, 0.0, 0.44)]
    p += [box((0.12, 1.0, 0.02), (x, 0, 0.01), "L_wood_8a6038", 0.004) for x in (-0.54, 0.0, 0.54)]
    rnd = random.Random(5)
    for i, (x, y) in enumerate([(-0.3, -0.25), (0.3, -0.25), (-0.3, 0.25), (0.3, 0.25)]):
        h = rnd.uniform(0.35, 0.5)
        p.append(box((0.55, 0.45, h), (x, y, 0.15 + h / 2), "L_paper_a87a48", 0.01))
        p.append(box((0.08, 0.46, h + 0.002), (x, y, 0.15 + h / 2), "L_paper_c8a868", 0.0))
    p.append(box((0.5, 0.4, 0.3), (0.0, 0.0, 0.66), "L_paper_b08a58", 0.01))
    wrap = box((1.15, 0.95, 0.4), (0, 0, 0.36), "G_e8f0f8", 0.02)
    p.append(wrap)
    prop_save("pallet", p, tris=900)


def boxes():
    reset()
    p = []
    for x, y, z, s, r in ((0, 0, 0, 0.5, 0.1), (0.45, 0.1, 0, 0.4, -0.2), (0.1, 0.05, 0.5, 0.38, 0.4), (-0.4, -0.05, 0, 0.35, 0.3)):
        p.append(box((s, s * 0.85, s * 0.8), (x, y, z + s * 0.4), "L_paper_a87a48", 0.01, rot=(0, 0, r)))
        p.append(box((s * 0.15, s * 0.86, s * 0.81), (x, y, z + s * 0.4), "L_paper_c8a868", 0.0, rot=(0, 0, r)))
    prop_save("boxes", p, tris=500)


def forklift():
    reset()
    Y = "L_paint_e8b420"
    p = [box((1.1, 1.8, 0.5), (0, -0.2, 0.45), Y, 0.06), box((1.0, 0.6, 0.55), (0, -0.85, 0.85), Y, 0.08)]
    p.append(box((1.0, 0.7, 0.12), (0, -0.25, 0.75), DARK, 0.02))
    seat = [box((0.5, 0.45, 0.12), (0, -0.4, 0.86), "L_leather_1e1c1a", 0.04), box((0.5, 0.1, 0.45), (0, -0.62, 1.1), "L_leather_1e1c1a", 0.04)]
    for x in (-0.48, 0.48):
        for y in (0.45, -0.65):
            p.append(box((0.07, 0.07, 1.4), (x, y, 1.5), DARK, 0.01))
    p.append(box((1.05, 1.2, 0.06), (0, -0.1, 2.2), DARK, 0.01))
    p += [box((0.1, 0.12, 2.2), (x, 0.75, 1.15), "L_metal_3a3d44", 0.01) for x in (-0.3, 0.3)]
    p += [box((0.9, 0.08, 0.1), (0, 0.78, z), "L_metal_3a3d44", 0.01) for z in (0.45, 1.6)]
    p += [box((0.12, 1.0, 0.05), (x, 1.25, 0.08), STEEL, 0.008) for x in (-0.25, 0.25)]
    wheel = [cyl(r, 0.22, (x, y, r), RUB, 16, rot=(0, math.pi / 2, 0), bevel=0.02) for x in (-0.48, 0.48) for y, r in ((0.4, 0.28), (-0.85, 0.24))]
    hubs = [cyl(0.12, 0.23, (x, y, r), STEEL, 10, rot=(0, math.pi / 2, 0)) for x in (-0.48, 0.48) for y, r in ((0.4, 0.28), (-0.85, 0.24))]
    wheel_s = box((0.06, 0.06, 0.4), (0.0, 0.0, 1.05), DARK, 0.01, rot=(-0.5, 0, 0))
    steer = cyl(0.15, 0.03, (0, 0.12, 1.25), RUB, 16, rot=(-0.5, 0, 0))
    beacon = cyl(0.06, 0.1, (0.4, -0.6, 2.28), "E_ffb04a", 10)
    stripes = [box((0.1, 0.02, 0.2), (-0.45 + i * 0.15, -1.16, 0.85), BLK, 0.0, rot=(0, 0.6, 0)) for i in range(7)]
    rust = [sphere(0.12, (0.55, 0.1, 0.5), "L_rust_7a4a22", 8, 4, (0.2, 1.4, 0.8))]
    prop_save("forklift", p + seat + wheel + hubs + [wheel_s, steer, beacon] + stripes + rust, tex=512, tris=3000)


def jerrycan():
    reset()
    b = box((0.18, 0.36, 0.46), (0, 0, 0.23), "L_paint_a02a20", 0.03)
    x_ = [box((0.19, 0.04, 0.5), (0, 0, 0.23), "L_paint_801e18", 0.01, rot=(a, 0, 0)) for a in (0.6, -0.6)]
    handles = [box((0.04, 0.1, 0.04), (0, y, 0.48), "L_paint_801e18", 0.01) for y in (-0.1, 0.0, 0.1)]
    spout = cyl(0.03, 0.06, (0, 0.14, 0.48), DARK, 10, rot=(0.6, 0, 0))
    prop_save("jerrycan", [b, spout] + x_ + handles, tris=500)


# ================================================================ office
def desk():
    reset()
    p = [box((1.6, 0.8, 0.05), (0, 0, 0.74), "L_wood_7a5a3a", 0.01)]
    p += [box((0.04, 0.7, 0.72), (s * 0.76, 0, 0.36), GREY, 0.006) for s in (1, -1)]
    p.append(box((0.42, 0.7, 0.6), (0.55, 0, 0.42), GREY, 0.01))
    p += [box((0.38, 0.02, 0.16), (0.55, 0.355, 0.62 - i * 0.19), "L_paint_4a545e", 0.004) for i in range(3)]
    p += [box((0.1, 0.02, 0.015), (0.55, 0.37, 0.65 - i * 0.19), STEEL, 0.003) for i in range(3)]
    mon = [box((0.5, 0.05, 0.32), (-0.15, -0.2, 1.0), "L_plastic_1a1c22", 0.01), box((0.46, 0.01, 0.28), (-0.15, -0.172, 1.0), "E_2a6aa0", 0.004),
           box((0.05, 0.05, 0.12), (-0.15, -0.22, 0.82), "L_plastic_1a1c22", 0.006), box((0.2, 0.15, 0.02), (-0.15, -0.22, 0.775), "L_plastic_1a1c22", 0.006)]
    kb = box((0.42, 0.14, 0.02), (-0.15, 0.12, 0.775), "L_plastic_2a2c33", 0.004)
    mug = cyl(0.04, 0.09, (0.35, 0.15, 0.81), "L_ceramic_c0302a", 12)
    papers = [box((0.22, 0.3, 0.01), (0.4, -0.15, 0.77 + i * 0.01), "L_paper_e8e0d0", 0.0, rot=(0, 0, 0.1 * i)) for i in range(3)]
    prop_save("desk", p + mon + [kb, mug] + papers, tris=1200)


def office_chair():
    reset()
    seat = box((0.5, 0.48, 0.08), (0, 0, 0.48), "L_fabric_2a2c33", 0.03)
    back = box((0.46, 0.08, 0.55), (0, -0.25, 0.85), "L_fabric_2a2c33", 0.03, rot=(-0.12, 0, 0))
    post = cyl(0.03, 0.35, (0, 0, 0.27), STEEL, 10)
    arms = [box((0.05, 0.3, 0.04), (s * 0.27, 0, 0.66), "L_plastic_1a1c22", 0.01) for s in (1, -1)] + [box((0.04, 0.04, 0.18), (s * 0.27, 0.05, 0.57), "L_plastic_1a1c22", 0.006) for s in (1, -1)]
    star = []
    for i in range(5):
        a = i * math.tau / 5
        star.append(box((0.34, 0.05, 0.04), (math.cos(a) * 0.17, math.sin(a) * 0.17, 0.1), "L_plastic_1a1c22", 0.01, rot=(0, 0, a)))
        star.append(sphere(0.035, (math.cos(a) * 0.33, math.sin(a) * 0.33, 0.04), RUB, 8, 4))
    rip = box((0.12, 0.01, 0.06), (0.1, 0.24, 0.5), "L_fabric_c8b080", 0.0)
    prop_save("office_chair", [seat, back, post, rip] + arms + star, tris=900)


def table():
    reset()
    p = [box((1.8, 0.9, 0.05), (0, 0, 0.74), "L_wood_6a4a2a", 0.01)]
    p += [box((0.06, 0.06, 0.72), (x, y, 0.36), DARK, 0.006) for x in (-0.82, 0.82) for y in (-0.38, 0.38)]
    p += [box((1.6, 0.04, 0.06), (0, y, 0.68), DARK, 0.006) for y in (-0.38, 0.38)]
    prop_save("table", p, tris=400)


def filing_cabinet():
    reset()
    p = [box((0.5, 0.65, 1.32), (0, 0, 0.66), "L_paint_6a7480", 0.015)]
    for i in range(4):
        z = 0.2 + i * 0.32
        p.append(box((0.44, 0.02, 0.28), (0, 0.33, z), "L_paint_5a6470", 0.008))
        p.append(box((0.14, 0.03, 0.025), (0, 0.345, z + 0.06), STEEL, 0.004))
        p.append(box((0.08, 0.01, 0.04), (0, 0.342, z + 0.1), "L_paper_e8e0d0", 0.0))
    p.append(box((0.44, 0.3, 0.26), (0, 0.45, 0.84), "L_paint_5a6470", 0.008))
    p.append(box((0.4, 0.26, 0.02), (0, 0.45, 0.97), "L_paper_e8e0d0", 0.0))
    dent = sphere(0.06, (0.25, 0.1, 0.5), "L_paint_4a545e", 6, 3, (0.2, 1, 1))
    prop_save("filing_cabinet", p + [dent], tris=600)


def locker():
    reset()
    p = []
    for i, x in enumerate((-0.3, 0.0, 0.3)):
        p.append(box((0.3, 0.5, 1.9), (x, 0, 0.95), "L_paint_3a5a7a", 0.008))
        p.append(box((0.26, 0.02, 1.8), (x, 0.255, 0.95), "L_paint_2e4e6a", 0.006))
        p += [box((0.18, 0.025, 0.012), (x, 0.268, 1.6 - k * 0.025), BLK, 0.0) for k in range(5)]
        p.append(box((0.03, 0.03, 0.12), (x + 0.09, 0.27, 1.05), STEEL, 0.004))
        p.append(box((0.06, 0.012, 0.04), (x, 0.268, 1.35), "L_paper_e8e0d0", 0.0))
    p.append(box((0.92, 0.52, 0.04), (0, 0, 1.92), "L_paint_2e4e6a", 0.006))
    p[1].rotation_euler = (0, 0, 0.0)
    prop_save("locker", p, tris=900)


def sofa():
    reset()
    F = "L_fabric_6a3a2a"
    p = [box((1.9, 0.85, 0.3), (0, 0, 0.3), F, 0.06), box((1.9, 0.25, 0.55), (0, -0.33, 0.6), F, 0.08)]
    p += [box((0.22, 0.85, 0.55), (s * 0.95, 0, 0.42), F, 0.08) for s in (1, -1)]
    p += [box((0.85, 0.6, 0.15), (s * 0.43, 0.08, 0.52), "L_fabric_7a4a32", 0.06) for s in (1, -1)]
    p += [box((0.06, 0.06, 0.12), (x, y, 0.06), "L_wood_3a2414", 0.01) for x in (-0.85, 0.85) for y in (-0.35, 0.35)]
    rip = box((0.2, 0.02, 0.1), (0.4, 0.38, 0.55), "L_fabric_d8c8a0", 0.0, rot=(0.6, 0, 0.2))
    prop_save("sofa", p + [rip], tris=900)


def plant():
    reset()
    pot = cyl(0.17, 0.32, (0, 0, 0.16), "L_ceramic_8a4a2a", 16, r2=0.21, bevel=0.01)
    soil = cyl(0.19, 0.02, (0, 0, 0.31), "L_stone_3a2a1a", 16)
    leaves = []
    rnd = random.Random(2)
    for i in range(9):
        a = i * 2.4
        h = rnd.uniform(0.5, 1.0)
        leaves.append(skin([(0, 0, 0.3, 0.012), (math.cos(a) * 0.1, math.sin(a) * 0.1, 0.3 + h * 0.6, 0.01), (math.cos(a) * 0.25, math.sin(a) * 0.25, 0.3 + h, 0.006)], material="L_wood_4a3a22", subdiv=1))
        leaves.append(meta("lf", [("ell", (math.cos(a) * 0.3, math.sin(a) * 0.3, 0.3 + h - 0.03), 0.09, (1.6, 0.6, 0.15), (0.3, 0, a))], "L_skin_3a6a2a" if i % 3 else "L_skin_6a6a2a", 0.015))
    prop_save("plant", [pot, soil] + leaves, tris=1400)


def floor_lamp():
    reset()
    base = cyl(0.16, 0.03, (0, 0, 0.015), DARK, 16, bevel=0.006)
    pole = cyl(0.015, 1.5, (0, 0, 0.78), "L_metal_b08a4a", 8)
    shade = cyl(0.22, 0.3, (0, 0, 1.6), "L_fabric_d8c8a0", 18, r2=0.15)
    bulb = sphere(0.05, (0, 0, 1.5), "E_ffd8a0", 8, 4)
    prop_save("floor_lamp", [base, pole, shade, bulb], tris=500)


def whiteboard():
    reset()
    board = box((1.6, 0.04, 0.95), (0, 0.02, 1.45), "L_paint_e8e8e0", 0.01)
    frame = [box((1.66, 0.05, 0.04), (0, 0.025, z), STEEL, 0.006) for z in (0.97, 1.93)] + [box((0.04, 0.05, 1.0), (s * 0.82, 0.025, 1.45), STEEL, 0.006) for s in (1, -1)]
    tray = box((1.0, 0.08, 0.02), (0, 0.06, 0.96), STEEL, 0.004)
    marks = [box((0.4, 0.005, 0.02), (-0.3, 0.042, 1.7), "L_paint_2a5ad8", 0.0, rot=(0, 0.1, 0)), box((0.25, 0.005, 0.02), (-0.4, 0.042, 1.6), "L_paint_2a5ad8", 0.0),
             box((0.3, 0.005, 0.02), (0.3, 0.042, 1.4), "L_paint_c0302a", 0.0, rot=(0, -0.4, 0))]
    marks.append(text_mesh("КВОТА?", 0.12, (0.25, 0.043, 1.68), "L_paint_c0302a", 0.002))
    legs = [box((0.04, 0.04, 1.0), (s * 0.82, 0.0, 0.5), STEEL, 0.004) for s in (1, -1)] + [box((0.04, 0.5, 0.04), (s * 0.82, 0.0, 0.02), STEEL, 0.004) for s in (1, -1)]
    prop_save("whiteboard", [board, tray] + frame + marks + legs, tris=700)


def water_cooler():
    reset()
    body = box((0.32, 0.32, 0.95), (0, 0, 0.475), "L_paint_e8e4da", 0.02)
    jug = cyl(0.13, 0.42, (0, 0, 1.17), "G_8ac8ff", 16, bevel=0.02)
    water = cyl(0.12, 0.25, (0, 0, 1.1), "G_3a8ad8", 16)
    taps = [box((0.04, 0.05, 0.05), (x, 0.17, 0.75), c, 0.006) for x, c in ((-0.06, "L_plastic_2a6ad8"), (0.06, "L_plastic_c0302a"))]
    tray = box((0.24, 0.1, 0.03), (0, 0.17, 0.6), DARK, 0.005)
    prop_save("water_cooler", [body, jug, water, tray] + taps, tris=500)


def vending():
    reset()
    body = box((0.9, 0.8, 1.9), (0, 0, 0.95), "L_paint_a02a20", 0.03)
    win = box((0.6, 0.02, 1.3), (-0.1, 0.405, 1.1), "G_c8e0f0", 0.01)
    glow = box((0.58, 0.01, 1.28), (-0.1, 0.39, 1.1), "E_ffe8c0", 0.0)
    goods = []
    cols = ["L_plastic_e8b420", "L_plastic_2a6ad8", "L_plastic_3aa040", "L_plastic_e86a1a", "L_plastic_e8e4da"]
    for r in range(5):
        goods.append(box((0.58, 0.3, 0.02), (-0.1, 0.25, 0.58 + r * 0.24), STEEL, 0.0))
        for c in range(5):
            goods.append(box((0.08, 0.1, 0.13), (-0.34 + c * 0.12, 0.32, 0.66 + r * 0.24), cols[(r + c) % 5], 0.01))
    panel = box((0.2, 0.02, 0.5), (0.33, 0.405, 1.25), "L_plastic_1a1c22", 0.01)
    disp = box((0.14, 0.01, 0.05), (0.33, 0.417, 1.42), "E_4aff7a", 0.003)
    keys = [box((0.03, 0.01, 0.03), (0.29 + (i % 3) * 0.04, 0.417, 1.32 - (i // 3) * 0.04), STEEL, 0.003) for i in range(9)]
    slot = box((0.5, 0.03, 0.15), (-0.1, 0.405, 0.25), "L_plastic_1a1c22", 0.01)
    logo = text_mesh("SNACK", 0.14, (-0.1, 0.42, 1.82), "E_ffe070", 0.004)
    prop_save("vending", [body, win, glow, panel, disp, slot, logo] + goods + keys, tex=512, tris=2500)


def toilet():
    reset()
    W = "L_ceramic_e8e4da"
    base = cyl(0.13, 0.35, (0, 0.05, 0.175), W, 16, r2=0.17)
    bowl = lathe([(0.0, 0.32), (0.16, 0.32), (0.21, 0.38), (0.21, 0.4), (0.16, 0.41), (0.0, 0.36)], W, 20, pos=(0, 0.12, 0))
    bowl.scale = (1.0, 1.25, 1.0)
    seat = lathe([(0.15, 0.4), (0.21, 0.405), (0.21, 0.43), (0.15, 0.425)], "L_plastic_e8e0d0", 20, cap_bottom=False, pos=(0, 0.12, 0))
    seat.scale = (1.0, 1.25, 1.0)
    tank = box((0.42, 0.2, 0.36), (0, -0.2, 0.6), W, 0.03)
    lid = box((0.44, 0.22, 0.04), (0, -0.2, 0.8), W, 0.015)
    btn = cyl(0.025, 0.02, (0, -0.2, 0.825), STEEL, 10)
    prop_save("toilet", [base, bowl, seat, tank, lid, btn], tris=700)


def sink():
    reset()
    W = "L_ceramic_e8e4da"
    basin = box((0.55, 0.45, 0.18), (0, 0.22, 0.8), W, 0.04)
    hole = box((0.44, 0.34, 0.1), (0, 0.24, 0.86), "L_ceramic_c8c4b8", 0.03)
    ped = cyl(0.1, 0.72, (0, 0.18, 0.36), W, 14, r2=0.08)
    tap = [cyl(0.015, 0.12, (0, 0.05, 0.95), STEEL, 8), box((0.02, 0.1, 0.02), (0, 0.09, 1.0), STEEL, 0.006)]
    mirror = box((0.5, 0.02, 0.65), (0, 0.01, 1.45), "L_chrome_c8d0d8", 0.01)
    crack = box((0.006, 0.01, 0.3), (0.1, 0.022, 1.5), "C_2a2a2a", 0.0, rot=(0, 0.4, 0))
    prop_save("sink", [basin, hole, ped, mirror, crack] + tap, tris=500)


def mirror():
    reset()
    frame = box((0.62, 0.04, 0.92), (0, 0.02, 1.3), "L_wood_3a2414", 0.012)
    glass = box((0.54, 0.01, 0.84), (0, 0.045, 1.3), "L_chrome_b8c4d0", 0.004)
    cracks = [box((0.006, 0.006, 0.4), (0.05 + i * 0.03, 0.052, 1.3), "C_2a2a2a", 0.0, rot=(0, -0.4 + i * 0.4, 0)) for i in range(3)]
    prop_save("mirror", [frame, glass] + cracks, tris=300)


def bed():
    reset()
    p = [box((0.05, 1.95, 0.05), (s * 0.45, 0, 0.35), DARK, 0.008) for s in (1, -1)]
    p += [box((0.95, 0.05, h), (0, y, h / 2), DARK, 0.008) for y, h in ((-0.97, 0.9), (0.97, 0.6))]
    p += [cyl(0.02, 0.8, (0, y, z), DARK, 8, rot=(0, math.pi / 2, 0)) for y in (-0.97, 0.97) for z in (0.5, 0.75) if not (y > 0 and z > 0.6)]
    p.append(box((0.88, 1.88, 0.16), (0, 0, 0.45), "L_fabric_a8a090", 0.05))
    p.append(box((0.6, 0.3, 0.12), (0, -0.75, 0.58), "L_fabric_e8e0d0", 0.05))
    p.append(cloth([(0.47, 0.42), (0.47, 0.55)], "L_fabric_3a5a6a", 6, 0.01, 4, 1, 0.0))
    p[-1].scale = (1.0, 1.0, 1.0)
    p[-1] = box((0.92, 1.2, 0.06), (0, 0.3, 0.55), "L_fabric_3a5a6a", 0.03)
    prop_save("bed", p, tris=600)


# ================================================================ lab
def lab_tank():
    reset()
    base = cyl(0.42, 0.3, (0, 0, 0.15), "L_metal_3a4656", 20, bevel=0.02)
    top = cyl(0.42, 0.25, (0, 0, 2.15), "L_metal_3a4656", 20, bevel=0.02)
    glass = cyl(0.36, 1.75, (0, 0, 1.17), "G_b8f0d0", 20)
    liquid = cyl(0.34, 1.6, (0, 0, 1.1), "E_2aa050", 20)
    rings = [cyl(0.37, 0.04, (0, 0, z), DARK, 20) for z in (0.3, 2.03)]
    specimen = meta("sp", [("ell", (0, 0, 1.2), 0.14, (0.9, 0.7, 1.5)), ("ball", (0, 0.02, 1.5), 0.09), ("ell", (0.12, 0, 1.05), 0.04, (0.7, 0.7, 2.0)), ("ell", (-0.12, 0, 1.05), 0.04, (0.7, 0.7, 2.0))], "L_skin_2a3a2a", 0.02)
    tubes = [cyl(0.02, 0.6, (x, 0, 2.55), "L_rubber_2a2c33", 8) for x in (-0.15, 0.15)]
    panel = box((0.25, 0.04, 0.12), (0, 0.42, 0.18), "L_plastic_101012", 0.01)
    leds = [box((0.03, 0.01, 0.02), (-0.06 + i * 0.06, 0.442, 0.18), ["E_4aff7a", "E_ffb04a", "E_ff3a2a"][i], 0.0) for i in range(3)]
    bubbles = [sphere(0.025, (math.cos(i) * 0.2, math.sin(i) * 0.2, 0.5 + i * 0.2), "G_e8fff0", 6, 3) for i in range(6)]
    prop_save("lab_tank", [base, top, glass, liquid, specimen, panel] + rings + tubes + leds + bubbles, tex=512, tris=2500)


def lab_bench():
    reset()
    p = [box((1.8, 0.8, 0.06), (0, 0, 0.92), "L_stone_2a2c30", 0.01), box((1.76, 0.76, 0.85), (0, 0, 0.45), "L_paint_d8dcd8", 0.01)]
    p += [box((0.42, 0.02, 0.7), (-0.66 + i * 0.44, 0.385, 0.45), "L_paint_c0c4c0", 0.006) for i in range(4)]
    p += [box((0.1, 0.03, 0.02), (-0.66 + i * 0.44, 0.4, 0.72), STEEL, 0.003) for i in range(4)]
    for i, x in enumerate((-0.6, -0.45, -0.3)):
        p.append(cyl(0.04, 0.18, (x, 0.1, 1.04), "G_d8f0ff", 10))
        p.append(cyl(0.035, 0.09, (x, 0.1, 1.0), ["E_4aff7a", "E_4ac8ff", "E_ff4ad8"][i], 10))
    p.append(box((0.4, 0.3, 0.25), (0.5, -0.1, 1.07), "L_paint_e8e4da", 0.02))
    p.append(box((0.3, 0.01, 0.14), (0.5, 0.05, 1.08), "E_3aa0d8", 0.006))
    p.append(cyl(0.012, 0.5, (0.0, -0.3, 1.2), STEEL, 6))
    p.append(cyl(0.06, 0.03, (0.0, -0.18, 1.45), STEEL, 10, rot=(math.pi / 2, 0, 0)))
    prop_save("lab_bench", p, tris=1100)


def server_rack():
    reset()
    cab = box((0.7, 1.0, 2.1), (0, 0, 1.05), "L_paint_1e2028", 0.02)
    door = box((0.62, 0.02, 1.95), (0, 0.505, 1.05), "G_2a3a4a", 0.01)
    units = []
    for i in range(16):
        z = 0.2 + i * 0.11
        units.append(box((0.58, 0.02, 0.08), (0, 0.48, z), "L_metal_15161a", 0.004))
        for k in range(5):
            col = ["E_4aff7a", "E_4ac8ff", "E_ffb04a"][(i + k) % 3] if (i * 7 + k) % 6 else "E_ff3a2a"
            units.append(box((0.015, 0.006, 0.01), (-0.24 + k * 0.03, 0.492, z + 0.02), col, 0.0))
    top = box((0.72, 1.02, 0.06), (0, 0, 2.12), DARK, 0.01)
    prop_save("server_rack", [cab, door, top] + units, tex=512, tris=2000)


def terminal():
    reset()
    desk_ = box((0.9, 0.6, 0.8), (0, 0, 0.4), "L_paint_5a6470", 0.02)
    slope = box((0.9, 0.4, 0.06), (0, 0.15, 0.85), "L_paint_4a545e", 0.02, rot=(0.35, 0, 0))
    crt = box((0.55, 0.45, 0.45), (0, -0.1, 1.15), "L_plastic_c8bea0", 0.04)
    scr = box((0.42, 0.02, 0.32), (0, 0.13, 1.16), "L_plastic_0a120a", 0.02)
    lines = [box((0.3 - i * 0.04, 0.005, 0.018), (-0.03 - i * 0.02, 0.142, 1.25 - i * 0.05), "E_4aff7a", 0.0) for i in range(5)]
    cursor = box((0.025, 0.005, 0.03), (0.15, 0.142, 1.05), "E_4aff7a", 0.0)
    keys = [box((0.04, 0.04, 0.015), (-0.3 + (i % 8) * 0.085, 0.1 + (i // 8) * 0.06, 0.885 + (i // 8) * 0.02), "L_plastic_2a2c33", 0.004, rot=(0.35, 0, 0)) for i in range(16)]
    btn = box((0.06, 0.06, 0.02), (0.35, 0.25, 0.92), "E_ff3a2a", 0.006, rot=(0.35, 0, 0))
    prop_save("terminal", [desk_, slope, crt, scr, cursor, btn] + lines + keys, tris=1000)


def panel():
    reset()
    body = box((0.8, 0.25, 1.2), (0, 0.125, 0.9), "L_paint_a02a20", 0.03)
    face = box((0.7, 0.02, 1.0), (0, 0.255, 0.9), "L_paint_801e18", 0.01)
    btns = []
    for i in range(3):
        for j in range(4):
            col = ["E_ff3a2a", "E_4aff7a", "E_ffb04a"][(i + j) % 3]
            btns.append(cyl(0.035, 0.03, (-0.22 + i * 0.22, 0.27, 1.25 - j * 0.15), col, 12, rot=(math.pi / 2, 0, 0)))
    lever = [box((0.06, 0.04, 0.1), (0.0, 0.28, 0.6), DARK, 0.01), cyl(0.015, 0.2, (0.0, 0.33, 0.68), STEEL, 8, rot=(0.6, 0, 0)), sphere(0.03, (0.0, 0.39, 0.77), "L_plastic_c0302a", 8, 4)]
    gauge = [cyl(0.07, 0.02, (0.25, 0.27, 0.62), "L_paint_e8e4da", 16, rot=(math.pi / 2, 0, 0)), box((0.005, 0.01, 0.06), (0.25, 0.282, 0.64), BLK, 0.0, rot=(0, 0.6, 0))]
    stripe = hazard_band(0.8, 0.25, 0.32, 0.06)
    for o in stripe:
        o.location.y += 0.125
    prop_save("panel", [body, face] + btns + lever + gauge + stripe, tris=900)


def med_cabinet():
    reset()
    body = box((0.6, 0.25, 0.8), (0, 0.125, 1.4), "L_paint_e8e4da", 0.02)
    doors = [box((0.28, 0.02, 0.74), (s * 0.145, 0.255, 1.4), "G_d8e8f0", 0.006) for s in (1, -1)]
    cross = [box((0.16, 0.012, 0.05), (0, 0.27, 1.85), "L_paint_c0302a", 0.0), box((0.05, 0.012, 0.16), (0, 0.27, 1.85), "L_paint_c0302a", 0.0)]
    top = box((0.62, 0.27, 0.15), (0, 0.135, 1.86), "L_paint_e8e4da", 0.02)
    bottles = [cyl(0.03, 0.12, (-0.2 + i * 0.1, 0.12, 1.12 + (i % 2) * 0.3), ["L_plastic_c87a20", "L_plastic_e8e4da", "L_plastic_2a6ad8"][i % 3], 8) for i in range(5)]
    shelf = [box((0.56, 0.2, 0.01), (0, 0.12, z), "G_e8f0f8", 0.0) for z in (1.05, 1.35, 1.65)]
    prop_save("med_cabinet", [body, top] + doors + bottles + shelf + cross, tris=500)


# ================================================================ basement / machinery
def boiler():
    reset()
    tank = cyl(0.55, 1.6, (0, 0, 0.95), "L_rust_6a4a32", 20, bevel=0.03)
    top = sphere(0.55, (0, 0, 1.75), "L_rust_6a4a32", 20, 8, (1, 1, 0.4))
    bands = [cyl(0.57, 0.06, (0, 0, z), DARK, 20) for z in (0.4, 1.0, 1.6)]
    door = cyl(0.22, 0.06, (0, 0.55, 0.6), DARK, 16, rot=(math.pi / 2, 0, 0), bevel=0.01)
    glow = cyl(0.12, 0.02, (0, 0.59, 0.6), "E_ff7a20", 12, rot=(math.pi / 2, 0, 0))
    gauge = [cyl(0.08, 0.04, (0.3, 0.48, 1.3), "L_paint_e8e4da", 14, rot=(math.pi / 2, 0, 0.5)), cyl(0.015, 0.3, (0.3, 0.3, 1.3), STEEL, 6, rot=(math.pi / 2, 0, 0.5))]
    pipes = [cyl(0.08, 1.4, (0, 0, 2.4), "L_metal_5a5e66", 12), cyl(0.06, 0.8, (0.4, -0.2, 2.1), "L_metal_5a5e66", 10, rot=(0, math.pi / 2, 0))]
    legs = [box((0.12, 0.12, 0.2), (math.cos(a) * 0.4, math.sin(a) * 0.4, 0.1), DARK, 0.01) for a in (0.8, 2.4, 3.9, 5.5)]
    valve = [cyl(0.1, 0.02, (0.6, -0.2, 2.1), "L_paint_c0302a", 12, rot=(0, math.pi / 2, 0))]
    prop_save("boiler", [tank, top, door, glow] + bands + gauge + pipes + legs + valve, tex=512, tris=1800)


def fusebox():
    reset()
    body = box((0.5, 0.2, 0.7), (0, 0.1, 1.4), "L_paint_8a9098", 0.02)
    door = box((0.46, 0.02, 0.66), (0, 0.205, 1.4), "L_paint_7a8088", 0.01)
    sign = box((0.15, 0.01, 0.13), (0, 0.218, 1.55), HAZ, 0.0)
    bolt = box((0.03, 0.012, 0.09), (0, 0.222, 1.55), BLK, 0.0, rot=(0, 0.4, 0))
    handle = box((0.03, 0.03, 0.1), (0.18, 0.225, 1.4), DARK, 0.006)
    cables = [cyl(0.02, 1.2, (x, 0.08, 0.6), "L_rubber_2a2c33", 6) for x in (-0.12, 0.0, 0.12)]
    led = sphere(0.015, (-0.17, 0.22, 1.7), "E_4aff7a", 6, 3)
    prop_save("fusebox", [body, door, sign, bolt, handle, led] + cables, tris=500)


def pipes():
    reset()
    p = []
    for i, (z, r, m) in enumerate(((2.6, 0.08, "L_metal_5a5e66"), (2.35, 0.05, "L_paint_c0302a"), (2.15, 0.06, "L_paint_2a6a4a"))):
        p.append(cyl(r, 2.0, (0, 0.18 + i * 0.03, z), m, 12, rot=(0, math.pi / 2, 0)))
        p += [cyl(r + 0.015, 0.05, (x, 0.18 + i * 0.03, z), DARK, 12, rot=(0, math.pi / 2, 0)) for x in (-0.9, 0.0, 0.9)]
    p += [box((0.04, 0.25, 0.04), (x, 0.12, 2.45), DARK, 0.005) for x in (-0.6, 0.6)]
    p += [box((0.04, 0.04, 0.6), (x, 0.0, 2.4), DARK, 0.005) for x in (-0.6, 0.6)]
    p.append(cyl(0.09, 0.03, (0.4, 0.27, 2.6), "L_paint_c0302a", 12, rot=(math.pi / 2, 0, 0)))
    o = join(p, "pipes")
    set_origin(o, (0, 0, 0))
    save("pipes", [o], tex=256, tris=800, split=False)


def generator():
    reset()
    body = box((1.1, 0.6, 0.6), (0, 0, 0.42), HAZ, 0.04)
    frame = [box((1.2, 0.05, 0.05), (0, y, z), DARK, 0.006) for y in (-0.33, 0.33) for z in (0.08, 0.76)] + [box((0.05, 0.05, 0.7), (x, y, 0.42), DARK, 0.006) for x in (-0.6, 0.6) for y in (-0.33, 0.33)]
    engine = box((0.5, 0.4, 0.35), (-0.15, 0, 0.3), DARK, 0.02)
    exhaust = cyl(0.05, 0.3, (0.4, -0.15, 0.85), "L_rust_6a4a32", 10)
    tank = box((0.5, 0.5, 0.15), (0.2, 0, 0.78), "L_paint_a02a20", 0.03)
    panel = box((0.25, 0.02, 0.2), (0.3, 0.31, 0.45), "L_plastic_101012", 0.01)
    led = box((0.04, 0.01, 0.02), (0.3, 0.322, 0.5), "E_4aff7a", 0.0)
    wheels = [cyl(0.1, 0.06, (x, s * 0.36, 0.1), RUB, 12, rot=(math.pi / 2, 0, 0)) for x in (-0.4, 0.4) for s in (1, -1)]
    prop_save("generator", [body, engine, exhaust, tank, panel, led] + frame + wheels, tris=900)


def vent():
    reset()
    frame = box((0.7, 0.06, 0.5), (0, 0.03, 0.25), "L_metal_6a6e78", 0.01)
    slats = [box((0.62, 0.04, 0.03), (0, 0.06, 0.06 + i * 0.055), "L_metal_3a3d44", 0.004, rot=(0.6, 0, 0)) for i in range(8)]
    screws = [sphere(0.012, (x, 0.065, z), STEEL, 6, 3) for x in (-0.32, 0.32) for z in (0.03, 0.47)]
    o = join([frame] + slats + screws, "vent")
    set_origin(o, (0, 0, 0))
    save("vent", [o], tex=256, tris=400, split=False)


# ================================================================ doors & openings
def door():
    """Metal door leaf for a 1.8 x 2.4 opening; hinge at -X, origin bottom of the hinge edge."""
    reset()
    W, H = 1.7, 2.35
    leaf = box((W, 0.06, H), (W / 2, 0, H / 2), "L_paint_4a5a6a", 0.015)
    panels = [box((W - 0.2, 0.065, 0.9), (W / 2, 0, 0.65), "L_paint_42525e", 0.01)]
    win = box((0.4, 0.07, 0.45), (W / 2, 0, 1.75), "G_8ab0c8", 0.01)
    wires = [box((0.4, 0.075, 0.01), (W / 2, 0, 1.6 + i * 0.1), DARK, 0.0) for i in range(4)]
    kick = []
    for s in (1, -1):
        kick += [box((W, 0.07, 0.18), (W / 2, 0, 0.1), HAZ, 0.0)]
        kick += [box((0.1, 0.075, 0.2), (0.1 + i * 0.22, 0, 0.1), BLK, 0.0, rot=(0, 0.6, 0)) for i in range(8)]
    handle = [box((0.04, 0.12, 0.04), (W - 0.15, 0.06, 1.05), STEEL, 0.008), box((0.18, 0.04, 0.03), (W - 0.2, 0.11, 1.05), STEEL, 0.008),
              box((0.04, 0.12, 0.04), (W - 0.15, -0.06, 1.05), STEEL, 0.008), box((0.18, 0.04, 0.03), (W - 0.2, -0.11, 1.05), STEEL, 0.008)]
    hinges = [cyl(0.03, 0.15, (0.0, 0, z), DARK, 8) for z in (0.4, 1.2, 2.0)]
    sign = box((0.3, 0.07, 0.1), (W / 2, 0, 2.15), "L_paint_e8e4da", 0.0)
    o = join([leaf, win, sign] + panels + wires + kick + handle + hinges, "door")
    set_origin(o, (0, 0, 0))
    save("door", [o], tex=256, tris=900, split=False)


def doorframe():
    reset()
    W, H = 1.8, 2.4
    p = [box((0.12, 0.34, H), (s * (W / 2 + 0.06), 0, H / 2), "L_metal_3a3d44", 0.01) for s in (1, -1)]
    p.append(box((W + 0.24, 0.34, 0.14), (0, 0, H + 0.07), "L_metal_3a3d44", 0.01))
    p += [box((0.13, 0.08, 0.2), (s * (W / 2 + 0.06), y, 0.15 + i * 0.4), BLK if i % 2 else HAZ, 0.0) for s in (1, -1) for y in (0.14, -0.14) for i in range(6)]
    p.append(box((0.4, 0.05, 0.12), (0, 0.18, H + 0.07), "E_4aff7a", 0.004))
    prop_save("doorframe", p, tris=700)


def gate():
    reset()
    W, H = 3.0, 2.8
    p = [box((W, 0.06, H - 0.4), (0, 0, (H - 0.4) / 2), "L_metal_7a8088", 0.0)]
    p += [box((W, 0.08, 0.04), (0, 0, 0.1 + i * 0.12), "L_metal_5a626a", 0.006) for i in range(20)]
    p.append(box((W + 0.2, 0.6, 0.45), (0, -0.2, H - 0.2), "L_metal_3a3d44", 0.04))
    p += [box((0.12, 0.2, H), (s * (W / 2 + 0.06), 0, H / 2), "L_metal_3a3d44", 0.01) for s in (1, -1)]
    p += [box((W, 0.09, 0.15), (0, 0, 0.08), HAZ, 0.0)] + [box((0.15, 0.1, 0.16), (-W / 2 + 0.1 + i * 0.3, 0, 0.08), BLK, 0.0, rot=(0, 0.6, 0)) for i in range(10)]
    p.append(box((0.1, 0.08, 0.12), (1.0, 0.05, 0.25), DARK, 0.01))
    rust = [sphere(0.3, (x, 0.04, z), "L_rust_7a4a22", 8, 4, (1, 0.1, 0.6)) for x, z in ((-0.8, 0.6), (0.6, 1.4))]
    prop_save("gate", p + rust, tex=512, tris=900)


def elevator():
    reset()
    p = [box((2.0, 0.3, 2.7), (0, -0.05, 1.35), "L_metal_5a626a", 0.02)]
    p += [box((0.68, 0.06, 2.2), (s * 0.35, 0.12, 1.1), "L_chrome_a8b0b8", 0.006) for s in (1, -1)]
    p.append(box((0.02, 0.07, 2.2), (0, 0.13, 1.1), DARK, 0.0))
    p.append(box((0.5, 0.06, 0.18), (0, 0.12, 2.45), "L_plastic_101012", 0.01))
    p.append(text_mesh("B2", 0.11, (0, 0.155, 2.45), "E_ff7a20", 0.003))
    p += [box((0.12, 0.06, 0.28), (0.85, 0.12, 1.2), "L_metal_3a3d44", 0.01), cyl(0.025, 0.02, (0.85, 0.16, 1.27), "E_ffb04a", 10, rot=(math.pi / 2, 0, 0)),
          cyl(0.025, 0.02, (0.85, 0.16, 1.15), "L_plastic_e8e4da", 10, rot=(math.pi / 2, 0, 0))]
    p.append(box((1.6, 0.08, 0.1), (0, 0.14, 0.05), HAZ, 0.0))
    prop_save("elevator", p, tex=256, tris=700)


def window():
    reset()
    W, H = 1.6, 1.1
    p = [box((W, 0.12, 0.08), (0, 0, z), "L_metal_5a626a", 0.008) for z in (0.04, H - 0.04)]
    p += [box((0.08, 0.12, H), (x, 0, H / 2), "L_metal_5a626a", 0.008) for x in (-W / 2 + 0.04, 0, W / 2 - 0.04)]
    p += [box(((W - 0.24) / 2, 0.02, H - 0.16), (s * W / 4, 0, H / 2), "G_2a3a4a", 0.0) for s in (1, -1)]
    p.append(box(((W - 0.24) / 2, 0.025, 0.4), (-W / 4, 0.0, 0.3), "C_0a0c10", 0.0, rot=(0, 0.3, 0)))
    p.append(box((W + 0.1, 0.25, 0.05), (0, 0.06, -0.02), "L_metal_3a3d44", 0.008))
    o = join(p, "window")
    set_origin(o, (0, 0, 0))
    save("window", [o], tex=256, tris=400, split=False)


# ================================================================ lights
def lamp_pendant():
    reset()
    cord = cyl(0.008, 0.6, (0, 0, 0.3), "L_rubber_1c1d22", 6)
    shade = lathe([(0.0, -0.02), (0.06, -0.02), (0.08, -0.08), (0.24, -0.25), (0.25, -0.27), (0.0, -0.08)], "L_paint_3a5a4a", 20, cap_bottom=False)
    inner = lathe([(0.06, -0.03), (0.235, -0.255)], "L_paint_e8e4da", 20, cap_bottom=False)
    bulb = sphere(0.06, (0, 0, -0.2), "E_ffd8a0", 10, 5)
    cage = [box((0.01, 0.01, 0.12), (math.cos(a) * 0.15, math.sin(a) * 0.15, -0.31), DARK, 0.0) for a in (0, 1.57, 3.14, 4.71)]
    o = join([cord, shade, inner, bulb] + cage, "lamp_pendant")
    set_origin(o, (0, 0, 0.6))
    save("lamp_pendant", [o], tex=128, tris=500, split=False)


def lamp_tube():
    reset()
    body = box((1.25, 0.18, 0.06), (0, 0, -0.04), "L_metal_9a9ea8", 0.01)
    tubes = [cyl(0.022, 1.15, (0, y, -0.09), "E_e8f4ff", 10, rot=(0, math.pi / 2, 0)) for y in (-0.04, 0.04)]
    caps = [box((0.04, 0.17, 0.05), (s * 0.6, 0, -0.08), DARK, 0.004) for s in (1, -1)]
    chains = [cyl(0.004, 0.3, (s * 0.45, 0, 0.12), DARK, 4) for s in (1, -1)]
    o = join([body] + tubes + caps + chains, "lamp_tube")
    set_origin(o, (0, 0, 0.27))
    save("lamp_tube", [o], tex=128, tris=300, split=False)


def lamp_cage():
    reset()
    base = cyl(0.08, 0.04, (0, 0.02, 0.0), DARK, 12, rot=(math.pi / 2, 0, 0))
    bulb = sphere(0.05, (0, 0.1, 0), "E_ffc070", 10, 5)
    cage = [lathe([(0.075, -0.004), (0.08, 0.0), (0.075, 0.004)], DARK, 12, cap_bottom=False, pos=(0, 0.1, 0)) for _ in range(2)]
    cage[0].rotation_euler = (0, 0, 0)
    cage[1].rotation_euler = (0, math.pi / 2, 0)
    bars = [box((0.008, 0.12, 0.008), (math.cos(a) * 0.07, 0.09, math.sin(a) * 0.07), DARK, 0.0) for a in (0, 1.57, 3.14, 4.71)]
    o = join([base, bulb] + cage + bars, "lamp_cage")
    set_origin(o, (0, 0, 0))
    save("lamp_cage", [o], tex=128, tris=400, split=False)


def _beacon(name, col):
    reset()
    base = cyl(0.08, 0.05, (0, 0, 0.025), DARK, 14, bevel=0.006)
    dome = cyl(0.065, 0.12, (0, 0, 0.11), "G_" + col, 14, bevel=0.02)
    light = cyl(0.04, 0.09, (0, 0, 0.1), "E_" + col, 10)
    cage = [box((0.008, 0.008, 0.13), (math.cos(a) * 0.07, math.sin(a) * 0.07, 0.11), DARK, 0.0) for a in (0, 1.57, 3.14, 4.71)]
    prop_save(name, [base, dome, light] + cage, tex=128, tris=400)


def beacon_red():
    _beacon("beacon_red", "ff2a1a")


def beacon_green():
    _beacon("beacon_green", "3aff6a")


def street_lamp():
    reset()
    pole = cyl(0.07, 4.5, (0, 0, 2.25), "L_paint_3a4a3a", 10, r2=0.05)
    base = cyl(0.14, 0.4, (0, 0, 0.2), "L_paint_3a4a3a", 10, bevel=0.01)
    arm = cyl(0.04, 1.0, (0, 0.45, 4.45), "L_paint_3a4a3a", 8, rot=(math.pi / 2 - 0.15, 0, 0))
    head = box((0.3, 0.55, 0.12), (0, 0.95, 4.5), "L_paint_3a4a3a", 0.03)
    light = box((0.24, 0.45, 0.02), (0, 0.95, 4.435), "E_ffc070", 0.01)
    prop_save("street_lamp", [pole, base, arm, head, light], tex=128, tris=500)


# ================================================================ shop
def shop_shelf():
    store_shelf(goods_on=False, name="shop_shelf")


def store_shelf(goods_on=True, name="store_shelf"):
    reset()
    M = "L_paint_4a545e"
    p = [box((0.05, 0.5, 2.0), (s * 0.95, 0, 1.0), M, 0.006) for s in (1, -1)]
    p.append(box((1.95, 0.04, 2.0), (0, -0.23, 1.0), "L_paint_3a4450", 0.0))
    for z in (0.12, 0.72, 1.32, 1.88):
        p.append(box((1.9, 0.48, 0.03), (0, 0, z), M, 0.004))
        p.append(box((1.9, 0.02, 0.06), (0, 0.24, z + 0.01), HAZ, 0.0))
    rnd = random.Random(9)
    goods = []
    for z in ((0.135, 0.735, 1.335) if goods_on else ()):
        x = -0.85
        while x < 0.8:
            kind = rnd.randint(0, 3)
            if kind == 0:
                w, h = 0.18, rnd.uniform(0.2, 0.3)
                goods.append(box((w, 0.25, h), (x + w / 2, 0.05, z + h / 2), rnd.choice(["L_paper_a87a48", "L_plastic_c0302a", "L_plastic_2a6ad8"]), 0.01))
            elif kind == 1:
                w, h = 0.1, rnd.uniform(0.18, 0.28)
                goods.append(cyl(0.05, h, (x + w / 2, 0.05, z + h / 2), rnd.choice(["L_paint_c0302a", "L_paint_e8b420", "L_metal_8a8f99"]), 10))
            elif kind == 2:
                w, h = 0.22, 0.14
                goods.append(box((w, 0.2, h), (x + w / 2, 0.05, z + h / 2), "L_paint_b8261e", 0.012))
            else:
                w, h = 0.14, 0.14
                goods.append(box((w, 0.14, h), (x + w / 2, 0.05, z + h / 2), "L_plastic_e8e4da", 0.01))
                goods.append(box((0.04, 0.142, 0.1), (x + w / 2, 0.05, z + h / 2), "L_plastic_c0302a", 0.0))
            x += w + 0.04
    prop_save(name, p + goods, tex=512 if goods_on else 256, tris=2500)


def counter():
    reset()
    p = [box((2.2, 0.7, 1.0), (0, 0, 0.5), "L_wood_6a4a2a", 0.02), box((2.3, 0.8, 0.06), (0, 0, 1.03), "L_metal_5a626a", 0.01)]
    p += [box((2.2, 0.02, 0.12), (0, 0.36, 0.12), HAZ, 0.0)]
    p += [box((0.5, 0.02, 0.3), (x, 0.355, 0.6), "L_wood_4a3018", 0.006) for x in (-0.7, 0.0, 0.7)]
    reg = [box((0.4, 0.35, 0.18), (0.6, 0, 1.15), "L_plastic_2a2c33", 0.02), box((0.36, 0.2, 0.12), (0.6, 0.05, 1.27), "L_plastic_3a3d44", 0.02, rot=(0.4, 0, 0)),
           box((0.2, 0.06, 0.12), (0.6, -0.12, 1.35), "L_plastic_1a1c22", 0.01), box((0.18, 0.01, 0.07), (0.6, -0.09, 1.36), "E_4aff7a", 0.004)]
    disp = [box((0.3, 0.06, 0.14), (-0.5, 0.0, 1.13), "L_plastic_1a1c22", 0.01), text_mesh("$0", 0.08, (-0.5, 0.035, 1.13), "E_4aff7a", 0.003)]
    bell = [cyl(0.05, 0.01, (0.0, 0.2, 1.065), STEEL, 12), sphere(0.04, (0.0, 0.2, 1.08), "L_gold_c8902a", 10, 5, (1, 1, 0.8))]
    prop_save("counter", p + reg + disp + bell, tex=512, tris=1200)


def shopkeeper():
    """Small boxy shopkeeper robot with a big round face screen (sits behind the counter)."""
    reset()
    body = box((0.42, 0.36, 0.45), (0, 0, 0.45), "L_paint_d8c8a0", 0.05)
    belly = box((0.3, 0.02, 0.16), (0, 0.18, 0.38), "L_plastic_2a2c33", 0.02)
    leds = [box((0.03, 0.01, 0.02), (-0.08 + i * 0.04, 0.192, 0.4), ["E_4aff7a", "E_ffb04a", "E_ff3a2a", "E_4ac8ff", "E_4aff7a"][i], 0.0) for i in range(5)]
    neck = cyl(0.05, 0.1, (0, 0, 0.72), DARK, 10)
    head = cyl(0.24, 0.18, (0, 0, 0.95), "L_paint_d8c8a0", 24, rot=(math.pi / 2, 0, 0), bevel=0.03)
    face = cyl(0.19, 0.02, (0, 0.09, 0.95), "L_plastic_0a0c10", 24, rot=(math.pi / 2, 0, 0))
    eyes = [cyl(0.035, 0.01, (s * 0.07, 0.102, 0.98), "E_7ad8ff", 12, rot=(math.pi / 2, 0, 0)) for s in (1, -1)]
    smile = [box((0.03, 0.01, 0.015), (x, 0.102, 0.88 - abs(x) * -0.4), "E_7ad8ff", 0.0) for x in (-0.06, -0.03, 0.0, 0.03, 0.06)]
    ears = [cyl(0.06, 0.06, (s * 0.25, 0, 0.95), DARK, 12, rot=(0, math.pi / 2, 0)) for s in (1, -1)]
    ant = [cyl(0.008, 0.18, (0.1, 0, 1.2), DARK, 6), sphere(0.025, (0.1, 0, 1.3), "E_ffb04a", 8, 4)]
    arms = [skin([(s * 0.22, 0, 0.6, 0.04), (s * 0.3, 0.08, 0.45, 0.035), (s * 0.28, 0.2, 0.38, 0.03)], material="L_metal_5a5e66", subdiv=1) for s in (1, -1)]
    hands = [sphere(0.05, (s * 0.28, 0.23, 0.36), "L_rubber_2a2c33", 10, 5) for s in (1, -1)]
    base = cyl(0.2, 0.22, (0, 0, 0.11), DARK, 16, bevel=0.02)
    cap = [cyl(0.17, 0.06, (0, 0, 1.12), "L_paint_c0302a", 16, r2=0.12), box((0.25, 0.12, 0.015), (0, 0.15, 1.1), "L_paint_c0302a", 0.005)]
    prop_save("shopkeeper", [body, belly, neck, head, face, base] + leds + eyes + smile + ears + ant + arms + hands + cap, tex=256, tris=1600)


def sign_shop():
    reset()
    back = box((1.4, 0.06, 0.55), (0, 0.03, 0.0), "L_metal_15161a", 0.02)
    letters = text_mesh("SHOP", 0.42, (0, 0.08, 0.0), "E_ff3a2a", 0.03)
    frame = [box((1.44, 0.04, 0.04), (0, 0.05, z), "L_metal_3a3d44", 0.006) for z in (-0.28, 0.28)]
    o = join([back, letters] + frame, "sign_shop")
    set_origin(o, (0, 0, 0))
    save("sign_shop", [o], tex=256, tris=1500, split=False)


def sign_tools():
    reset()
    board = box((1.0, 0.04, 0.32), (0, 0.02, 0.0), HAZ, 0.02)
    letters = text_mesh("TOOLS", 0.22, (0, 0.045, 0.0), "L_paint_15151a", 0.005)
    screws = [sphere(0.012, (x, 0.045, z), STEEL, 6, 3) for x in (-0.45, 0.45) for z in (-0.12, 0.12)]
    o = join([board, letters] + screws, "sign_tools")
    set_origin(o, (0, 0, 0))
    save("sign_tools", [o], tex=256, tris=1200, split=False)


# ================================================================ yard
def dumpster():
    reset()
    body = box((1.8, 1.1, 1.1), (0, 0, 0.65), "L_paint_2a5a3a", 0.03)
    lids = [box((0.9, 1.2, 0.06), (s * 0.45, -0.02, 1.23), "L_paint_1e4a2e", 0.02, rot=(0.05 * s, 0, 0)) for s in (1, -1)]
    ribs = [box((0.06, 1.14, 1.0), (x, 0, 0.62), "L_paint_1e4a2e", 0.008) for x in (-0.6, 0.0, 0.6)]
    wheels = [cyl(0.08, 0.06, (x, y, 0.08), RUB, 10, rot=(math.pi / 2, 0, 0)) for x in (-0.75, 0.75) for y in (-0.45, 0.45)]
    rust = [sphere(0.25, (0.5, 0.55, 0.4), "L_rust_7a4a22", 8, 4, (1.2, 0.1, 0.8))]
    bag = meta("bag", [("ell", (0.3, 0.0, 1.32), 0.18, (1.2, 1.0, 0.7))], "L_plastic_1a1c22", 0.02)
    prop_save("dumpster", [body, bag] + lids + ribs + wheels + rust, tex=256, tris=900)


def fence():
    reset()
    posts = [cyl(0.03, 2.2, (x, 0, 1.1), "L_metal_6a6e78", 8) for x in (-1.0, 1.0)]
    rails = [cyl(0.02, 2.0, (0, 0, z), "L_metal_6a6e78", 6, rot=(0, math.pi / 2, 0)) for z in (0.1, 2.1)]
    mesh = [box((0.008, 0.008, 2.0), (-0.95 + i * 0.1, 0, 1.1), "L_metal_8a8f99", 0.0) for i in range(20)]
    mesh += [box((1.96, 0.008, 0.008), (0, 0, 0.15 + k * 0.1), "L_metal_8a8f99", 0.0) for k in range(20)]
    wire = [cyl(0.006, 2.0, (0, 0, 2.25 + k * 0.08), "L_metal_5a5e66", 4, rot=(0, math.pi / 2, 0)) for k in range(2)]
    prop_save("fence", posts + rails + mesh + wire, tex=128, tris=900)


def tires():
    reset()
    p = []
    for i in range(3):
        t = lathe([(0.2, -0.1), (0.33, -0.1), (0.36, -0.06), (0.36, 0.06), (0.33, 0.1), (0.2, 0.1), (0.18, 0.0)], RUB, 20, cap_bottom=False)
        t.location = (0.02 * i, -0.01 * i, 0.1 + i * 0.2)
        t.rotation_euler = (0, 0, i * 0.3)
        p.append(t)
    lean = lathe([(0.2, -0.1), (0.33, -0.1), (0.36, -0.06), (0.36, 0.06), (0.33, 0.1), (0.2, 0.1), (0.18, 0.0)], RUB, 20, cap_bottom=False)
    lean.location = (0.6, 0.2, 0.36)
    lean.rotation_euler = (math.pi / 2, 0.3, 0.4)
    p.append(lean)
    prop_save("tires", p, tex=128, tris=900)


run([crate, crate_metal, barrel, cone, rack, pallet, boxes, forklift, jerrycan,
     desk, office_chair, table, filing_cabinet, locker, sofa, plant, floor_lamp, whiteboard, water_cooler, vending, toilet, sink, mirror, bed,
     lab_tank, lab_bench, server_rack, terminal, panel, med_cabinet,
     boiler, fusebox, pipes, generator, vent,
     door, doorframe, gate, elevator, window,
     lamp_pendant, lamp_tube, lamp_cage, beacon_red, beacon_green, street_lamp,
     store_shelf, shop_shelf, counter, shopkeeper, sign_shop, sign_tools,
     dumpster, fence, tires])
