"""Shared setup for the HAULBOTS art v3 pass (staging, outside the Godot project).
Blender Z-up, models face +Y (= Godot -Z), origin at the feet / floor contact.
Animated parts are separate objects whose origin is the joint pivot; names match what the game
looks for (body, head, arm_l/arm_r, leg_l/leg_r, leg0..leg5, jaw, lid, tongue, mouth, fuse, gun, eye_l/eye_r).

Material names (see tools/bake.py):
  L_<look>_<rrggbb>  baked procedural look: paint, plastic, metal, rust, wood, fabric, leather, skin,
                     slime, fur, rubber, ceramic, bone, stone, marble, paper, chrome, gold
  M_player           runtime player colour (not baked)   E_rrggbb emissive (not baked)
  G_rrggbb           glass (not baked)                    K_...   kept as is
"""
import sys, os, math, random
HB = "/home/claude/haulbots/tools"
if HB not in sys.path:
    sys.path.insert(0, HB)
from blib import *                      # noqa
from organic import *                   # noqa
import bake as BK
import blib as _blib
import organic as _organic

_set_origin_raw = _blib.set_origin


def set_origin(obj, point):          # noqa: F811
    """blib.set_origin + a view-layer update: without it matrix_world stays stale and split limbs
    exported their lower half with a zero offset (knees/elbows drawn on top of the thighs)."""
    _set_origin_raw(obj, point)
    bpy.context.view_layer.update()


_blib.set_origin = set_origin
_organic.set_origin = set_origin

ART = "/home/claude/art3"
BK.MTEX = os.path.join(ART, "mtex")
OUT = os.path.join(ART, "models")

# ---------------------------------------------------------------- palette (sRGB hex)
PAL = {
    "navy": "141c26", "steel": "3a4656", "steel_lt": "6b7a8c", "concrete": "6e6e6a",
    "hazard": "e8b420", "rust": "8a4a22", "wood": "8a5a32", "crate": "7a5a36",
    "red": "c0302a", "olive": "5a6a3a", "cream": "d8d0b8", "rubber": "18181c",
    "glow_orange": "ffb04a", "glow_red": "ff3a2a", "glow_green": "4aff7a", "glow_cyan": "5ad8ff",
    "glow_white": "f4f6ff", "glow_yellow": "ffe070",
}


def part(objs, name, pivot):
    o = join(objs, name)
    set_origin(o, pivot)
    return o


def tris_count(parts):
    return sum(sum(len(p.vertices) - 2 for p in o.data.polygons) for o in parts if o.type == "MESH")


def clean_mesh(ob):
    """Merge coincident verts and drop degenerate faces (cones with r2=0 leave zero-area caps that
    make the glTF exporter drop the whole mesh)."""
    import bmesh as _bm
    bm = _bm.new()
    bm.from_mesh(ob.data)
    _bm.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
    _bm.ops.dissolve_degenerate(bm, edges=bm.edges, dist=1e-6)
    bad = [f for f in bm.faces if f.calc_area() < 1e-12]
    if bad:
        _bm.ops.delete(bm, geom=bad, context="FACES")
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        _bm.ops.delete(bm, geom=loose, context="VERTS")
    bm.to_mesh(ob.data)
    bm.free()
    ob.data.validate(clean_customdata=True)


def save(name, parts, tex=512, tris=6000, ao=0.25, split=True):
    """Split limbs (knees/elbows), keep the triangle budget, bake textures, export the GLB."""
    if split:
        for o in list(parts):
            if o.type == "MESH" and o.name in ("leg_l", "leg_r", "arm_l", "arm_r"):
                mat_name = o.material_slots[0].material.name if o.material_slots else "C_808080"
                split_limb(o, 0.5, mat_name, 0.0)
    total = tris_count(parts)
    if total > tris:
        k = tris / total
        for o in parts:
            if o.type == "MESH":
                n = sum(len(p.vertices) - 2 for p in o.data.polygons)
                decimate(o, max(min(n, 320), int(n * k)))
    for o in parts:
        for ob in [o] + list(o.children_recursive):
            if ob.type == "MESH":
                clean_mesh(ob)
    BK.bake(name, parts, tex, ao_dist=ao)
    export(os.path.join(OUT, name + ".glb"), parts)
    print("EXPORT", name, tris_count(parts))


def prop_save(name, objs, tex=256, tris=2500, ao=0.2, center=False):
    """Single-piece props / items: join everything, origin at the bottom centre
    (center=True: at the bounding-box centre, the convention for physics items / loot)."""
    o = join([x for x in objs if x is not None], name)
    bpy.context.view_layer.update()
    ws = [o.matrix_world @ v.co for v in o.data.vertices]
    if center:
        set_origin(o, tuple((min(w[i] for w in ws) + max(w[i] for w in ws)) / 2 for i in range(3)))
    else:
        set_origin(o, (0, 0, min(w.z for w in ws)))
    save(name, [o], tex, tris, ao, split=False)
    return o


# ---------------------------------------------------------------- reusable bits
def eyeball(pos, r, iris="C_d8b020", look=(0, 1, 0), pupil="C_050505", glow=False):
    x, y, z = pos
    ps = [sphere(r, pos, "L_ceramic_efe9dc", 14, 8)]
    ps.append(sphere(r * 0.55, (x, y + r * 0.62, z), ("E_" + iris[2:]) if glow else iris, 12, 6, (1, 0.45, 1)))
    ps.append(sphere(r * 0.28, (x, y + r * 0.86, z), pupil, 10, 5, (1, 0.4, 1)))
    ps.append(sphere(r * 0.1, (x + r * 0.18, y + r * 0.95, z + r * 0.22), "E_ffffff", 6, 3))
    return ps


def glow_eye(pos, r, col="ffb04a", socket="C_0a0a0a"):
    """Glowing eye in a dark socket (the template's monster look)."""
    x, y, z = pos
    return [sphere(r * 1.35, (x, y - r * 0.4, z), socket, 12, 6, (1, 0.6, 1)),
            sphere(r, (x, y, z), "E_" + col, 12, 6, (1, 0.7, 1))]


def teeth_row(cx, y, z, width, n, h, material="L_bone_e8dcc0", down=True, r=0.012, curve=0.0):
    out = []
    for i in range(n):
        t = (i / max(1, n - 1)) - 0.5
        x = cx + t * width
        yy = y - curve * (t * t) * 4
        c = cyl(r, h, (x, yy, z - h / 2 if down else z + h / 2), material, 5, r2=0.0, smooth=False)
        if not down:
            c.rotation_euler = (math.pi, 0, 0)
        out.append(c)
    return out


def claw_hand(x, y, z, material, side=1, n=3, length=0.06, r=0.012, claw="L_bone_d8cfb0"):
    out = [sphere(r * 2.6, (x, y, z), material, 10, 6, (1, 0.8, 0.9))]
    for i in range(n):
        a = (i - (n - 1) / 2) * 0.45
        fx = x + math.sin(a) * r * 2 * side
        fy = y + math.cos(a) * r * 1.6
        out.append(skin([(fx, fy, z, r), (fx + math.sin(a) * length * 0.5, fy + length * 0.6, z - length * 0.4, r * 0.8)], material=material, subdiv=1))
        out.append(cyl(r * 0.7, length * 0.5, (fx + math.sin(a) * length * 0.7, fy + length * 0.85, z - length * 0.65), claw, 5, r2=0.0, smooth=False, rot=(-2.2, 0, 0)))
    return out


def run(funcs):
    only = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    for f in funcs:
        if not only or f.__name__ in only:
            try:
                f()
            except Exception as e:     # keep going: one broken model must not stop the batch
                import traceback
                traceback.print_exc()
                print("FAILED", f.__name__, e)
