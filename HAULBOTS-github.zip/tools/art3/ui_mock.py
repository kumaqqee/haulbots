"""UI concept mockups for art v3 (main menu, HUD, shop, server list), 1600x900."""
import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance

A = "/home/claude/art3"
F1 = "/home/claude/haulbots/assets/fonts/RussoOne.ttf"
F2 = "/home/claude/haulbots/assets/fonts/Rubik-Medium.ttf"
F3 = "/home/claude/haulbots/assets/fonts/Rubik-Bold.ttf"
W, H = 1600, 900
PANEL = (13, 20, 30, 235)
PANEL2 = (20, 30, 44, 240)
EDGE = (46, 74, 102, 255)
TXT = (228, 236, 245, 255)
DIM = (140, 156, 176, 255)
YEL = (242, 194, 48, 255)
GRN = (96, 214, 96, 255)
RED = (255, 74, 58, 255)
CYAN = (90, 200, 255, 255)


def f(path, s):
    return ImageFont.truetype(path, s)


def bg(name, dark=0.55, blur=0):
    im = Image.open(f"{A}/renders/rooms/{name}.png").convert("RGB").resize((W, H), Image.LANCZOS)
    if blur:
        im = im.filter(ImageFilter.GaussianBlur(blur))
    im = ImageEnhance.Brightness(im).enhance(dark)
    return im.convert("RGBA")


def panel(d, box, fill=PANEL, edge=EDGE, r=14, w=2):
    d.rounded_rectangle(box, r, fill=fill, outline=edge, width=w)


def icon(path, size):
    if not os.path.exists(path):
        return None
    im = Image.open(path).convert("RGBA")
    bb = im.getbbox()
    if bb:
        im = im.crop(bb)
    k = size / max(im.size)
    return im.resize((max(1, int(im.size[0] * k)), max(1, int(im.size[1] * k))), Image.LANCZOS)


def paste_c(base, im, cx, cy):
    if im is not None:
        base.alpha_composite(im, (int(cx - im.size[0] / 2), int(cy - im.size[1] / 2)))


def menu():
    im = bg("warehouse", 0.45, 2)
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    for x in range(760):
        a = int(220 * (1 - x / 760) ** 1.2)
        d.line([(x, 0), (x, H)], fill=(8, 12, 18, a))
    im.alpha_composite(ov)
    d = ImageDraw.Draw(im)
    d.text((80, 70), "HAULBOTS", font=f(F1, 96), fill=YEL)
    d.text((84, 178), "ТАСКАЙ ЛУТ. НЕ ШУМИ. ВЫЖИВИ.", font=f(F2, 24), fill=DIM)
    items = ["ИГРАТЬ", "ИГРА ПО СЕТИ", "НАСТРОЙКИ", "КОЛЛЕКЦИЯ", "ПОДДЕРЖАТЬ", "ВЫХОД"]
    y = 270
    for i, t in enumerate(items):
        if i == 0:
            d.polygon([(70, y), (520, y), (500, y + 66), (70, y + 66)], fill=YEL)
            d.text((100, y + 14), t, font=f(F1, 34), fill=(16, 18, 22, 255))
        else:
            d.text((100, y + 14), t, font=f(F1, 34), fill=TXT if i != 4 else (255, 120, 140, 255))
        y += 84
    d.text((80, H - 50), "v3.0  •  Сервер: Азия (45 мс)", font=f(F2, 20), fill=DIM)
    crew = [("r_y", 1180), ("r_g", 1330), ("r_b", 1030), ("r_p", 1460)]
    for name, cx in crew:
        ic = icon(f"{A}/renders/p/{name}.png", 360)
        paste_c(im, ic, cx, 560)
    panel(d, (1180, 60, 1540, 140), PANEL2)
    d.text((1205, 75), "СЕГОДНЯ НОЧЬЮ", font=f(F2, 18), fill=DIM)
    d.text((1205, 98), "Склад «Северный»  •  Луна: полная", font=f(F2, 20), fill=TXT)
    im.save(f"{A}/sheets/ui_menu.png")


def bar(d, x, y, w, h, frac, col, label, val):
    d.rounded_rectangle((x, y, x + w, y + h), h // 2, fill=(10, 14, 20, 220), outline=EDGE, width=2)
    d.rounded_rectangle((x + 3, y + 3, x + 3 + int((w - 6) * frac), y + h - 3), (h - 6) // 2, fill=col)
    d.text((x + w + 14, y - 4), val, font=f(F1, 28), fill=col)
    d.text((x + 12, y + 2), label, font=f(F3, 18), fill=(10, 12, 16, 255))


def hud():
    im = bg("warehouse", 0.95)
    d = ImageDraw.Draw(im)
    panel(d, (28, 24, 430, 128), (10, 16, 24, 190))
    bar(d, 48, 42, 240, 30, 1.0, GRN, "ЗДОРОВЬЕ", "100/100")
    bar(d, 48, 84, 240, 30, 0.72, YEL, "ЭНЕРГИЯ", "29/40")
    panel(d, (1300, 24, 1572, 90), (10, 16, 24, 190))
    d.text((1322, 34), "$12 400", font=f(F1, 40), fill=GRN)
    panel(d, (640, 24, 960, 84), (10, 16, 24, 190))
    d.text((800, 54), "КВОТА  $8 200 / $15 000", font=f(F2, 22), fill=TXT, anchor="mm")
    d.rounded_rectangle((660, 72, 940, 78), 3, fill=(40, 50, 60, 255))
    d.rounded_rectangle((660, 72, 660 + int(280 * 0.55), 78), 3, fill=YEL)
    d.ellipse((794, 444, 806, 456), outline=TXT, width=2)
    panel(d, (650, 610, 950, 660), (10, 16, 24, 200))
    d.text((800, 635), "Поднять:  Сейф  —  $9 400", font=f(F2, 22), fill=TXT, anchor="mm")
    notes = [("Вы подобрали: Фонарик", TXT, "⚡"), ("Недостаточно денег", RED, "!"), ("Вы нашли: $50", GRN, "$"), ("Нужно больше места!", RED, "!")]
    y = 120
    for t, c, ic in notes:
        panel(d, (1220, y, 1572, y + 46), (10, 16, 24, 200), EDGE, 10)
        d.ellipse((1232, y + 9, 1260, y + 37), fill=c)
        d.text((1246, y + 23), ic, font=f(F3, 18), fill=(10, 12, 16, 255), anchor="mm")
        d.text((1272, y + 11), t, font=f(F2, 20), fill=TXT)
        y += 56
    # touch controls
    d.ellipse((60, 600, 300, 840), fill=(20, 30, 44, 120), outline=(120, 150, 180, 160), width=3)
    d.ellipse((140, 680, 220, 760), fill=(200, 210, 225, 150))
    btns = [(1450, 760, 70, "ЗАХВАТ", YEL), (1300, 800, 50, "ПРЫЖОК", TXT), (1330, 660, 46, "ПРИСЕД", TXT), (1480, 610, 46, "КУВЫРОК", TXT), (1180, 760, 40, "ФОНАРЬ", TXT)]
    for x, y, r, t, c in btns:
        d.ellipse((x - r, y - r, x + r, y + r), fill=(20, 30, 44, 150), outline=c, width=3)
        d.text((x, y), t, font=f(F3, 14 if r < 60 else 18), fill=c, anchor="mm")
    slots = ["medkit_m", "w_pistol", "g_explosive"]
    for i, s in enumerate(slots):
        x = 640 + i * 110
        panel(d, (x, 790, x + 96, 880), (10, 16, 24, 200), YEL if i == 1 else EDGE, 12, 3 if i == 1 else 2)
        paste_c(im, icon(f"{A}/renders/gear/{s}.png", 70), x + 48, 835)
        d.text((x + 8, 794), str(i + 1), font=f(F3, 16), fill=DIM)
    im.save(f"{A}/sheets/ui_hud.png")


def shop():
    im = bg("shop", 0.35, 4)
    d = ImageDraw.Draw(im)
    panel(d, (80, 60, 1520, 840))
    d.text((120, 90), "МАГАЗИН", font=f(F1, 50), fill=TXT)
    d.text((124, 152), "Покупай. Выживай. Зарабатывай.", font=f(F2, 22), fill=DIM)
    d.text((1480, 100), "$12 400", font=f(F1, 44), fill=GRN, anchor="ra")
    cats = ["Все", "Инструменты", "Оружие", "Полезное", "Улучшения", "Дроны"]
    for i, c in enumerate(cats):
        y = 210 + i * 62
        if i == 0:
            d.rounded_rectangle((110, y, 330, y + 50), 10, fill=YEL)
            d.text((130, y + 12), c, font=f(F1, 24), fill=(16, 18, 22, 255))
        else:
            d.text((130, y + 12), c, font=f(F2, 24), fill=TXT)
    items = [("gear", "t_valuable", "$15 000"), ("gear", "medkit_m", "$7 000"), ("gear", "w_bat", "$30 000"), ("gear", "w_pistol", "$20 000"),
             ("gear", "w_shotgun", "$45 000"), ("gear", "g_explosive", "$3 000"), ("gear", "d_shield", "$28 000"), ("gear", "m_stun", "$3 000"),
             ("gear", "w_prod", "$28 000"), ("gear", "i_crystal", "$8 000"), ("gear", "up_item", "$12 000"), ("gear", "i_pocketcart", "$17 000")]
    for i, (cat, n, p) in enumerate(items):
        cx = 360 + (i % 4) * 170
        cy = 210 + (i // 4) * 200
        sel = i == 1
        panel(d, (cx, cy, cx + 156, cy + 186), PANEL2, YEL if sel else EDGE, 12, 3 if sel else 2)
        paste_c(im, icon(f"{A}/renders/{cat}/{n}.png", 110), cx + 78, cy + 80)
        d.text((cx + 78, cy + 165), p, font=f(F1, 22), fill=GRN, anchor="mm")
    panel(d, (1060, 200, 1490, 800), PANEL2)
    paste_c(im, icon(f"{A}/renders/gear/medkit_m.png", 220), 1275, 350)
    d.text((1090, 480), "Аптечка M", font=f(F1, 34), fill=TXT)
    for k, line in enumerate(["Восстанавливает 50 здоровья.", "Брось в напарника — вылечит его.", "Хранится в слоте инвентаря."]):
        d.text((1090, 535 + k * 32), line, font=f(F2, 21), fill=DIM)
    d.text((1090, 660), "$7 000", font=f(F1, 40), fill=GRN)
    d.rounded_rectangle((1090, 720, 1460, 780), 12, fill=(70, 180, 80, 255))
    d.text((1275, 750), "КУПИТЬ", font=f(F1, 30), fill=(10, 20, 10, 255), anchor="mm")
    im.save(f"{A}/sheets/ui_shop.png")


def servers():
    im = bg("yard", 0.4, 3)
    d = ImageDraw.Draw(im)
    panel(d, (80, 60, 1520, 840))
    d.text((120, 90), "ИГРА ПО СЕТИ", font=f(F1, 48), fill=TXT)
    d.text((124, 150), "Выбери регион и комнату или создай свою", font=f(F2, 22), fill=DIM)
    regs = [("Азия", "45 мс", GRN, True), ("Европа", "210 мс", YEL, False), ("США", "160 мс", YEL, False)]
    for i, (n, p, c, sel) in enumerate(regs):
        x = 120 + i * 230
        d.rounded_rectangle((x, 200, x + 210, 260), 12, fill=YEL if sel else PANEL2, outline=EDGE, width=2)
        d.text((x + 20, 212), n, font=f(F1, 26), fill=(16, 18, 22, 255) if sel else TXT)
        d.ellipse((x + 180, 214, x + 194, 228), fill=c)
        d.text((x + 194, 246), p, font=f(F2, 16), fill=(30, 30, 30, 255) if sel else DIM, anchor="rm")
    d.rounded_rectangle((1080, 200, 1480, 260), 12, fill=PANEL2, outline=EDGE, width=2)
    d.text((1100, 216), "Поиск по названию…", font=f(F2, 22), fill=DIM)
    cols = [(130, "КОМНАТА"), (700, "ИГРОКИ"), (860, "УРОВЕНЬ"), (1020, "ВЕРСИЯ"), (1180, "ПИНГ")]
    for x, t in cols:
        d.text((x, 290), t, font=f(F3, 18), fill=DIM)
    rows = [("Igor's crew", "3/4", "5", "3.0", 42, False), ("Склад до утра", "1/4", "1", "3.0", 48, False), ("ТОЛЬКО ГОЛОС", "2/4", "8", "3.0", 51, True),
            ("busan_haulers", "4/4", "3", "3.0", 39, False), ("noob friendly", "2/4", "2", "3.0", 66, False), ("arena runs", "1/4", "11", "3.0", 58, True)]
    for i, (n, pl, lv, ver, ping, lock) in enumerate(rows):
        y = 325 + i * 66
        sel = i == 0
        d.rounded_rectangle((110, y, 1490, y + 56), 10, fill=(34, 48, 66, 245) if sel else PANEL2, outline=YEL if sel else EDGE, width=3 if sel else 1)
        d.text((130, y + 13), n + ("   [пароль]" if lock else ""), font=f(F2, 26), fill=TXT)
        full = pl.startswith("4/")
        d.text((700, y + 13), pl, font=f(F1, 26), fill=RED if full else TXT)
        d.text((860, y + 13), lv, font=f(F1, 26), fill=TXT)
        d.text((1020, y + 13), ver, font=f(F2, 24), fill=DIM)
        pc = GRN if ping < 60 else YEL
        d.text((1180, y + 13), f"{ping} мс", font=f(F1, 24), fill=pc)
        for k in range(4):
            hgt = 8 + k * 6
            d.rectangle((1300 + k * 10, y + 42 - hgt, 1306 + k * 10, y + 42), fill=pc if k < (4 if ping < 50 else 3) else (60, 70, 80, 255))
    btns = [("СОЗДАТЬ КОМНАТУ", YEL, (16, 18, 22, 255)), ("ВВЕСТИ КОД", PANEL2, TXT), ("ОБНОВИТЬ", PANEL2, TXT), ("НАЗАД", PANEL2, TXT)]
    x = 110
    for t, c, tc in btns:
        w = 330 if t.startswith("СОЗДАТЬ") else 250
        d.rounded_rectangle((x, 740, x + w, 805), 12, fill=c, outline=EDGE, width=2)
        d.text((x + w / 2, 772), t, font=f(F1, 24), fill=tc, anchor="mm")
        x += w + 20
    im.save(f"{A}/sheets/ui_servers.png")


for fn in (menu, hud, shop, servers):
    try:
        fn()
        print("UI", fn.__name__)
    except Exception as e:
        import traceback
        traceback.print_exc()
