"""Preview renders of art v3 models (Blender 4.0, Cycles CPU).
blender -b --python render.py -- <out_dir> <spec> [<spec> ...]
spec = name[:key=val,...]   keys: color=rrggbb  pose=<POSES key>  yaw=deg  label=file  src=old|new  size=px  cam=x/y/z
A transparent PNG per spec; sheet.py composes them onto cards."""
import bpy, sys, os, math
from mathutils import Vector, Euler

ART = "/home/claude/art3"
ENGINE = os.environ.get("ART_ENGINE", "cycles")
OLD = "/home/claude/haulbots/assets"

# part rotations (Blender euler, radians) + model offset for showcase poses
POSES = {
    "crouch": {"_z": -0.26, "body": (-0.32, 0, 0), "head": (0.1, 0, 0), "_off_head": (0, 0.18, -0.04),
               "leg_l": (1.25, 0, 0.12), "leg_r": (1.25, 0, -0.12), "leg_l_lo": (-2.1, 0, 0), "leg_r_lo": (-2.1, 0, 0),
               "arm_l": (0.75, 0, -0.1), "arm_r": (0.75, 0, 0.1), "arm_l_lo": (0.9, 0, 0), "arm_r_lo": (0.9, 0, 0),
               "_off_arm_l": (0, 0.16, -0.03), "_off_arm_r": (0, 0.16, -0.03)},
    "walk": {"leg_l": (0.5, 0, 0), "leg_r": (-0.45, 0, 0), "leg_r_lo": (-0.5, 0, 0),
             "arm_l": (-0.45, 0, 0), "arm_r": (0.45, 0, 0), "arm_r_lo": (0.4, 0, 0), "body": (0.06, 0, 0)},
    "grab": {"arm_r": (1.45, 0, 0.1), "arm_l": (1.2, 0, -0.2), "arm_l_lo": (0.4, 0, 0), "head": (0.12, 0, 0)},
    "attack": {"arm_l": (2.2, 0, 0), "arm_r": (2.2, 0, 0), "jaw": (0.5, 0, 0), "body": (0.15, 0, 0)},
    "open": {"jaw": (0.6, 0, 0), "lid": (1.0, 0, 0)},
}


def lin(h):
    def f(v):
        v /= 255.0
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return tuple(f(int(h[i:i + 2], 16)) for i in (0, 2, 4))


LIB = {"M_wood": "6b4020", "M_wood_dark": "331a0d", "M_gold": "ffb84d", "M_metal": "9ea1a8", "M_dark_metal": "242529",
       "M_marble": "e6e0d9", "M_fabric": "8c2424", "M_rubber": "0b0b0c", "M_stone": "736e66", "M_paper": "dbcfb3",
       "M_bone": "e0d6bd", "M_chrome": "d1d3db", "M_screen": "0a1410", "M_canvas": "c7ad80", "M_vase": "3359cc", "M_mask": "cc9933"}


def setup_material(m, player_col):
    n = m.name.split(".")[0]
    m.use_nodes = True
    nt = m.node_tree
    for nd in list(nt.nodes):
        nt.nodes.remove(nd)
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    bs = nt.nodes.new("ShaderNodeBsdfPrincipled")
    nt.links.new(bs.outputs[0], out.inputs[0])
    bs.inputs["Roughness"].default_value = 0.6
    if n.startswith("T_"):
        model = n[2:]
        p = os.path.join(ART, "mtex", model + ".png")
        if not os.path.exists(p):
            p = os.path.join(OLD, "mtex", model + ".png")
        if os.path.exists(p):
            tx = nt.nodes.new("ShaderNodeTexImage")
            tx.image = bpy.data.images.load(p, check_existing=True)
            nt.links.new(tx.outputs[0], bs.inputs["Base Color"])
            po = p.replace(".png", "_orm.png")
            if os.path.exists(po):
                to = nt.nodes.new("ShaderNodeTexImage")
                to.image = bpy.data.images.load(po, check_existing=True)
                to.image.colorspace_settings.name = "Non-Color"
                sp = nt.nodes.new("ShaderNodeSeparateColor")
                nt.links.new(to.outputs[0], sp.inputs[0])
                nt.links.new(sp.outputs[1], bs.inputs["Roughness"])
                nt.links.new(sp.outputs[2], bs.inputs["Metallic"])
        return
    if n.startswith("E_") or n.endswith("glow"):
        c = lin(n[2:8]) if n.startswith("E_") and len(n) >= 8 else lin("ffb04a")
        if n == "M_player_glow":
            c = lin("ffb04a")
        bs.inputs["Base Color"].default_value = (*c, 1)
        bs.inputs["Emission Color"].default_value = (*c, 1)
        bs.inputs["Emission Strength"].default_value = 6.0
        return
    if n.startswith("G_"):
        c = lin(n[2:8])
        bs.inputs["Base Color"].default_value = (*c, 1)
        bs.inputs["Alpha"].default_value = 0.45
        bs.inputs["Roughness"].default_value = 0.12
        m.blend_method = "BLEND"
        return
    if n == "M_player":
        bs.inputs["Base Color"].default_value = (*lin(player_col), 1)
        bs.inputs["Roughness"].default_value = 0.5
        return
    if n in LIB:
        bs.inputs["Base Color"].default_value = (*lin(LIB[n]), 1)
        if n in ("M_gold", "M_metal", "M_dark_metal", "M_chrome"):
            bs.inputs["Metallic"].default_value = 1.0
            bs.inputs["Roughness"].default_value = 0.3
        return
    if len(n) >= 8 and n[1] == "_":
        try:
            bs.inputs["Base Color"].default_value = (*lin(n[2:8]), 1)
        except ValueError:
            pass


def area(name, loc, target, energy, col, size):
    ld = bpy.data.lights.new(name, "AREA")
    ld.energy = energy
    ld.color = col
    ld.size = size
    ob = bpy.data.objects.new(name, ld)
    bpy.context.scene.collection.objects.link(ob)
    ob.location = loc
    d = Vector(target) - Vector(loc)
    ob.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()
    return ob


def render(spec, out_dir):
    name, _, opts = spec.partition(":")
    o = {}
    for kv in opts.split(","):
        if "=" in kv:
            k, v = kv.split("=", 1)
            o[k] = v
    bpy.ops.wm.read_factory_settings(use_empty=True)
    src = os.path.join(OLD if o.get("src") == "old" else ART, "models", name + ".glb")
    bpy.ops.import_scene.gltf(filepath=src)
    for hn in o.get("hide", "").split("+"):
        for ob in list(bpy.context.scene.objects):
            if hn and ob.name.split(".")[0] == hn:
                bpy.data.objects.remove(ob, do_unlink=True)
    objs = [ob for ob in bpy.context.scene.objects if ob.type == "MESH"]
    roots = [ob for ob in bpy.context.scene.objects if ob.parent is None]
    pose = POSES.get(o.get("pose", ""), {})
    for ob in bpy.context.scene.objects:
        base = ob.name.split(".")[0]
        if base in pose:
            r = pose[base]
            ob.rotation_mode = "XYZ"
            ob.rotation_euler = Euler((ob.rotation_euler.x + r[0], ob.rotation_euler.y + r[1], ob.rotation_euler.z + r[2]))
        if "_off_" + base in pose:
            ob.location += Vector(pose["_off_" + base])
    yaw = math.radians(float(o.get("yaw", "0")))
    for r in roots:
        r.rotation_mode = "XYZ"
        r.rotation_euler.z += yaw
        r.location.z += pose.get("_z", 0.0)
    for m in bpy.data.materials:
        setup_material(m, o.get("color", "e8b420"))
    bpy.context.view_layer.update()
    pts = [ob.matrix_world @ Vector(c) for ob in objs for c in ob.bound_box]
    lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    ctr = (lo + hi) / 2
    rad = max((hi - lo).length / 2, 0.05)
    scn = bpy.context.scene
    # ground shadow catcher
    bpy.ops.mesh.primitive_plane_add(size=rad * 30, location=(ctr.x, ctr.y, lo.z))
    gp = bpy.context.active_object
    gp.is_shadow_catcher = True
    # camera
    cd = Vector(tuple(float(x) for x in o.get("cam", "0.55/1.0/0.42").split("/"))).normalized()
    camd = bpy.data.cameras.new("cam")
    camd.lens = 50
    cam = bpy.data.objects.new("cam", camd)
    scn.collection.objects.link(cam)
    fov = 2 * math.atan(18 / 50)
    dist = rad / math.tan(fov / 2) * 1.08
    cam.location = ctr + cd * dist
    cam.rotation_euler = (ctr - cam.location).to_track_quat("-Z", "Y").to_euler()
    scn.camera = cam
    camd.clip_start = 0.01
    camd.clip_end = dist * 10
    # lights
    s = rad / 0.5
    area("key", ctr + Vector((1.6, 2.2, 2.4)) * s, ctr, 260 * s * s, (1.0, 0.86, 0.68), 1.4 * s)
    area("rim", ctr + Vector((-1.8, -2.2, 1.9)) * s, ctr, 320 * s * s, (0.45, 0.66, 1.0), 1.0 * s)
    area("fill", ctr + Vector((-2.4, 1.6, 0.6)) * s, ctr, 55 * s * s, (0.6, 0.72, 0.95), 2.0 * s)
    w = bpy.data.worlds.new("w")
    w.use_nodes = True
    w.node_tree.nodes["Background"].inputs[0].default_value = (0.012, 0.016, 0.024, 1)
    w.node_tree.nodes["Background"].inputs[1].default_value = 1.0
    scn.world = w
    scn.render.engine = "BLENDER_EEVEE" if o.get("eng", ENGINE) == "eevee" else "CYCLES"
    scn.cycles.device = "CPU"
    if scn.render.engine == "BLENDER_EEVEE":
        ee = scn.eevee
        ee.taa_render_samples = 64
        ee.use_gtao = True
        ee.gtao_distance = rad * 0.6
        ee.use_soft_shadows = True
        ee.shadow_cube_size = "2048"
        ee.shadow_cascade_size = "2048"
        ee.use_bloom = False
    scn.cycles.samples = int(o.get("samples", "96"))
    scn.cycles.use_denoising = False
    scn.render.film_transparent = True
    sz = int(o.get("size", "512"))
    scn.render.resolution_x = sz
    scn.render.resolution_y = sz
    scn.render.image_settings.file_format = "PNG"
    scn.render.image_settings.color_mode = "RGBA"
    scn.view_settings.view_transform = o.get("vt", "Filmic")
    scn.view_settings.look = o.get("look", "Medium High Contrast")
    # glow on emissive bits
    scn.use_nodes = True
    ct = scn.node_tree
    for nd in list(ct.nodes):
        ct.nodes.remove(nd)
    rl = ct.nodes.new("CompositorNodeRLayers")
    gl = ct.nodes.new("CompositorNodeGlare")
    gl.glare_type = "FOG_GLOW"
    gl.threshold = 1.0
    gl.size = 6
    gl.mix = -0.35
    co = ct.nodes.new("CompositorNodeComposite")
    ct.links.new(rl.outputs["Image"], gl.inputs[0])
    ct.links.new(gl.outputs[0], co.inputs["Image"])
    ct.links.new(rl.outputs["Alpha"], co.inputs["Alpha"])
    scn.render.filepath = os.path.join(out_dir, o.get("label", name) + ".png")
    bpy.ops.render.render(write_still=True)
    print("RENDERED", scn.render.filepath)


args = sys.argv[sys.argv.index("--") + 1:]
out = args[0]
os.makedirs(out, exist_ok=True)
for sp in args[1:]:
    try:
        render(sp, out)
    except Exception as e:
        import traceback
        traceback.print_exc()
        print("RENDER FAILED", sp, e)
