"""Room mood renders from the art v3 models + textures (Cycles).
blender -b --python rooms.py -- <room> [<room> ...]"""
import bpy, sys, os, math
from mathutils import Vector, Euler

exec(open("/home/claude/art3/scripts/render.py").read().split("args = sys.argv")[0])

TEX = "/home/claude/art3/tex"
OUTR = "/home/claude/art3/renders/rooms"
_cache = {}


def tex_mat(name, scale=1.0, tint=(1, 1, 1)):
    key = (name, scale, tint)
    if key in _cache:
        return _cache[key]
    m = bpy.data.materials.new("TX_" + name)
    m.use_nodes = True
    nt = m.node_tree
    bs = nt.nodes["Principled BSDF"]
    tc = nt.nodes.new("ShaderNodeTexCoord")
    mp = nt.nodes.new("ShaderNodeMapping")
    mp.inputs["Scale"].default_value = (scale, scale, scale)
    nt.links.new(tc.outputs["UV"], mp.inputs["Vector"])
    a = nt.nodes.new("ShaderNodeTexImage")
    a.image = bpy.data.images.load(f"{TEX}/{name}.png", check_existing=True)
    nt.links.new(mp.outputs[0], a.inputs[0])
    mul = nt.nodes.new("ShaderNodeMix")
    mul.data_type = "RGBA"
    mul.blend_type = "MULTIPLY"
    mul.inputs[0].default_value = 1.0
    nt.links.new(a.outputs[0], mul.inputs[6])
    mul.inputs[7].default_value = (*tint, 1)
    nt.links.new(mul.outputs[2], bs.inputs["Base Color"])
    r = nt.nodes.new("ShaderNodeTexImage")
    r.image = bpy.data.images.load(f"{TEX}/{name}_r.png", check_existing=True)
    r.image.colorspace_settings.name = "Non-Color"
    nt.links.new(mp.outputs[0], r.inputs[0])
    nt.links.new(r.outputs[0], bs.inputs["Roughness"])
    n = nt.nodes.new("ShaderNodeTexImage")
    n.image = bpy.data.images.load(f"{TEX}/{name}_n.png", check_existing=True)
    n.image.colorspace_settings.name = "Non-Color"
    nt.links.new(mp.outputs[0], n.inputs[0])
    nm = nt.nodes.new("ShaderNodeNormalMap")
    nm.inputs["Strength"].default_value = 0.8
    nt.links.new(n.outputs[0], nm.inputs["Color"])
    nt.links.new(nm.outputs[0], bs.inputs["Normal"])
    _cache[key] = m
    return m


def plane(w, h, loc, rot, material, tile=2.0):
    bpy.ops.mesh.primitive_plane_add(size=1, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.scale = (w, h, 1)
    bpy.ops.object.transform_apply(scale=True)
    for l in o.data.uv_layers.active.data:
        l.uv = (l.uv[0] * w / tile, l.uv[1] * h / tile)
    o.data.materials.append(material)
    return o


def decal(name, w, h, loc, rot):
    m = bpy.data.materials.new("DC_" + name)
    m.use_nodes = True
    m.blend_method = "BLEND"
    nt = m.node_tree
    bs = nt.nodes["Principled BSDF"]
    t = nt.nodes.new("ShaderNodeTexImage")
    t.image = bpy.data.images.load(f"{TEX}/decals/{name}.png", check_existing=True)
    nt.links.new(t.outputs[0], bs.inputs["Base Color"])
    nt.links.new(t.outputs[1], bs.inputs["Alpha"])
    bs.inputs["Roughness"].default_value = 0.7
    if name.startswith("sign_exit"):
        nt.links.new(t.outputs[0], bs.inputs["Emission Color"])
        bs.inputs["Emission Strength"].default_value = 2.0
    bpy.ops.mesh.primitive_plane_add(size=1, location=loc, rotation=rot)
    o = bpy.context.active_object
    o.scale = (w, h, 1)
    o.data.materials.append(m)
    return o


_models = {}


def place(name, loc, rz=0.0, scale=1.0, color=None, pose=None):
    """Import a model (first time) and drop a copy at loc, rotated rz degrees about Z."""
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=f"{ART}/models/{name}.glb")
    new = [o for o in bpy.data.objects if o not in before]
    for m in {s.material for o in new if o.type == "MESH" for s in o.material_slots if s.material}:
        if not m.get("_set"):
            setup_material(m, color or "e8b420")
            m["_set"] = 1
    if pose:
        for o in new:
            b = o.name.split(".")[0]
            if b in POSES[pose]:
                r = POSES[pose][b]
                o.rotation_mode = "XYZ"
                o.rotation_euler = Euler((o.rotation_euler.x + r[0], o.rotation_euler.y + r[1], o.rotation_euler.z + r[2]))
            if "_off_" + b in POSES[pose]:
                o.location += Vector(POSES[pose]["_off_" + b])
    root = bpy.data.objects.new("R_" + name, None)
    bpy.context.scene.collection.objects.link(root)
    for o in new:
        if o.parent is None:
            o.parent = root
    root.location = loc
    root.rotation_euler = (0, 0, math.radians(rz))
    root.scale = (scale, scale, scale)
    if pose and "_z" in POSES[pose]:
        root.location.z += POSES[pose]["_z"] * scale
    return root


def light(kind, loc, energy, color, size=0.5, rot=(0, 0, 0), spot=None):
    ld = bpy.data.lights.new("L", kind)
    ld.energy = energy
    ld.color = color
    if kind == "AREA":
        ld.size = size
    elif kind in ("POINT", "SPOT"):
        ld.shadow_soft_size = size
    if spot:
        ld.spot_size = spot
        ld.spot_blend = 0.5
    o = bpy.data.objects.new("L", ld)
    bpy.context.scene.collection.objects.link(o)
    o.location = loc
    o.rotation_euler = rot
    return o


def shell(w, d, h, wall, floor, ceil, tw=2.0, tint_w=(1, 1, 1), tint_f=(1, 1, 1), open_side=None):
    plane(w, d, (0, 0, 0), (0, 0, 0), tex_mat(floor, 1.0, tint_f), tw)
    if ceil:
        plane(w, d, (0, 0, h), (math.pi, 0, 0), tex_mat(ceil), tw)
    sides = {"n": ((0, d / 2, h / 2), (math.pi / 2, 0, math.pi), w), "s": ((0, -d / 2, h / 2), (math.pi / 2, 0, 0), w),
             "e": ((w / 2, 0, h / 2), (math.pi / 2, 0, math.pi / 2), d), "w": ((-w / 2, 0, h / 2), (math.pi / 2, 0, -math.pi / 2), d)}
    for k, (loc, rot, ln) in sides.items():
        if k != open_side:
            plane(ln, h, loc, rot, tex_mat(wall, 1.0, tint_w), tw)


def camera(loc, target, lens=20):
    cd = bpy.data.cameras.new("c")
    cd.lens = lens
    c = bpy.data.objects.new("c", cd)
    bpy.context.scene.collection.objects.link(c)
    c.location = loc
    c.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat("-Z", "Y").to_euler()
    bpy.context.scene.camera = c


def setup(world=(0.004, 0.005, 0.008), samples=int(os.environ.get("ROOM_SAMPLES", "96"))):
    scn = bpy.context.scene
    scn.render.engine = "CYCLES"
    scn.cycles.device = "CPU"
    scn.cycles.samples = samples
    scn.cycles.use_denoising = False
    scn.cycles.max_bounces = 4
    scn.cycles.sample_clamp_indirect = 3.0
    scn.cycles.sample_clamp_direct = 12.0
    scn.render.resolution_x = 960
    scn.render.resolution_y = 540
    scn.render.film_transparent = False
    scn.view_settings.view_transform = "Filmic"
    scn.view_settings.look = "Medium High Contrast"
    w = bpy.data.worlds.new("w")
    w.use_nodes = True
    w.node_tree.nodes["Background"].inputs[0].default_value = (*world, 1)
    scn.world = w
    scn.use_nodes = True
    ct = scn.node_tree
    for nd in list(ct.nodes):
        ct.nodes.remove(nd)
    rl = ct.nodes.new("CompositorNodeRLayers")
    gl = ct.nodes.new("CompositorNodeGlare")
    gl.glare_type = "FOG_GLOW"
    gl.threshold = 0.9
    gl.size = 7
    gl.mix = -0.2
    co = ct.nodes.new("CompositorNodeComposite")
    ct.links.new(rl.outputs["Image"], gl.inputs[0])
    ct.links.new(gl.outputs[0], co.inputs["Image"])


def finish(name):
    bpy.context.scene.render.filepath = f"{OUTR}/{name}.png"
    bpy.ops.render.render(write_still=True)
    print("RENDERED", name)


WARM = (1.0, 0.72, 0.42)
COOL = (0.75, 0.88, 1.0)
RED = (1.0, 0.12, 0.08)
GREEN = (0.35, 1.0, 0.5)


def room_warehouse():
    shell(10, 10, 4.0, "wall_corrugated", "floor_concrete", "ceiling_concrete")
    for x in (-3.6, -0.4):
        place("rack", (x, 3.6, 0), 0)
        place("rack", (x, -3.6, 0), 180)
    place("forklift", (2.8, 2.6, 0), -140)
    place("pallet", (2.6, -2.8, 0), 20)
    place("pallet", (3.8, -1.2, 0), -10)
    place("crate", (-3.8, 0.4, 0), 15)
    place("crate", (-3.6, 0.5, 0.8), 40, 0.8)
    place("crate_metal", (-2.4, -1.0, 0), -30)
    place("barrel", (4.2, 1.0, 0))
    place("barrel", (4.3, 0.3, 0))
    place("cone", (0.6, 0.4, 0))
    place("cone", (1.4, -0.2, 0))
    place("cart", (-0.8, -1.2, 0.48), 70)
    place("robot", (0.2, -0.6, 0), 200, color="e8b420", pose="walk")
    place("robot", (-1.6, -2.2, 0), 120, color="2f6fd6", pose="grab")
    place("toolbox", (-0.9, -1.1, 0.65), 30)
    place("safe", (1.5, -3.6, 0), -150)
    decal("arrow_floor", 0.9, 0.9, (0.0, 1.0, 0.01), (0, 0, 0.0))
    decal("stencil_numbers", 1.2, 0.6, (-4.98, -2.0, 2.6), (math.pi / 2, 0, -math.pi / 2))
    decal("oil_stain", 1.4, 1.4, (2.0, 0.8, 0.005), (0, 0, 0.5))
    for x, y in ((-2.0, 0.0), (2.0, 0.0), (0, 3.0), (0, -3.0)):
        place("lamp_pendant", (x, y, 4.0 - 0.6))
        light("POINT", (x, y, 3.0), 260, WARM, 0.3)
    light("AREA", (0, 0, 3.9), 120, COOL, 8.0)
    camera((4.6, -4.6, 2.2), (-0.5, 0.6, 0.9), 18)


def room_office():
    shell(9, 9, 3.2, "wall_plaster", "floor_carpet", "ceiling_tiles")
    for x, y, r in ((-2.5, 1.5, 0), (0.5, 1.5, 0), (-2.5, -1.2, 180), (0.5, -1.2, 180)):
        place("desk", (x, y, 0), r)
        place("office_chair", (x - 0.1, y - 0.7 if r == 0 else y + 0.7, 0), 180 + r + 20)
    place("filing_cabinet", (3.8, 3.8, 0), 180)
    place("filing_cabinet", (3.2, 3.8, 0), 180)
    place("locker", (-3.9, 3.9, 0), 180)
    place("plant", (3.9, -3.9, 0))
    place("water_cooler", (3.9, 0.5, 0), -90)
    place("whiteboard", (0.0, 4.45, 0), 180)
    place("sofa", (3.4, -2.0, 0), -90)
    place("laptop", (0.6, 1.4, 0.77), 10)
    place("computer", (-2.6, -1.1, 0.77), 180)
    place("gremlin", (1.5, -0.2, 0), 210)
    place("gremlin", (2.0, 0.6, 0), 240)
    place("robot", (-1.0, -3.4, 0), 40, color="4caf3a", pose="crouch")
    for x, y in ((-2.0, 0.2), (1.5, 0.2), (-2.0, -3.0), (1.5, 3.0)):
        place("lamp_tube", (x, y, 3.2 - 0.27))
        light("AREA", (x, y, 3.0), 90 if (x, y) != (1.5, 3.0) else 15, COOL, 1.2)
    decal("poster_safety", 0.6, 0.9, (-4.48, 0.5, 1.6), (math.pi / 2, 0, -math.pi / 2))
    camera((4.0, -4.1, 1.9), (-0.8, 0.8, 0.8), 18)


def room_lab():
    shell(9, 9, 3.4, "wall_tiles", "floor_vinyl", "ceiling_tiles")
    for x in (-3.3, -2.0, 2.0, 3.3):
        place("lab_tank", (x, 3.7, 0))
        light("POINT", (x, 3.3, 1.2), 120, GREEN, 0.3)
    place("lab_bench", (-0.6, 0.2, 0), 0)
    place("lab_bench", (-0.6, -2.0, 0), 180)
    place("terminal", (3.6, -0.5, 0), -90)
    place("server_rack", (3.8, 1.4, 0), -90)
    place("med_cabinet", (-4.45, -1.0, 0), 90)
    place("flasks", (-0.9, 0.2, 0.95))
    place("microscope", (0.0, 0.1, 0.95), 30)
    place("projector", (1.6, 1.6, 0), 210)
    place("robot", (-1.8, -3.4, 0), 30, color="d64aa0", pose="walk")
    place("powercell", (0.9, -2.0, 0.95))
    for x, y in ((-1.5, -1), (1.5, -1)):
        place("lamp_tube", (x, y, 3.4 - 0.27))
        light("AREA", (x, y, 3.2), 45, COOL, 1.2)
    decal("sign_danger", 0.5, 0.5, (-4.48, 2.0, 1.7), (math.pi / 2, 0, -math.pi / 2))
    camera((3.9, -4.0, 1.8), (-0.8, 1.2, 1.0), 18)


def room_corridor():
    shell(2.8, 12, 3.0, "wall_metal", "floor_plate", "ceiling_concrete")
    place("doorframe", (1.4, 1.0, 0), 90)
    place("door", (1.38, 0.15, 0), 90)
    place("doorframe", (-1.4, -2.0, 0), -90)
    place("vent", (-1.4, 2.5, 0.3), -90)
    place("pipes", (1.4, -3.0, 0), 90)
    place("pipes", (1.4, -1.0, 0), 90)
    place("fusebox", (-1.4, -4.0, 0), -90)
    place("barrel", (-0.9, 4.5, 0))
    place("lurker", (0.1, 3.4, 0), 180)
    place("robot", (0.3, -2.4, 0), 0, color="2f6fd6", pose="crouch")
    for y in (-4.0, 0.0, 4.0):
        place("beacon_red", (0, y, 3.0 - 0.17))
        light("POINT", (0, y, 2.6), 160, RED, 0.2)
    place("beacon_red", (-1.36, 5.5, 2.4), 0)
    decal("sign_exit", 0.6, 0.3, (0, 5.98, 2.5), (math.pi / 2, 0, math.pi))
    decal("footprints", 0.6, 0.6, (0.2, -0.8, 0.005), (0, 0, 0.1))
    light("AREA", (0, 0, 2.95), 10, (0.4, 0.5, 0.7), 2.0)
    camera((0.5, -5.6, 1.5), (0, 3.0, 1.1), 20)


def room_basement():
    shell(9, 9, 3.0, "wall_brick", "floor_concrete", "ceiling_concrete", tint_f=(0.7, 0.7, 0.7))
    place("boiler", (-3.2, 3.0, 0), 20)
    place("generator", (2.6, 3.4, 0), 180)
    place("fusebox", (4.45, 0.5, 0), -90)
    place("pipes", (-4.45, 0.0, 0), -90)
    place("pipes", (0.0, 4.45, 0), 180)
    for x, y in ((3.6, -3.4), (3.0, -3.8), (3.8, -2.6)):
        place("barrel", (x, y, 0))
    place("rack", (-3.6, -3.2, 0), 90, 0.8)
    place("brute", (0.5, 1.2, 0), 200)
    place("robot", (-1.2, -2.2, 0), 30, color="e8b420", pose="walk")
    place("jerrycan", (1.8, -1.0, 0), 40)
    place("lamp_cage", (4.45, -1.5, 2.2), -90)
    light("POINT", (4.1, -1.5, 2.2), 70, WARM, 0.15)
    light("POINT", (-3.0, 2.4, 0.6), 50, (1.0, 0.45, 0.15), 0.3)
    place("lamp_pendant", (0, -0.5, 3.0 - 0.6))
    light("POINT", (0, -0.5, 2.2), 120, WARM, 0.25)
    camera((3.8, -4.0, 1.7), (-0.8, 1.0, 1.0), 18)


def room_shop():
    shell(10, 10, 3.6, "wall_metal", "floor_concrete", "ceiling_concrete", tint_w=(0.9, 0.85, 0.8))
    for x in (-3.8, -1.2):
        place("store_shelf", (x, 4.6, 0), 180)
    place("store_shelf", (-4.7, 1.0, 0), -90)
    place("store_shelf", (-4.7, -2.0, 0), -90)
    place("counter", (2.2, 2.2, 0), 180)
    place("shopkeeper", (2.2, 3.0, 0.6), 180)
    place("sign_shop", (2.2, 4.95, 2.6), 180)
    place("sign_tools", (-2.5, 4.95, 2.6), 180)
    place("vending", (4.5, -0.5, 0), -90)
    place("crate", (4.0, -3.6, 0), 20)
    place("plant", (4.4, 4.3, 0))
    place("medkit_m", (1.6, 2.2, 1.12), 20)
    place("w_pistol", (2.6, 2.0, 1.1), 70)
    place("robot", (0.6, -0.8, 0), 160, color="e8b420", pose="walk")
    place("robot", (-1.0, 0.6, 0), 140, color="4caf3a")
    decal("poster_loot", 0.7, 1.05, (4.95, 2.4, 1.8), (math.pi / 2, 0, math.pi / 2))
    light("POINT", (2.2, 4.4, 2.6), 120, RED, 0.3)
    for x, y in ((-2.5, 2.5), (2.0, 0.0), (-2.5, -2.0)):
        place("lamp_pendant", (x, y, 3.6 - 0.6))
        light("POINT", (x, y, 2.7), 230, WARM, 0.3)
    camera((4.2, -4.4, 2.0), (-0.6, 1.8, 1.1), 18)


def room_garage():
    shell(12, 12, 4.5, "wall_block", "floor_concrete", "ceiling_concrete")
    place("truck", (0.0, 0.3, 0), 200)
    place("gate", (0.0, 5.95, 0), 180)
    place("tires", (4.6, -4.0, 0))
    place("jerrycan", (4.8, -3.0, 0), 20)
    place("cone", (3.0, -2.0, 0))
    place("charger", (-5.5, -2.5, 0), 90)
    place("button", (-3.0, -4.0, 0))
    place("robot", (2.0, -3.4, 0), 210, color="d64aa0", pose="walk")
    place("robot", (2.8, -2.6, 0), 230, color="4caf3a")
    place("moneybag", (1.2, -2.8, 0.2))
    for x in (-3, 3):
        place("lamp_tube", (x, 0, 4.5 - 0.27))
        light("AREA", (x, 0, 4.2), 160, COOL, 1.4)
    decal("hazard_dummy", 0.01, 0.01, (0, 0, -5), (0, 0, 0)) if False else None
    camera((5.6, -5.6, 2.3), (-0.4, 0.6, 1.2), 18)


def room_yard():
    plane(30, 30, (0, 0, 0), (0, 0, 0), tex_mat("asphalt"), 3.0)
    plane(8, 30, (-12, 0, 0.01), (0, 0, 0), tex_mat("ground"), 3.0)
    for i in range(6):
        place("fence", (-8.0, -10 + i * 2.0, 0), 90)
    place("street_lamp", (-5.2, -1.6, 0), -90)
    light("SPOT", (-4.3, -1.6, 4.4), 2200, (1.0, 0.7, 0.4), 0.3, rot=(0, 0, 0), spot=1.9)
    light("AREA", (4.0, -6.0, 3.0), 150, (0.5, 0.6, 1.0), 4.0, rot=(1.0, 0, 0.6))
    place("truck", (0.0, 0.0, 0), 160)
    place("dumpster", (5.0, 4.0, 0), 200)
    place("tires", (4.0, -3.0, 0))
    place("robot", (-2.2, -2.8, 0), 200, color="e8b420", pose="walk")
    place("robot", (-3.0, -1.8, 0), 170, color="2f6fd6")
    place("robot", (-1.2, -1.6, 0), 230, color="d64aa0", pose="grab")
    place("cart", (-2.0, -0.6, 0.48), 120)
    w = bpy.context.scene.world
    w.node_tree.nodes["Background"].inputs[0].default_value = (0.012, 0.018, 0.04, 1)
    w.node_tree.nodes["Background"].inputs[1].default_value = 1.5
    light("SUN", (0, 0, 10), 0.9, (0.5, 0.6, 1.0), rot=(0.9, 0.2, 2.2))
    camera((6.0, -7.5, 2.4), (-1.5, 0.5, 1.0), 20)


ROOMS = {"warehouse": room_warehouse, "office": room_office, "lab": room_lab, "corridor": room_corridor,
         "basement": room_basement, "shop": room_shop, "garage": room_garage, "yard": room_yard}

args = sys.argv[sys.argv.index("--") + 1:]
os.makedirs(OUTR, exist_ok=True)
for r in args:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    _cache.clear()
    setup()
    try:
        ROOMS[r]()
        finish(r)
    except Exception as e:
        import traceback
        traceback.print_exc()
        print("ROOM FAILED", r, e)
