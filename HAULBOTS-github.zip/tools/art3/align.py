"""Shift new gear GLBs so their bounding-box centre matches the old model of the same name
(the game holds / collides them relative to that origin). No re-bake: re-export as is."""
import bpy, sys, os
from mathutils import Vector
sys.path.insert(0, "/home/claude/haulbots/tools")
from blib import export
ART = "/home/claude/art3/models"
OLD = "/home/claude/haulbots/assets/models"

def bbox(path):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=path)
    bpy.context.view_layer.update()
    pts = [o.matrix_world @ Vector(c) for o in bpy.context.scene.objects if o.type == "MESH" for c in o.bound_box]
    lo = Vector([min(p[i] for p in pts) for i in range(3)])
    hi = Vector([max(p[i] for p in pts) for i in range(3)])
    return lo, hi

for name in sys.argv[sys.argv.index("--") + 1:]:
    olo, ohi = bbox(f"{OLD}/{name}.glb")
    nlo, nhi = bbox(f"{ART}/{name}.glb")
    d = (olo + ohi) / 2 - (nlo + nhi) / 2
    roots = [o for o in bpy.context.scene.objects if o.parent is None]
    for r in roots:
        if r.type == "MESH" and not r.children:
            r.data.transform(__import__("mathutils").Matrix.Translation(d))
        else:
            r.location += d
    bpy.context.view_layer.update()
    export(f"{ART}/{name}.glb", roots)
    print("ALIGN", name, tuple(round(x, 3) for x in d), "old", tuple(round(x, 2) for x in ohi - olo), "new", tuple(round(x, 2) for x in nhi - nlo))
