"""Lighter copies of the heaviest GLBs for the APK (same nodes, pivots, materials and UVs).
blender -b -P tools/art3/slim.py -- <src_dir> <dst_dir> name:ratio ..."""
import bpy, sys, math
sys.path.insert(0, "/home/claude/haulbots/tools")
from blib import export

args = sys.argv[sys.argv.index("--") + 1:]
src, dst = args[0], args[1]
for spec in args[2:]:
    name, ratio = spec.split(":")
    ratio = float(ratio)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=f"{src}/{name}.glb", merge_vertices=True)
    before = after = 0
    for o in list(bpy.context.scene.objects):
        if o.type != "MESH":
            continue
        me = o.data
        n = sum(len(p.vertices) - 2 for p in me.polygons)
        before += n
        bpy.context.view_layer.objects.active = o
        for s in bpy.context.selected_objects:
            s.select_set(False)
        o.select_set(True)
        # one material slot per material: fewer surfaces (draw calls) and fewer split vertices
        first = {}
        remap = {}
        for i, ms in enumerate(me.materials):
            key = ms.name if ms else ""
            remap[i] = first.setdefault(key, i)
        if any(remap[i] != i for i in remap):
            for p in me.polygons:
                p.material_index = remap[p.material_index]
            bpy.ops.object.material_slot_remove_unused()
        if ratio < 0.999 and n > 200:
            if me.has_custom_normals:
                bpy.ops.mesh.customdata_custom_splitnormals_clear()
            for p in me.polygons:
                p.use_smooth = True
            if hasattr(me, "use_auto_smooth"):
                me.use_auto_smooth = True
                me.auto_smooth_angle = math.radians(40)
            m = o.modifiers.new("dec", "DECIMATE")
            m.decimate_type = "COLLAPSE"
            m.ratio = ratio
            m.use_collapse_triangulate = True
            bpy.ops.object.modifier_apply(modifier=m.name)
        after += sum(len(p.vertices) - 2 for p in me.polygons)
    roots = [o for o in bpy.context.scene.objects if o.parent is None]
    export(f"{dst}/{name}.glb", roots)
    print("SLIM", name, before, "->", after)
