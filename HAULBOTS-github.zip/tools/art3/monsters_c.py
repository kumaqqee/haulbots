"""Tier-3 monsters, art v3. blender -b --python monsters_c.py -- [names]"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *


def bighead():
    """Giant swollen bald head with an enormous grin, floating over a tiny withered body."""
    reset()
    S = "L_leather_8a7a70"
    head = meta("h", [("ell", (0, 0.0, 1.7), 0.42, (1.0, 0.95, 0.88)), ("ell", (0, 0.08, 1.52), 0.32, (1.05, 0.9, 0.5)),
                      ("ell", (0, -0.06, 1.9), 0.3, (1.05, 1.0, 0.65)),
                      {"t": "ell", "co": (0, 0.4, 1.46), "r": 0.22, "s": (1.3, 0.6, 0.32), "neg": True, "stiff": 3.0}], S, 0.025)
    displace(head, 0.014, 0.09, depth=3)
    spots = [sphere(0.035, (math.sin(a) * 0.35, math.cos(a) * 0.3, 1.9 + 0.05 * math.cos(3 * a)), "L_leather_5a4a50", 6, 3, (1, 1, 0.4)) for a in (0.6, -0.8, 2.4, 3.6, 1.6)]
    snap_objs(spots, head, 0.4)
    eyes = []
    for x in (-0.14, 0.14):
        eyes.append(sphere(0.07, (x, 0.32, 1.76), "C_080606", 10, 5, (1, 0.7, 0.75)))
        eyes.append(sphere(0.022, (x, 0.385, 1.76), "E_ffe060", 6, 3))
    brows = [box((0.16, 0.06, 0.045), (s * 0.14, 0.37, 1.85), S, 0.02, rot=(0, -0.35 * s, 0)) for s in (1, -1)]
    mouth_in = sphere(0.2, (0, 0.33, 1.46), "C_120406", 16, 8, (1.3, 0.55, 0.3))
    upper = teeth_row(0, 0.43, 1.5, 0.44, 13, 0.065, "L_bone_e0d4b0", r=0.02, curve=0.07)
    head = part([head, mouth_in] + spots + eyes + brows + upper, "head", (0, 0, 1.5))
    jaw = meta("jaw", [("ell", (0, 0.12, 1.34), 0.3, (1.05, 0.95, 0.38)), {"t": "ell", "co": (0, 0.24, 1.4), "r": 0.22, "s": (1.2, 0.8, 0.3), "neg": True}], S, 0.02)
    displace(jaw, 0.008, 0.06)
    tongue = meta("tg", [("ell", (0, 0.22, 1.38), 0.13, (1.0, 1.1, 0.22))], "L_skin_7a2030", 0.015)
    lower = teeth_row(0, 0.42, 1.4, 0.4, 12, 0.055, "L_bone_e0d4b0", r=0.018, down=False, curve=0.07)
    jaw = part([jaw, tongue] + lower, "jaw", (0, 0.05, 1.4))
    body = meta("b", [("ell", (0, 0, 0.95), 0.1, (1.2, 0.8, 1.6)), ("ell", (0, 0.02, 1.12), 0.09, (1.6, 0.8, 0.6))], "L_leather_6a5a50", 0.012)
    limbs = []
    for s_ in (1, -1):
        limbs.append(skin([(0.12 * s_, 0.02, 1.12, 0.025), (0.2 * s_, 0.06, 0.92, 0.018), (0.22 * s_, 0.1, 0.74, 0.012)], material="L_leather_6a5a50", subdiv=1))
        limbs.append(skin([(0.06 * s_, 0, 0.8, 0.03), (0.08 * s_, 0.03, 0.55, 0.02), (0.07 * s_, -0.02, 0.36, 0.012)], material="L_leather_6a5a50", subdiv=1))
    gown = cloth([(0.16, 0.7), (0.14, 0.9), (0.12, 1.08)], "L_fabric_8a8478", 8, 0.02, 24, 1, 0.08)
    body = part([body, gown] + limbs, "body", (0, 0, 1.0))
    save("bighead", [head, jaw, body], tex=512, tris=6000, split=False)


def projector():
    """TV-man: tall thin man in a dark suit, a CRT TV for a head with a glowing face on the screen."""
    reset()
    suit = "L_fabric_1e2028"
    torso = meta("t", [("ell", (0, 0, 1.55), 0.17, (1.35, 0.7, 1.4)), ("ell", (0, 0, 1.25), 0.14, (1.1, 0.7, 0.9)),
                       ("ell", (0, 0, 1.8), 0.13, (2.1, 0.8, 0.45))], suit, 0.018)
    shirt = box((0.12, 0.02, 0.36), (0, 0.11, 1.6), "L_fabric_c8c4b8", 0.01)
    tie = meta("tie", [("ell", (0, 0.125, 1.55), 0.025, (1.0, 0.4, 5.0)), ("ell", (0, 0.125, 1.76), 0.022, (1.2, 0.5, 0.8))], "L_fabric_8a1a1a", 0.008)
    lapels = [box((0.08, 0.02, 0.26), (s * 0.08, 0.115, 1.66), suit, 0.01, rot=(0, 0.35 * s, 0)) for s in (1, -1)]
    buttons = [sphere(0.012, (0.03, 0.12, 1.38 + i * 0.08), "L_plastic_101010", 6, 3) for i in range(2)]
    body = part([torso, shirt, tie] + lapels + buttons, "body", (0, 0, 1.2))
    case = box((0.5, 0.42, 0.4), (0, -0.02, 2.13), "L_plastic_5a5048", 0.04)
    back = box((0.34, 0.24, 0.26), (0, -0.28, 2.12), "L_plastic_4a4038", 0.04)
    bezel = box((0.42, 0.04, 0.32), (0, 0.19, 2.14), "L_plastic_1a1a1a", 0.03)
    screen = box((0.36, 0.02, 0.27), (0, 0.205, 2.14), "E_3a1a5a", 0.03)
    face = [sphere(0.035, (x, 0.218, 2.18), "E_f0e0ff", 8, 4, (1.3, 0.3, 0.6)) for x in (-0.08, 0.08)]
    face.append(box((0.16, 0.01, 0.025), (0, 0.218, 2.07), "E_f0e0ff", 0.008))
    knobs = [cyl(0.02, 0.02, (0.23, 0.13, 2.06 + i * 0.07), "L_plastic_2a2a2a", 10, rot=(0, math.pi / 2, 0)) for i in range(2)]
    ant = [cyl(0.008, 0.36, (s * 0.1, -0.05, 2.45), "L_metal_9a9ea8", 6, rot=(0, -0.5 * s, 0.3 * s)) for s in (1, -1)]
    ant_base = cyl(0.04, 0.03, (0, -0.05, 2.34), "L_plastic_2a2a2a", 10)
    neck = cyl(0.05, 0.12, (0, 0, 1.92), "L_fabric_c8c4b8", 10)
    vents = [box((0.3, 0.01, 0.012), (0, -0.4, 2.06 + i * 0.03), "L_plastic_1a1a1a", 0.0) for i in range(4)]
    head = part([case, back, bezel, screen, ant_base, neck] + face + knobs + ant + vents, "head", (0, 0, 1.95))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.3 * s
        a = [skin([(x, 0, 1.78, 0.06), (x + 0.04 * s, 0.03, 1.3, 0.05), (x + 0.03 * s, 0.06, 0.88, 0.045)], material=suit, subdiv=1),
             cyl(0.04, 0.05, (x + 0.03 * s, 0.06, 0.86), "L_fabric_c8c4b8", 10)]
        a += claw_hand(x + 0.03 * s, 0.07, 0.8, "L_skin_c8b8a8", s, 4, 0.1, 0.011, "L_skin_c8b8a8")
        arms.append(part(a, nm, (x, 0, 1.78)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.12 * s
        legs.append(part([skin([(x, 0, 1.2, 0.08), (x, 0.02, 0.6, 0.06), (x, 0.0, 0.1, 0.055)], material=suit, subdiv=1),
                          meta("shoe", [("ell", (x, 0.06, 0.04), 0.06, (0.9, 1.9, 0.6))], "L_leather_101010", 0.012)], nm, (x, 0, 1.2)))
    save("projector", [body, head] + arms + legs, tex=512, tris=6000)


def hunter():
    """The Blind one: tall sinewy dark-red humanoid, no eyes, one mining lamp on the forehead, double barrel."""
    reset()
    S = "L_skin_6a2420"
    coat = "L_leather_3a2a20"
    torso = skin([(0, 0, 1.02, 0.13), (0, 0, 1.25, 0.14), (0, 0, 1.5, 0.18), (0, 0.01, 1.7, 0.17), (0, 0.02, 1.76, 0.1)], material=S, subdiv=2)
    torso.scale = (1.25, 0.75, 1.0)
    vest = skin([(0, -0.01, 1.08, 0.15), (0, -0.01, 1.28, 0.16), (0, -0.01, 1.5, 0.195), (0, 0.0, 1.68, 0.18)], material=coat, subdiv=2)
    vest.scale = (1.25, 0.78, 1.0)
    displace(vest, 0.006, 0.05)
    tails = cloth([(0.19, 0.78), (0.18, 0.95), (0.17, 1.08)], coat, 7, 0.02, 24, 2, 0.1)
    tails.scale = (1.15, 0.85, 1.0)
    strap = skin([(0.2, 0.13, 1.7, 0.02), (0.0, 0.17, 1.4, 0.02), (-0.18, 0.12, 1.12, 0.02)], material="L_leather_1e140e", subdiv=1)
    shells = [cyl(0.012, 0.05, (0.15 - i * 0.06, 0.18, 1.62 - i * 0.1), "L_plastic_b8261e", 8, rot=(0, 0.6, 0)) for i in range(5)]
    belt = lathe([(0.17, 1.0), (0.18, 1.01), (0.18, 1.05), (0.17, 1.06)], "L_leather_1e140e", 20, cap_bottom=False)
    body = part([torso, vest, tails, strap, belt] + shells, "body", (0, 0, 1.1))
    head = meta("h", [("ell", (0, 0.03, 2.0), 0.13, (0.9, 1.05, 1.25)), ("ell", (0, 0.08, 1.9), 0.09, (1.0, 1.0, 0.8))], S, 0.012)
    displace(head, 0.004, 0.03)
    mouth = box((0.09, 0.02, 0.012), (0, 0.16, 1.88), "C_100404", 0.004)
    lamp_band = lathe([(0.125, 2.02), (0.135, 2.03), (0.135, 2.06), (0.125, 2.07)], "L_leather_1e140e", 20, cap_bottom=False)
    lamp_band.location = (0, 0.03, 0)
    lamp = cyl(0.05, 0.06, (0, 0.17, 2.05), "L_metal_5a5e66", 14, rot=(math.pi / 2, 0, 0), bevel=0.006)
    lens = cyl(0.04, 0.01, (0, 0.205, 2.05), "E_ff6a20", 14, rot=(math.pi / 2, 0, 0))
    scars = [box((0.06, 0.01, 0.008), (s * 0.05, 0.14, 1.98), "L_skin_3a1210", 0.0, rot=(0, 0.4 * s, 0)) for s in (1, -1)]
    snap_objs(scars + [mouth], head, 0.4)
    head = part([head, lamp_band, lamp, lens, mouth] + scars, "head", (0, 0, 1.85))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.26 * s
        a = [skin([(x, 0, 1.72, 0.07), (x + 0.05 * s, 0.05, 1.42, 0.055), (x + 0.04 * s, 0.12, 1.15, 0.045)], material=S, subdiv=1),
             sphere(0.085, (x - 0.01 * s, 0, 1.7), coat, 10, 5, (1.1, 1.0, 0.9))]
        a += claw_hand(x + 0.04 * s, 0.15, 1.1, S, s, 4, 0.08, 0.011)
        arms.append(part(a, nm, (x, 0, 1.72)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.12 * s
        legs.append(part([skin([(x, 0, 1.1, 0.07), (x, 0.03, 0.55, 0.055), (x, 0.0, 0.1, 0.05)], material="L_fabric_2e2a24", subdiv=1),
                          meta("boot", [("ell", (x, 0.06, 0.05), 0.065, (0.9, 1.7, 0.7))], "L_leather_1e140e", 0.012)], nm, (x, 0, 1.1)))
    gun = [cyl(0.026, 0.85, (0.32, 0.55, 1.15), "L_metal_2a2d33", 10, rot=(math.pi / 2, 0, 0)), cyl(0.026, 0.85, (0.37, 0.55, 1.15), "L_metal_2a2d33", 10, rot=(math.pi / 2, 0, 0)),
           box((0.1, 0.12, 0.08), (0.345, 0.12, 1.14), "L_metal_5a5e66", 0.01), box((0.08, 0.36, 0.1), (0.345, -0.12, 1.1), "L_wood_4a2a14", 0.02, rot=(0.2, 0, 0)),
           box((0.06, 0.25, 0.05), (0.345, 0.35, 1.1), "L_wood_4a2a14", 0.015)]
    g = join(gun, "gun")
    parent(g, arms[0])
    save("hunter", [body, head] + arms + legs + [g], tex=512, tris=6000)


def brute():
    """Hulking brute: huge shoulders and fists, tiny head in a gas mask with red lenses, plates and chains."""
    reset()
    S = "L_leather_56606a"
    torso = meta("t", [("ell", (0, 0.05, 1.75), 0.55, (1.35, 0.85, 0.75)), ("ell", (0, 0.05, 1.4), 0.42, (1.1, 0.85, 0.9)),
                       ("ell", (0, 0.08, 1.1), 0.36, (1.05, 0.9, 0.6))], S, 0.035)
    displace(torso, 0.02, 0.1, depth=3)
    plates = [box((0.42, 0.06, 0.32), (0, 0.42, 1.55), "L_metal_5a5e66", 0.03, rot=(-0.15, 0, 0)),
              box((0.3, 0.06, 0.24), (0.42, 0.32, 1.8), "L_rust_7a4a2a", 0.03, rot=(-0.2, 0, -0.4)),
              box((0.3, 0.06, 0.24), (-0.42, 0.32, 1.8), "L_metal_5a5e66", 0.03, rot=(-0.2, 0, 0.4))]
    snap_objs(plates, torso, 0.35)
    rivets = [sphere(0.02, (x, 0.47, z), "L_metal_9a9ea8", 6, 3) for x in (-0.16, 0.16) for z in (1.45, 1.65)]
    snap_objs(rivets, torso, -0.2)
    chain = [lathe([(0.05, -0.012), (0.062, 0.0), (0.05, 0.012)], "L_metal_6a6e78", 10, cap_bottom=False, pos=(-0.5 + i * 0.1, 0.45 - abs(i - 5) * 0.02, 1.95 - i * 0.07)) for i in range(11)]
    for i, c in enumerate(chain):
        c.rotation_euler = (math.pi / 2 if i % 2 else 0, 0.6, 0)
    snap_objs(chain, torso, 0.1)
    belt = lathe([(0.4, 0.95), (0.42, 0.96), (0.42, 1.05), (0.4, 1.06)], "L_leather_2a2018", 28, cap_bottom=False)
    pants = meta("p", [("ell", (0, 0.05, 0.98), 0.38, (1.1, 0.9, 0.45))], "L_fabric_2a2620", 0.03)
    body = part([torso, belt, pants] + plates + rivets + chain, "body", (0, 0, 1.0))
    head = meta("h", [("ell", (0, 0.32, 2.25), 0.2, (1.0, 1.0, 1.0))], S, 0.014)
    mask = meta("m", [("ell", (0, 0.44, 2.22), 0.16, (1.1, 0.8, 1.0)), ("cap", (0, 0.52, 2.12), 0.05, (0.0, 0.0, 0.03), (math.pi / 2, 0, 0))], "L_rubber_1e2026", 0.012)
    filt = [cyl(0.055, 0.08, (s * 0.11, 0.6, 2.08), "L_metal_5a5e66", 12, rot=(math.pi / 2 - 0.4, 0, -0.5 * s), bevel=0.008) for s in (1, -1)]
    lenses = []
    for x in (-0.07, 0.07):
        lenses.append(cyl(0.04, 0.025, (x, 0.57, 2.28), "L_metal_2a2d33", 14, rot=(math.pi / 2, 0, 0)))
        lenses.append(cyl(0.032, 0.01, (x, 0.585, 2.28), "E_ff2a14", 14, rot=(math.pi / 2, 0, 0)))
    straps = lathe([(0.16, 2.2), (0.17, 2.21), (0.17, 2.24), (0.16, 2.25)], "L_rubber_1e2026", 18, cap_bottom=False)
    straps.location = (0, 0.32, 0)
    head = part([head, mask, straps] + filt + lenses, "head", (0, 0.3, 2.15))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.75 * s
        arm = skin([(x, 0.05, 1.9, 0.2), (x + 0.1 * s, 0.12, 1.4, 0.16), (x + 0.12 * s, 0.22, 0.85, 0.2)], material=S, subdiv=1)
        pad = meta("pad", [("cube", (x, 0.05, 2.0), 0.06, (0.18, 0.16, 0.06))], "L_rust_6a4a32", 0.02)
        fist = meta("fist", [("ell", (x + 0.12 * s, 0.25, 0.6), 0.2, (1.0, 1.05, 1.0))], S, 0.02)
        knuckles = [box((0.08, 0.08, 0.06), (x + 0.12 * s + dx, 0.42, 0.62), "L_metal_6a6e78", 0.015) for dx in (-0.1, 0.0, 0.1)]
        wrap = cyl(0.19, 0.14, (x + 0.12 * s, 0.22, 0.82), "L_fabric_8a7a5a", 14)
        arms.append(part([arm, pad, fist, wrap] + knuckles, nm, (x, 0.05, 1.9)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.3 * s
        legs.append(part([skin([(x, 0, 1.0, 0.22), (x, 0.05, 0.5, 0.19), (x, 0.0, 0.14, 0.17)], material="L_fabric_2a2620", subdiv=1),
                          meta("boot", [("ell", (x, 0.08, 0.09), 0.18, (1.0, 1.4, 0.6))], "L_rubber_1e2026", 0.02)], nm, (x, 0, 1.0)))
    save("brute", [body, head] + arms + legs, tex=512, tris=8000, ao=0.4)


def watcher():
    """Creepy store mannequin: beige plastic, ball joints, featureless cracked face, painted smile."""
    reset()
    P = "L_plastic_d8c8b0"
    J = "L_plastic_a89880"
    torso = meta("t", [("ell", (0, 0, 1.5), 0.17, (1.25, 0.75, 1.35)), ("ell", (0, 0, 1.15), 0.13, (1.15, 0.75, 0.8)), ("ell", (0, 0.0, 1.72), 0.12, (1.9, 0.75, 0.45))], P, 0.015)
    seam = lathe([(0.15, 1.28), (0.155, 1.29), (0.15, 1.3)], J, 24, cap_bottom=False)
    seam.scale = (1.15, 0.75, 1.0)
    crack = [box((0.008, 0.01, 0.12), (0.12, 0.11, 1.62), "C_2a2018", 0.0, rot=(0, 0.6, 0)), box((0.008, 0.01, 0.08), (0.15, 0.1, 1.54), "C_2a2018", 0.0, rot=(0, -0.4, 0))]
    snap_objs(crack, torso, 0.5)
    chip = sphere(0.04, (0.18, 0.05, 1.72), "C_5a5048", 6, 3, (1, 1, 0.5))
    snap_objs([chip], torso, 0.6)
    neck = cyl(0.045, 0.12, (0, 0, 1.8), P, 12)
    hips = sphere(0.14, (0, 0, 1.02), P, 16, 8, (1.25, 0.8, 0.6))
    body = part([torso, seam, neck, hips, chip] + crack, "body", (0, 0, 1.0))
    head = meta("h", [("ell", (0, 0.01, 1.98), 0.12, (0.88, 1.0, 1.28))], P, 0.012)
    smile = box((0.1, 0.01, 0.008), (0, 0.12, 1.92), "C_6a1418", 0.004)
    smile2 = [box((0.025, 0.01, 0.008), (s * 0.055, 0.115, 1.93), "C_6a1418", 0.002, rot=(0, -0.5 * s, 0)) for s in (1, -1)]
    hcrack = [box((0.006, 0.01, 0.1), (-0.03, 0.12, 2.04), "C_1a1410", 0.0, rot=(0, 0.3, 0)), box((0.006, 0.01, 0.06), (-0.06, 0.11, 1.98), "C_1a1410", 0.0, rot=(0, -0.6, 0))]
    snap_objs([smile] + smile2 + hcrack, head, 0.5)
    head = part([head, smile] + smile2 + hcrack, "head", (0, 0, 1.86))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.25 * s
        up = cyl(0.045, 0.32, (x, 0, 1.56), P, 12, r2=0.04, bevel=0.01)
        sh = sphere(0.06, (x, 0, 1.72), J, 12, 6)
        el = sphere(0.045, (x, 0, 1.38), J, 10, 5)
        lo = cyl(0.04, 0.3, (x, 0.02, 1.22), P, 12, r2=0.032, bevel=0.01)
        hand = meta("hand", [("ell", (x, 0.03, 1.02), 0.045, (0.6, 0.9, 1.3)), ("ell", (x - 0.015 * s, 0.06, 1.05), 0.016, (0.8, 0.8, 1.6))], P, 0.01)
        arms.append(part([up, sh, el, lo, hand], nm, (x, 0, 1.72)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.11 * s
        up = cyl(0.065, 0.45, (x, 0, 0.76), P, 12, r2=0.05, bevel=0.01)
        kn = sphere(0.055, (x, 0, 0.5), J, 10, 5)
        lo = cyl(0.05, 0.42, (x, 0, 0.27), P, 12, r2=0.04, bevel=0.01)
        foot = meta("ft", [("ell", (x, 0.05, 0.03), 0.05, (0.8, 2.0, 0.55))], P, 0.012)
        legs.append(part([up, kn, lo, foot], nm, (x, 0, 0.98)))
    save("watcher", [body, head] + arms + legs, tex=512, tris=5000)


run([bighead, projector, hunter, brute, watcher])
