"""Tier-2 monsters, art v3. blender -b --python monsters_b.py -- [names]"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *


def humanoid_arm(x, top, hand_z, r0, r1, material, side, fwd=0.05, claws=3, clen=0.08, cr=0.012, claw_mat="L_bone_d8cfb0"):
    a = skin([(x, 0, top, r0), (x + 0.05 * side, fwd, (top + hand_z) / 2, (r0 + r1) / 2), (x + 0.07 * side, fwd * 2, hand_z, r1)], material=material, subdiv=1)
    return [a] + claw_hand(x + 0.07 * side, fwd * 2 + 0.02, hand_z - 0.03, material, side, claws, clen, cr, claw_mat)


def puff():
    """Fluffy grey dust-bunny with big glossy eyes; a ring of needle teeth pops out when angry."""
    reset()
    W = "L_fur_9a9690"
    fluff = meta("fluff", [("ball", (0, 0, 0.26), 0.21)] + [("ball", (0.21 * math.cos(a) * math.cos(b), 0.21 * math.sin(a) * math.cos(b), 0.26 + 0.19 * math.sin(b)), 0.085)
                                                              for a in [i * 0.9 for i in range(7)] for b in (-0.5, 0.3, 1.0)], W, 0.02)
    displace(fluff, 0.014, 0.03, depth=3)
    tuft = spikes((0, 0, 0.42), 10, 0.08, 0.06, W, 0.025, seed=2, up_only=True)
    eyes = []
    face = meta("face", [("ell", (0, 0.2, 0.29), 0.13, (1.3, 0.55, 0.9))], "L_fur_c8c4bc", 0.014)
    for x in (-0.075, 0.075):
        eyes.append(sphere(0.06, (x, 0.25, 0.31), "C_0c0c10", 14, 7, (1, 0.55, 1.2)))
        eyes.append(sphere(0.02, (x + 0.02, 0.28, 0.345), "E_ffffff", 6, 3))
        eyes.append(sphere(0.01, (x - 0.018, 0.285, 0.285), "E_c8d8ff", 5, 3))
    nose = sphere(0.016, (0, 0.285, 0.255), "L_skin_c08080", 8, 4)
    eyes.append(face)
    feet = [meta("ft", [("ell", (x, 0.05, 0.03), 0.042, (1.0, 1.4, 0.5))], "L_skin_8a7a72", 0.012) for x in (-0.08, 0.08)]
    body = part([fluff, nose] + tuft + eyes + feet, "body", (0, 0, 0.25))
    jaw = meta("jawm", [("ell", (0, 0.12, 0.2), 0.19, (1.05, 1.0, 0.55)), {"t": "ell", "co": (0, 0.15, 0.23), "r": 0.16, "s": (1.0, 0.95, 0.4), "neg": True}], "L_skin_7a1418", 0.015)
    jt = teeth_row(0, 0.27, 0.25, 0.26, 11, 0.055, r=0.01, curve=0.04) + teeth_row(0, 0.26, 0.15, 0.22, 10, 0.045, r=0.009, down=False, curve=0.04)
    gl = sphere(0.08, (0, 0.18, 0.2), "E_ff3a3a", 10, 5, (1.4, 0.5, 0.3))
    jaw = part([jaw, gl] + jt, "jaw", (0, 0, 0.26))
    save("puff", [body, jaw], tex=256, tris=3000, split=False)


def howler():
    """Gaunt floating figure: long neck, round siren mouth, pinprick eyes, trailing rags."""
    reset()
    S = "L_skin_8a8680"
    head = meta("head", [("ell", (0, 0.0, 1.74), 0.13, (0.95, 0.95, 1.25)), ("ell", (0, 0.06, 1.6), 0.13, (1.05, 0.9, 1.05)),
                         {"t": "ell", "co": (0, 0.16, 1.56), "r": 0.1, "s": (1.0, 0.9, 1.15), "neg": True, "stiff": 3.0}], S, 0.014)
    displace(head, 0.004, 0.03)
    lip = lathe([(0.075, -0.02), (0.1, 0.0), (0.105, 0.02), (0.085, 0.03)], "L_skin_6a5a56", 20, cap_bottom=False)
    lip.rotation_euler = (math.pi / 2, 0, 0)
    lip.location = (0, 0.17, 1.56)
    eyes = []
    for x in (-0.05, 0.05):
        eyes.append(sphere(0.03, (x, 0.1, 1.78), "C_050505", 8, 4, (1, 0.6, 1.1)))
        eyes.append(sphere(0.011, (x, 0.125, 1.78), "E_f4f6ff", 6, 3))
    snap_objs(eyes, head, 0.4)
    neck = skin([(0, -0.02, 1.42, 0.05), (0, 0.0, 1.55, 0.045)], material=S, subdiv=1)
    head = part([head, lip, neck] + eyes, "head", (0, 0, 1.45))
    mouth = part([sphere(0.085, (0, 0.13, 1.56), "C_100404", 12, 6, (1.0, 0.5, 1.05)),
                  sphere(0.035, (0, 0.11, 1.56), "E_d0e0ff", 8, 4, (1, 0.5, 1))], "mouth", (0, 0.14, 1.56))
    ribs = [lathe([(0.15, 1.2 + i * 0.05), (0.16, 1.21 + i * 0.05), (0.15, 1.22 + i * 0.05)], "L_bone_b8ac90", 18, cap_bottom=False) for i in range(3)]
    torso = meta("t", [("ell", (0, 0, 1.3), 0.15, (1.2, 0.8, 1.0)), ("ell", (0, 0, 1.42), 0.12, (1.6, 0.8, 0.5))], S, 0.02)
    rags = cloth([(0.3, 0.1), (0.27, 0.4), (0.22, 0.8), (0.18, 1.1), (0.15, 1.25)], "L_fabric_2e2a28", 13, 0.04, 48, 5, 0.18)
    body = part([torso, rags] + ribs, "body", (0, 0, 0.8))
    arms = []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.2 * s
        arms.append(part(humanoid_arm(x, 1.42, 0.62, 0.035, 0.022, S, s, 0.06, 4, 0.12, 0.011), nm, (x, 0, 1.42)))
    save("howler", [body, head, mouth] + arms, tex=512, tris=6000)


def levitator():
    """Hovering figure in a torn lab coat, cyan core in the chest, gas mask with cyan lenses."""
    reset()
    COAT = "L_fabric_c8c4b8"
    coat = cloth([(0.24, 0.02), (0.22, 0.25), (0.19, 0.5), (0.18, 0.68), (0.16, 0.78), (0.1, 0.82)], COAT, 9, 0.025, 40, 2, 0.15)
    dirt = cloth([(0.245, 0.0), (0.225, 0.12)], "L_fabric_5a5040", 9, 0.025, 40, 2, 0.1)
    core_ring = cyl(0.07, 0.04, (0, 0.17, 0.62), "L_metal_3a3d44", 16, rot=(math.pi / 2, 0, 0), bevel=0.008)
    core = sphere(0.05, (0, 0.19, 0.62), "E_5ae8ff", 12, 6)
    cracks = [box((0.006, 0.01, 0.12), (math.cos(a) * 0.09, 0.17, 0.62 + math.sin(a) * 0.09), "E_5ae8ff", 0.0, rot=(0, -a + math.pi / 2, 0)) for a in (0.4, 2.0, 3.6, 5.0)]
    debris = []
    rnd = random.Random(4)
    for i in range(7):
        a = i * math.tau / 7
        r = 0.42 + rnd.uniform(-0.05, 0.05)
        debris.append(box((0.05, 0.04, 0.035), (math.cos(a) * r, math.sin(a) * r, 0.25 + rnd.uniform(-0.08, 0.15)), rnd.choice(["L_stone_6a6660", "L_metal_5a5e66", "L_rust_8a4a22"]), 0.01,
                          rot=(rnd.uniform(0, 3), rnd.uniform(0, 3), 0)))
    pocket = box((0.08, 0.02, 0.07), (0.1, 0.18, 0.5), COAT, 0.005)
    pens = [cyl(0.006, 0.07, (0.08 + i * 0.015, 0.19, 0.54), "L_plastic_2a4a8a", 6) for i in range(2)]
    body = part([coat, dirt, core_ring, core, pocket] + cracks + debris + pens, "body", (0, 0, 0.4))
    hood = meta("hood", [("ell", (0, -0.02, 1.0), 0.14, (1.0, 1.05, 1.1))], "L_fabric_3a3a3a", 0.015)
    mask = meta("mask", [("ell", (0, 0.07, 0.98), 0.11, (1.0, 0.9, 1.0)), ("cap", (0, 0.17, 0.92), 0.04, (0.02, 1, 1), (math.pi / 2, 0, 0))], "L_rubber_2a2c33", 0.012)
    filt = cyl(0.045, 0.05, (0, 0.2, 0.9), "L_metal_5a5e66", 12, rot=(math.pi / 2 - 0.3, 0, 0), bevel=0.006)
    lenses = []
    for x in (-0.045, 0.045):
        lenses.append(cyl(0.033, 0.02, (x, 0.155, 1.0), "L_metal_2a2d33", 14, rot=(math.pi / 2, 0, 0)))
        lenses.append(cyl(0.026, 0.008, (x, 0.165, 1.0), "E_5ae8ff", 14, rot=(math.pi / 2, 0, 0)))
    head = part([hood, mask, filt] + lenses, "head", (0, 0, 0.85))
    arms = []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.2 * s
        sl = skin([(x, 0, 0.78, 0.055), (x + 0.12 * s, 0.06, 0.92, 0.045), (x + 0.2 * s, 0.1, 1.06, 0.04)], material=COAT, subdiv=1)
        hand = claw_hand(x + 0.21 * s, 0.12, 1.1, "L_skin_7a8a8a", s, 4, 0.06, 0.01)
        glow = sphere(0.04, (x + 0.22 * s, 0.14, 1.16), "E_5ae8ff", 8, 4)
        arms.append(part([sl, glow] + hand, nm, (x, 0, 0.78)))
    save("levitator", [body, head] + arms, tex=512, tris=5000)


def butcher():
    """Big-bellied butcher: rubber apron, sack mask with stitched holes, cleaver in the right hand."""
    reset()
    SK = "L_skin_a07a6a"
    torso = meta("t", [("ell", (0, 0.04, 1.15), 0.32, (1.1, 1.0, 1.0)), ("ell", (0, 0.1, 1.0), 0.3, (1.05, 1.0, 0.85)),
                       ("ell", (0, -0.02, 1.38), 0.27, (1.4, 0.9, 0.6))], SK, 0.03)
    displace(torso, 0.01, 0.06)
    shirt = meta("sh", [("ell", (0, 0.04, 1.15), 0.335, (1.1, 1.0, 1.0)), ("ell", (0, 0.1, 1.0), 0.315, (1.05, 1.0, 0.85)),
                        ("ell", (0, -0.02, 1.38), 0.285, (1.4, 0.9, 0.6))], "L_fabric_5a5a50", 0.03)
    apron = cloth([(0.36, 0.72), (0.37, 0.9), (0.36, 1.1), (0.33, 1.28)], "L_rubber_5a6a5a", 6, 0.02, 32, 4, 0.03)
    apron.scale = (1.0, 0.9, 1.0)
    stains = [sphere(r, (x, 0.34, z), "L_paint_4a1410", 8, 4, (1, 0.25, 1.4)) for x, z, r in ((0.1, 1.0, 0.07), (-0.15, 0.85, 0.05), (0.05, 0.8, 0.04))]
    snap_objs(stains, apron, 0.5)
    belt = lathe([(0.37, 0.8), (0.385, 0.81), (0.385, 0.85), (0.37, 0.86)], "L_leather_3a2418", 28, cap_bottom=False)
    pants = meta("p", [("ell", (0, 0.0, 0.82), 0.27, (1.15, 0.9, 0.5))], "L_fabric_2a2a3a", 0.03)
    body = part([torso, shirt, apron, belt, pants] + stains, "body", (0, 0, 0.9))
    sack = meta("sack", [("ell", (0, 0.18, 1.62), 0.17, (1.0, 1.0, 1.1)), ("ell", (0, 0.16, 1.5), 0.15, (1.1, 1.0, 0.6))], "L_fabric_9a8060", 0.014)
    displace(sack, 0.008, 0.04)
    rope = lathe([(0.13, 1.47), (0.145, 1.48), (0.145, 1.51), (0.13, 1.52)], "L_fabric_6a5a3a", 18, cap_bottom=False)
    rope.location = (0, 0.17, 0)
    holes = []
    for x in (-0.06, 0.06):
        holes += glow_eye((x, 0.33, 1.66), 0.024, "ff4020", "C_0a0505")
    stitches = [box((0.006, 0.01, 0.05), (x, 0.34, 1.56), "L_fabric_2a1a10", 0.0, rot=(0, 0.5, 0)) for x in (-0.06, -0.03, 0.0, 0.03, 0.06)]
    snap_objs(holes + stitches, sack, 0.4)
    head = part([sack, rope] + holes + stitches, "head", (0, 0.18, 1.5))
    arms = []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.42 * s
        a = [skin([(x, 0, 1.4, 0.12), (x + 0.04 * s, 0.05, 1.12, 0.1), (x + 0.04 * s, 0.12, 0.85, 0.09)], material=SK, subdiv=1),
             meta("glove", [("ell", (x + 0.04 * s, 0.14, 0.76), 0.09, (1.0, 1.0, 1.15))], "L_rubber_c8b020", 0.015),
             cyl(0.1, 0.12, (x + 0.04 * s, 0.12, 0.88), "L_rubber_c8b020", 14)]
        if s == 1:
            a += [box((0.03, 0.04, 0.16), (x + 0.04 * s, 0.17, 0.74), "L_wood_3a2414", 0.008),
                  box((0.012, 0.36, 0.2), (x + 0.04 * s, 0.37, 0.72), "L_metal_9a9ea8", 0.004),
                  box((0.014, 0.02, 0.2), (x + 0.04 * s, 0.55, 0.72), "L_rust_5a2a14", 0.0)]
        arms.append(part(a, nm, (x, 0, 1.4)))
    legs = []
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.18 * s
        legs.append(part([skin([(x, 0, 0.85, 0.13), (x, 0.02, 0.45, 0.11), (x, 0.0, 0.18, 0.1)], material="L_fabric_2a2a3a", subdiv=1),
                          meta("boot", [("ell", (x, 0.04, 0.12), 0.12, (0.9, 1.0, 1.2)), ("ell", (x, 0.12, 0.06), 0.09, (1.0, 1.5, 0.6))], "L_rubber_2a3a2a", 0.02)], nm, (x, 0, 0.85)))
    save("butcher", [body, head] + arms + legs, tex=512, tris=6000)


def lurker():
    """The Ghost: emaciated, hunched, screaming open mouth, very long clawed arms."""
    reset()
    S = "L_leather_4a4038"
    torso = meta("t", [("ell", (0, 0.14, 1.55), 0.19, (1.2, 0.8, 1.0)), ("ell", (0, 0.02, 1.28), 0.14, (1.1, 0.75, 1.3)),
                       ("ell", (0, 0.02, 1.04), 0.15, (1.2, 0.8, 0.7)), ("ell", (0, 0.22, 1.7), 0.15, (1.7, 0.85, 0.5)),
                       ("cap", (0, -0.02, 1.3), 0.07, (0.0, 0.0, 0.3), (0, 0, 0))], S, 0.018)
    displace(torso, 0.006, 0.04)
    ribs = []
    for i in range(4):
        z = 1.4 + i * 0.065
        r = sphere(0.02, (0, 0.17, z), "L_bone_c8bca0", 6, 3, (7.0, 1.0, 0.7))
        ribs.append(r)
    snap_objs(ribs, torso, 0.55)
    spine = [sphere(0.032, (0, -0.12, 1.12 + i * 0.1), "L_bone_a89c80", 8, 4) for i in range(6)]
    snap_objs(spine, torso, 0.5)
    rag = cloth([(0.2, 0.86), (0.19, 1.0), (0.17, 1.1)], "L_fabric_2a2622", 9, 0.03, 32, 3, 0.12)
    body = part([torso, rag] + ribs + spine, "body", (0, 0, 1.0))
    head = meta("h", [("ell", (0, 0.26, 2.0), 0.14, (0.95, 1.05, 1.4)), ("ell", (0, 0.3, 1.84), 0.13, (1.0, 0.9, 1.0)),
                      {"t": "ell", "co": (0, 0.41, 1.82), "r": 0.085, "s": (0.8, 0.9, 1.6), "neg": True, "stiff": 3.0},
                      {"t": "ball", "co": (-0.055, 0.37, 2.0), "r": 0.042, "neg": True}, {"t": "ball", "co": (0.055, 0.37, 2.0), "r": 0.042, "neg": True}], S, 0.013)
    displace(head, 0.005, 0.03)
    neck = skin([(0, 0.2, 1.7, 0.06), (0, 0.27, 1.8, 0.055)], material=S, subdiv=1)
    mouth_in = sphere(0.08, (0, 0.37, 1.82), "C_0a0404", 10, 5, (0.8, 0.6, 1.5))
    teeth = teeth_row(0, 0.42, 1.91, 0.09, 5, 0.03, r=0.008, curve=0.01) + teeth_row(0, 0.42, 1.72, 0.08, 5, 0.03, r=0.008, down=False, curve=0.01)
    eyes = []
    for x in (-0.055, 0.055):
        eyes.append(sphere(0.04, (x, 0.34, 2.0), "C_050404", 8, 4))
        eyes.append(sphere(0.011, (x, 0.365, 2.0), "E_ff6a3a", 6, 3))
    hair = [skin([(x, 0.14, 2.14, 0.012), (x * 1.6, 0.06, 1.95, 0.009), (x * 1.8, 0.1, 1.68, 0.003)], material="L_fur_1a1a1a", subdiv=1) for x in (-0.09, -0.04, 0.02, 0.07)]
    head = part([head, neck, mouth_in] + teeth + eyes + hair, "head", (0, 0.2, 1.72))
    arms = []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.26 * s
        a = skin([(x, 0.17, 1.68, 0.06), (x + 0.08 * s, 0.26, 1.2, 0.045), (x + 0.09 * s, 0.34, 0.7, 0.04)], material=S, subdiv=1)
        elbow = sphere(0.05, (x + 0.08 * s, 0.26, 1.2), S, 8, 4)
        claws = claw_hand(x + 0.09 * s, 0.36, 0.64, S, s, 4, 0.2, 0.015)
        arms.append(part([a, elbow] + claws, nm, (x, 0.17, 1.68)))
    legs = []
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.11 * s
        legs.append(part([skin([(x, 0, 1.0, 0.09), (x, 0.08, 0.55, 0.06), (x, -0.04, 0.14, 0.045), (x, 0.14, 0.02, 0.04)], material=S, subdiv=1),
                          sphere(0.06, (x, 0.08, 0.55), S, 8, 4)], nm, (x, 0, 1.0)))
    save("lurker", [body, head] + arms + legs, tex=512, tris=6000)


def hidden():
    """A tall shadow of smoke and static: translucent dark mass, ragged edges, two faint eyes."""
    reset()
    D = "G_0a0c12"
    mass = meta("m", [("ell", (0, 0, 1.0), 0.28, (0.9, 0.7, 2.6)), ("ell", (0, 0.02, 1.72), 0.14, (1.0, 1.0, 1.2)),
                      ("ell", (0, 0, 1.4), 0.24, (1.6, 0.7, 0.6)), ("ell", (0.32, 0.05, 1.0), 0.06, (0.8, 0.8, 4.0)), ("ell", (-0.32, 0.05, 1.0), 0.06, (0.8, 0.8, 4.0))], D, 0.03)
    displace(mass, 0.06, 0.12, depth=3)
    wisps = [skin([(math.cos(a) * 0.2, math.sin(a) * 0.15, 0.4, 0.06), (math.cos(a) * 0.3, math.sin(a) * 0.22, 0.15, 0.03), (math.cos(a) * 0.32, math.sin(a) * 0.25, 0.0, 0.005)], material=D, subdiv=1) for a in [i * 1.05 for i in range(6)]]
    eyes = [sphere(0.018, (x, 0.13, 1.76), "E_e8f0ff", 8, 4, (1.2, 0.6, 0.7)) for x in (-0.045, 0.045)]
    core = meta("c", [("ell", (0, 0, 1.2), 0.14, (0.8, 0.6, 2.0))], "L_paint_08090c", 0.03)
    prop = [mass, core] + wisps + eyes
    o = join(prop, "body")
    set_origin(o, (0, 0, 0))
    save("hidden", [o], tex=256, tris=3000, split=False)


def mimic():
    """Red metal toolbox that is secretly a mouth: teeth on both rims, tongue, eyes on stalks."""
    reset()
    R = "L_paint_b8261e"
    body_parts = [box((0.66, 0.4, 0.32), (0, 0, 0.18), R, 0.02)]
    body_parts += [box((0.68, 0.42, 0.03), (0, 0, 0.02), "L_metal_2a2d33", 0.006)]
    for x in (-0.31, 0.31):
        body_parts.append(box((0.03, 0.42, 0.3), (x, 0, 0.18), "L_paint_8a1a14", 0.006))
    body_parts += [box((0.1, 0.03, 0.05), (x, 0.205, 0.3), "L_metal_9a9ea8", 0.006) for x in (-0.2, 0.2)]
    label = box((0.16, 0.012, 0.06), (0, 0.205, 0.17), "L_paint_e8e4da", 0.004)
    dents = [sphere(0.03, (0.12, 0.2, 0.1), "L_metal_6a6e78", 6, 3, (1, 0.2, 1))]
    inner = box((0.6, 0.34, 0.02), (0, 0, 0.335), "C_3a0a0a", 0.0)
    gum = box((0.62, 0.36, 0.03), (0, 0, 0.33), "L_skin_8a2030", 0.01)
    lower_teeth = teeth_row(0, 0.17, 0.34, 0.56, 10, 0.05, r=0.016, down=False) + teeth_row(0, -0.17, 0.34, 0.56, 10, 0.04, r=0.014, down=False)
    tongue = part([skin([(0, 0.0, 0.35, 0.06), (0, 0.15, 0.38, 0.05), (0, 0.32, 0.34, 0.035), (0, 0.42, 0.27, 0.02)], material="L_skin_b3162a", subdiv=1)], "tongue", (0, 0.0, 0.35))
    body = part(body_parts + [label, inner, gum] + dents + lower_teeth, "body", (0, 0, 0.0))
    lid_parts = [box((0.66, 0.4, 0.06), (0, 0.0, 0.37), R, 0.015), box((0.62, 0.36, 0.02), (0, 0.0, 0.34), "L_skin_8a2030", 0.008)]
    lid_parts.append(box((0.3, 0.05, 0.03), (0, 0.0, 0.43), "L_metal_2a2d33", 0.01))
    lid_parts += [box((0.03, 0.05, 0.06), (x, 0.0, 0.41), "L_metal_2a2d33", 0.006) for x in (-0.15, 0.15)]
    upper_teeth = teeth_row(0, 0.17, 0.335, 0.56, 10, 0.06, r=0.018) + teeth_row(0, -0.17, 0.335, 0.56, 10, 0.05, r=0.015)
    lid = part(lid_parts + upper_teeth, "lid", (0, -0.21, 0.37))
    eyes = []
    for x, nm in ((-0.14, "eye_l"), (0.14, "eye_r")):
        st = skin([(x, 0.08, 0.35, 0.015), (x * 1.1, 0.11, 0.42, 0.012)], material="L_skin_b3162a", subdiv=1)
        eyes.append(part([st] + eyeball((x * 1.1, 0.12, 0.45), 0.045, "C_e8c020", glow=True), nm, (x, 0.08, 0.35)))
    save("mimic", [body, lid, tongue] + eyes, tex=256, tris=3500, split=False)


run([puff, howler, levitator, butcher, lurker, hidden, mimic])
