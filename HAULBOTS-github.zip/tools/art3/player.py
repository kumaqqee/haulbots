"""Player robot v3: a hauler bot in a hooded raincoat with one big camera eye, a big canvas backpack
and chunky boots (template: yellow / green / blue / pink crew). Parts keep the game's names.
blender -b --python player.py -- [robot robot_ball head]"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *

P = "M_player"                 # raincoat, recoloured per player at runtime
FACE = "L_plastic_0d0f13"      # dark visor inside the hood
BOOT = "L_rubber_1c1d22"
GLOVE = "L_rubber_2a2c33"
PACK = "L_fabric_4a3c2c"       # worn canvas
STRAP = "L_leather_2a2018"
REFL = "L_plastic_c9ccd0"      # reflective hi-vis band
METAL = "L_metal_8a8f99"


def hood(cz=1.40, r=0.30):
    """Hood shell with the face opening, the dark visor inside and the rim."""
    shell = meta("hood", [
        ("ell", (0, -0.01, cz), r, (1.0, 1.0, 0.98)),
        ("ell", (0, -0.07, cz + 0.06), r * 0.85, (0.9, 1.0, 1.0)),          # fuller back
        ("ball", (0, -0.16, cz + 0.17), r * 0.42),                            # soft point at the back
        ("ell", (0, 0.02, cz - 0.2), r * 0.7, (1.05, 0.95, 0.55)),           # chin / collar
        {"t": "ell", "co": (0, r * 0.98, cz - 0.01), "r": r * 0.66, "s": (1.0, 0.75, 1.05), "neg": True, "stiff": 3.0},
    ], P, 0.02)
    smooth(shell, 2, 0.4)
    visor = sphere(r * 0.66, (0, r * 0.48, cz - 0.01), FACE, 24, 14, (1.0, 0.55, 1.0))
    # rim around the opening (a flattened ring facing +Y)
    rim = lathe([(r * 0.62, -0.02), (r * 0.7, -0.012), (r * 0.72, 0.0), (r * 0.7, 0.012), (r * 0.62, 0.02)], P, 32, cap_bottom=False)
    rim.rotation_euler = (math.pi / 2, 0, 0)
    rim.location = (0, r * 0.74, cz - 0.01)
    rim.scale = (1.0, 1.08, 1.0)
    # drawstrings with metal tips
    cords = []
    for s in (1, -1):
        x = 0.1 * s
        cords.append(skin([(x, r * 0.62, cz - 0.2, 0.008), (x * 1.1, r * 0.66, cz - 0.3, 0.007), (x * 1.05, r * 0.64, cz - 0.38, 0.007)], material="L_fabric_d8d2c0", subdiv=1))
        cords.append(cyl(0.011, 0.035, (x * 1.05, r * 0.64, cz - 0.4), METAL, 8))
    return [shell, visor, rim] + cords


def eye(cz=1.40, r=0.30, kind="normal"):
    """The big camera eye. In game a shader quad draws the lids; here it is a real disc for previews."""
    y = r * 0.82
    out = [cyl(0.118, 0.03, (0, y - 0.02, cz + 0.005), "L_metal_2a2d33", 24, rot=(math.pi / 2, 0, 0), bevel=0.006)]
    if kind == "broken":
        out.append(cyl(0.1, 0.012, (0, y, cz + 0.005), "E_ff5a3a", 24, rot=(math.pi / 2, 0, 0)))
        for a in (0.78, -0.78):
            out.append(box((0.16, 0.012, 0.024), (0, y + 0.01, cz + 0.005), "C_0a0a0a", rot=(0, a, 0)))
        return out
    out.append(cyl(0.1, 0.012, (0, y, cz + 0.005), "E_eef3ff", 24, rot=(math.pi / 2, 0, 0)))
    out.append(cyl(0.046, 0.01, (0.012, y + 0.008, cz + 0.0), "C_06070a", 20, rot=(math.pi / 2, 0, 0)))
    out.append(cyl(0.012, 0.006, (0.03, y + 0.013, cz + 0.022), "E_ffffff", 10, rot=(math.pi / 2, 0, 0)))
    return out


def robot():
    reset()
    # ---------------------------------------------------------- body: raincoat + backpack
    coat = cloth([(0.17, 1.13), (0.24, 1.09), (0.285, 1.0), (0.29, 0.88), (0.295, 0.76), (0.315, 0.66), (0.335, 0.6)],
                 P, folds=7, amp=0.016, segs=40, seed=3, hem_ragged=0.0)
    coat.scale = (1.0, 0.86, 1.0)
    shoulder = meta("sh", [("ell", (0.2, 0, 1.06), 0.1, (1.1, 0.9, 0.8)), ("ell", (-0.2, 0, 1.06), 0.1, (1.1, 0.9, 0.8)),
                           ("ell", (0, 0, 1.08), 0.15, (1.5, 0.9, 0.5))], P, 0.025)
    band = lathe([(0.31, 0.64), (0.322, 0.645), (0.326, 0.675), (0.315, 0.68)], REFL, 40, cap_bottom=False)
    band.scale = (1.0, 0.86, 1.0)
    placket = box((0.035, 0.02, 0.46), (0, 0.255, 0.86), P, 0.008)
    zip_pull = box((0.02, 0.012, 0.045), (0.0, 0.268, 1.0), METAL, 0.004)
    pockets = [box((0.13, 0.03, 0.11), (s * 0.15, 0.255, 0.75), P, 0.012) for s in (1, -1)]
    flaps = [box((0.14, 0.035, 0.03), (s * 0.15, 0.262, 0.81), P, 0.008) for s in (1, -1)]
    collar = lathe([(0.15, 1.08), (0.19, 1.1), (0.2, 1.15), (0.16, 1.16)], P, 28, cap_bottom=False)
    collar.scale = (1.0, 0.9, 1.0)
    # backpack: main bag, top flap, side bottles, bedroll, front straps
    bag = meta("bag", [("cube", (0, -0.37, 0.84), 0.07, (0.13, 0.06, 0.18)), ("ell", (0, -0.42, 0.84), 0.19, (1.0, 0.6, 1.15))], PACK, 0.022)
    flap = meta("flap", [("cube", (0, -0.36, 1.08), 0.03, (0.18, 0.11, 0.014))], "L_fabric_3a2e22", 0.02)
    pocket = box((0.24, 0.07, 0.17), (0, -0.585, 0.76), "L_fabric_3e3226", 0.02)
    buckles = [box((0.035, 0.015, 0.03), (s * 0.07, -0.625, 0.79), METAL, 0.004) for s in (1, -1)]
    roll = cyl(0.08, 0.5, (0, -0.38, 1.2), "L_fabric_5a6a3a", 14, rot=(0, math.pi / 2, 0), bevel=0.01)
    roll_ties = [cyl(0.084, 0.02, (s * 0.15, -0.38, 1.2), STRAP, 14, rot=(0, math.pi / 2, 0)) for s in (1, -1)]
    side = []
    straps = []
    for s in (1, -1):
        straps.append(skin([(s * 0.13, -0.24, 1.08, 0.022), (s * 0.15, -0.05, 1.13, 0.022), (s * 0.15, 0.17, 1.07, 0.02),
                            (s * 0.155, 0.245, 0.98, 0.018)], material=STRAP, subdiv=1))
        straps.append(box((0.04, 0.015, 0.03), (s * 0.155, 0.255, 0.975), METAL, 0.004))
    chest_strap = None
    badge = box((0.09, 0.012, 0.05), (-0.12, 0.262, 0.98), "L_paint_e8e4da", 0.004)
    lamp = [cyl(0.03, 0.03, (0.13, 0.27, 1.0), "L_metal_2a2d33", 12, rot=(math.pi / 2, 0, 0)),
            cyl(0.022, 0.006, (0.13, 0.287, 1.0), "E_fff0c0", 12, rot=(math.pi / 2, 0, 0))]
    body = part([coat, shoulder, band, placket, zip_pull, collar, bag, flap, pocket, roll, badge]
                + pockets + flaps + buckles + roll_ties + side + straps + lamp, "body", (0, 0, 0.55))
    # ---------------------------------------------------------- head: hood + eye
    head = part(hood() + eye(), "head", (0, 0, 1.12))
    # ---------------------------------------------------------- arms: sleeves + mittens
    arms = []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.34 * s
        sl = skin([(x, 0, 1.04, 0.088), (x + 0.04 * s, 0.0, 0.86, 0.08), (x + 0.055 * s, 0.01, 0.7, 0.076), (x + 0.06 * s, 0.015, 0.6, 0.08)], material=P, subdiv=1)
        cuff = cyl(0.074, 0.05, (x + 0.06 * s, 0.015, 0.575), "L_plastic_1a1c22", 16, bevel=0.01)
        mitt = meta("mitt", [("ell", (x + 0.06 * s, 0.02, 0.49), 0.07, (0.85, 1.0, 1.2)),
                             ("ell", (x + 0.03 * s, 0.075, 0.515), 0.028, (0.9, 1.0, 1.4), (0.3, 0, 0))], GLOVE, 0.012)
        arms.append(part([sl, cuff, mitt], nm, (x, 0, 1.04)))
    # ---------------------------------------------------------- legs: trousers + boots
    legs = []
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.12 * s
        tr = skin([(x, 0, 0.56, 0.095), (x, 0.0, 0.36, 0.085), (x, 0.0, 0.2, 0.08)], material=P, subdiv=1)
        boot = meta("boot", [("ell", (x, 0.025, 0.1), 0.085, (0.95, 1.0, 1.1)), ("ell", (x, 0.08, 0.05), 0.07, (0.95, 1.25, 0.7)),
                             ("cube", (x, 0.045, 0.03), 0.03, (0.045, 0.1, 0.012))], BOOT, 0.014)
        cuffb = cyl(0.083, 0.035, (x, 0.0, 0.19), "L_rubber_2e3036", 16, bevel=0.008)
        sole = box((0.15, 0.27, 0.035), (x, 0.045, 0.0175), "L_rubber_0e0e10", 0.01)
        toe = meta("toe", [("ell", (x, 0.13, 0.05), 0.05, (1.1, 0.8, 0.75))], "L_metal_5a5e66", 0.012)
        legs.append(part([tr, boot, cuffb, sole, toe], nm, (x, 0, 0.56)))
    save("robot", [body, head] + arms + legs, tex=512, tris=9000)


def robot_ball():
    """Tumble form: curled up into a ball, hood and eye still peeking out, boots and backpack showing."""
    reset()
    ball = meta("ball", [("ball", (0, 0, 0.3), 0.3), ("ell", (0, 0.02, 0.28), 0.27, (1.05, 1.0, 0.95))], P, 0.02)
    smooth(ball, 2, 0.4)
    band = lathe([(0.272, 0.15), (0.282, 0.17), (0.28, 0.19), (0.27, 0.2)], REFL, 32, cap_bottom=False)
    cz = 0.42
    visor = sphere(0.15, (0, 0.2, cz), FACE, 20, 12, (1.0, 0.55, 1.0))
    rim = lathe([(0.14, -0.015), (0.165, 0.0), (0.14, 0.015)], P, 28, cap_bottom=False)
    rim.rotation_euler = (math.pi / 2 - 0.5, 0, 0)
    rim.location = (0, 0.235, cz + 0.01)
    ey = [cyl(0.075, 0.02, (0, 0.27, cz + 0.02), "L_metal_2a2d33", 20, rot=(math.pi / 2 - 0.5, 0, 0)),
          cyl(0.062, 0.01, (0, 0.28, cz + 0.026), "E_eef3ff", 20, rot=(math.pi / 2 - 0.5, 0, 0)),
          cyl(0.03, 0.008, (0.008, 0.287, cz + 0.03), "C_06070a", 16, rot=(math.pi / 2 - 0.5, 0, 0))]
    bag = meta("bag", [("cube", (0, -0.3, 0.36), 0.06, (0.1, 0.04, 0.1))], PACK, 0.02)
    roll = cyl(0.06, 0.34, (0, -0.25, 0.56), "L_fabric_5a6a3a", 12, rot=(0, math.pi / 2, 0), bevel=0.01)
    boots = [meta("b", [("ell", (s * 0.13, 0.22, 0.09), 0.075, (0.9, 1.25, 0.8))], BOOT, 0.014) for s in (1, -1)]
    mitts = [meta("m", [("ell", (s * 0.27, 0.12, 0.3), 0.055, (0.8, 1.0, 1.1))], GLOVE, 0.012) for s in (1, -1)]
    prop_save("robot_ball", [ball, band, visor, rim, bag, roll] + ey + boots + mitts, tex=256, tris=3000)


def head_item():
    """The broken robot's head left on the floor: carry it to the extraction to rebuild the bot."""
    reset()
    parts = hood(cz=0.3, r=0.3) + eye(cz=0.3, r=0.3, kind="broken")
    sparks = [cyl(0.01, 0.06, (0.03 * i - 0.03, -0.02, 0.02), "E_ffb04a", 6, r2=0.0, rot=(math.pi, 0.4 * i, 0)) for i in range(3)]
    stub = cyl(0.07, 0.06, (0, 0, 0.04), "L_metal_3a3d44", 12, bevel=0.01)
    wires = [skin([(0.02, 0.0, 0.03, 0.008), (0.05, 0.03, -0.0, 0.007)], material="L_rubber_c03020", subdiv=1),
             skin([(-0.02, 0.01, 0.03, 0.008), (-0.06, 0.0, 0.0, 0.007)], material="L_rubber_e8b420", subdiv=1)]
    o = prop_save("head", parts + sparks + [stub] + wires, tex=256, tris=3000)


run([robot, robot_ball, head_item])
