"""Tileable PBR textures + decals for art v3 (numpy/PIL; everything wraps at the edges).
python3 textures.py [names]  ->  /home/claude/art3/tex/<name>.png, _n.png, _r.png ; decals/<name>.png"""
import os, sys, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = os.environ.get("TEX_OUT", "/home/claude/art3/tex")
N = int(os.environ.get("TEX_N", "512"))
FONT = "/home/claude/haulbots/assets/fonts/RussoOne.ttf"
FONT2 = "/home/claude/haulbots/assets/fonts/Rubik-Bold.ttf"
rng = np.random.default_rng(7)
Y, X = np.mgrid[0:N, 0:N] / N          # 0..1, wraps


# ---------------------------------------------------------------- noise (FFT = tileable)
def fbm(scale=8.0, power=2.0, seed=None):
    r = np.random.default_rng(seed) if seed is not None else rng
    f = np.fft.fftfreq(N)
    fx, fy = np.meshgrid(f, f)
    k = np.sqrt(fx ** 2 + fy ** 2) * N / scale
    k[0, 0] = 1.0
    amp = 1.0 / (k ** power)
    amp[0, 0] = 0.0
    ph = r.normal(size=(N, N)) + 1j * r.normal(size=(N, N))
    n = np.real(np.fft.ifft2(ph * amp))
    n -= n.min()
    return n / max(n.max(), 1e-9)


def band(lo, hi, freq):
    """Noise that only keeps detail between two frequencies (in cycles per tile)."""
    f = np.fft.fftfreq(N) * N
    fx, fy = np.meshgrid(f, f)
    k = np.sqrt(fx ** 2 + fy ** 2)
    m = ((k >= lo) & (k <= hi)).astype(float)
    ph = rng.normal(size=(N, N)) + 1j * rng.normal(size=(N, N))
    n = np.real(np.fft.ifft2(ph * m))
    n -= n.min()
    return n / max(n.max(), 1e-9)


def blur(a, r):
    k = np.fft.fftfreq(N)
    fx, fy = np.meshgrid(k, k)
    g = np.exp(-(fx ** 2 + fy ** 2) * (2 * math.pi * r) ** 2 / 2)
    return np.real(np.fft.ifft2(np.fft.fft2(a) * g))


def col(hexs):
    return np.array([int(hexs[i:i + 2], 16) / 255.0 for i in (0, 2, 4)])


def mix(a, b, t):
    t = np.clip(t, 0, 1)[..., None] if np.ndim(t) == 2 else t
    return a * (1 - t) + b * t


def grid_lines(nx, ny, width, offset_rows=False):
    """Distance-based groove mask for a grid of nx x ny cells (1 in grooves)."""
    gx = X * nx
    gy = Y * ny
    if offset_rows:
        gx = gx + 0.5 * (np.floor(gy) % 2)
    dx = np.abs(gx - np.round(gx)) / nx
    dy = np.abs(gy - np.round(gy)) / ny
    d = np.minimum(dx, dy)
    return np.clip(1 - d / width, 0, 1), np.floor(gx) % nx, np.floor(gy) % ny


def cell_rand(ix, iy, seed=0):
    h = (np.sin(ix * 12.9898 + iy * 78.233 + seed * 3.1) * 43758.5453) % 1.0
    return np.abs(h)


def normal_from_height(h, strength=4.0):
    dx = (np.roll(h, -1, 1) - np.roll(h, 1, 1)) * strength * N / 256
    dy = (np.roll(h, -1, 0) - np.roll(h, 1, 0)) * strength * N / 256
    nz = np.ones_like(h)
    n = np.stack([-dx, dy, nz], -1)          # OpenGL (Y+) convention
    n /= np.linalg.norm(n, axis=-1, keepdims=True)
    return (n * 0.5 + 0.5)


def save(name, albedo, height, rough, nstr=4.0):
    os.makedirs(OUT, exist_ok=True)
    a = np.clip(albedo, 0, 1)
    rough = np.broadcast_to(np.asarray(rough, dtype=float), (N, N))
    height = np.broadcast_to(np.asarray(height, dtype=float), (N, N))
    Image.fromarray((a * 255).astype(np.uint8)).save(os.path.join(OUT, name + ".png"))
    Image.fromarray((normal_from_height(height, nstr) * 255).astype(np.uint8)).save(os.path.join(OUT, name + "_n.png"))
    Image.fromarray((np.clip(rough, 0, 1) * 255).astype(np.uint8)).save(os.path.join(OUT, name + "_r.png"))
    print("TEX", name)


def grime(amount=0.35, scale=5.0):
    return fbm(scale, 1.8) * amount


# ---------------------------------------------------------------- walls
def wall_metal():
    g, ix, iy = grid_lines(2, 2, 0.006)
    base = col("4a5868")
    var = cell_rand(ix, iy)
    n1 = fbm(6, 1.9)
    brush = blur(rng.normal(size=(N, N)), 0.0) * 0
    streak = fbm(40, 1.2)
    streak = np.repeat(streak.mean(axis=0, keepdims=True), N, 0) * 0.5 + streak * 0.5
    alb = base[None, None] * (0.85 + 0.15 * var[..., None]) * (0.9 + 0.2 * n1[..., None])
    alb = alb * (0.92 + 0.12 * streak[..., None])
    # rivets near panel edges
    riv = np.zeros((N, N))
    for cx in np.linspace(0, 1, 9)[:-1] + 1 / 16:
        for cy in (0.02, 0.48, 0.52, 0.98):
            d = np.sqrt(((X - cx + 0.5) % 1 - 0.5) ** 2 + ((Y - cy + 0.5) % 1 - 0.5) ** 2)
            riv = np.maximum(riv, np.clip(1 - d / 0.008, 0, 1))
    for cy in np.linspace(0, 1, 9)[:-1] + 1 / 16:
        for cx in (0.02, 0.48, 0.52, 0.98):
            d = np.sqrt(((X - cx + 0.5) % 1 - 0.5) ** 2 + ((Y - cy + 0.5) % 1 - 0.5) ** 2)
            riv = np.maximum(riv, np.clip(1 - d / 0.008, 0, 1))
    dirt = fbm(4, 2.0)
    alb = mix(alb, col("23272c"), g * 0.8)
    alb = mix(alb, alb * 0.55 + col("3a2a1a") * 0.1, np.clip((dirt - 0.55) * 2.5, 0, 1) * 0.6)
    alb = mix(alb, col("8a96a4"), riv * 0.7)
    h = 0.6 - g * 0.5 + riv * 0.3 + n1 * 0.05
    r = 0.45 + 0.2 * dirt + 0.1 * g - riv * 0.15
    save("wall_metal", alb, h, r, 5.0)


def wall_block():
    g, ix, iy = grid_lines(2, 4, 0.008, offset_rows=True)
    base = col("5e7272")
    var = cell_rand(ix, iy, 2)
    pores = band(80, 200, 0)
    n1 = fbm(5, 2.0)
    alb = base[None, None] * (0.9 + 0.12 * var[..., None]) * (0.88 + 0.12 * pores[..., None]) * (0.92 + 0.12 * n1[..., None])
    alb = mix(alb, col("2e3634"), g * 0.85)
    stains = np.clip((fbm(3, 2.2) - 0.6) * 3, 0, 1)
    drips = np.clip(fbm(60, 1.0) * (1 - Y) * 1.2 - 0.6, 0, 1)
    alb = mix(alb, alb * 0.6, stains * 0.6 + drips * 0.4)
    h = 0.6 - g * 0.45 + pores * 0.08
    save("wall_block", alb, h, 0.8 + 0.1 * pores - 0.1 * g, 4.0)


def wall_tiles():
    g, ix, iy = grid_lines(8, 8, 0.003)
    base = col("d8dcd8")
    var = cell_rand(ix, iy, 5)
    alb = base[None, None] * (0.92 + 0.08 * var[..., None])
    dirt = fbm(4, 2.0)
    alb = mix(alb, col("6a6a60"), g * 0.9)
    alb = mix(alb, col("8a8a70"), np.clip((dirt - 0.5) * 2, 0, 1) * 0.45)
    cracked = (var > 0.93).astype(float) * np.clip(1 - np.abs(((X * 8 + Y * 8 * 0.7) % 1) - 0.5) * 30, 0, 1)
    alb = mix(alb, col("3a3a36"), cracked * 0.8)
    h = 0.7 - g * 0.5 - cracked * 0.2
    r = 0.2 + 0.5 * g + 0.2 * dirt
    save("wall_tiles", alb, h, r, 3.5)


def wall_plaster():
    base = col("8a8478")
    n1 = fbm(6, 2.0)
    n2 = band(60, 160, 0)
    alb = base[None, None] * (0.88 + 0.16 * n1[..., None]) * (0.95 + 0.05 * n2[..., None])
    scuff = np.clip((fbm(12, 1.6) - 0.62) * 4, 0, 1) * (Y > 0.7)
    alb = mix(alb, alb * 0.7, scuff * 0.6)
    crack = np.clip(1 - np.abs(fbm(3, 2.5) - 0.5) * 120, 0, 1) * (fbm(2, 2) > 0.6)
    alb = mix(alb, col("3a362e"), crack * 0.7)
    h = 0.5 + n2 * 0.08 + n1 * 0.05 - crack * 0.2
    save("wall_plaster", alb, h, 0.85 + 0.1 * n1, 3.0)


def wall_brick():
    g, ix, iy = grid_lines(4, 8, 0.01, offset_rows=True)
    var = cell_rand(ix, iy, 9)
    base = mix(col("5a2e22")[None, None] * np.ones((N, N, 1)), col("7a4030")[None, None] * np.ones((N, N, 1)), var)
    pores = band(60, 180, 0)
    n1 = fbm(5, 2.0)
    alb = base * (0.85 + 0.2 * pores[..., None]) * (0.85 + 0.2 * n1[..., None])
    alb = mix(alb, col("3a3632"), g)
    soot = np.clip((fbm(3, 2) - 0.45) * 2, 0, 1)
    alb = mix(alb, alb * 0.45, soot * 0.6)
    h = 0.65 - g * 0.55 + pores * 0.1
    save("wall_brick", alb, h, 0.85 + 0.1 * pores, 5.0)


def wall_corrugated():
    ridge = 0.5 + 0.5 * np.sin(X * 2 * math.pi * 12)
    base = col("6a7478")
    n1 = fbm(5, 2.0)
    streaks = fbm(30, 1.0)
    streaks = np.repeat(np.clip(streaks.mean(axis=0, keepdims=True) * 2 - 0.8, 0, 1), N, 0) * (0.4 + 0.6 * Y)
    rust_m = np.clip((fbm(4, 2.0) - 0.62) * 4, 0, 1)
    alb = base[None, None] * (0.75 + 0.3 * ridge[..., None]) * (0.9 + 0.15 * n1[..., None])
    alb = mix(alb, col("7a4a26"), np.clip(rust_m + streaks * 0.8, 0, 1) * 0.75)
    h = ridge * 0.8 + n1 * 0.05
    r = 0.45 + 0.4 * rust_m
    save("wall_corrugated", alb, h, r, 6.0)


# ---------------------------------------------------------------- floors
def floor_concrete():
    base = col("6a6a66")
    n1 = fbm(4, 2.0)
    n2 = band(70, 220, 0)
    alb = base[None, None] * (0.88 + 0.14 * n1[..., None]) * (0.9 + 0.12 * n2[..., None])
    oil = np.clip((fbm(3, 2.2) - 0.62) * 3.5, 0, 1)
    alb = mix(alb, col("2a2a28"), oil * 0.3)
    crack = np.clip(1 - np.abs(fbm(2.5, 2.4) - 0.5) * 140, 0, 1) * (fbm(2, 2) > 0.62)
    alb = mix(alb, col("2a2a28"), crack * 0.7)
    line = np.clip(1 - np.abs(X - 0.12) / 0.018, 0, 1)
    wear = np.clip(fbm(20, 1.5) * 1.6 - 0.3, 0, 1)
    alb = mix(alb, col("c8a030"), line * wear * 0.75)
    h = 0.5 + n2 * 0.06 + n1 * 0.08 - crack * 0.3
    r = 0.85 - oil * 0.35 + 0.05 * n2
    save("floor_concrete", alb, h, r, 3.0)


def floor_plate():
    g, ix, iy = grid_lines(1, 1, 0.004)
    u = (X * 16) % 1
    v = (Y * 16) % 1
    par = (np.floor(X * 16) + np.floor(Y * 16)) % 2
    d1 = np.abs(((u - 0.5) * 0.7 + (v - 0.5) * 0.7))
    d2 = np.abs(((u - 0.5) * 0.7 - (v - 0.5) * 0.7))
    lens = np.where(par == 0, np.clip(1 - d1 * 12, 0, 1) * np.clip(1 - np.abs(d2) * 2.4, 0, 1), np.clip(1 - d2 * 12, 0, 1) * np.clip(1 - np.abs(d1) * 2.4, 0, 1))
    n1 = fbm(5, 2.0)
    base = col("7a8088")
    alb = base[None, None] * (0.8 + 0.2 * n1[..., None]) * (0.85 + 0.25 * lens[..., None])
    dirt = np.clip((fbm(4, 2) - 0.5) * 2, 0, 1)
    alb = mix(alb, col("3a3630"), dirt * 0.45 * (1 - lens))
    h = 0.4 + lens * 0.5
    r = 0.35 + 0.35 * dirt - lens * 0.15
    save("floor_plate", alb, h, r, 6.0)


def floor_vinyl():
    g, ix, iy = grid_lines(4, 4, 0.002)
    chk = (ix + iy) % 2
    base = mix(col("6a7a88")[None, None] * np.ones((N, N, 1)), col("8a96a0")[None, None] * np.ones((N, N, 1)), chk)
    spk = band(120, 256, 0)
    n1 = fbm(4, 2.0)
    alb = base * (0.92 + 0.1 * spk[..., None]) * (0.92 + 0.1 * n1[..., None])
    alb = mix(alb, col("3a4048"), g * 0.8)
    scuff = np.clip((fbm(10, 1.4) - 0.6) * 3, 0, 1)
    alb = mix(alb, alb * 0.75, scuff * 0.5)
    h = 0.6 - g * 0.3
    r = 0.3 + 0.3 * scuff + 0.1 * spk
    save("floor_vinyl", alb, h, r, 2.0)


def floor_carpet():
    g, ix, iy = grid_lines(2, 2, 0.002)
    fib = band(150, 256, 0)
    var = cell_rand(ix, iy, 3)
    n1 = fbm(5, 2.0)
    base = col("3a4250")
    dir_ = np.where((ix + iy) % 2 == 0, 0.96, 1.04)
    alb = base[None, None] * (0.8 + 0.35 * fib[..., None]) * dir_[..., None] * (0.9 + 0.15 * n1[..., None])
    alb = mix(alb, col("1e222a"), g * 0.6)
    stain = np.clip((fbm(3, 2) - 0.64) * 4, 0, 1)
    alb = mix(alb, col("2a2620"), stain * 0.22)
    h = 0.5 + fib * 0.4 - g * 0.3
    save("floor_carpet", alb, h, 0.95 - 0.05 * fib, 2.5)


def floor_wood():
    rows = 6
    py = Y * rows
    iy = np.floor(py)
    off = cell_rand(iy, iy, 4)
    px = (X + off) * 2
    ix = np.floor(px)
    gy = np.abs(py - np.round(py)) / rows
    gx = np.abs(px - np.round(px)) / 2
    g = np.clip(1 - np.minimum(gy / 0.004, gx / 0.002), 0, 1)
    var = cell_rand(ix, iy, 8)
    grain = fbm(60, 1.0)
    grain = np.repeat(grain.mean(axis=1, keepdims=True), N, 1) * 0.7 + grain * 0.3
    rings = 0.5 + 0.5 * np.sin((Y * 60 + fbm(3, 2) * 8 + var * 10) * math.pi)
    base = mix(col("6a4628")[None, None] * np.ones((N, N, 1)), col("8a6038")[None, None] * np.ones((N, N, 1)), var)
    alb = base * (0.8 + 0.25 * grain[..., None]) * (0.9 + 0.1 * rings[..., None])
    alb = mix(alb, col("1e140c"), g * 0.9)
    wear = np.clip((fbm(4, 2) - 0.45) * 2, 0, 1)
    alb = mix(alb, alb * 0.7 + col("8a8070") * 0.1, wear * 0.4)
    h = 0.6 - g * 0.5 + grain * 0.06
    save("floor_wood", alb, h, 0.65 + 0.2 * wear, 3.0)


def floor_grate():
    u = (X * 10) % 1
    v = (Y * 10) % 1
    bar = np.maximum(np.clip(1 - np.abs(u - 0.5) * 2 / 0.25, 0, 1) > 0, np.clip(1 - np.abs(v - 0.5) * 2 / 0.25, 0, 1) > 0)
    bar_x = np.abs(u - 0.5) < 0.12
    bar_y = np.abs(v - 0.5) < 0.12
    m = (bar_x | bar_y).astype(float)
    m = blur(m, 0.6 / N)
    n1 = fbm(5, 2.0)
    alb = mix(col("0a0b0c")[None, None] * np.ones((N, N, 1)), col("6a7078")[None, None] * np.ones((N, N, 1)) * (0.8 + 0.3 * n1[..., None]), m)
    rust_m = np.clip((fbm(4, 2) - 0.6) * 3, 0, 1) * m
    alb = mix(alb, col("6a3a1e"), rust_m * 0.6)
    save("floor_grate", alb, m * 0.9, 0.5 + 0.3 * rust_m + (1 - m) * 0.4, 6.0)


# ---------------------------------------------------------------- ceilings
def ceiling_tiles():
    g, ix, iy = grid_lines(2, 2, 0.008)
    spk = band(120, 256, 0)
    holes = (band(160, 256, 0) > 0.72).astype(float)
    var = cell_rand(ix, iy, 6)
    base = col("b8b4a8")
    alb = base[None, None] * (0.88 + 0.1 * spk[..., None]) * (0.9 + 0.1 * var[..., None]) * (1 - 0.25 * holes[..., None])
    alb = mix(alb, col("4a4e54"), g)
    stain = np.clip((fbm(3, 2) - 0.6) * 3, 0, 1)
    ring = np.clip(1 - np.abs(fbm(3, 2) - 0.66) * 40, 0, 1)
    alb = mix(alb, col("8a7040"), stain * 0.45 + ring * 0.3)
    missing = (var > 0.9).astype(float) * (g < 0.1)
    alb = mix(alb, col("101012"), missing * 0.9)
    h = 0.6 - g * 0.5 - holes * 0.08 - missing * 0.5
    save("ceiling_tiles", alb, h, 0.9 - g * 0.3, 3.0)


def ceiling_concrete():
    n1 = fbm(4, 2.0)
    n2 = band(70, 220, 0)
    lines = np.clip(1 - np.abs(((Y * 3) % 1) - 0.5) * 2 / 0.02, 0, 1) * 0 + np.clip(1 - (np.abs((Y * 3 + 0.5) % 1 - 0.5) / 0.006), 0, 1)
    holes = np.zeros((N, N))
    for cx in (0.25, 0.75):
        for cy in (1 / 6, 0.5, 5 / 6):
            d = np.sqrt(((X - cx + 0.5) % 1 - 0.5) ** 2 + ((Y - cy + 0.5) % 1 - 0.5) ** 2)
            holes = np.maximum(holes, np.clip(1 - d / 0.012, 0, 1))
    base = col("6e6e6a")
    alb = base[None, None] * (0.82 + 0.22 * n1[..., None]) * (0.92 + 0.1 * n2[..., None])
    alb = mix(alb, col("3a3a38"), lines * 0.6 + holes * 0.8)
    h = 0.5 + n2 * 0.06 - lines * 0.2 - holes * 0.3
    save("ceiling_concrete", alb, h, 0.9, 3.0)


# ---------------------------------------------------------------- misc
def hazard():
    s = ((X + Y) * 4) % 1
    m = (s < 0.5).astype(float)
    m = blur(m, 0.8 / N)
    wear = np.clip(fbm(14, 1.6) * 1.7 - 0.55, 0, 1)
    chips = (band(60, 200, 0) > 0.7).astype(float) * 0.6
    alb = mix(col("1a1a1c")[None, None] * np.ones((N, N, 1)), col("e8b420")[None, None] * np.ones((N, N, 1)), m)
    alb = mix(alb, col("5a5a58"), np.clip(wear + chips * 0.5, 0, 1) * 0.7)
    n1 = fbm(5, 2)
    alb *= (0.9 + 0.15 * n1[..., None])
    save("hazard", alb, 0.5 - wear * 0.1 + n1 * 0.05, 0.6 + 0.3 * wear, 2.0)


def metal():
    base = col("6a7684")
    streak = fbm(80, 1.0)
    streak = np.repeat(streak.mean(axis=0, keepdims=True), N, 0) * 0.7 + streak * 0.3
    n1 = fbm(4, 2)
    alb = base[None, None] * (0.85 + 0.25 * streak[..., None]) * (0.9 + 0.15 * n1[..., None])
    scr = (band(100, 256, 0) > 0.78).astype(float)
    alb = mix(alb, col("a8b4c0"), scr * 0.4)
    save("metal", alb, streak * 0.1 + n1 * 0.05, 0.35 + 0.2 * n1 - 0.1 * scr, 2.0)


def wood_crate():
    rows = 4
    py = Y * rows
    iy = np.floor(py)
    gy = np.abs(py - np.round(py)) / rows
    g = np.clip(1 - gy / 0.006, 0, 1)
    var = cell_rand(iy, iy, 2)
    grain = fbm(60, 1.0)
    grain = np.repeat(grain.mean(axis=1, keepdims=True), N, 1) * 0.7 + grain * 0.3
    base = mix(col("8a6038")[None, None] * np.ones((N, N, 1)), col("a87a48")[None, None] * np.ones((N, N, 1)), var)
    alb = base * (0.78 + 0.3 * grain[..., None])
    nails = np.zeros((N, N))
    for cy in (0.125, 0.375, 0.625, 0.875):
        for cx in (0.06, 0.94):
            d = np.sqrt(((X - cx + 0.5) % 1 - 0.5) ** 2 + ((Y - cy + 0.5) % 1 - 0.5) ** 2)
            nails = np.maximum(nails, np.clip(1 - d / 0.01, 0, 1))
    alb = mix(alb, col("2a1a0e"), g * 0.9)
    alb = mix(alb, col("4a4a4e"), nails)
    save("wood_crate", alb, 0.6 - g * 0.5 + grain * 0.08 + nails * 0.2, 0.8, 3.0)


def plastic_dark():
    base = col("2a3a50")
    tex = band(90, 256, 0)
    n1 = fbm(4, 2)
    alb = base[None, None] * (0.85 + 0.25 * tex[..., None]) * (0.92 + 0.12 * n1[..., None])
    save("plastic_dark", alb, tex * 0.3, 0.55 + 0.15 * tex, 2.5)


def rust():
    n1 = fbm(4, 2.2)
    n2 = band(60, 220, 0)
    pit = (band(100, 256, 0) > 0.72).astype(float)
    alb = mix(col("5a3a26")[None, None] * np.ones((N, N, 1)), col("9a5a2a")[None, None] * np.ones((N, N, 1)), n1)
    alb *= (0.85 + 0.25 * n2[..., None])
    paint = np.clip((fbm(3, 2) - 0.62) * 4, 0, 1)
    alb = mix(alb, col("4a5a6a"), paint * 0.8)
    alb = mix(alb, col("2a1a10"), pit * 0.6)
    save("rust", alb, 0.5 + n2 * 0.15 - pit * 0.2 + paint * 0.05, 0.85 - paint * 0.35, 4.0)


def asphalt():
    n1 = fbm(4, 2)
    gravel = band(120, 256, 0)
    stones = (band(60, 140, 0) > 0.7).astype(float)
    alb = col("2e3032")[None, None] * (0.8 + 0.3 * gravel[..., None]) * (0.9 + 0.15 * n1[..., None])
    alb = mix(alb, col("5a5a58"), stones * 0.35)
    crack = np.clip(1 - np.abs(fbm(2.5, 2.4) - 0.5) * 120, 0, 1) * (fbm(2, 2) > 0.55)
    alb = mix(alb, col("101010"), crack * 0.8)
    patch = np.clip((fbm(2, 2.5) - 0.65) * 5, 0, 1)
    alb = mix(alb, alb * 0.75, patch * 0.6)
    save("asphalt", alb, 0.5 + gravel * 0.15 + stones * 0.1 - crack * 0.3, 0.9, 3.5)


def ground():
    n1 = fbm(4, 2)
    n2 = band(80, 220, 0)
    grass = np.clip((fbm(7, 1.9) - 0.45) * 3, 0, 1)
    blades = (band(150, 256, 0) > 0.6).astype(float) * grass
    dirt = col("4a3a2a")[None, None] * (0.8 + 0.3 * n2[..., None]) * (0.85 + 0.2 * n1[..., None])
    g = mix(col("4a4a2a")[None, None] * np.ones((N, N, 1)), col("6a6a3a")[None, None] * np.ones((N, N, 1)), n2)
    alb = mix(dirt, g, grass * 0.85)
    alb = mix(alb, col("8a8a4a"), blades * 0.4)
    pebbles = (band(80, 160, 0) > 0.76).astype(float) * (1 - grass)
    alb = mix(alb, col("7a7468"), pebbles * 0.6)
    save("ground", alb, 0.5 + n2 * 0.15 + blades * 0.1 + pebbles * 0.15, 0.92, 3.5)


# ---------------------------------------------------------------- decals
def _decal(name, img):
    os.makedirs(os.path.join(OUT, "decals"), exist_ok=True)
    img.save(os.path.join(OUT, "decals", name + ".png"))
    print("DECAL", name)


def decals():
    S = 256
    yy, xx = np.mgrid[0:S, 0:S] / S
    small = lambda s: np.array(Image.fromarray((s * 255).astype(np.uint8)).resize((S, S), Image.BILINEAR)) / 255.0
    # oil stain
    n = small(fbm(3, 2.0))
    r = np.sqrt((xx - 0.5) ** 2 + (yy - 0.5) ** 2)
    a = np.clip((0.42 - r + (n - 0.5) * 0.3) * 8, 0, 1) * 0.85
    rgb = np.zeros((S, S, 3)) + np.array([0.06, 0.055, 0.05])
    rgb += (np.clip(1 - np.abs(r - 0.3) * 30, 0, 1) * 0.08)[..., None] * np.array([0.6, 0.3, 1.0])
    _decal("oil_stain", Image.fromarray((np.dstack([rgb, a]) * 255).astype(np.uint8)))
    # crack
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    rr = np.random.default_rng(3)
    def branch(x, y, ang, ln, w):
        for _ in range(int(ln)):
            nx_ = x + math.cos(ang) * 6
            ny_ = y + math.sin(ang) * 6
            d.line([(x, y), (nx_, ny_)], fill=(20, 18, 16, 230), width=max(1, int(w)))
            x, y = nx_, ny_
            ang += rr.normal() * 0.35
            w *= 0.96
            if rr.random() < 0.08 and w > 1.2:
                branch(x, y, ang + rr.choice([-1, 1]) * 0.8, ln * 0.4, w * 0.7)
    branch(20, 128, 0.0, 38, 4)
    _decal("crack", img.filter(ImageFilter.GaussianBlur(0.6)))
    # robot boot prints
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i in range(4):
        x = 90 + (i % 2) * 70
        y = 220 - i * 60
        d.rounded_rectangle([x - 18, y - 28, x + 18, y + 28], 10, fill=(30, 26, 22, 150))
        for k in range(4):
            d.rectangle([x - 14, y - 22 + k * 12, x + 14, y - 18 + k * 12], fill=(0, 0, 0, 0))
    _decal("footprints", img.filter(ImageFilter.GaussianBlur(1.2)))
    # floor arrow
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon([(128, 20), (220, 120), (165, 120), (165, 236), (91, 236), (91, 120), (36, 120)], fill=(232, 180, 32, 235))
    wear = (small(band(10, 40, 0)) > 0.62)
    arr = np.array(img).astype(float)
    arr[..., 3] *= np.where(wear, 0.35, 1.0)
    _decal("arrow_floor", Image.fromarray(arr.astype(np.uint8)))
    # EXIT sign
    img = Image.new("RGBA", (S, S // 2), (20, 160, 70, 255))
    d = ImageDraw.Draw(img)
    d.rectangle([4, 4, S - 5, S // 2 - 5], outline=(230, 255, 235, 255), width=4)
    d.text((112, 64), "EXIT", font=ImageFont.truetype(FONT, 62), fill=(240, 255, 240, 255), anchor="mm")
    d.ellipse([28, 22, 46, 40], fill=(240, 255, 240, 255))
    d.line([(37, 42), (32, 74), (20, 100)], fill=(240, 255, 240, 255), width=7)
    d.line([(32, 74), (50, 100)], fill=(240, 255, 240, 255), width=7)
    d.line([(36, 52), (54, 62)], fill=(240, 255, 240, 255), width=6)
    d.line([(36, 52), (20, 64)], fill=(240, 255, 240, 255), width=6)
    _decal("sign_exit", img)
    # danger sign
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rectangle([8, 8, S - 8, S - 8], fill=(232, 180, 32, 255), outline=(20, 20, 20, 255), width=8)
    d.polygon([(128, 40), (210, 190), (46, 190)], fill=(20, 20, 20, 255))
    d.polygon([(128, 70), (186, 175), (70, 175)], fill=(232, 180, 32, 255))
    d.rectangle([120, 100, 136, 145], fill=(20, 20, 20, 255))
    d.ellipse([119, 152, 137, 168], fill=(20, 20, 20, 255))
    d.text((128, 222), "ОПАСНО", font=ImageFont.truetype(FONT, 26), fill=(20, 20, 20, 255), anchor="mm")
    _decal("sign_danger", img)
    # loot poster (portrait 256 x 384 -> stored 256x384)
    W, H = 256, 384
    img = Image.new("RGBA", (W, H), (178, 40, 32, 255))
    d = ImageDraw.Draw(img)
    for i in range(12):
        a = i * math.tau / 12
        d.polygon([(128, 170), (128 + math.cos(a) * 300, 170 + math.sin(a) * 300), (128 + math.cos(a + 0.26) * 300, 170 + math.sin(a + 0.26) * 300)], fill=(200, 60, 40, 255))
    d.ellipse([78, 100, 178, 200], fill=(232, 180, 32, 255))
    d.ellipse([98, 125, 158, 185], fill=(20, 20, 24, 255))
    d.ellipse([113, 140, 143, 170], fill=(240, 244, 255, 255))
    d.ellipse([122, 149, 136, 163], fill=(10, 10, 12, 255))
    d.rectangle([12, 14, W - 12, 80], fill=(20, 20, 24, 255))
    d.text((W / 2, 47), "БОЛЬШЕ ЛУТА", font=ImageFont.truetype(FONT, 30), fill=(232, 180, 32, 255), anchor="mm")
    d.rectangle([12, 290, W - 12, 360], fill=(20, 20, 24, 255))
    d.text((W / 2, 325), "БОЛЬШЕ ЖИЗНИ", font=ImageFont.truetype(FONT, 28), fill=(240, 236, 220, 255), anchor="mm")
    d.text((W / 2, 272), "— ОЦЕНЩИК —", font=ImageFont.truetype(FONT2, 16), fill=(255, 220, 180, 255), anchor="mm")
    arr = np.array(img).astype(float)
    nz = np.array(Image.fromarray((fbm(6, 1.6)[:H, :W] * 255).astype(np.uint8))) / 255.0
    arr[..., :3] *= (0.78 + 0.3 * nz)[..., None]
    tear = (np.array(Image.fromarray((band(8, 30, 0)[:H, :W] * 255).astype(np.uint8))) / 255.0) > 0.78
    edge = np.zeros((H, W), bool)
    edge[:12, :] = True
    edge[-12:, :] = True
    edge[:, :10] = True
    edge[:, -10:] = True
    arr[..., 3] = np.where(edge & tear, 0, 255)
    _decal("poster_loot", Image.fromarray(arr.astype(np.uint8)))
    # safety poster
    img = Image.new("RGBA", (W, H), (230, 226, 210, 255))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, W, 70], fill=(30, 110, 60, 255))
    d.text((W / 2, 36), "ТЕХНИКА", font=ImageFont.truetype(FONT, 28), fill=(255, 255, 255, 255), anchor="mm")
    d.text((W / 2, 92), "БЕЗОПАСНОСТИ", font=ImageFont.truetype(FONT, 24), fill=(30, 110, 60, 255), anchor="mm")
    # pictogram: hooded bot carrying a box
    d.ellipse([88, 120, 148, 180], fill=(232, 180, 32, 255))
    d.ellipse([104, 136, 132, 164], fill=(20, 20, 24, 255))
    d.ellipse([112, 144, 124, 156], fill=(240, 240, 255, 255))
    d.rounded_rectangle([86, 176, 150, 260], 14, fill=(232, 180, 32, 255))
    d.rectangle([140, 196, 200, 246], fill=(150, 100, 60, 255), outline=(60, 40, 20, 255), width=3)
    d.rectangle([92, 258, 110, 300], fill=(30, 30, 34, 255))
    d.rectangle([126, 258, 144, 300], fill=(30, 30, 34, 255))
    d.text((W / 2, 335), "НЕ РОНЯЙ ВАЗЫ", font=ImageFont.truetype(FONT2, 22), fill=(40, 40, 40, 255), anchor="mm")
    d.text((W / 2, 362), "ЭТО ВЫЧТУТ ИЗ КВОТЫ", font=ImageFont.truetype(FONT2, 14), fill=(160, 40, 30, 255), anchor="mm")
    arr = np.array(img).astype(float)
    arr[..., :3] *= (0.8 + 0.25 * nz)[..., None]
    _decal("poster_safety", Image.fromarray(arr.astype(np.uint8)))
    # stencil
    img = Image.new("RGBA", (S, S // 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.text((S / 2, S / 4), "B-07", font=ImageFont.truetype(FONT, 90), fill=(225, 220, 205, 220), anchor="mm")
    arr = np.array(img).astype(float)
    w2 = np.array(Image.fromarray((band(20, 60, 0)[:S // 2, :S] * 255).astype(np.uint8))) / 255.0
    arr[..., 3] *= np.where(w2 > 0.65, 0.3, 1.0)
    _decal("stencil_numbers", Image.fromarray(arr.astype(np.uint8)))


ALL = [wall_metal, wall_block, wall_tiles, wall_plaster, wall_brick, wall_corrugated, floor_concrete, floor_plate, floor_vinyl, floor_carpet,
       floor_wood, floor_grate, ceiling_tiles, ceiling_concrete, hazard, metal, wood_crate, plastic_dark, rust, asphalt, ground, decals]
only = sys.argv[1:]
for f in ALL:
    if not only or f.__name__ in only:
        f()
