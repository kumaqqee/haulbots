"""Tier-1 monsters, art v3. blender -b --python monsters_a.py -- [names]"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *


def gremlin():
    """Little green goblin in torn overalls with a lamp helmet."""
    reset()
    S = "L_skin_6f8a3e"
    OV = "L_fabric_3e4a5a"
    torso = meta("t", [("ell", (0, 0.0, 0.32), 0.14, (1.0, 0.9, 1.15)), ("ell", (0, 0.03, 0.4), 0.11, (1.15, 0.9, 0.7)),
                       ("ell", (0, -0.01, 0.23), 0.12, (1.15, 1.0, 0.75))], S, 0.016)
    overalls = meta("ov", [("ell", (0, 0.0, 0.26), 0.135, (1.1, 1.0, 0.8)), ("cube", (0, 0.1, 0.33), 0.012, (0.06, 0.01, 0.05))], OV, 0.016)
    straps = [skin([(s * 0.05, 0.11, 0.37, 0.012), (s * 0.07, 0.05, 0.45, 0.012), (s * 0.05, -0.08, 0.42, 0.011)], material=OV, subdiv=1) for s in (1, -1)]
    belt = lathe([(0.15, 0.19), (0.158, 0.2), (0.155, 0.225), (0.148, 0.23)], "L_leather_4a3020", 20, cap_bottom=False)
    tools = [box((0.02, 0.02, 0.07), (0.12, 0.09, 0.19), "L_metal_8a8f99", 0.004, rot=(0, 0.3, 0)),
             cyl(0.012, 0.08, (-0.13, 0.07, 0.2), "L_plastic_c0302a", 8, rot=(0, -0.2, 0))]
    patch = box((0.05, 0.01, 0.05), (-0.06, 0.13, 0.24), "L_fabric_7a6a40", 0.004)
    body = part([torso, overalls, belt, patch] + straps + tools, "body", (0, 0, 0.25))
    head = meta("h", [
        ("ell", (0, 0.02, 0.6), 0.14, (1.08, 0.95, 0.9)),
        ("ell", (0, 0.1, 0.64), 0.055, (1.8, 0.7, 0.5)),
        ("cap", (0, 0.17, 0.585), 0.028, (0.03, 1.0, 1.0), (0, 1.1, math.pi / 2)),
        ("ell", (0, 0.07, 0.52), 0.08, (1.5, 1.0, 0.6)),
        {"t": "ell", "co": (0, 0.145, 0.535), "r": 0.05, "s": (1.7, 0.7, 0.5), "neg": True},
    ], S, 0.012)
    displace(head, 0.004, 0.04)
    ears = []
    for s in (1, -1):
        ears.append(meta("ear", [("ell", (0.15 * s, -0.01, 0.63), 0.035, (2.4, 0.35, 1.0), (0, 0, 0.25 * s)),
                                 ("ell", (0.2 * s, -0.02, 0.655), 0.025, (2.2, 0.3, 0.75), (0, 0, 0.35 * s))], S, 0.008))
    eyes = []
    for x in (-0.05, 0.05):
        eyes += glow_eye((x, 0.13, 0.605), 0.022, "ffd030", "C_150a05")
    mouth_in = sphere(0.045, (0, 0.13, 0.535), "C_2a0606", 10, 5, (1.5, 0.5, 0.45))
    teeth = teeth_row(0, 0.168, 0.555, 0.085, 6, 0.02, r=0.007, curve=0.012) + teeth_row(0, 0.162, 0.515, 0.065, 5, 0.016, r=0.006, down=False, curve=0.01)
    helmet = lathe([(0.0, 0.735), (0.08, 0.73), (0.125, 0.7), (0.15, 0.66), (0.17, 0.652), (0.172, 0.643), (0.135, 0.645), (0.12, 0.665), (0.0, 0.667)], "L_plastic_e8b420", 24)
    lamp = cyl(0.026, 0.035, (0, 0.135, 0.71), "L_metal_2a2d33", 12, rot=(math.pi / 2 - 0.3, 0, 0))
    lens = cyl(0.02, 0.005, (0, 0.152, 0.716), "E_fff0b0", 12, rot=(math.pi / 2 - 0.3, 0, 0))
    dent = sphere(0.02, (0.08, 0.05, 0.73), "L_plastic_a07a10", 6, 3, (1, 1, 0.4))
    head = part([head, mouth_in, helmet, lamp, lens, dent] + ears + eyes + teeth, "head", (0, 0, 0.46))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.13 * s
        a = skin([(x, 0, 0.42, 0.034), (x + 0.05 * s, 0.02, 0.31, 0.026), (x + 0.06 * s, 0.05, 0.2, 0.022)], material=S, subdiv=1)
        arms.append(part([a] + claw_hand(x + 0.06 * s, 0.07, 0.175, S, s, 3, 0.055, 0.011), nm, (x, 0, 0.42)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.07 * s
        l = skin([(x, 0, 0.22, 0.045), (x, 0.01, 0.12, 0.034), (x, 0.0, 0.05, 0.03)], material=OV, subdiv=1)
        foot = meta("foot", [("ell", (x, 0.04, 0.025), 0.045, (0.95, 1.7, 0.55)), ("ball", (x, 0.11, 0.025), 0.03)], S, 0.012)
        toes = [cyl(0.006, 0.02, (x + dx, 0.15, 0.02), "L_bone_d8cfb0", 5, r2=0.0, rot=(-1.6, 0, 0), smooth=False) for dx in (-0.02, 0, 0.02)]
        legs.append(part([l, foot] + toes, nm, (x, 0, 0.22)))
    save("gremlin", [body, head] + arms + legs, tex=256, tris=3500)


def bomber():
    """Riveted iron bomb critter with a hazard band and one angry eye."""
    reset()
    iron = "L_metal_33363d"
    shell = meta("shell", [("ball", (0, 0, 0.32), 0.22), ("ell", (0, 0.02, 0.28), 0.17, (1.1, 1.0, 0.8))], iron, 0.02)
    br = ring_radius(shell, 0.17)
    band = lathe([(br - 0.004, 0.14), (br + 0.008, 0.15), (br + 0.008, 0.2), (br - 0.004, 0.21)], "L_paint_e8b420", 32, cap_bottom=False)
    stripes = []
    for i in range(10):
        a = i * math.tau / 10
        b = box((0.035, 0.012, 0.075), (math.cos(a) * (br + 0.01), math.sin(a) * (br + 0.01), 0.175), "L_paint_15151a", 0.0)
        b.rotation_euler = (0, 0.6, a + math.pi / 2)
        stripes.append(b)
    rivets = []
    for z, rr in ((0.45, 0.17), (0.24, 0.2)):
        for i in range(10):
            a = i * math.tau / 10 + 0.3
            rivets.append(sphere(0.012, (math.cos(a) * rr, math.sin(a) * rr, z), "L_metal_6a6e78", 6, 3))
    snap_objs(rivets, shell, 0.4)
    # one big angry eye under a heavy iron brow + a zigzag grin
    eye_sock = sphere(0.075, (0, 0.17, 0.37), "C_0a0606", 14, 7, (1.2, 0.5, 0.8))
    eye_glow = sphere(0.05, (0, 0.2, 0.37), "E_ff3a1a", 12, 6, (1.3, 0.4, 0.55))
    pupil = box((0.012, 0.01, 0.05), (0, 0.222, 0.37), "C_1a0000", 0.0)
    brow = [box((0.1, 0.04, 0.028), (s * 0.045, 0.175, 0.43), iron, 0.01, rot=(0.0, -0.35 * s, 0)) for s in (1, -1)]
    snap_objs(brow, shell, 0.5)
    snap_objs([eye_sock], shell, 0.25)
    snap_objs([eye_glow, pupil], shell, -0.1)
    grin = sphere(0.085, (0, 0.18, 0.28), "C_120606", 12, 6, (1.4, 0.4, 0.38))
    gl = sphere(0.055, (0, 0.2, 0.28), "E_ff7a20", 10, 5, (1.6, 0.3, 0.2))
    teeth = teeth_row(0, 0.2, 0.305, 0.14, 6, 0.026, "L_metal_9a9ea8", r=0.012) + teeth_row(0, 0.2, 0.255, 0.12, 5, 0.022, "L_metal_9a9ea8", r=0.011, down=False)
    snap_objs([grin], shell, 0.2)
    snap_objs([gl], shell, 0.0)
    top_z = max((shell.matrix_world @ v.co).z for v in shell.data.vertices)
    cap = cyl(0.055, 0.07, (0, 0, top_z + 0.015), "L_metal_1e2026", 14, bevel=0.006)
    capr = cyl(0.062, 0.015, (0, 0, top_z - 0.01), "L_metal_6a6e78", 14)
    body = part([shell, band, eye_sock, eye_glow, pupil, grin, gl, cap, capr] + brow + stripes + rivets + teeth, "body", (0, 0, 0.3))
    fz = top_z + 0.05
    fuse = part([skin([(0, 0, fz, 0.011), (0.025, 0.01, fz + 0.06, 0.01), (0.005, 0.03, fz + 0.11, 0.009)], material="L_fabric_a88a5a", subdiv=1),
                 sphere(0.022, (0.005, 0.03, fz + 0.125), "E_ffd040", 8, 4), sphere(0.036, (0.005, 0.03, fz + 0.125), "G_ff7020", 8, 4)]
                + [cyl(0.004, 0.04, (0.005 + math.cos(a) * 0.03, 0.03 + math.sin(a) * 0.03, fz + 0.13), "E_ffb030", 4, r2=0.0, rot=(math.cos(a) * 1.2, -math.sin(a) * 1.2, 0)) for a in (0.3, 2.2, 4.2)],
                "fuse", (0, 0, fz))
    legs = []
    for x in (0.11, -0.11):
        l = skin([(x, 0, 0.2, 0.036), (x * 1.1, 0.01, 0.12, 0.033), (x * 1.15, 0.03, 0.06, 0.028)], material="L_metal_2a2d33", subdiv=1)
        boot = meta("boot", [("ell", (x * 1.15, 0.055, 0.032), 0.045, (1.0, 1.65, 0.62)), ("cube", (x * 1.15, 0.05, 0.012), 0.01, (0.035, 0.07, 0.008))], "L_rubber_1c1d22", 0.012)
        legs.append(part([l, boot], "leg_" + ("r" if x > 0 else "l"), (x, 0, 0.18)))
    save("bomber", [body, fuse] + legs, tex=256, tris=3000, split=False)


def eye():
    """Floating veiny eyeball: an optic nerve rises to a small knot, wet tendrils dangle below."""
    reset()
    F = "L_skin_6a2a34"
    knot = meta("knot", [("ell", (0, -0.16, -0.46), 0.1, (1.1, 0.8, 1.0)), ("ball", (0.04, -0.2, -0.52), 0.06), ("ball", (-0.05, -0.19, -0.4), 0.05)], F, 0.016)
    displace(knot, 0.008, 0.04)
    nerve = None
    tend = []
    rnd = random.Random(7)
    for i in range(8):
        a = i * math.tau / 8 + rnd.uniform(-0.25, 0.25)
        r0 = 0.13
        m = F if i % 3 else "L_rubber_2a2c33"
        z0 = -0.58
        tend.append(skin([(math.cos(a) * r0, math.sin(a) * r0 - 0.02, z0, 0.03),
                          (math.cos(a) * (r0 + 0.04), math.sin(a) * (r0 + 0.04), z0 - 0.12, 0.02),
                          (math.cos(a) * (r0 + 0.01), math.sin(a) * (r0 + 0.06), z0 - 0.22, 0.012),
                          (math.cos(a) * (r0 + 0.05), math.sin(a) * (r0 + 0.03), z0 - 0.32 - rnd.uniform(0, 0.08), 0.004)], material=m, subdiv=1))
    plugs = [cyl(0.012, 0.03, (math.cos(a) * 0.18, math.sin(a) * 0.16 - 0.02, -0.88), "L_metal_8a8f99", 6) for a in (0.9, 3.3)]
    body = part([knot] + tend + plugs, "body", (0, 0, 0.0))
    C = -0.42
    ball = meta("ball", [("ball", (0, 0, C), 0.21)], "L_ceramic_e8dccb", 0.018)
    veins = []
    for i in range(12):
        a = i * math.tau / 12
        pts = []
        for k in range(5):
            th = 1.3 - k * 0.2
            ph = a + 0.22 * math.sin(k * 1.7 + i)
            d = (math.sin(th) * math.cos(ph), math.cos(th), math.sin(th) * math.sin(ph))
            pts.append((d[0] * 0.212, d[1] * 0.212, C + d[2] * 0.212, 0.007 - k * 0.0012))
        veins.append(snap_verts(skin(pts, material="C_a01820", subdiv=0), ball, 0.001))
    ring = sphere(0.115, (0, 0.152, C), "C_5a1a06", 20, 10, (1, 0.45, 1))
    iris = sphere(0.1, (0, 0.165, C), "E_ff8a1a", 20, 10, (1, 0.45, 1))
    pupil = sphere(0.045, (0, 0.2, C), "C_020202", 12, 6, (0.5, 0.25, 1.25))
    glint = sphere(0.016, (0.04, 0.205, C + 0.05), "E_ffffff", 6, 3)
    lids = meta("lids", [("ell", (0, -0.03, C + 0.15), 0.19, (1.1, 1.0, 0.36)), ("ell", (0, -0.03, C - 0.16), 0.17, (1.08, 0.98, 0.28))], F, 0.016)
    head = part([ball, ring, iris, pupil, glint, lids] + veins, "head", (0, 0, C))
    save("eye", [body, head], tex=256, tris=3200, split=False)


def tick():
    """Bloated tick: glossy dark carapace, glowing red spots, eight legs."""
    reset()
    C = "L_leather_3a1a22"
    abdomen = meta("abd", [("ell", (0, -0.035, 0.075), 0.072, (1.0, 1.3, 0.78)), ("ell", (0, 0.03, 0.07), 0.045, (1.1, 0.9, 0.7))], "L_skin_5a2832", 0.006)
    displace(abdomen, 0.002, 0.02)
    shield = meta("shield", [("ell", (0, 0.035, 0.088), 0.042, (1.15, 1.0, 0.42))], C, 0.006)
    head = sphere(0.022, (0, 0.085, 0.07), "L_leather_1a0e0a", 10, 5, (1.1, 1.2, 0.8))
    mand = [cyl(0.005, 0.032, (x, 0.11, 0.064), "L_bone_4a3a2a", 5, r2=0.0, rot=(-1.4, 0, 0.35 * (1 if x > 0 else -1))) for x in (-0.011, 0.011)]
    eyes = [sphere(0.007, (x, 0.1, 0.084), "E_ff2a10", 6, 3) for x in (-0.013, 0.013)]
    spots = []
    for x, y in ((-0.03, -0.05), (0.03, -0.05), (0.0, -0.09), (-0.025, -0.01), (0.025, -0.01)):
        spots.append(sphere(0.009, (x, y, 0.13), "E_ff3020", 6, 3, (1, 1, 0.5)))
    snap_objs(spots, abdomen, 0.4)
    body = part([abdomen, shield, head] + mand + eyes + spots, "body", (0, 0, 0.06))
    legs = []
    for i in range(8):
        side = 1 if i < 4 else -1
        y = 0.06 - (i % 4) * 0.035
        legs.append(part([skin([(side * 0.035, y, 0.07, 0.006), (side * 0.068, y + 0.008, 0.095, 0.005), (side * 0.1, y + 0.015, 0.0, 0.0025)], material="L_leather_2a1612", subdiv=1)],
                         "leg%d" % i, (side * 0.035, y, 0.07)))
    save("tick", [body] + legs, tex=128, tris=2000, split=False)


def spewer():
    """Carnivorous flower pod on root legs: the toothed upper petal is the jaw."""
    reset()
    G = "L_skin_4a6a2a"
    PET = "L_skin_a8302a"
    bulb = meta("bulb", [("ell", (0, 0.0, 0.25), 0.19, (1.15, 1.05, 0.85)), ("ell", (0, 0.04, 0.2), 0.15, (1.2, 1.0, 0.6)),
                         {"t": "ell", "co": (0, 0.2, 0.25), "r": 0.13, "s": (1.25, 0.9, 0.55), "neg": True}], G, 0.018)
    displace(bulb, 0.01, 0.06)
    throat = sphere(0.1, (0, 0.13, 0.24), "E_c8ff40", 14, 7, (1.2, 0.5, 0.5))
    lower_teeth = teeth_row(0, 0.2, 0.18, 0.22, 8, 0.035, "L_bone_e8dcc0", r=0.011, down=False, curve=0.035)
    leaves = []
    for s in (1, -1):
        lf = meta("leaf", [("ell", (0.2 * s, 0.02, 0.17), 0.06, (2.2, 1.0, 0.3), (0, -0.4 * s, 0.3 * s)),
                           ("ell", (0.28 * s, 0.05, 0.13), 0.04, (1.8, 0.9, 0.25), (0, -0.5 * s, 0.4 * s))], "L_skin_3a5a22", 0.012)
        leaves.append(lf)
    petals = []
    for i in range(6):
        a = math.pi * 1.15 + i * (math.pi * 0.7 / 5) + math.pi * 0.0
        petals.append(meta("p", [("ell", (math.cos(a) * 0.17, math.sin(a) * 0.17 - 0.02, 0.3), 0.07, (1.3, 0.6, 0.35), (0.4, 0, a + math.pi / 2))], PET, 0.012))
    drips = [skin([(x, 0.18, 0.17, 0.011), (x + 0.005, 0.2, 0.09, 0.008), (x, 0.2, 0.04, 0.004)], material="G_c8ff40", subdiv=1) for x in (-0.07, 0.06)]
    stem = skin([(0, -0.02, 0.18, 0.06), (0, -0.01, 0.1, 0.05)], material=G, subdiv=1)
    body = part([bulb, throat, stem] + lower_teeth + leaves + petals + drips, "body", (0, 0, 0.2))
    # jaw: the big toothed upper petal (hinged at the back of the bulb)
    lid = meta("lid", [("ell", (0, 0.07, 0.33), 0.17, (1.2, 1.05, 0.42)), {"t": "ell", "co": (0, 0.1, 0.29), "r": 0.14, "s": (1.15, 0.95, 0.35), "neg": True},
                       ("ell", (0, 0.12, 0.38), 0.07, (1.4, 1.0, 0.4))], PET, 0.014)
    spots = [sphere(0.018, (x, y, 0.4), "L_skin_e8c040", 6, 3, (1, 1, 0.4)) for x, y in ((-0.07, 0.04), (0.06, 0.1), (0.0, -0.02), (0.1, 0.0))]
    snap_objs(spots, lid, 0.3)
    up_teeth = teeth_row(0, 0.21, 0.31, 0.24, 9, 0.04, "L_bone_e8dcc0", r=0.012, curve=0.04)
    rim_eyes = []
    for x in (-0.07, 0.07):
        rim_eyes += glow_eye((x, 0.2, 0.39), 0.02, "f0ff60", "C_100a04")
    jaw = part([lid] + spots + up_teeth + rim_eyes, "jaw", (0, -0.04, 0.3))
    legs = []
    for x in (0.1, -0.1):
        roots = [skin([(x, 0.0, 0.11, 0.045), (x * 1.5, 0.05, 0.05, 0.033), (x * 1.8 + dx, 0.12 + dy, 0.01, 0.012)], material="L_wood_4a3a22", subdiv=1)
                 for dx, dy in ((0.0, 0.0), (0.03 * (1 if x > 0 else -1), -0.08), (-0.03 * (1 if x > 0 else -1), 0.03))]
        legs.append(part(roots, "leg_" + ("r" if x > 0 else "l"), (x, 0.0, 0.11)))
    save("spewer", [body, jaw] + legs, tex=256, tris=3500, split=False)


def rugrat():
    """Round matted rat-beast that throws junk: orange eyes, buck teeth, scaly tail."""
    reset()
    FUR = "L_fur_5e4a3a"
    SK = "L_skin_b07a6a"
    torso = meta("t", [("ell", (0, 0, 0.55), 0.38, (1.0, 0.95, 0.95)), ("ell", (0, 0.06, 0.42), 0.3, (1.1, 1.0, 0.7)),
                       ("ell", (0, -0.08, 0.68), 0.28, (1.05, 1.0, 0.8))], FUR, 0.03)
    displace(torso, 0.025, 0.06, depth=3)
    belly = meta("b", [("ell", (0, 0.22, 0.5), 0.22, (1.1, 0.6, 1.1))], "L_fur_8a7a62", 0.025)
    tufts = spikes((0, -0.02, 0.7), 22, 0.33, 0.07, FUR, 0.03, seed=3, up_only=True)
    tail = skin([(0, -0.34, 0.3, 0.06), (0.05, -0.6, 0.18, 0.045), (0.2, -0.82, 0.1, 0.03), (0.35, -0.92, 0.12, 0.012)], material=SK, subdiv=2)
    rings = [cyl(0.05 - i * 0.008, 0.012, (0.03 + i * 0.07, -0.5 - i * 0.12, 0.22 - i * 0.03), "L_skin_8a5a4a", 10, rot=(1.2, 0, 0.3)) for i in range(3)]
    scar = box((0.12, 0.01, 0.015), (-0.12, 0.3, 0.62), "L_skin_c08a7a", 0.004, rot=(0, 0.5, 0))
    body = part([torso, belly, tail, scar] + tufts + rings, "body", (0, 0, 0.35))
    head = meta("h", [("ell", (0, 0.15, 0.92), 0.2, (1.0, 1.1, 0.85)), ("ell", (0, 0.32, 0.88), 0.1, (0.9, 1.3, 0.75)),
                      ("ball", (0, 0.42, 0.88), 0.045)], FUR, 0.02)
    displace(head, 0.01, 0.05)
    nose = sphere(0.035, (0, 0.47, 0.9), "L_skin_c86a6a", 10, 5, (1.2, 0.8, 0.8))
    ears = []
    for s in (1, -1):
        ears.append(meta("ear", [("ell", (0.16 * s, 0.05, 1.07), 0.08, (1.0, 0.3, 1.1), (0.2, 0, 0.4 * s))], SK, 0.012))
        ears.append(meta("eari", [("ell", (0.165 * s, 0.075, 1.06), 0.055, (0.9, 0.2, 1.0), (0.2, 0, 0.4 * s))], "L_skin_d08a8a", 0.012))
    eyes = []
    for x in (-0.09, 0.09):
        eyes += glow_eye((x, 0.33, 0.97), 0.034, "ffa030", "C_0a0604")
    teeth = [box((0.035, 0.02, 0.07), (x, 0.43, 0.82), "L_bone_e8d8a8", 0.008) for x in (-0.02, 0.02)]
    whiskers = [cyl(0.003, 0.18, (s * 0.1, 0.44, 0.88 + dz), "L_bone_d8d0c0", 4, rot=(0, math.pi / 2 + s * 0.2, dz * 3), smooth=False) for s in (1, -1) for dz in (-0.02, 0.02)]
    head = part([head, nose] + ears + eyes + teeth + whiskers, "head", (0, 0.1, 0.8))
    arms, legs = [], []
    for s, nm in ((1, "arm_r"), (-1, "arm_l")):
        x = 0.3 * s
        a = skin([(x, 0.05, 0.7, 0.07), (x + 0.07 * s, 0.14, 0.52, 0.06), (x + 0.06 * s, 0.24, 0.4, 0.05)], material=FUR, subdiv=1)
        arms.append(part([a] + claw_hand(x + 0.06 * s, 0.27, 0.36, SK, s, 4, 0.07, 0.014), nm, (x, 0.05, 0.7)))
    for s, nm in ((1, "leg_r"), (-1, "leg_l")):
        x = 0.18 * s
        l = skin([(x, 0, 0.32, 0.1), (x, 0.03, 0.16, 0.075), (x, 0.06, 0.05, 0.05)], material=FUR, subdiv=1)
        foot = meta("f", [("ell", (x, 0.12, 0.035), 0.07, (0.9, 1.6, 0.5))], SK, 0.015)
        claws = [cyl(0.008, 0.035, (x + dx, 0.22, 0.03), "L_bone_d8cfb0", 5, r2=0.0, rot=(-1.6, 0, 0), smooth=False) for dx in (-0.03, 0, 0.03)]
        legs.append(part([l, foot] + claws, nm, (x, 0, 0.32)))
    save("rugrat", [body, head] + arms + legs, tex=512, tris=5000)


def skitter():
    """Spider-ball: armoured ball that is mostly one huge toothy mouth, eye cluster, six spindly legs."""
    reset()
    SH = "L_leather_4a2a22"
    ball = meta("ball", [("ball", (0, 0, 0.36), 0.2), ("ell", (0, -0.04, 0.38), 0.19, (1.0, 1.1, 0.95)),
                         {"t": "ell", "co": (0, 0.19, 0.32), "r": 0.15, "s": (1.15, 0.7, 0.62), "neg": True, "stiff": 3.0}], SH, 0.018)
    displace(ball, 0.008, 0.05)
    plates = spikes((0, -0.06, 0.4), 14, 0.17, 0.07, "L_bone_6a5a48", 0.016, seed=5, up_only=True)
    mouth = sphere(0.15, (0, 0.12, 0.32), "C_1a0404", 16, 8, (1.1, 0.55, 0.62))
    gum = sphere(0.135, (0, 0.11, 0.32), "L_skin_8a2a2a", 16, 8, (1.12, 0.62, 0.66))
    glow = sphere(0.07, (0, 0.13, 0.31), "E_ff5a20", 10, 5, (1.4, 0.4, 0.6))
    teeth = []
    for k in range(14):
        a = k * math.tau / 14
        x, z = math.cos(a) * 0.15, 0.32 + math.sin(a) * 0.085
        t = cyl(0.014, 0.05, (x, 0.2, z), "L_bone_e8dcc0", 5, r2=0.0, smooth=False)
        t.rotation_euler = (0, a + math.pi / 2, 0)
        teeth.append(t)
    eyes = []
    for (x, z, r) in ((-0.06, 0.47, 0.03), (0.06, 0.47, 0.03), (-0.12, 0.43, 0.02), (0.12, 0.43, 0.02), (0.0, 0.5, 0.02), (-0.03, 0.43, 0.015), (0.03, 0.43, 0.015)):
        eyes += glow_eye((x, 0.17, z), r, "ff2a14", "C_080404")
    snap_objs(eyes, ball, 0.5)
    body = part([ball, gum, mouth, glow] + plates + teeth + eyes, "body", (0, 0, 0.3))
    legs = []
    for i in range(6):
        side = 1 if i < 3 else -1
        y = 0.1 - (i % 3) * 0.12
        x = 0.14 * side
        pts = [(x, y, 0.36, 0.028), (x + 0.2 * side, y + 0.03, 0.52, 0.022), (x + 0.36 * side, y + 0.05, 0.16, 0.016), (x + 0.41 * side, y + 0.06, 0.0, 0.006)]
        knee = sphere(0.026, (x + 0.2 * side, y + 0.03, 0.52), "L_leather_2a1612", 8, 4)
        legs.append(part([skin(pts, material=SH, subdiv=1), knee], "leg%d" % i, (x, y, 0.36)))
    save("skitter", [body] + legs, tex=256, tris=3500, split=False)


run([gremlin, bomber, eye, tick, spewer, rugrat, skitter])
