"""Print the AABB (Godot axes: x, y, z) of GLB models. Usage: python3 tools/glb_aabb.py name..."""
import json, struct, sys, numpy as np

def mat(n):
    if 'matrix' in n: return np.array(n['matrix']).reshape(4, 4).T
    t = np.eye(4); s = np.eye(4); r = np.eye(4)
    if 'translation' in n: t[:3, 3] = n['translation']
    if 'scale' in n: s[0, 0], s[1, 1], s[2, 2] = n['scale']
    if 'rotation' in n:
        x, y, z, w = n['rotation']
        r[:3, :3] = [[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]]
    return t @ r @ s

def aabb(path):
    d = open(path, 'rb').read(); n = struct.unpack('<I', d[12:16])[0]; j = json.loads(d[20:20+n])
    lo = np.full(3, 1e9); hi = np.full(3, -1e9)
    def walk(i, m):
        nonlocal lo, hi
        nd = j['nodes'][i]; m = m @ mat(nd)
        if 'mesh' in nd:
            for p in j['meshes'][nd['mesh']]['primitives']:
                a = j['accessors'][p['attributes']['POSITION']]
                mn, mx = np.array(a['min']), np.array(a['max'])
                for c in range(8):
                    v = np.array([mx[0] if c & 1 else mn[0], mx[1] if c & 2 else mn[1], mx[2] if c & 4 else mn[2], 1.0])
                    w = (m @ v)[:3]; lo = np.minimum(lo, w); hi = np.maximum(hi, w)
        for ch in nd.get('children', []): walk(ch, m)
    for r in j['scenes'][j.get('scene', 0)]['nodes']: walk(r, np.eye(4))
    return lo, hi

if __name__ == '__main__':
    for nm in sys.argv[1:]:
        lo, hi = aabb('assets/models/%s.glb' % nm)
        print(nm, 'size', np.round(hi - lo, 3), 'min', np.round(lo, 3), 'max', np.round(hi, 3))
