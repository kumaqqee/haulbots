#!/bin/bash
# 4-player network playthrough on localhost: host + 3 clients, logs in /tmp/mp4_*.log
# Usage: tools/mp4.sh [levels] [timeout_s]
cd "$(dirname "$0")/.."
LV=${1:-6}
pkill -x godot 2>/dev/null
sleep 1
for r in 0 1 2 3; do
  HB_DMGLOG=1 HB_ROLE=$r HB_LEVELS=$LV timeout ${2:-3000} godot --headless --path . -- --autotest=mp4 > /tmp/mp4_$r.log 2>&1 &
  sleep 0.5
done
wait
for r in 0 1 2 3; do echo "== role $r: $(grep -E '\[MP[0-9]\] (ALL PASSED|FAILURES)' /tmp/mp4_$r.log)  script errors: $(grep -c 'SCRIPT ERROR' /tmp/mp4_$r.log)"; done
