"""Post-process an exported APK:
 * shrink the launcher icons (Godot writes full-colour PNGs for every density),
 * recompress every deflated entry with a stronger deflate (advzip: 7-zip / zopfli) — entries that
   were stored (resources.arsc, ...) stay stored, so the APK stays installable on Android 11+,
 * zipalign + re-sign.
Usage: python3 tools/postbuild.py <in.apk> <out.apk> [keystore] [alias] [pass] [--fast]"""
import sys, os, io, zipfile, subprocess, shutil, tempfile, struct, zlib
from PIL import Image

args = [a for a in sys.argv[1:] if not a.startswith("--")]
fast = "--fast" in sys.argv
src, dst = args[0], args[1]
ks = args[2] if len(args) > 2 else "/opt/keys/release.keystore"
alias = args[3] if len(args) > 3 else "haulbots"
pw = args[4] if len(args) > 4 else os.environ.get("KS_PASS", "")
ROOT = os.path.join(os.path.dirname(__file__), "..")
SOURCES = {
    "icon.png": os.path.join(ROOT, "icon_192.png"),
    "icon_foreground.png": os.path.join(ROOT, "icon_fg.png"),
}


def small_png(path_src, size, colors):
    im = Image.open(path_src).convert("RGB").resize((size, size), Image.LANCZOS)
    q = im.quantize(colors=colors, method=Image.MEDIANCUT, dither=Image.FLOYDSTEINBERG)
    b = io.BytesIO()
    q.save(b, "PNG", optimize=True)
    return b.getvalue()


def raw_entries(path):
    """[(ZipInfo, raw_compressed_bytes)] straight from the file (no recompression)."""
    out = []
    with open(path, "rb") as f, zipfile.ZipFile(path) as z:
        for info in z.infolist():
            f.seek(info.header_offset)
            h = f.read(30)
            nlen, xlen = struct.unpack("<HH", h[26:30])
            f.seek(info.header_offset + 30 + nlen + xlen)
            out.append((info, f.read(info.compress_size)))
    return out


tmp = tempfile.mkdtemp()
saved_icons = 0
entries = []   # (name, method, crc, usize, raw, date_time, ext_attr)
to_pack = {}   # name -> data (deflated entries to recompress strongly)
with zipfile.ZipFile(src) as zi:
    for info in zi.infolist():
        n = info.filename
        if n.startswith("META-INF/"):
            continue   # old signature
        base = os.path.basename(n)
        if n.startswith("res/mipmap") and base in SOURCES:
            data = zi.read(n)
            w = Image.open(io.BytesIO(data)).size[0]
            new = small_png(SOURCES[base], w, 128 if w > 200 else 96)
            if len(new) < len(data):
                saved_icons += len(data) - len(new)
                data = new
            entries.append([n, 0, zlib.crc32(data), len(data), data, info.date_time, info.external_attr])
        elif info.compress_type == zipfile.ZIP_DEFLATED:
            to_pack[n] = zi.read(n)
            entries.append([n, 8, None, None, None, info.date_time, info.external_attr])
        else:
            data = zi.read(n)
            entries.append([n, 0, zlib.crc32(data), len(data), data, info.date_time, info.external_attr])

# strong deflate of everything that was deflated
packz = os.path.join(tmp, "pack.zip")
with zipfile.ZipFile(packz, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zp:
    for n, d in to_pack.items():
        zp.writestr(n, d)
subprocess.check_call(["advzip", "-z", "-3" if fast else "-4", "-i", "5", packz], stdout=subprocess.DEVNULL)
strong = {i.filename: (i, raw) for i, raw in raw_entries(packz)}
before = sum(i.compress_size for i in zipfile.ZipFile(src).infolist())
for e in entries:
    if e[1] == 8:
        i, raw = strong[e[0]]
        if i.compress_type == 8:
            e[2], e[3], e[4] = i.CRC, i.file_size, raw
        else:   # advzip decided to store it
            e[1], e[2], e[3], e[4] = 0, i.CRC, i.file_size, raw


def dos(dt):
    y, mo, d, h, mi, s = dt
    return ((max(y, 1980) - 1980) << 9 | mo << 5 | d), (h << 11 | mi << 5 | s // 2)


unsigned = os.path.join(tmp, "u.apk")
with open(unsigned, "wb") as f:
    cd = b""
    for n, method, crc, usize, raw, dt, ext in entries:
        nb = n.encode("utf-8")
        ddate, dtime = dos(dt)
        off = f.tell()
        f.write(struct.pack("<IHHHHHIIIHH", 0x04034b50, 20, 0x800, method, dtime, ddate, crc & 0xffffffff, len(raw), usize, len(nb), 0))
        f.write(nb)
        f.write(raw)
        cd += struct.pack("<IHHHHHHIIIHHHHHII", 0x02014b50, 20, 20, 0x800, method, dtime, ddate, crc & 0xffffffff, len(raw), usize, len(nb), 0, 0, 0, 0, ext, off) + nb
    cdo = f.tell()
    f.write(cd)
    f.write(struct.pack("<IHHHHIIH", 0x06054b50, 0, 0, len(entries), len(entries), len(cd), cdo, 0))

aligned = os.path.join(tmp, "a.apk")
subprocess.check_call(["zipalign", "-f", "-p", "4", unsigned, aligned])
subprocess.check_call(["apksigner", "sign", "--ks", ks, "--ks-key-alias", alias, "--ks-pass", "pass:" + pw,
                       "--key-pass", "pass:" + pw, "--out", dst, aligned])
subprocess.check_call(["zipalign", "-c", "-p", "4", dst])
shutil.rmtree(tmp)
after = sum(i.compress_size for i in zipfile.ZipFile(dst).infolist())
print("icons saved %d bytes, strong deflate saved %d bytes -> %s (%d bytes)" % (saved_icons, before - after - saved_icons, dst, os.path.getsize(dst)))
