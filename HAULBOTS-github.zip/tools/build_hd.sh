#!/bin/bash
# Builds the optional HD content pack(s) for art 3.0: 1024 px PBR surfaces and full-size model
# atlases (512 px; the APK keeps them at 224-256), both in Basis Universal, and the full-poly
# versions of the heaviest models (hd_src/models; the APK ships tools/art3/slim.py copies).
# Usage: tools/build_hd.sh <version> <out_dir> [work_dir]
set -e
VER=${1:-3.0}
OUT=$(realpath -m ${2:-build})
ROOT=$(cd "$(dirname "$0")/.." && pwd)
WORK=$(realpath -m ${3:-/tmp/haulbots_hd})
HDP=$WORK/proj
TEX=$WORK/tex1024
mkdir -p "$OUT" "$WORK"

echo "== project copy"
rm -rf "$HDP"
mkdir -p "$HDP"
( cd "$ROOT" && tar cf - --exclude=./build --exclude=./hd_src . ) | ( cd "$HDP" && tar xf - )

echo "== full-poly models (the APK has lighter copies)"
cp "$ROOT"/hd_src/models/*.glb "$HDP/assets/models/"
echo "== full-size model atlases (the project keeps 256 px copies)"
cp "$ROOT"/hd_src/mtex/*.png "$HDP/assets/mtex/"

echo "== 1024 surfaces"
if [ ! -f "$TEX/floor_concrete.png" ]; then
  TEX_N=1024 TEX_OUT="$TEX" python3 "$ROOT/tools/art3/textures.py" wall_metal wall_block wall_tiles wall_plaster wall_brick \
    wall_corrugated floor_concrete floor_plate floor_vinyl floor_carpet floor_wood floor_grate ceiling_tiles ceiling_concrete \
    hazard metal wood_crate plastic_dark rust asphalt ground
fi
cp "$TEX"/*.png "$HDP/assets/tex/"

LIST=$WORK/list.txt
: > "$LIST"
set_basis() {  # file limit
  local f=$1.import
  sed -i 's/^compress\/mode=.*/compress\/mode=4/; s/^compress\/rdo_quality_loss=.*/compress\/rdo_quality_loss=1.6/; s/^compress\/normal_map=.*/compress\/normal_map=0/; s/^mipmaps\/generate=.*/mipmaps\/generate=true/; s/^process\/size_limit=.*/process\/size_limit='"$2"'/' "$f"
  grep -q '^compress/rdo_quality_loss' "$f" || sed -i 's/^compress\/mode=4/compress\/mode=4\ncompress\/rdo_quality_loss=1.6\ncompress\/uastc_level=1/' "$f"
  echo "res://${1#$HDP/}" >> "$LIST"
}
for p in "$TEX"/*.png; do
  n=$(basename "$p")
  case $n in
    *_r.png) set_basis "$HDP/assets/tex/$n" 512 ;;
    *) set_basis "$HDP/assets/tex/$n" 0 ;;
  esac
done
for p in "$HDP"/assets/mtex/*.png; do
  case $p in *_orm.png) continue ;; esac
  set_basis "$p" 0
done

for p in "$ROOT"/hd_src/models/*.glb; do
  echo "res://assets/models/$(basename "$p")" >> "$LIST"
done

echo "== import ($(wc -l < "$LIST") resources)"
godot --headless --path "$HDP" --import > "$WORK/import.log" 2>&1 || true
grep -E "ERROR" "$WORK/import.log" | grep -v ALSA | head -5 || true

echo "== pack"
rm -f "$OUT"/HAULBOTS-HD-"$VER"-*.pck
godot --headless --path "$HDP" -s res://tools/pack_hd.gd -- "$OUT" "$VER" "$LIST" 2>&1 | grep -E "HD\]|ERROR" | grep -v ALSA
ls -l "$OUT"/HAULBOTS-HD-"$VER"-*.pck
