#!/bin/bash
# 4-player playthrough over the internet relay (server/relay.js on localhost, optional fake lag).
# Usage: tools/mp4relay.sh [levels] [timeout_s] [lag_ms]
cd "$(dirname "$0")/.."
LV=${1:-6}
pkill -x godot 2>/dev/null
pkill -x node 2>/dev/null
sleep 1
(cd server && RELAY_DELAY_MS=${3:-0} PORT=8089 node relay.js > /tmp/relay_test.log 2>&1 &)
sleep 1
for r in 0 1 2 3; do
  HB_RELAY=ws://127.0.0.1:8089 HB_ROLE=$r HB_LEVELS=$LV $HB_EXTRA timeout ${2:-3000} godot --headless --path . -- --autotest=mp4 > /tmp/mp4_$r.log 2>&1 &
  sleep 0.5
done
wait $(jobs -p) 2>/dev/null
sleep 1
pkill -x node 2>/dev/null
for r in 0 1 2 3; do echo "== role $r: $(grep -E '\[MP[0-9]\] (ALL PASSED|FAILURES)' /tmp/mp4_$r.log)  script errors: $(grep -c 'SCRIPT ERROR' /tmp/mp4_$r.log)"; done
